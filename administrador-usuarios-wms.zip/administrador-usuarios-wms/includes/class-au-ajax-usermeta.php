<?php
/**
 * Controlador AJAX del modal "Ver WP_USERMETA" (listado de Integrantes).
 *
 * @package Administrador_Usuarios_WMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AU_Ajax_Usermeta {

	/**
	 * Instancia única (singleton).
	 *
	 * @var AU_Ajax_Usermeta|null
	 */
	private static $instance = null;

	/**
	 * Devuelve la instancia única y engancha las acciones AJAX.
	 *
	 * @return AU_Ajax_Usermeta
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
			self::$instance->register_hooks();
		}

		return self::$instance;
	}

	/**
	 * Registra los endpoints AJAX del modal.
	 *
	 * @return void
	 */
	private function register_hooks() {
		add_action( 'wp_ajax_au_wms_usermeta_listar', array( $this, 'handle_listar' ) );
		add_action( 'wp_ajax_au_wms_usermeta_crear', array( $this, 'handle_crear' ) );
		add_action( 'wp_ajax_au_wms_usermeta_actualizar', array( $this, 'handle_actualizar' ) );
		add_action( 'wp_ajax_au_wms_usermeta_eliminar', array( $this, 'handle_eliminar' ) );
	}

	/**
	 * Lista/pagina/busca los registros de usermeta de un usuario.
	 *
	 * @return void
	 */
	public function handle_listar() {
		AU_Security::guard();

		$user_id  = isset( $_POST['user_id'] ) ? AU_Security::sanitize_int( $_POST['user_id'] ) : 0;
		$search   = isset( $_POST['search'] ) ? AU_Security::sanitize_text( $_POST['search'] ) : '';
		$page     = isset( $_POST['page'] ) ? AU_Security::sanitize_int( $_POST['page'] ) : 1;
		$per_page = isset( $_POST['per_page'] ) ? AU_Security::sanitize_int( $_POST['per_page'] ) : 10;

		if ( ! $user_id || ! get_userdata( $user_id ) ) {
			wp_send_json_error( array( 'message' => __( 'Usuario inválido.', 'au-wms' ) ) );
		}

		$resultado = AU_Repository_Usermeta::buscar( $user_id, $search, $page, $per_page );

		$items = array();
		foreach ( $resultado['items'] as $row ) {
			$items[] = array(
				'umeta_id'   => (int) $row['umeta_id'],
				'meta_key'   => $row['meta_key'],
				'meta_value' => $row['meta_value'],
				'protegido'  => AU_Repository_Usermeta::es_clave_protegida( $row['meta_key'] ),
			);
		}

		$per_page    = ! empty( $per_page ) ? $per_page : 10;
		$total_pages = $per_page > 0 ? (int) ceil( $resultado['total'] / $per_page ) : 1;

		wp_send_json_success(
			array(
				'items'       => $items,
				'total'       => $resultado['total'],
				'page'        => max( 1, (int) $page ),
				'per_page'    => $per_page,
				'total_pages' => max( 1, $total_pages ),
			)
		);
	}

	/**
	 * Crea un nuevo atributo (registro de usermeta) para el usuario.
	 *
	 * @return void
	 */
	public function handle_crear() {
		AU_Security::guard();

		$user_id    = isset( $_POST['user_id'] ) ? AU_Security::sanitize_int( $_POST['user_id'] ) : 0;
		$meta_key   = isset( $_POST['meta_key'] ) ? sanitize_text_field( wp_unslash( $_POST['meta_key'] ) ) : '';
		$meta_value = isset( $_POST['meta_value'] ) ? sanitize_textarea_field( wp_unslash( $_POST['meta_value'] ) ) : '';

		if ( ! $user_id || ! get_userdata( $user_id ) ) {
			wp_send_json_error( array( 'message' => __( 'Usuario inválido.', 'au-wms' ) ) );
		}

		AU_Security::exigir_usuario_gestionable( $user_id );

		if ( '' === trim( $meta_key ) ) {
			wp_send_json_error( array( 'message' => __( 'El Meta Key es obligatorio.', 'au-wms' ) ) );
		}

		$umeta_id = AU_Repository_Usermeta::crear( $user_id, $meta_key, $meta_value );

		if ( ! $umeta_id ) {
			wp_send_json_error( array( 'message' => __( 'No fue posible crear el atributo.', 'au-wms' ) ) );
		}

		wp_send_json_success( array( 'message' => __( 'Atributo creado correctamente.', 'au-wms' ) ) );
	}

	/**
	 * Actualiza un atributo existente (meta_key y/o meta_value).
	 *
	 * @return void
	 */
	public function handle_actualizar() {
		AU_Security::guard();

		$umeta_id   = isset( $_POST['umeta_id'] ) ? AU_Security::sanitize_int( $_POST['umeta_id'] ) : 0;
		$user_id    = isset( $_POST['user_id'] ) ? AU_Security::sanitize_int( $_POST['user_id'] ) : 0;
		$meta_key   = isset( $_POST['meta_key'] ) ? sanitize_text_field( wp_unslash( $_POST['meta_key'] ) ) : '';
		$meta_value = isset( $_POST['meta_value'] ) ? sanitize_textarea_field( wp_unslash( $_POST['meta_value'] ) ) : '';

		AU_Security::exigir_usuario_gestionable( $user_id );

		$actual = AU_Repository_Usermeta::obtener_por_id( $umeta_id, $user_id );

		if ( ! $actual ) {
			wp_send_json_error( array( 'message' => __( 'El registro no existe o no pertenece a este usuario.', 'au-wms' ) ) );
		}

		if ( AU_Repository_Usermeta::es_clave_protegida( $actual['meta_key'] ) ) {
			wp_send_json_error( array( 'message' => __( 'Este atributo es reservado por WordPress y no puede editarse desde aquí.', 'au-wms' ) ) );
		}

		if ( '' === trim( $meta_key ) ) {
			wp_send_json_error( array( 'message' => __( 'El Meta Key es obligatorio.', 'au-wms' ) ) );
		}

		AU_Repository_Usermeta::actualizar( $umeta_id, $user_id, $meta_key, $meta_value );

		wp_send_json_success( array( 'message' => __( 'Atributo actualizado correctamente.', 'au-wms' ) ) );
	}

	/**
	 * Elimina un atributo (registro de usermeta).
	 *
	 * @return void
	 */
	public function handle_eliminar() {
		AU_Security::guard();

		$umeta_id = isset( $_POST['umeta_id'] ) ? AU_Security::sanitize_int( $_POST['umeta_id'] ) : 0;
		$user_id  = isset( $_POST['user_id'] ) ? AU_Security::sanitize_int( $_POST['user_id'] ) : 0;

		AU_Security::exigir_usuario_gestionable( $user_id );

		$actual = AU_Repository_Usermeta::obtener_por_id( $umeta_id, $user_id );

		if ( ! $actual ) {
			wp_send_json_error( array( 'message' => __( 'El registro no existe o no pertenece a este usuario.', 'au-wms' ) ) );
		}

		if ( AU_Repository_Usermeta::es_clave_protegida( $actual['meta_key'] ) ) {
			wp_send_json_error( array( 'message' => __( 'Este atributo es reservado por WordPress y no puede eliminarse desde aquí.', 'au-wms' ) ) );
		}

		AU_Repository_Usermeta::eliminar( $umeta_id, $user_id );

		wp_send_json_success( array( 'message' => __( 'Atributo eliminado correctamente.', 'au-wms' ) ) );
	}
}
