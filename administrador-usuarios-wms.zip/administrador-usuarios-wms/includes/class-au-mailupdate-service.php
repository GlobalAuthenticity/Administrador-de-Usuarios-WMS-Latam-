<?php
/**
 * Ejecuta el procesamiento por lotes de la actualización masiva de
 * correos, una vez el administrador confirma la previsualización
 * ("Actualizar correos" en el Paso 3 del asistente).
 *
 * Cada fila se procesa dentro de su propia transacción SQL: si algo
 * falla a mitad de un registro, ESE registro se revierte por completo
 * (nunca queda parcialmente actualizado) y el proceso continúa con
 * los demás (sección "Manejo de errores" del requerimiento).
 *
 * Todas las validaciones (existencia del usuario, disponibilidad del
 * correo nuevo) se vuelven a verificar aquí, dentro de la transacción y
 * justo antes de escribir, en vez de confiar únicamente en la foto
 * tomada durante la previsualización (que pudo quedar desactualizada).
 *
 * @package Administrador_Usuarios_WMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AU_Mail_Update_Service {

	/**
	 * Procesa un lote (batch) de filas ya validadas, a partir de un
	 * offset dado.
	 *
	 * @param string $update_id        ID del proceso.
	 * @param int    $offset           Posición inicial del lote.
	 * @param int    $batch_size       Tamaño del lote.
	 * @param bool   $generar_password Si se debe generar y notificar una nueva contraseña.
	 * @return array{results:array,offset:int,total:int,done:bool}
	 * @throws Exception Si no existe una previsualización válida para el update_id.
	 */
	public static function procesar_lote( $update_id, $offset, $batch_size, $generar_password ) {
		// Con lotes grandes (hasta 100 filas), cada una con su propia
		// transacción SQL + posible hash de contraseña, se puede superar
		// el `max_execution_time` por defecto de muchos hostings (30s).
		// Se sube el límite solo para esta petición si el hosting lo
		// permite (algunos deshabilitan set_time_limit() en modos
		// restringidos, de ahí el function_exists()).
		if ( function_exists( 'set_time_limit' ) ) {
			@set_time_limit( 120 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
		}

		$preview = AU_Mail_Update_Validator::get_preview( $update_id );

		if ( ! $preview ) {
			throw new Exception( __( 'La sesión del asistente expiró. Vuelve a iniciar el proceso.', 'au-wms' ) );
		}

		$listos = $preview['listos'];
		$total  = count( $listos );
		$lote   = array_slice( $listos, $offset, $batch_size );

		$resultados = array();

		foreach ( $lote as $fila ) {
			$resultados[] = self::procesar_fila( $fila, (bool) $generar_password );
		}

		$nuevo_offset = $offset + count( $lote );

		return array(
			'results' => $resultados,
			'offset'  => $nuevo_offset,
			'total'   => $total,
			'done'    => $nuevo_offset >= $total,
		);
	}

	/**
	 * Procesa una única fila dentro de su propia transacción SQL.
	 *
	 * @param array $fila             Fila validada (correo_actual, correo_nuevo, user_id).
	 * @param bool  $generar_password Si se debe generar y notificar una nueva contraseña.
	 * @return array{correo_anterior:string,correo_nuevo:string,resultado:string,mensaje?:string}
	 */
	private static function procesar_fila( array $fila, $generar_password ) {
		global $wpdb;

		$correo_actual = $fila['correo_actual'];
		$correo_nuevo  = $fila['correo_nuevo'];
		$user_id       = absint( $fila['user_id'] );

		$respuesta_base = array(
			'correo_anterior' => $correo_actual,
			'correo_nuevo'    => $correo_nuevo,
		);

		// Re-validación defensiva: el usuario debe seguir existiendo con
		// el mismo correo, y el correo nuevo debe seguir disponible.
		$user = get_userdata( $user_id );
		if ( ! $user || strtolower( $user->user_email ) !== $correo_actual ) {
			return array_merge(
				$respuesta_base,
				array(
					'resultado' => 'error',
					'mensaje'   => __( 'El usuario ya no existe o su correo cambió desde la previsualización.', 'au-wms' ),
				)
			);
		}

		if ( ! AU_Security::puede_gestionar_usuario( $user ) ) {
			return array_merge(
				$respuesta_base,
				array(
					'resultado' => 'error',
					'mensaje'   => AU_Security::mensaje_usuario_protegido(),
				)
			);
		}

		if ( email_exists( $correo_nuevo ) ) {
			return array_merge(
				$respuesta_base,
				array(
					'resultado' => 'error',
					'mensaje'   => __( 'El correo nuevo ya fue tomado por otro usuario mientras se procesaba el archivo.', 'au-wms' ),
				)
			);
		}

		// NOTA: anteriormente aquí se bloqueaba la actualización si el
		// usuario ya tenía su perfil completo. Se quitó a pedido
		// explícito: el correo se actualiza sin importar el estado del
		// perfil.

		$user_login_usa_correo = ( strtolower( $user->user_login ) === $correo_actual );
		$correos_table         = $wpdb->prefix . 'correos_configurados';
		$password_generada     = null;

		$wpdb->query( 'START TRANSACTION' );

		try {
			// Paso 1: actualizar el correo (y el user_login si el sistema
			// lo usa como nombre de usuario) mediante funciones nativas.
			$resultado_update = wp_update_user(
				array(
					'ID'         => $user_id,
					'user_email' => $correo_nuevo,
				)
			);

			if ( is_wp_error( $resultado_update ) ) {
				throw new Exception( $resultado_update->get_error_message() );
			}

			if ( $user_login_usa_correo ) {
				// wp_update_user() no permite renombrar user_login (no
				// existe una función nativa de alto nivel para ello);
				// se actualiza directamente la tabla nativa wp_users con
				// $wpdb y se limpia la caché de usuario con la función
				// nativa clean_user_cache(), como recomienda el Core de
				// WordPress tras modificar esa tabla manualmente.
				$actualizado_login = $wpdb->update(
					$wpdb->users,
					array( 'user_login' => $correo_nuevo ),
					array( 'ID' => $user_id ),
					array( '%s' ),
					array( '%d' )
				);

				if ( false === $actualizado_login ) {
					throw new Exception( __( 'No fue posible actualizar el nombre de usuario (user_login).', 'au-wms' ) );
				}

				clean_user_cache( $user_id );
			}

			// Paso 2: actualizar wp_correos_configurados con el correo nuevo.
			$actualizado_correos = @$wpdb->update(
				$correos_table,
				array( 'email' => $correo_nuevo ),
				array( 'email' => $correo_actual ),
				array( '%s' ),
				array( '%s' )
			);

			if ( false === $actualizado_correos && ! empty( $wpdb->last_error ) && false === strpos( (string) $wpdb->last_error, 'Duplicate entry' ) ) {
				throw new Exception( __( 'No fue posible actualizar wp_correos_configurados.', 'au-wms' ) );
			}

			// Paso 3 (opcional): generar nueva contraseña.
			if ( $generar_password ) {
				$password_generada = AU_Password_Generator::generar();
				wp_set_password( $password_generada, $user_id );
			}

			$wpdb->query( 'COMMIT' );
		} catch ( Exception $e ) {
			$wpdb->query( 'ROLLBACK' );
			error_log( '[AU-WMS] Error en actualización masiva de correos para el usuario #' . $user_id . ' (' . $correo_actual . '): ' . $e->getMessage() );

			return array_merge(
				$respuesta_base,
				array(
					'resultado' => 'error',
					'mensaje'   => $e->getMessage(),
				)
			);
		}

		// Paso 4 (opcional): notificar el webhook de recuperación de
		// contraseña, solo cuando esta se regeneró y ya fuera de la
		// transacción de $wpdb (es una llamada HTTP externa).
		if ( null !== $password_generada ) {
			AU_Webhook_Service::notificar_actualizacion_correo_masiva( $correo_nuevo, $password_generada );
		}

		return array_merge(
			$respuesta_base,
			array( 'resultado' => 'actualizado' )
		);
	}
}
