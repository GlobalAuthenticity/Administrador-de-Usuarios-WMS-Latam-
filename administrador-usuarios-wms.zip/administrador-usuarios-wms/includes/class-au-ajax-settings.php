<?php
/**
 * Controlador AJAX de la página "Configuración" (APIs / Webhooks).
 *
 * @package Administrador_Usuarios_WMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AU_Ajax_Settings {

	/**
	 * Instancia única (singleton).
	 *
	 * @var AU_Ajax_Settings|null
	 */
	private static $instance = null;

	/**
	 * Devuelve la instancia única y engancha las acciones AJAX.
	 *
	 * @return AU_Ajax_Settings
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
			self::$instance->register_hooks();
		}

		return self::$instance;
	}

	/**
	 * Registra el endpoint AJAX de guardado de configuración.
	 *
	 * @return void
	 */
	private function register_hooks() {
		add_action( 'wp_ajax_au_wms_guardar_configuracion', array( $this, 'handle_guardar' ) );
	}

	/**
	 * Valida y guarda la configuración enviada desde el formulario.
	 *
	 * @return void
	 */
	public function handle_guardar() {
		AU_Security::guard();

		$webhook_nuevo  = isset( $_POST['webhook_nuevo_usuario_url'] ) ? esc_url_raw( wp_unslash( $_POST['webhook_nuevo_usuario_url'] ) ) : '';
		$webhook_update = isset( $_POST['webhook_usuario_actualizado_url'] ) ? esc_url_raw( wp_unslash( $_POST['webhook_usuario_actualizado_url'] ) ) : '';
		$token          = isset( $_POST['token_autorizacion'] ) ? sanitize_text_field( wp_unslash( $_POST['token_autorizacion'] ) ) : '';
		$activos        = ! empty( $_POST['webhooks_activos'] );

		$inspira_url      = isset( $_POST['inspira_sync_url'] ) ? esc_url_raw( wp_unslash( $_POST['inspira_sync_url'] ) ) : '';
		$inspira_token    = isset( $_POST['inspira_sync_token'] ) ? sanitize_text_field( wp_unslash( $_POST['inspira_sync_token'] ) ) : '';
		$octagono_url     = isset( $_POST['octagono_sync_url'] ) ? esc_url_raw( wp_unslash( $_POST['octagono_sync_url'] ) ) : '';
		$octagono_token   = isset( $_POST['octagono_sync_token'] ) ? sanitize_text_field( wp_unslash( $_POST['octagono_sync_token'] ) ) : '';
		$recovery_pass_url = isset( $_POST['webhook_recovery_pass_url'] ) ? esc_url_raw( wp_unslash( $_POST['webhook_recovery_pass_url'] ) ) : '';
		$reset_password_masivo_url = isset( $_POST['webhook_reset_password_masivo_url'] ) ? esc_url_raw( wp_unslash( $_POST['webhook_reset_password_masivo_url'] ) ) : '';
		$pdf_resultado_test_url    = isset( $_POST['pdf_resultado_test_url'] ) ? esc_url_raw( wp_unslash( $_POST['pdf_resultado_test_url'] ) ) : '';

		$urls_a_validar = array(
			'webhook_nuevo_usuario_url'       => $webhook_nuevo,
			'webhook_usuario_actualizado_url' => $webhook_update,
			'inspira_sync_url'                => $inspira_url,
			'octagono_sync_url'               => $octagono_url,
			'webhook_recovery_pass_url'       => $recovery_pass_url,
			'webhook_reset_password_masivo_url' => $reset_password_masivo_url,
			'pdf_resultado_test_url'          => $pdf_resultado_test_url,
		);

		// Los campos del asistente "Crear Empresa" se sanean a partir de
		// su registro (AU_Settings::CAMPOS_CREAR_EMPRESA): son 16 y
		// repetirlos uno a uno aquí y en `guardar()` multiplicaba el
		// trabajo de añadir uno nuevo.
		$crear_empresa = $this->leer_campos_crear_empresa();

		foreach ( AU_Settings::CAMPOS_CREAR_EMPRESA as $clave => $campo ) {
			if ( 'url' === $campo['tipo'] ) {
				$urls_a_validar[ $clave ] = $crear_empresa[ $clave ];
			}
		}

		foreach ( $urls_a_validar as $campo => $valor ) {
			if ( '' !== $valor && false === filter_var( $valor, FILTER_VALIDATE_URL ) ) {
				wp_send_json_error( array( 'message' => __( 'Una de las URLs configuradas no es válida.', 'au-wms' ) ) );
			}
		}

		// La plantilla del correo sin el marcador generaría el mismo
		// correo para todas las empresas: se rechaza antes de guardar.
		if ( '' !== $crear_empresa['crear_empresa_email_plantilla']
			&& false === strpos( $crear_empresa['crear_empresa_email_plantilla'], '{nombre_empresa_normalizado}' ) ) {
			wp_send_json_error(
				array( 'message' => __( 'La plantilla del correo debe incluir {nombre_empresa_normalizado}.', 'au-wms' ) )
			);
		}

		$guardado = AU_Settings::guardar(
			$crear_empresa + array(
				'webhook_nuevo_usuario_url'       => $webhook_nuevo,
				'webhook_usuario_actualizado_url' => $webhook_update,
				'token_autorizacion'              => $token,
				'webhooks_activos'                => $activos,
				'inspira_sync_url'                => $inspira_url,
				'inspira_sync_token'              => $inspira_token,
				'octagono_sync_url'               => $octagono_url,
				'octagono_sync_token'             => $octagono_token,
				'webhook_recovery_pass_url'       => $recovery_pass_url,
				'webhook_reset_password_masivo_url' => $reset_password_masivo_url,
				'pdf_resultado_test_url'          => $pdf_resultado_test_url,
			)
		);

		wp_send_json_success(
			array(
				'message' => __( 'Configuración guardada correctamente.', 'au-wms' ),
				'config'  => $guardado,
			)
		);
	}

	/**
	 * Lee y sanea los campos del asistente "Crear Empresa" según el tipo
	 * declarado en `AU_Settings::CAMPOS_CREAR_EMPRESA`.
	 *
	 * Un campo ausente en el POST conserva su valor actual (no se borra):
	 * así un formulario parcial nunca vacía la configuración.
	 *
	 * @return array clave => valor saneado.
	 */
	private function leer_campos_crear_empresa() {
		$actuales = AU_Settings::crear_empresa();
		$valores  = array();

		foreach ( AU_Settings::CAMPOS_CREAR_EMPRESA as $clave => $campo ) {
			if ( ! isset( $_POST[ $clave ] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing -- AU_Security::guard() ya verificó el nonce.
				$valores[ $clave ] = $actuales[ $clave ];
				continue;
			}

			$crudo = wp_unslash( $_POST[ $clave ] ); // phpcs:ignore WordPress.Security.NonceVerification.Missing

			switch ( $campo['tipo'] ) {
				case 'url':
					$valores[ $clave ] = esc_url_raw( $crudo );
					break;
				case 'entero':
					$valores[ $clave ] = absint( $crudo );
					break;
				default: // 'texto' y 'token'.
					$valores[ $clave ] = sanitize_text_field( $crudo );
			}
		}

		return $valores;
	}
}
