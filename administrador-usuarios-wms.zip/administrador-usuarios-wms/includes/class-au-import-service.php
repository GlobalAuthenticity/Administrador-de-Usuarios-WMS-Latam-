<?php
/**
 * Ejecuta el procesamiento por lotes de la importación masiva, una vez
 * el administrador confirma la previsualización ("Continuar").
 *
 * Cada fila se procesa dentro de su propio try/catch: si una falla, las
 * demás continúan (sección 9 del requerimiento). El procesamiento se
 * hace por lotes pequeños invocados repetidamente desde JavaScript para
 * no agotar memoria ni exceder el tiempo máximo de ejecución de PHP.
 *
 * @package Administrador_Usuarios_WMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AU_Import_Service {

	/**
	 * Campos opcionales del sistema y su meta_key correspondiente.
	 *
	 * @return array<string,string>
	 */
	private static function mapa_meta_keys() {
		return array(
			'nombre'   => 'first_name',
			'apellido' => 'last_name',
			'edad'     => 'user_age',
			'genero'   => 'user_gender',
			'pais'     => 'country',
			'telefono' => 'phone_number',
			'cargo'    => 'user_position',
		);
	}

	/**
	 * Procesa un lote (batch) de filas ya validadas, a partir de un
	 * offset dado.
	 *
	 * @param string $import_id  ID de importación.
	 * @param int    $offset     Posición inicial del lote.
	 * @param int    $batch_size Tamaño del lote.
	 * @return array{results:array,offset:int,total:int,done:bool}
	 * @throws Exception Si no existe una previsualización válida para el import_id.
	 */
	public static function procesar_lote( $import_id, $offset, $batch_size ) {
		$preview = AU_Import_Validator::get_preview( $import_id );

		if ( ! $preview ) {
			throw new Exception( __( 'La sesión de importación expiró. Vuelve a iniciar el proceso.', 'au-wms' ) );
		}

		// Se combina el conjunto completo (sin filtrar por el flag
		// "cabe_en_cupos" de la previsualización, que puede haber quedado
		// desactualizado): la disponibilidad real de cupos se vuelve a
		// verificar fila por fila, dentro del lock, en el momento exacto
		// de procesar cada registro.
		$combinado = array();
		foreach ( $preview['nuevos'] as $fila ) {
			$combinado[] = array_merge( $fila, array( 'tipo' => 'nuevo' ) );
		}
		foreach ( $preview['actualizar'] as $fila ) {
			$combinado[] = array_merge( $fila, array( 'tipo' => 'actualizar' ) );
		}
		foreach ( (array) ( $preview['agregar_area'] ?? array() ) as $fila ) {
			$combinado[] = array_merge( $fila, array( 'tipo' => 'agregar_area' ) );
		}

		$total = count( $combinado );
		$lote  = array_slice( $combinado, $offset, $batch_size );

		$codigo_area = $preview['codigo_area'];
		$resultados  = array();

		// Lock con nombre a nivel de MySQL: si otra importación (u otro
		// proceso) está consumiendo cupos de la misma área en este
		// instante, este lote espera hasta 10s antes de desistir, en vez
		// de proceder a ciegas y arriesgarse a sobrepasar el cupo real.
		if ( ! AU_Cupos_Lock::adquirir( $codigo_area ) ) {
			throw new Exception(
				__( 'El área seleccionada está siendo procesada por otra importación en este momento. Inténtalo de nuevo en unos segundos.', 'au-wms' )
			);
		}

		try {
			foreach ( $lote as $fila ) {
				try {
					if ( ! self::hay_cupo_disponible( $preview ) ) {
						$resultados[] = array(
							'email'  => $fila['correo'],
							'status' => 'sin_cupo',
							'accion' => $fila['tipo'],
							'mensaje' => __( 'Sin cupo disponible al momento de procesar.', 'au-wms' ),
						);
						continue;
					}

					if ( 'nuevo' === $fila['tipo'] ) {
						$resultado = self::crear_usuario_nuevo( $fila, $preview );
					} elseif ( 'agregar_area' === $fila['tipo'] ) {
						$resultado = self::agregar_area_existente( $fila, $preview );
					} else {
						$resultado = self::actualizar_usuario_external( $fila, $preview );
					}

					$resultados[] = array_merge( array( 'email' => $fila['correo'] ), $resultado );
				} catch ( Exception $e ) {
					$resultados[] = array(
						'email'  => $fila['correo'],
						'status' => 'error',
						'accion' => $fila['tipo'],
						'mensaje' => $e->getMessage(),
					);
				}
			}
		} finally {
			// Se libera el lock siempre, incluso si una fila lanzó un
			// error inesperado, para no dejar el área bloqueada.
			AU_Cupos_Lock::liberar( $codigo_area );
		}

		$results = $resultados;

		$nuevo_offset = $offset + count( $lote );

		return array(
			'results' => $results,
			'offset'  => $nuevo_offset,
			'total'   => $total,
			'done'    => $nuevo_offset >= $total,
		);
	}

	/**
	 * Verifica en tiempo real (dentro del lock) si el área todavía tiene
	 * al menos un cupo disponible, volviendo a contar los registros
	 * reales en `wp_correos_configurados` en vez de confiar en la foto
	 * tomada durante la previsualización.
	 *
	 * @param array $preview Contexto de la importación (paquete_id, codigo_area).
	 * @return bool
	 */
	private static function hay_cupo_disponible( array $preview ) {
		$paquete = AU_Repository_Empresas::get_paquete( $preview['paquete_id'] );

		if ( ! $paquete ) {
			return false;
		}

		$cupo       = (int) $paquete['cupo'];
		$utilizados = AU_Repository_Usuarios::contar_por_codigo_area( $preview['codigo_area'] );

		return $utilizados < $cupo;
	}

	/**
	 * Crea un usuario nuevo con rol `subscriber` y password aleatoria.
	 *
	 * @param array $fila    Datos de la fila (correo + opcionales).
	 * @param array $preview Contexto de la importación (empresa_id, paquete_id, codigo_area).
	 * @return array{status:string,accion:string,password:string}
	 * @throws Exception Si la creación del usuario falla.
	 */
	private static function crear_usuario_nuevo( array $fila, array $preview ) {
		$email    = $fila['correo'];
		$password = AU_Password_Generator::generar();

		$user_login = self::generar_username_disponible( $email );

		$user_id = wp_insert_user(
			array(
				'user_login' => $user_login,
				'user_email' => $email,
				'user_pass'  => $password,
				'role'       => 'subscriber',
			)
		);

		if ( is_wp_error( $user_id ) ) {
			throw new Exception( $user_id->get_error_message() );
		}

		self::guardar_meta_opcionales( $user_id, $fila );
		update_user_meta( $user_id, 'usuario_importado', true );
		update_user_meta( $user_id, 'empresa_id', $preview['empresa_id'] );

		self::registrar_correo_configurado( $preview, $email, $user_id );

		AU_Webhook_Service::notificar_usuario_nuevo( $email, $password );

		// La contraseña viaja también en la respuesta AJAX (no solo por
		// webhook) para que el asistente pueda mostrar el resumen de
		// "Importación finalizada" con la contraseña EXACTA que se
		// generó aquí, sin necesidad de regenerarla ni de depender de
		// que el webhook haya llegado a destino.
		return array(
			'status'   => 'creado',
			'accion'   => 'nuevo',
			'password' => $password,
		);
	}

	/**
	 * Actualiza un usuario existente con rol `external_user`,
	 * cambiándolo a `subscriber` y actualizando sus metadatos.
	 *
	 * @param array $fila    Datos de la fila (correo + opcionales + user_id).
	 * @param array $preview Contexto de la importación.
	 * @return array{status:string,accion:string}
	 * @throws Exception Si el usuario ya no existe.
	 */
	private static function actualizar_usuario_external( array $fila, array $preview ) {
		$user_id = absint( $fila['user_id'] );
		$user    = get_userdata( $user_id );

		if ( ! $user ) {
			throw new Exception( __( 'El usuario ya no existe.', 'au-wms' ) );
		}

		$user->set_role( 'subscriber' );

		self::guardar_meta_opcionales( $user_id, $fila );
		update_user_meta( $user_id, 'usuario_importado', true );
		update_user_meta( $user_id, 'empresa_id', $preview['empresa_id'] );

		self::registrar_correo_configurado( $preview, $fila['correo'], $user_id );

		AU_Webhook_Service::notificar_usuario_actualizado( $fila['correo'] );

		return array(
			'status' => 'actualizado',
			'accion' => 'actualizar',
		);
	}

	/**
	 * Agrega una relación de área adicional a un usuario que YA es
	 * `subscriber` activo (pertenece a otra área distinta). A partir de
	 * ahora un usuario puede pertenecer a varias áreas simultáneamente,
	 * así que aquí NO se toca su rol (ya es el correcto), ni su
	 * "empresa principal" (`empresa_id`), ni sus metadatos opcionales
	 * (nombre, apellido, etc., que ya tiene de su alta original), ni
	 * `user_code_company` (para no pisar su área principal existente).
	 * Tampoco se dispara ningún webhook: el usuario ya tiene cuenta y
	 * contraseña activas, así que no necesita ser notificado.
	 *
	 * Solo se agrega la nueva fila en `wp_correos_configurados`
	 * (email + codigo_area de la importación actual).
	 *
	 * @param array $fila    Datos de la fila (correo + user_id).
	 * @param array $preview Contexto de la importación (empresa_id, codigo_area).
	 * @return array{status:string,accion:string}
	 * @throws Exception Si el usuario ya no existe o la inserción falla.
	 */
	private static function agregar_area_existente( array $fila, array $preview ) {
		global $wpdb;

		$user_id = absint( $fila['user_id'] );
		$user    = get_userdata( $user_id );

		if ( ! $user ) {
			throw new Exception( __( 'El usuario ya no existe.', 'au-wms' ) );
		}

		$table = $wpdb->prefix . 'correos_configurados';

		// Se usa @ para suprimir el warning nativo de $wpdb en la
		// colisión de la clave única (email + codigo_area); si ya
		// existía (por ejemplo, otro proceso lo agregó justo antes),
		// no se considera un error.
		$insertado = @$wpdb->insert(
			$table,
			array(
				'codigo_area' => $preview['codigo_area'],
				'empresa_id'  => $preview['empresa_id'],
				'email'       => $fila['correo'],
				'estado'      => 0,
				'test'        => 0,
			),
			array( '%s', '%d', '%s', '%d', '%d' )
		);

		if ( false === $insertado && false === strpos( (string) $wpdb->last_error, 'Duplicate entry' ) ) {
			throw new Exception( __( 'No fue posible agregar al usuario a la nueva área.', 'au-wms' ) );
		}

		return array(
			'status' => 'area_agregada',
			'accion' => 'agregar_area',
		);
	}

	/**
	 * Guarda los metadatos opcionales de una fila, solo para los campos
	 * que traigan un valor no vacío.
	 *
	 * @param int   $user_id ID del usuario.
	 * @param array $fila    Datos de la fila.
	 * @return void
	 */
	private static function guardar_meta_opcionales( $user_id, array $fila ) {
		foreach ( self::mapa_meta_keys() as $campo => $meta_key ) {
			if ( isset( $fila[ $campo ] ) && '' !== $fila[ $campo ] ) {
				update_user_meta( $user_id, $meta_key, sanitize_text_field( $fila[ $campo ] ) );
			}
		}
	}

	/**
	 * Genera un `user_login` disponible a partir del correo, agregando
	 * un sufijo aleatorio si el nombre base ya está en uso.
	 *
	 * @param string $email Correo del usuario.
	 * @return string
	 */
	private static function generar_username_disponible( $email ) {
		$base = sanitize_user( current( explode( '@', $email ) ), true );
		if ( '' === $base ) {
			$base = 'usuario';
		}

		$user_login = $base;
		$intentos   = 0;

		while ( username_exists( $user_login ) && $intentos < 10 ) {
			$user_login = $base . '_' . substr( md5( uniqid( '', true ) ), 0, 6 );
			++$intentos;
		}

		return $user_login;
	}

	/**
	 * Inserta el registro en `wp_correos_configurados` para el usuario
	 * creado/actualizado. Si ya existe (email + codigo_area, restricción
	 * UNIQUE), se ignora silenciosamente sin considerarlo un error.
	 *
	 * Además, guarda el `codigo_area` de ese registro en `wp_usermeta`
	 * bajo el meta_key `user_code_company` (usando `update_user_meta()`,
	 * no un INSERT crudo, para que quede una sola vez aunque el usuario
	 * se vuelva a importar).
	 *
	 * @param array  $preview Contexto de la importación (codigo_area, empresa_id).
	 * @param string $email   Correo del usuario.
	 * @param int    $user_id ID del usuario creado/actualizado.
	 * @return void
	 */
	private static function registrar_correo_configurado( array $preview, $email, $user_id ) {
		global $wpdb;

		$table = $wpdb->prefix . 'correos_configurados';

		// Se usa @ para suprimir el warning nativo de $wpdb en la
		// colisión de la clave única; el error se revisa explícitamente
		// después mediante $wpdb->last_error para distinguirlo de un
		// fallo real de base de datos.
		$insertado = @$wpdb->insert(
			$table,
			array(
				'codigo_area' => $preview['codigo_area'],
				'empresa_id'  => $preview['empresa_id'],
				'email'       => $email,
				'estado'      => 0,
				'test'        => 0,
			),
			array( '%s', '%d', '%s', '%d', '%d' )
		);

		if ( false === $insertado && false === strpos( (string) $wpdb->last_error, 'Duplicate entry' ) ) {
			throw new Exception( __( 'No fue posible registrar al usuario en el área seleccionada.', 'au-wms' ) );
		}

		// El registro quedó bien (recién insertado o ya existía de
		// antes): el codigo_area de ESTE registro es válido para el
		// usuario, así que se guarda en su perfil.
		update_user_meta( $user_id, 'user_code_company', $preview['codigo_area'] );
	}
}
