<?php
/**
 * Controlador AJAX del Tab "Empresas".
 *
 * @package Administrador_Usuarios_WMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AU_Ajax_Empresas {

	/**
	 * Instancia única (singleton).
	 *
	 * @var AU_Ajax_Empresas|null
	 */
	private static $instance = null;

	/**
	 * Devuelve la instancia única y engancha las acciones AJAX.
	 *
	 * @return AU_Ajax_Empresas
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
			self::$instance->register_hooks();
		}

		return self::$instance;
	}

	/**
	 * Registra el endpoint AJAX de búsqueda/paginación de empresas.
	 *
	 * @return void
	 */
	private function register_hooks() {
		add_action( 'wp_ajax_au_wms_buscar_empresas', array( $this, 'handle_buscar_empresas' ) );
		add_action( 'wp_ajax_au_wms_buscar_areas_empresa', array( $this, 'handle_buscar_areas_empresa' ) );
		add_action( 'wp_ajax_au_wms_buscar_cursos_area', array( $this, 'handle_buscar_cursos_area' ) );
		add_action( 'wp_ajax_au_wms_actualizar_codigo_empresa_usuarios', array( $this, 'handle_actualizar_codigo_empresa_usuarios' ) );
		add_action( 'wp_ajax_au_wms_crear_areas_empresa', array( $this, 'handle_crear_areas_empresa' ) );
		add_action( 'wp_ajax_au_wms_obtener_area', array( $this, 'handle_obtener_area' ) );
		add_action( 'wp_ajax_au_wms_editar_area', array( $this, 'handle_editar_area' ) );
		add_action( 'wp_ajax_au_wms_cambiar_licencia_empresa', array( $this, 'handle_cambiar_licencia_empresa' ) );
		add_action( 'wp_ajax_au_wms_obtener_empresa', array( $this, 'handle_obtener_empresa' ) );
		add_action( 'wp_ajax_au_wms_editar_empresa', array( $this, 'handle_editar_empresa' ) );
	}

	/**
	 * Busca/pagina empresas (usuarios con rol `company`) según los
	 * filtros recibidos.
	 *
	 * @return void
	 */
	public function handle_buscar_empresas() {
		AU_Security::guard();

		$args = array(
			'search'          => isset( $_POST['search'] ) ? AU_Security::sanitize_text( $_POST['search'] ) : '',
			'licencia_id'     => isset( $_POST['licencia_id'] ) ? AU_Security::sanitize_text( $_POST['licencia_id'] ) : '',
			'programa_filtro' => isset( $_POST['programa_filtro'] ) ? AU_Security::sanitize_text( $_POST['programa_filtro'] ) : '',
			'page'            => isset( $_POST['page'] ) ? AU_Security::sanitize_int( $_POST['page'] ) : 1,
			'per_page'        => isset( $_POST['per_page'] ) ? AU_Security::sanitize_int( $_POST['per_page'] ) : 10,
		);

		$resultado = AU_Repository_Empresas::buscar_listado( $args );

		$per_page    = ! empty( $args['per_page'] ) ? $args['per_page'] : 10;
		$total_pages = $per_page > 0 ? (int) ceil( $resultado['total'] / $per_page ) : 1;

		wp_send_json_success(
			array(
				'items'       => $resultado['items'],
				'total'       => $resultado['total'],
				'page'        => max( 1, (int) $args['page'] ),
				'per_page'    => $per_page,
				'total_pages' => max( 1, $total_pages ),
			)
		);
	}

	/**
	 * Busca/pagina las áreas de una empresa (modal "Ver más" de la
	 * columna Áreas).
	 *
	 * @return void
	 */
	public function handle_buscar_areas_empresa() {
		AU_Security::guard();

		$args = array(
			'empresa_id'    => isset( $_POST['empresa_id'] ) ? AU_Security::sanitize_int( $_POST['empresa_id'] ) : 0,
			'search'        => isset( $_POST['search'] ) ? AU_Security::sanitize_text( $_POST['search'] ) : '',
			'lider_filtro'  => isset( $_POST['lider_filtro'] ) ? AU_Security::sanitize_text( $_POST['lider_filtro'] ) : '',
			'licencia_id'   => isset( $_POST['licencia_id'] ) ? AU_Security::sanitize_text( $_POST['licencia_id'] ) : '',
			'cursos_filtro' => isset( $_POST['cursos_filtro'] ) ? AU_Security::sanitize_text( $_POST['cursos_filtro'] ) : '',
			'page'          => isset( $_POST['page'] ) ? AU_Security::sanitize_int( $_POST['page'] ) : 1,
			'per_page'      => isset( $_POST['per_page'] ) ? AU_Security::sanitize_int( $_POST['per_page'] ) : 10,
		);

		$resultado = AU_Repository_Empresas::buscar_areas_empresa( $args );

		$per_page    = ! empty( $args['per_page'] ) ? $args['per_page'] : 10;
		$total_pages = $per_page > 0 ? (int) ceil( $resultado['total'] / $per_page ) : 1;

		wp_send_json_success(
			array(
				'items'       => $resultado['items'],
				'total'       => $resultado['total'],
				'page'        => max( 1, (int) $args['page'] ),
				'per_page'    => $per_page,
				'total_pages' => max( 1, $total_pages ),
			)
		);
	}

	/**
	 * Devuelve los cursos de LearnDash asignados a un área (modal
	 * "Ver cursos" de la columna "Cursos asignados").
	 *
	 * @return void
	 */
	public function handle_buscar_cursos_area() {
		AU_Security::guard();

		$area_id   = isset( $_POST['area_id'] ) ? AU_Security::sanitize_int( $_POST['area_id'] ) : 0;
		$resultado = AU_Repository_Empresas::obtener_cursos_area( $area_id );

		wp_send_json_success(
			array(
				'area_nombre' => $resultado['area_nombre'],
				'cursos'      => $resultado['cursos'],
			)
		);
	}

	/**
	 * Ejecuta "Actualizar id empresa usuario" para todos los usuarios
	 * de una empresa.
	 *
	 * @return void
	 */
	public function handle_actualizar_codigo_empresa_usuarios() {
		AU_Security::guard();

		$empresa_id = isset( $_POST['empresa_id'] ) ? AU_Security::sanitize_int( $_POST['empresa_id'] ) : 0;

		$resultado = AU_Empresa_Actions_Service::actualizar_codigo_empresa_usuarios( $empresa_id );

		if ( ! empty( $resultado['success'] ) ) {
			wp_send_json_success( $resultado );
		}

		wp_send_json_error( array( 'message' => $resultado['message'] ) );
	}

	/**
	 * Crea una o varias áreas/paquetes para una empresa en una sola
	 * petición (modal "Crear Área/s" del Tab Empresas). Cada elemento de
	 * `areas` (JSON) se procesa por separado con `AU_Area_Service::crear()`
	 * — un área inválida no bloquea a las demás — y el resultado se
	 * devuelve en el mismo orden en que se recibió, para que el JS pueda
	 * emparejarlo con su fila del formulario.
	 *
	 * @return void
	 */
	public function handle_crear_areas_empresa() {
		AU_Security::guard();

		$empresa_id  = isset( $_POST['empresa_id'] ) ? AU_Security::sanitize_int( $_POST['empresa_id'] ) : 0;
		$areas_json  = isset( $_POST['areas'] ) ? wp_unslash( $_POST['areas'] ) : '[]';
		$areas_input = json_decode( $areas_json, true );

		if ( ! is_array( $areas_input ) || empty( $areas_input ) ) {
			wp_send_json_error( array( 'message' => __( 'No se recibió ninguna área para crear.', 'au-wms' ) ) );
		}

		$resultados = array();

		foreach ( $areas_input as $area_input ) {
			$area_input = is_array( $area_input ) ? $area_input : array();

			$data = array(
				'empresa_id'  => $empresa_id,
				'nombre'      => isset( $area_input['nombre'] ) ? sanitize_text_field( (string) $area_input['nombre'] ) : '',
				'codigo'      => '', // Siempre se autogenera; ver AU_Area_Service::crear().
				'cupos'       => isset( $area_input['cupos'] ) ? absint( $area_input['cupos'] ) : 0,
				'licencia_id' => isset( $area_input['licencia_id'] ) ? absint( $area_input['licencia_id'] ) : 0,
			);

			$resultados[] = AU_Area_Service::crear( $data );
		}

		wp_send_json_success( array( 'resultados' => $resultados ) );
	}

	/**
	 * Devuelve los datos "en crudo" de un área (para precargar el modal
	 * "Editar Área" con el valor real guardado, no el que se muestra por
	 * herencia en el listado).
	 *
	 * @return void
	 */
	public function handle_obtener_area() {
		AU_Security::guard();

		$area_id = isset( $_POST['area_id'] ) ? AU_Security::sanitize_int( $_POST['area_id'] ) : 0;
		$area    = AU_Repository_Empresas::obtener_area_por_id( $area_id );

		if ( ! $area ) {
			wp_send_json_error( array( 'message' => __( 'El área indicada no existe.', 'au-wms' ) ) );
		}

		wp_send_json_success( $area );
	}

	/**
	 * Edita un área/paquete existente (acción "Editar Área" del dropdown
	 * de cada fila del listado de Áreas). Delega toda la lógica de
	 * negocio en `AU_Area_Service::editar()`.
	 *
	 * @return void
	 */
	public function handle_editar_area() {
		AU_Security::guard();

		$data = array(
			'area_id'     => isset( $_POST['area_id'] ) ? AU_Security::sanitize_int( $_POST['area_id'] ) : 0,
			'nombre'      => isset( $_POST['nombre'] ) ? AU_Security::sanitize_text( $_POST['nombre'] ) : '',
			'cupos'       => isset( $_POST['cupos'] ) ? AU_Security::sanitize_int( $_POST['cupos'] ) : 0,
			'licencia_id' => isset( $_POST['licencia_id'] ) ? AU_Security::sanitize_int( $_POST['licencia_id'] ) : 0,
		);

		$resultado = AU_Area_Service::editar( $data );

		if ( ! empty( $resultado['success'] ) ) {
			wp_send_json_success( $resultado );
		}

		wp_send_json_error( array( 'message' => $resultado['message'] ) );
	}

	/**
	 * Cambia la licencia de una empresa (modal "Cambiar Licencia" del
	 * dropdown de acciones de cada fila).
	 *
	 * @return void
	 */
	/**
	 * Datos actuales de una empresa, para precargar el modal "Editar
	 * empresa" (el listado no trae NIT, contacto ni ocupación).
	 *
	 * @return void
	 */
	public function handle_obtener_empresa() {
		AU_Security::guard();

		$empresa_id = isset( $_POST['empresa_id'] ) ? AU_Security::sanitize_int( $_POST['empresa_id'] ) : 0;
		$empresa    = AU_Empresa_Actions_Service::obtener( $empresa_id );

		if ( ! $empresa ) {
			wp_send_json_error( array( 'message' => __( 'La empresa seleccionada no existe.', 'au-wms' ) ) );
		}

		wp_send_json_success( $empresa );
	}

	/**
	 * Guarda el modal "Editar empresa".
	 *
	 * Solo se leen del POST los campos editables: aunque alguien envíe a
	 * mano `email` o `licencia`, aquí no se recogen y el servicio
	 * tampoco los escribe.
	 *
	 * @return void
	 */
	public function handle_editar_empresa() {
		AU_Security::guard();

		$empresa_id = isset( $_POST['empresa_id'] ) ? AU_Security::sanitize_int( $_POST['empresa_id'] ) : 0;
		$datos      = array();

		foreach ( array_keys( AU_Empresa_Actions_Service::CAMPOS_EDITABLES ) as $campo ) {
			$datos[ $campo ] = isset( $_POST[ $campo ] ) ? AU_Security::sanitize_text( $_POST[ $campo ] ) : '';
		}

		$resultado = AU_Empresa_Actions_Service::editar( $empresa_id, $datos );

		if ( ! empty( $resultado['success'] ) ) {
			wp_send_json_success( $resultado );
		}

		wp_send_json_error( array( 'message' => $resultado['message'] ) );
	}

	public function handle_cambiar_licencia_empresa() {
		AU_Security::guard();

		$empresa_id  = isset( $_POST['empresa_id'] ) ? AU_Security::sanitize_int( $_POST['empresa_id'] ) : 0;
		$licencia_id = isset( $_POST['licencia_id'] ) ? AU_Security::sanitize_int( $_POST['licencia_id'] ) : 0;

		$resultado = AU_Empresa_Actions_Service::cambiar_licencia( $empresa_id, $licencia_id );

		if ( ! empty( $resultado['success'] ) ) {
			wp_send_json_success( $resultado );
		}

		wp_send_json_error( array( 'message' => $resultado['message'] ) );
	}
}
