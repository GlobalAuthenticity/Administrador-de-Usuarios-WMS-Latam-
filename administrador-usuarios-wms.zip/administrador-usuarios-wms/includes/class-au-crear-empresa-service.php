<?php
/**
 * Asistente "Crear Empresa" (Tab Empresas): crea la empresa en WMS y, si
 * se pidieron, en Inspira y en Octágono del sentido, y entrega las
 * credenciales al webhook configurado.
 *
 * La creación en WMS replica las reglas de `UDA_Company::create()` del
 * plugin "User Data API" (nombre de empresa y NIT únicos, ascenso de un
 * `external_user` existente, GET_LOCK por nombre, misma generación de
 * contraseña y mismos metadatos), con una diferencia obligada: allí
 * `licencia_id` es obligatorio, y aquí la licencia solo aplica cuando se
 * eligió Liderazgo (WMS). Sin Liderazgo el usuario queda como
 * `external_user`, sin licencia y sin áreas — por eso esta clase no
 * puede delegar en UDA_Company y mantiene su propia copia de esas
 * reglas. Las áreas de Liderazgo sí se delegan en `AU_Area_Service`.
 *
 * Inspira y Octágono se crean por su API REST (ver
 * `AU_Programas_Api_Client`), siempre desde el servidor.
 *
 * @package Administrador_Usuarios_WMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AU_Crear_Empresa_Service {

	/**
	 * Programas que puede crear el asistente, con su etiqueta visible.
	 *
	 * @var array<string,string>
	 */
	const PROGRAMAS = array(
		'wms'      => 'Liderazgo (WMS)',
		'inspira'  => 'Inspira',
		'octagono' => 'Octágono del sentido',
	);

	/**
	 * Prefijo del transient donde vive el estado de cada operación, para
	 * poder reintentar solo lo que falló sin volver a crear nada.
	 */
	const TRANSIENT_PREFIX = 'au_wms_crear_empresa_';

	/**
	 * Cuánto se conserva el estado de una operación (y con él la
	 * posibilidad de reintentar).
	 */
	const TRANSIENT_TTL = HOUR_IN_SECONDS;

	/**
	 * Ejecuta el asistente completo: WMS primero y, solo si WMS salió
	 * bien, los programas externos y el webhook de credenciales.
	 *
	 * @param array $datos {
	 *     @type string[] $programas            Claves de PROGRAMAS seleccionadas.
	 *     @type array    $empresa              Campos del formulario de empresa.
	 *     @type int      $licencia_id          Licencia de Liderazgo (0 = sin licencia).
	 *     @type array    $areas_wms            Áreas de Liderazgo.
	 *     @type array    $areas_inspira        Áreas de Inspira.
	 *     @type array    $areas_octagono       Áreas de Octágono.
	 * }
	 * @return array Estado de la operación (ver `estado_inicial()`).
	 */
	public static function crear( array $datos ) {
		$programas = self::normalizar_programas( $datos['programas'] );

		if ( ! $programas ) {
			return array(
				'success' => false,
				'message' => __( 'Debes seleccionar al menos un programa.', 'au-wms' ),
			);
		}

		$empresa = self::aplicar_defaults( $datos['empresa'] );

		// La empresa y su usuario SIEMPRE se registran en WMS: con rol
		// 'company' si se eligió Liderazgo, o 'external_user' si no.
		$con_liderazgo = in_array( 'wms', $programas, true );
		$areas_wms     = $con_liderazgo ? $datos['areas_wms'] : array();
		$licencia_id   = $con_liderazgo ? (int) $datos['licencia_id'] : 0;

		$wms = self::crear_en_wms( $empresa, $licencia_id, $con_liderazgo, $areas_wms );

		if ( empty( $wms['success'] ) ) {
			// Sin usuario en WMS no se sigue: ni programas externos ni
			// webhook de credenciales (no hay credenciales que enviar).
			return array(
				'success'   => false,
				'message'   => $wms['message'],
				'wms'       => $wms,
				'programas' => array(),
			);
		}

		$estado = self::estado_inicial( $programas, $empresa, $wms, $datos );

		foreach ( array( 'inspira', 'octagono' ) as $programa ) {
			if ( in_array( $programa, $programas, true ) ) {
				$estado['programas'][ $programa ] = self::crear_en_programa( $programa, $estado );
			}
		}

		$estado['webhook'] = self::enviar_credenciales( $estado );
		$estado['success'] = self::todo_completo( $estado );

		self::guardar_estado( $estado );

		return $estado;
	}

	/**
	 * Reintenta una sola operación fallida de una creación anterior, sin
	 * volver a crear la empresa ni las áreas ya creadas.
	 *
	 * @param string $op_id    Identificador devuelto por `crear()`.
	 * @param string $objetivo 'inspira', 'octagono' o 'webhook'.
	 * @return array Estado actualizado, o error si no se puede reintentar.
	 */
	public static function reintentar( $op_id, $objetivo ) {
		$estado = self::leer_estado( $op_id );

		if ( ! $estado ) {
			return array(
				'success' => false,
				'message' => __( 'Esta operación ya no está disponible para reintentar. Vuelve a abrir el asistente.', 'au-wms' ),
			);
		}

		if ( 'webhook' === $objetivo ) {
			// Nunca se reenvía un webhook que ya respondió bien: evita
			// duplicar credenciales en el sistema receptor.
			if ( empty( $estado['webhook']['success'] ) ) {
				$estado['webhook'] = self::enviar_credenciales( $estado );
			}
		} elseif ( in_array( $objetivo, array( 'inspira', 'octagono' ), true ) ) {
			if ( ! in_array( $objetivo, $estado['programas_seleccionados'], true ) ) {
				return array(
					'success' => false,
					'message' => __( 'Ese programa no formaba parte de esta creación.', 'au-wms' ),
				);
			}

			// Igual que el webhook: un programa ya creado no se vuelve a
			// crear, se devuelve tal cual para no duplicar la empresa allá.
			if ( empty( $estado['programas'][ $objetivo ]['success'] ) ) {
				$estado['programas'][ $objetivo ] = self::crear_en_programa( $objetivo, $estado );
			}
		} else {
			return array(
				'success' => false,
				'message' => __( 'No se reconoce qué se quiere reintentar.', 'au-wms' ),
			);
		}

		$estado['success'] = self::todo_completo( $estado );

		self::guardar_estado( $estado );

		return $estado;
	}

	/**
	 * Arma el estado inicial de la operación, que es también lo que ve el
	 * JS y lo que se guarda para los reintentos.
	 *
	 * @param string[] $programas Programas seleccionados.
	 * @param array    $empresa   Datos finales de la empresa.
	 * @param array    $wms       Resultado de la creación en WMS.
	 * @param array    $datos     Datos crudos del asistente (áreas externas).
	 * @return array
	 */
	private static function estado_inicial( array $programas, array $empresa, array $wms, array $datos ) {
		return array(
			'success'                 => false,
			'op_id'                   => wp_generate_uuid4(),
			'programas_seleccionados' => $programas,
			'empresa'                 => $empresa,
			'wms'                     => $wms,
			'areas_externas'          => array(
				'inspira'  => $datos['areas_inspira'],
				'octagono' => $datos['areas_octagono'],
			),
			'programas'               => array(),
			'webhook'                 => array(),
		);
	}

	/**
	 * ¿Salió todo bien (programas externos + webhook)?
	 *
	 * @param array $estado Estado de la operación.
	 * @return bool
	 */
	private static function todo_completo( array $estado ) {
		foreach ( $estado['programas'] as $resultado ) {
			if ( empty( $resultado['success'] ) ) {
				return false;
			}
		}

		return ! empty( $estado['webhook']['success'] );
	}

	// ------------------------------------------------------------------
	// WMS
	// ------------------------------------------------------------------

	/**
	 * Crea (o asciende) el usuario-empresa en este sitio y, con
	 * Liderazgo, sus áreas.
	 *
	 * @param array $empresa       Datos ya completados con los defaults.
	 * @param int   $licencia_id   Licencia de Liderazgo (0 = ninguna).
	 * @param bool  $con_liderazgo true -> rol 'company'; false -> 'external_user'.
	 * @param array $areas         Áreas de Liderazgo a crear.
	 * @return array
	 */
	private static function crear_en_wms( array $empresa, $licencia_id, $con_liderazgo, array $areas ) {
		global $wpdb;

		// Mismo bloque check-then-act que UDA_Company::create(): sin
		// exclusión mutua, dos envíos simultáneos con el mismo nombre
		// pasan ambos las comprobaciones de unicidad antes de insertar.
		$lock_key = 'crear_empresa_' . md5( strtolower( $empresa['nombre_empresa'] ) );

		if ( ! AU_Cupos_Lock::adquirir( $lock_key ) ) {
			return array(
				'success' => false,
				'message' => __( 'El servidor está ocupado procesando otra empresa con el mismo nombre. Intenta de nuevo.', 'au-wms' ),
			);
		}

		try {
			$duplicado = self::validar_unicidad( $empresa, $wpdb );

			if ( $duplicado ) {
				return array( 'success' => false, 'message' => $duplicado );
			}

			if ( $licencia_id ) {
				$licencias_table = $wpdb->prefix . 'licencias';
				$existe          = (int) $wpdb->get_var(
					$wpdb->prepare( "SELECT COUNT(*) FROM {$licencias_table} WHERE id = %d", $licencia_id )
				);

				if ( ! $existe ) {
					return array(
						'success' => false,
						'message' => __( 'La licencia seleccionada no existe.', 'au-wms' ),
					);
				}
			}

			// Un correo que ya es de un external_user se asciende (misma
			// regla que la API); con cualquier otro rol es un conflicto.
			$existente = get_user_by( 'email', $empresa['email'] );

			if ( $existente && ! in_array( 'external_user', (array) $existente->roles, true ) ) {
				return array(
					'success' => false,
					'message' => __( 'Este correo electrónico ya pertenece a otro usuario.', 'au-wms' ),
				);
			}

			$password = self::generar_password();
			$metas    = self::metas_empresa( $empresa, $licencia_id );

			if ( $existente ) {
				$user_id = (int) $existente->ID;

				wp_update_user(
					array(
						'ID'         => $user_id,
						'nickname'   => $empresa['nombre_empresa'],
						'first_name' => $empresa['nombre_empresa'],
					)
				);

				wp_set_password( $password, $user_id );
			} else {
				$user_id = wp_insert_user(
					array(
						'user_login' => $empresa['email'],
						'user_pass'  => $password,
						'user_email' => $empresa['email'],
						'nickname'   => $empresa['nombre_empresa'],
						'first_name' => $empresa['nombre_empresa'],
					)
				);

				if ( is_wp_error( $user_id ) ) {
					return array( 'success' => false, 'message' => $user_id->get_error_message() );
				}

				$user_id = (int) $user_id;
			}

			foreach ( $metas as $meta_key => $meta_value ) {
				update_user_meta( $user_id, $meta_key, $meta_value );
			}

			$rol  = $con_liderazgo ? 'company' : 'external_user';
			$user = new WP_User( $user_id );
			$user->set_role( $rol );
		} finally {
			AU_Cupos_Lock::liberar( $lock_key );
		}

		// Las áreas van fuera del lock: ya no dependen del check-then-act
		// del nombre, y AU_Area_Service tiene su propio lock por área.
		$areas_creadas = array();

		foreach ( $areas as $area ) {
			$resultado = AU_Area_Service::crear(
				array(
					'empresa_id'  => $user_id,
					'nombre'      => $area['nombre'],
					'codigo'      => '',
					'cupos'       => $area['cupos'],
					'licencia_id' => $area['licencia_id'],
				)
			);

			$areas_creadas[] = array(
				'nombre'  => $area['nombre'],
				'cupos'   => $area['cupos'],
				'codigo'  => isset( $resultado['codigo'] ) ? $resultado['codigo'] : '',
				'success' => ! empty( $resultado['success'] ),
				'message' => isset( $resultado['message'] ) ? $resultado['message'] : '',
			);
		}

		return array(
			'success'        => true,
			'user_id'        => $user_id,
			'nombre_empresa' => $empresa['nombre_empresa'],
			'email'          => $empresa['email'],
			'password'       => $password,
			'rol'            => $rol,
			'rol_etiqueta'   => $con_liderazgo ? __( 'Company', 'au-wms' ) : __( 'External User', 'au-wms' ),
			'ascendido'      => (bool) $existente,
			'licencia_id'    => $licencia_id,
			'areas'          => $areas_creadas,
		);
	}

	/**
	 * Comprueba que el nombre de la empresa y el NIT no estén usados ya.
	 *
	 * @param array $empresa Datos de la empresa.
	 * @param wpdb  $wpdb    Instancia global de wpdb.
	 * @return string Mensaje de error, o '' si no hay duplicados.
	 */
	private static function validar_unicidad( array $empresa, $wpdb ) {
		$nombre_usado = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$wpdb->usermeta} WHERE meta_key = 'nombre_empresa' AND meta_value = %s",
				$empresa['nombre_empresa']
			)
		);

		if ( $nombre_usado > 0 ) {
			return __( 'Ya existe una empresa registrada con este nombre.', 'au-wms' );
		}

		$nit_usado = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$wpdb->usermeta} WHERE meta_key = 'nit_empresa' AND meta_value = %s",
				$empresa['nit_empresa']
			)
		);

		if ( $nit_usado > 0 ) {
			return __( 'Este NIT ya se encuentra registrado.', 'au-wms' );
		}

		return '';
	}

	/**
	 * Metadatos del usuario-empresa. Mismos que escriben el formulario
	 * "Registrar Empresa" y UDA_Company, salvo los de licencia, que solo
	 * se escriben cuando hay licencia de Liderazgo.
	 *
	 * @param array $empresa     Datos de la empresa.
	 * @param int   $licencia_id Licencia de Liderazgo (0 = ninguna).
	 * @return array<string,string>
	 */
	private static function metas_empresa( array $empresa, $licencia_id ) {
		$metas = array(
			'nombre_empresa'   => $empresa['nombre_empresa'],
			'nombre_encargado' => $empresa['nombre_encargado'],
			'last_name'        => $empresa['apellidos_encargado'],
			'contacto'         => $empresa['contacto'],
			'ocupacion'        => $empresa['ocupacion'],
			'nit_empresa'      => $empresa['nit_empresa'],
			'empresa'          => 'true',
			'created_by_api'   => 'true',
		);

		if ( $licencia_id ) {
			$metas['licencia']             = (string) $licencia_id;
			$metas['fecha_final_licencia'] = gmdate( 'd-m-Y', strtotime( '+365 days' ) );
			$metas['licencia_activa']      = 'true';
		}

		return $metas;
	}

	// ------------------------------------------------------------------
	// Programas externos
	// ------------------------------------------------------------------

	/**
	 * Crea la empresa y sus áreas en Inspira u Octágono.
	 *
	 * Cada API genera su propia contraseña y no acepta recibir una: lo
	 * único que se reutiliza de WMS son los datos de la empresa y el
	 * correo, de modo que la cuenta sea la misma persona en los tres
	 * sitios. Las contraseñas devueltas se guardan en el estado para
	 * mostrarlas en el resultado y enviarlas al webhook.
	 *
	 * @param string $programa 'inspira' u 'octagono'.
	 * @param array  $estado   Estado de la operación.
	 * @return array
	 */
	private static function crear_en_programa( $programa, array $estado ) {
		$empresa = $estado['empresa'];
		$areas   = $estado['areas_externas'][ $programa ];

		$payload = array(
			'nombre_empresa' => $empresa['nombre_empresa'],
			'user_email'     => $empresa['email'],
			'contacto'       => $empresa['contacto'],
			'ocupacion'      => $empresa['ocupacion'],
			'areas'          => array_map(
				function ( $area ) {
					return array(
						'nombre'           => $area['nombre'],
						'cupos'            => (int) $area['cupos'],
						'fecha_expiracion' => $area['fecha_expiracion'],
					);
				},
				$areas
			),
		);

		// Los contratos difieren: Inspira separa nombre y apellidos del
		// encargado; Octágono solo tiene `nombre_encargado`, así que allá
		// van juntos en ese campo.
		if ( 'inspira' === $programa ) {
			$payload['nombre_encargado'] = $empresa['nombre_encargado'];
			$payload['apellidos']        = $empresa['apellidos_encargado'];
		} else {
			$payload['nombre_encargado'] = trim( $empresa['nombre_encargado'] . ' ' . $empresa['apellidos_encargado'] );
		}

		return AU_Programas_Api_Client::crear_empresa( $programa, $payload );
	}

	// ------------------------------------------------------------------
	// Webhook de credenciales
	// ------------------------------------------------------------------

	/**
	 * Envía las credenciales al webhook configurado.
	 *
	 * Se manda siempre que el usuario de WMS exista, incluso con
	 * programas externos fallidos: el cuerpo incluye el estado por
	 * plataforma, así quien recibe distingue un resultado completo de
	 * uno parcial. Nunca viajan los tokens de las APIs.
	 *
	 * El correo y la contraseña de WMS van siempre, en `email`/`password`
	 * del nivel superior y repetidos dentro de `programas.wms`: son las
	 * únicas credenciales con las que se inicia sesión, da igual qué
	 * programas se hayan elegido.
	 *
	 * @param array $estado Estado de la operación.
	 * @return array {success:bool, message:string, codigo?:int}
	 */
	private static function enviar_credenciales( array $estado ) {
		$url = trim( (string) AU_Settings::get( 'crear_empresa_webhook_url', '' ) );

		if ( '' === $url ) {
			return array(
				'success' => false,
				'message' => __( 'No hay un webhook de credenciales configurado (Usuarios WMS → Configuración).', 'au-wms' ),
			);
		}

		// WMS va SIEMPRE, se haya elegido Liderazgo o no: la empresa y su
		// usuario se crean en WMS en todos los casos (con rol 'company' o
		// 'external_user') y el acceso a cualquier programa pasa por ahí,
		// así que quien recibe el webhook siempre encuentra la misma
		// clave. `liderazgo` distingue si se pidió el programa o si el
		// usuario existe solo para poder iniciar sesión.
		$programas = array(
			'wms' => array(
				'creado'    => true,
				'liderazgo' => in_array( 'wms', $estado['programas_seleccionados'], true ),
				'rol'       => $estado['wms']['rol'],
				'user_id'   => $estado['wms']['user_id'],
				'email'     => $estado['wms']['email'],
				'password'  => $estado['wms']['password'],
			),
		);

		foreach ( $estado['programas_seleccionados'] as $programa ) {
			if ( 'wms' === $programa ) {
				continue;
			}

			$resultado = isset( $estado['programas'][ $programa ] ) ? $estado['programas'][ $programa ] : array();

			$programas[ $programa ] = array(
				'creado'   => ! empty( $resultado['success'] ),
				'email'    => isset( $resultado['email'] ) ? $resultado['email'] : '',
				// Cada plataforma genera su propia contraseña (ninguna de
				// las dos APIs acepta recibir una), así que se entregan
				// todas: son credenciales distintas para el mismo correo.
				'password' => isset( $resultado['password'] ) ? $resultado['password'] : '',
				'mensaje'  => isset( $resultado['message'] ) ? $resultado['message'] : '',
			);
		}

		$body = array(
			'nombre_empresa' => $estado['empresa']['nombre_empresa'],
			'email'          => $estado['wms']['email'],
			'password'       => $estado['wms']['password'],
			'rol_wms'        => $estado['wms']['rol'],
			'programas'      => $programas,
			'completo'       => self::sin_fallos_externos( $estado ),
		);

		$respuesta = wp_remote_post(
			$url,
			array(
				'timeout' => 30,
				'headers' => array( 'Content-Type' => 'application/json' ),
				'body'    => wp_json_encode( $body ),
			)
		);

		if ( is_wp_error( $respuesta ) ) {
			// El mensaje de error de WordPress nunca incluye el cuerpo
			// enviado, así que no hay riesgo de registrar la contraseña.
			return array( 'success' => false, 'message' => $respuesta->get_error_message() );
		}

		$codigo = (int) wp_remote_retrieve_response_code( $respuesta );

		if ( $codigo < 200 || $codigo >= 300 ) {
			return array(
				'success' => false,
				'codigo'  => $codigo,
				/* translators: %d: HTTP status code. */
				'message' => sprintf( __( 'El webhook respondió con el código %d.', 'au-wms' ), $codigo ),
			);
		}

		return array(
			'success' => true,
			'codigo'  => $codigo,
			'message' => __( 'Credenciales enviadas al webhook.', 'au-wms' ),
		);
	}

	/**
	 * ¿Se crearon todos los programas externos seleccionados?
	 *
	 * @param array $estado Estado de la operación.
	 * @return bool
	 */
	private static function sin_fallos_externos( array $estado ) {
		foreach ( $estado['programas'] as $resultado ) {
			if ( empty( $resultado['success'] ) ) {
				return false;
			}
		}

		return true;
	}

	// ------------------------------------------------------------------
	// Valores por defecto y normalización
	// ------------------------------------------------------------------

	/**
	 * Completa con los valores de "Configuración" los campos de la
	 * empresa que llegaron vacíos. Lo escrito a mano siempre manda.
	 *
	 * @param array $empresa Campos del formulario (ya saneados).
	 * @return array Los mismos campos completos, más `defaults_aplicados`.
	 */
	public static function aplicar_defaults( array $empresa ) {
		$config   = AU_Settings::crear_empresa();
		$aplicados = array();

		$mapa = array(
			'nombre_encargado'    => 'crear_empresa_nombre_encargado',
			'apellidos_encargado' => 'crear_empresa_apellidos_encargado',
			'contacto'            => 'crear_empresa_contacto',
			'ocupacion'           => 'crear_empresa_ocupacion',
		);

		foreach ( $mapa as $campo => $clave_config ) {
			if ( '' === trim( (string) $empresa[ $campo ] ) ) {
				$empresa[ $campo ] = $config[ $clave_config ];
				$aplicados[]       = $campo;
			}
		}

		if ( '' === trim( (string) $empresa['nit_empresa'] ) ) {
			$empresa['nit_empresa'] = self::generar_nit_unico();
			$aplicados[]            = 'nit_empresa';
		}

		if ( '' === trim( (string) $empresa['email'] ) ) {
			$empresa['email'] = self::generar_email( $empresa['nombre_empresa'], $config['crear_empresa_email_plantilla'] );
			$aplicados[]      = 'email';
		}

		$empresa['defaults_aplicados'] = $aplicados;

		return $empresa;
	}

	/**
	 * Correo por defecto a partir del nombre de la empresa y la plantilla
	 * configurada (`admin.{nombre_empresa_normalizado}@wmslatam.com`).
	 *
	 * Normaliza igual que `UDA_Company::build_default_email()`:
	 * minúsculas, sin tildes ni ñ, sin la palabra "demo" (completa, sin
	 * distinguir mayúsculas) y sin caracteres especiales. Si el resultado
	 * queda vacío se usa un identificador de respaldo, y si el correo ya
	 * existe se le añade un sufijo numérico hasta encontrar uno libre.
	 *
	 * @param string $nombre_empresa Nombre de la empresa.
	 * @param string $plantilla      Plantilla con {nombre_empresa_normalizado}.
	 * @return string
	 */
	public static function generar_email( $nombre_empresa, $plantilla ) {
		$slug = self::normalizar_nombre( $nombre_empresa );

		if ( '' === $slug ) {
			$slug = 'empresa' . wp_rand( 100, 999 );
		}

		$plantilla = '' !== trim( (string) $plantilla )
			? $plantilla
			: AU_Settings::CAMPOS_CREAR_EMPRESA['crear_empresa_email_plantilla']['default'];

		$email  = str_replace( '{nombre_empresa_normalizado}', $slug, $plantilla );
		$base   = $email;
		$sufijo = 2;

		// El sufijo se añade al slug, no al final del correo entero, para
		// no romper el dominio: admin.acme2@wmslatam.com.
		while ( get_user_by( 'email', $email ) ) {
			$email = str_replace( '{nombre_empresa_normalizado}', $slug . $sufijo, $plantilla );

			if ( $email === $base ) {
				// La plantilla no tiene el marcador: se desiste y se
				// devuelve el correo tal cual (lo rechazará la validación
				// de duplicados, con un mensaje claro).
				break;
			}

			++$sufijo;
		}

		return $email;
	}

	/**
	 * Normaliza el nombre de la empresa para usarlo en un correo.
	 *
	 * @param string $nombre_empresa Nombre crudo.
	 * @return string Solo [a-z0-9], o '' si no queda nada.
	 */
	public static function normalizar_nombre( $nombre_empresa ) {
		$sin_demo    = preg_replace( '/\bdemo\b/iu', '', (string) $nombre_empresa );
		$sin_acentos = remove_accents( $sin_demo );
		$slug        = strtolower( preg_replace( '/[^a-zA-Z0-9]/', '', $sin_acentos ) );

		return substr( $slug, 0, 40 );
	}

	/**
	 * NIT aleatorio con el formato del resto del sitio (9 dígitos, guion
	 * y dígito de verificación) que no esté ya en uso.
	 *
	 * @return string
	 */
	public static function generar_nit_unico() {
		global $wpdb;

		do {
			$candidato = wp_rand( 100000000, 999999999 ) . '-' . wp_rand( 0, 9 );

			$existe = (int) $wpdb->get_var(
				$wpdb->prepare(
					"SELECT COUNT(*) FROM {$wpdb->usermeta} WHERE meta_key = 'nit_empresa' AND meta_value = %s",
					$candidato
				)
			);
		} while ( $existe > 0 );

		return $candidato;
	}

	/**
	 * Contraseña de 8 caracteres sin caracteres ambiguos (0/O, 1/I/l),
	 * igual que la que genera la API para que una credencial dictada por
	 * teléfono no se transcriba mal.
	 *
	 * @return string
	 */
	private static function generar_password() {
		$charset = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789';
		$max     = strlen( $charset ) - 1;
		$password = '';

		for ( $i = 0; $i < 8; $i++ ) {
			$password .= $charset[ random_int( 0, $max ) ];
		}

		return $password;
	}

	/**
	 * Deja solo los programas conocidos, en el orden de PROGRAMAS.
	 *
	 * @param mixed $programas Lista recibida del cliente.
	 * @return string[]
	 */
	private static function normalizar_programas( $programas ) {
		$programas = is_array( $programas ) ? $programas : array();

		return array_values( array_intersect( array_keys( self::PROGRAMAS ), $programas ) );
	}

	// ------------------------------------------------------------------
	// Estado de la operación (para reintentar)
	// ------------------------------------------------------------------

	/**
	 * Guarda el estado de la operación por usuario: así un reintento no
	 * puede tocar la operación de otro administrador.
	 *
	 * @param array $estado Estado completo.
	 * @return void
	 */
	private static function guardar_estado( array $estado ) {
		set_transient( self::clave_estado( $estado['op_id'] ), $estado, self::TRANSIENT_TTL );
	}

	/**
	 * Lee el estado de una operación anterior.
	 *
	 * @param string $op_id Identificador de la operación.
	 * @return array|null
	 */
	private static function leer_estado( $op_id ) {
		$estado = get_transient( self::clave_estado( $op_id ) );

		return is_array( $estado ) ? $estado : null;
	}

	/**
	 * Clave del transient, ligada al usuario que hizo la creación.
	 *
	 * @param string $op_id Identificador de la operación.
	 * @return string
	 */
	private static function clave_estado( $op_id ) {
		return self::TRANSIENT_PREFIX . get_current_user_id() . '_' . md5( (string) $op_id );
	}
}
