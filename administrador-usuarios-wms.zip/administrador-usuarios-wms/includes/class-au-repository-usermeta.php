<?php
/**
 * Repositorio de acceso a datos para `wp_usermeta`, usado por el modal
 * "Ver WP_USERMETA" del listado de Integrantes.
 *
 * Todas las operaciones de escritura (actualizar/eliminar) incluyen
 * `user_id` en su cláusula WHERE junto al `umeta_id`, de modo que un
 * `umeta_id` manipulado que pertenezca a otro usuario nunca afecta
 * registros ajenos (protección IDOR a nivel de consulta).
 *
 * @package Administrador_Usuarios_WMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AU_Repository_Usermeta {

	/**
	 * Claves de `wp_usermeta` consideradas sensibles/reservadas por
	 * WordPress, que no deben poder editarse ni eliminarse desde este
	 * panel genérico para evitar romper la cuenta del usuario.
	 *
	 * @return array<int,string>
	 */
	public static function claves_protegidas() {
		global $wpdb;

		return array(
			$wpdb->prefix . 'capabilities',
			$wpdb->prefix . 'user_level',
			$wpdb->prefix . 'user-settings',
			$wpdb->prefix . 'user-settings-time',
			'session_tokens',
		);
	}

	/**
	 * Indica si una meta_key está en la lista de claves protegidas.
	 *
	 * @param string $meta_key Meta key a verificar.
	 * @return bool
	 */
	public static function es_clave_protegida( $meta_key ) {
		return in_array( $meta_key, self::claves_protegidas(), true );
	}

	/**
	 * Busca los registros de `wp_usermeta` de un usuario, con búsqueda
	 * libre (meta_key o meta_value) y paginación nativa en SQL.
	 *
	 * @param int    $user_id  ID del usuario.
	 * @param string $search   Texto de búsqueda (opcional).
	 * @param int    $page     Página actual (1-indexed).
	 * @param int    $per_page Registros por página.
	 * @return array{items:array,total:int}
	 */
	public static function buscar( $user_id, $search, $page, $per_page ) {
		global $wpdb;

		$user_id  = absint( $user_id );
		$page     = max( 1, absint( $page ) );
		$per_page = in_array( absint( $per_page ), array( 10, 25, 50, 100 ), true ) ? absint( $per_page ) : 10;
		$offset   = ( $page - 1 ) * $per_page;

		$where  = 'user_id = %d';
		$params = array( $user_id );

		$search = trim( (string) $search );
		if ( '' !== $search ) {
			$like    = '%' . $wpdb->esc_like( $search ) . '%';
			$where  .= ' AND (meta_key LIKE %s OR meta_value LIKE %s)';
			$params[] = $like;
			$params[] = $like;
		}

		$total = (int) $wpdb->get_var(
			$wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->usermeta} WHERE {$where}", $params )
		);

		$select_params   = $params;
		$select_params[] = $per_page;
		$select_params[] = $offset;

		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT umeta_id, meta_key, meta_value FROM {$wpdb->usermeta} WHERE {$where} ORDER BY umeta_id DESC LIMIT %d OFFSET %d",
				$select_params
			),
			ARRAY_A
		);

		return array(
			'items' => $rows ? $rows : array(),
			'total' => $total,
		);
	}

	/**
	 * Obtiene un registro puntual, verificando que pertenezca al
	 * usuario indicado.
	 *
	 * @param int $umeta_id ID del registro (`umeta_id`).
	 * @param int $user_id  ID del usuario propietario esperado.
	 * @return array|null
	 */
	public static function obtener_por_id( $umeta_id, $user_id ) {
		global $wpdb;

		$row = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT umeta_id, user_id, meta_key, meta_value FROM {$wpdb->usermeta} WHERE umeta_id = %d AND user_id = %d",
				absint( $umeta_id ),
				absint( $user_id )
			),
			ARRAY_A
		);

		return $row ? $row : null;
	}

	/**
	 * Crea un nuevo registro de usermeta asociado a un usuario.
	 *
	 * @param int    $user_id    ID del usuario.
	 * @param string $meta_key   Meta key.
	 * @param string $meta_value Meta value.
	 * @return int ID del nuevo registro (`umeta_id`), o 0 si falló.
	 */
	public static function crear( $user_id, $meta_key, $meta_value ) {
		global $wpdb;

		$insertado = $wpdb->insert(
			$wpdb->usermeta,
			array(
				'user_id'    => absint( $user_id ),
				'meta_key'   => $meta_key,
				'meta_value' => $meta_value,
			),
			array( '%d', '%s', '%s' )
		);

		return $insertado ? (int) $wpdb->insert_id : 0;
	}

	/**
	 * Actualiza un registro existente, exigiendo que pertenezca al
	 * usuario indicado.
	 *
	 * @param int    $umeta_id   ID del registro.
	 * @param int    $user_id    ID del usuario propietario esperado.
	 * @param string $meta_key   Nuevo meta key.
	 * @param string $meta_value Nuevo meta value.
	 * @return bool
	 */
	public static function actualizar( $umeta_id, $user_id, $meta_key, $meta_value ) {
		global $wpdb;

		$actualizado = $wpdb->update(
			$wpdb->usermeta,
			array(
				'meta_key'   => $meta_key,
				'meta_value' => $meta_value,
			),
			array(
				'umeta_id' => absint( $umeta_id ),
				'user_id'  => absint( $user_id ),
			),
			array( '%s', '%s' ),
			array( '%d', '%d' )
		);

		return false !== $actualizado;
	}

	/**
	 * Elimina un registro, exigiendo que pertenezca al usuario indicado.
	 *
	 * @param int $umeta_id ID del registro.
	 * @param int $user_id  ID del usuario propietario esperado.
	 * @return bool
	 */
	public static function eliminar( $umeta_id, $user_id ) {
		global $wpdb;

		$eliminado = $wpdb->delete(
			$wpdb->usermeta,
			array(
				'umeta_id' => absint( $umeta_id ),
				'user_id'  => absint( $user_id ),
			),
			array( '%d', '%d' )
		);

		return false !== $eliminado && $eliminado > 0;
	}
}
