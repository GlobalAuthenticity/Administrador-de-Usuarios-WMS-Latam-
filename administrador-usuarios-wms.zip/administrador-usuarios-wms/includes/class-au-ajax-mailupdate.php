<?php
/**
 * Controlador AJAX para la actualización masiva de correos (modal
 * "Actualizar correos" dentro del Tab Integrantes).
 *
 * @package Administrador_Usuarios_WMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AU_Ajax_Mail_Update {

	/**
	 * Instancia única (singleton).
	 *
	 * @var AU_Ajax_Mail_Update|null
	 */
	private static $instance = null;

	/**
	 * Extensiones de archivo permitidas para este asistente (el
	 * requerimiento solo contempla Excel, a diferencia del asistente
	 * de importación que también acepta CSV).
	 *
	 * @var array<int,string>
	 */
	const EXTENSIONES_PERMITIDAS = array( 'xls', 'xlsx' );

	/**
	 * Devuelve la instancia única y engancha las acciones AJAX.
	 *
	 * @return AU_Ajax_Mail_Update
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
			self::$instance->register_hooks();
		}

		return self::$instance;
	}

	/**
	 * Registra los endpoints AJAX del asistente.
	 *
	 * @return void
	 */
	private function register_hooks() {
		add_action( 'wp_ajax_au_wms_mailupdate_upload', array( $this, 'handle_upload' ) );
		add_action( 'wp_ajax_au_wms_mailupdate_validar', array( $this, 'handle_validar' ) );
		add_action( 'wp_ajax_au_wms_mailupdate_procesar_lote', array( $this, 'handle_procesar_lote' ) );
	}

	/**
	 * Recibe el archivo subido (XLS/XLSX), lo parsea y devuelve los
	 * encabezados detectados para que el administrador elija las
	 * columnas de correo actual y correo nuevo.
	 *
	 * @return void
	 */
	public function handle_upload() {
		AU_Security::guard();

		if ( empty( $_FILES['archivo'] ) || UPLOAD_ERR_OK !== $_FILES['archivo']['error'] ) {
			wp_send_json_error( array( 'message' => __( 'No se recibió ningún archivo válido.', 'au-wms' ) ) );
		}

		$nombre_original = sanitize_file_name( $_FILES['archivo']['name'] );
		$extension       = strtolower( pathinfo( $nombre_original, PATHINFO_EXTENSION ) );

		if ( ! in_array( $extension, self::EXTENSIONES_PERMITIDAS, true ) ) {
			wp_send_json_error( array( 'message' => __( 'Solo se permiten archivos XLS o XLSX.', 'au-wms' ) ) );
		}

		if ( ! function_exists( 'wp_handle_upload' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
		}

		$archivo_subido = wp_handle_upload(
			$_FILES['archivo'],
			array(
				'test_form' => false,
				'mimes'     => array(
					'xls'  => 'application/vnd.ms-excel',
					'xlsx' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
				),
			)
		);

		if ( isset( $archivo_subido['error'] ) ) {
			wp_send_json_error( array( 'message' => $archivo_subido['error'] ) );
		}

		try {
			$parseado = AU_File_Parser::parse( $archivo_subido['file'], $extension );
		} catch ( Exception $e ) {
			wp_delete_file( $archivo_subido['file'] );
			wp_send_json_error( array( 'message' => $e->getMessage() ) );
		}

		// El archivo ya fue leído en memoria; no es necesario conservarlo.
		wp_delete_file( $archivo_subido['file'] );

		if ( empty( $parseado['rows'] ) ) {
			wp_send_json_error( array( 'message' => __( 'El archivo no contiene filas de datos.', 'au-wms' ) ) );
		}

		$update_id = AU_Mail_Update_Validator::guardar_archivo_parseado( $parseado['headers'], $parseado['rows'] );

		wp_send_json_success(
			array(
				'update_id'   => $update_id,
				'headers'     => $parseado['headers'],
				'total_filas' => count( $parseado['rows'] ),
			)
		);
	}

	/**
	 * Ejecuta la validación previa (sin escribir en base de datos) y
	 * devuelve la tabla de previsualización completa + resumen.
	 *
	 * @return void
	 */
	public function handle_validar() {
		AU_Security::guard();

		$update_id  = isset( $_POST['update_id'] ) ? AU_Security::sanitize_text( $_POST['update_id'] ) : '';
		$col_actual = isset( $_POST['col_actual'] ) ? $_POST['col_actual'] : '';
		$col_nuevo  = isset( $_POST['col_nuevo'] ) ? $_POST['col_nuevo'] : '';

		if ( '' === $col_actual || '' === $col_nuevo ) {
			wp_send_json_error( array( 'message' => __( 'Debes seleccionar la columna de correo actual y la de correo nuevo.', 'au-wms' ) ) );
		}

		try {
			$resultado = AU_Mail_Update_Validator::validar( $update_id, absint( $col_actual ), absint( $col_nuevo ) );
		} catch ( Exception $e ) {
			wp_send_json_error( array( 'message' => $e->getMessage() ) );
		}

		wp_send_json_success( $resultado );
	}

	/**
	 * Procesa un lote de la actualización ya validada.
	 *
	 * @return void
	 */
	public function handle_procesar_lote() {
		AU_Security::guard();

		$update_id        = isset( $_POST['update_id'] ) ? AU_Security::sanitize_text( $_POST['update_id'] ) : '';
		$offset           = isset( $_POST['offset'] ) ? AU_Security::sanitize_int( $_POST['offset'] ) : 0;
		$batch_size       = isset( $_POST['batch_size'] ) ? AU_Security::sanitize_int( $_POST['batch_size'] ) : 20;
		$generar_password = ! empty( $_POST['generar_password'] ) && 'true' === $_POST['generar_password'];

		// Límite subido de 50 a 100: cada lote es una petición AJAX
		// completa (arranque de WordPress + bootstrap del plugin), así
		// que con actualizaciones grandes (100+ correos) conviene menos
		// idas y vueltas por red aunque cada una procese más filas.
		$batch_size = max( 1, min( 100, $batch_size ) );

		try {
			$resultado = AU_Mail_Update_Service::procesar_lote( $update_id, $offset, $batch_size, $generar_password );
		} catch ( Exception $e ) {
			wp_send_json_error( array( 'message' => $e->getMessage() ) );
		}

		wp_send_json_success( $resultado );
	}
}
