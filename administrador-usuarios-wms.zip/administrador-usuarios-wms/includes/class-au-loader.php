<?php
/**
 * Clase responsable de cargar todas las dependencias del plugin y
 * arrancar los componentes (Admin, Ajax, Servicios, Repositorios).
 *
 * @package Administrador_Usuarios_WMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AU_Loader {

	/**
	 * Bandera para evitar doble inicialización.
	 *
	 * @var bool
	 */
	private static $initialized = false;

	/**
	 * Inicializa el plugin: incluye archivos y engancha los componentes.
	 *
	 * @return void
	 */
	public static function init() {
		if ( self::$initialized ) {
			return;
		}
		self::$initialized = true;

		self::load_dependencies();

		// Componentes de administración (menú, tabs, assets).
		AU_Admin::instance();

		// Controlador de peticiones AJAX.
		AU_Ajax::instance();

		// Controlador AJAX del asistente de importación masiva.
		AU_Ajax_Importacion::instance();

		// Controlador AJAX del asistente "Actualizar correos" (Tab Integrantes).
		AU_Ajax_Mail_Update::instance();

		// Controlador AJAX de la página de Configuración.
		AU_Ajax_Settings::instance();

		// Controlador AJAX del modal "Ver WP_USERMETA".
		AU_Ajax_Usermeta::instance();

		// Controlador AJAX del modal "Áreas del usuario" (Tab Integrantes).
		AU_Ajax_Areas_Usuario::instance();

		// Controlador AJAX del Tab "Empresas".
		AU_Ajax_Empresas::instance();

		// Controlador AJAX del modal "Licencias" (dropdown "Acciones" del
		// Tab Empresas).
		AU_Ajax_Licencias::instance();

		// Controlador AJAX del modal "Resetear contraseñas" (Tab Empresas).
		AU_Ajax_Reset_Password::instance();

		// Controlador AJAX del modal "Exportar usuarios" (Tab Empresas).
		AU_Ajax_Exportar_Usuarios::instance();

		// Controlador AJAX del modal "Comparar usuarios" (Tab Empresas).
		AU_Ajax_Comparar_Usuarios::instance();

		// Controlador AJAX del Tab "Usuarios Externos".
		AU_Ajax_Usuarios_Externos::instance();

		// Controlador AJAX de "Refrescar programas" (Tab Empresas).
		AU_Ajax_Sync_Programas::instance();

		// Controlador AJAX de "Descargar resultado" (Tab Integrantes).
		AU_Ajax_Resultado_Test::instance();

		// Controlador AJAX del asistente "Crear Empresa" (Tab Empresas).
		AU_Ajax_Crear_Empresa::instance();

		// "Volver al administrador" tras impersonar a un usuario
		// (Tab Empresas y Tab Integrantes comparten el mismo flujo de
		// impersonación, así que un solo registro cubre ambos).
		AU_Impersonation_Service::init_hooks();

		// Bloquea el inicio de sesión de los usuarios marcados como
		// "acceso deshabilitado" (meta_key `au_wms_login_disabled`).
		// Prioridad 30: se ejecuta DESPUÉS de que WordPress ya validó
		// usuario/contraseña (wp_authenticate_username_password corre en
		// prioridad 20), para poder anular un login que de otro modo
		// habría sido válido.
		add_filter( 'authenticate', array( __CLASS__, 'bloquear_login_si_deshabilitado' ), 30, 1 );
	}

	/**
	 * Filtro `authenticate`: si el usuario autenticado tiene el
	 * meta_key `au_wms_login_disabled`, reemplaza el resultado por un
	 * error, impidiendo el inicio de sesión.
	 *
	 * @param WP_User|WP_Error|null $user Usuario autenticado (o error) hasta este punto.
	 * @return WP_User|WP_Error|null
	 */
	public static function bloquear_login_si_deshabilitado( $user ) {
		if ( ! ( $user instanceof WP_User ) ) {
			return $user;
		}

		if ( metadata_exists( 'user', $user->ID, 'au_wms_login_disabled' ) ) {
			return new WP_Error(
				'au_wms_acceso_deshabilitado',
				__( '<strong>Error</strong>: tu acceso a esta cuenta ha sido deshabilitado. Contacta al administrador si crees que esto es un error.', 'au-wms' )
			);
		}

		return $user;
	}

	/**
	 * Incluye los archivos de clases del plugin en el orden correcto
	 * (repositorios y servicios primero, luego los consumidores).
	 *
	 * @return void
	 */
	private static function load_dependencies() {
		$includes = array(
			'includes/class-au-security.php',
			'includes/class-au-password-generator.php',
			'includes/class-au-settings.php',
			'includes/class-au-repository-empresas.php',
			'includes/class-au-repository-licencias.php',
			'includes/class-au-empresa-actions-service.php',
			'includes/class-au-repository-usuarios.php',
			'includes/class-au-reset-password-service.php',
			'includes/class-au-repository-usuarios-externos.php',
			'includes/class-au-repository-usermeta.php',
			'includes/class-au-coupon-service.php',
			'includes/class-au-area-service.php',
			'includes/class-au-area-usuario-service.php',
			'includes/class-au-user-service.php',
			'includes/class-au-impersonation-service.php',
			'includes/class-au-file-parser.php',
			'includes/class-au-column-mapper.php',
			'includes/class-au-import-validator.php',
			'includes/class-au-mailupdate-validator.php',
			'includes/class-au-mailupdate-service.php',
			'includes/class-au-cupos-lock.php',
			'includes/class-au-webhook-service.php',
			'includes/class-au-import-service.php',
			'includes/class-au-sync-programas-service.php',
			'includes/class-au-programas-api-client.php',
			'includes/class-au-crear-empresa-service.php',
			'includes/class-au-admin.php',
			'includes/class-au-ajax.php',
			'includes/class-au-ajax-importacion.php',
			'includes/class-au-ajax-mailupdate.php',
			'includes/class-au-ajax-settings.php',
			'includes/class-au-ajax-usermeta.php',
			'includes/class-au-ajax-areas-usuario.php',
			'includes/class-au-ajax-empresas.php',
			'includes/class-au-ajax-licencias.php',
			'includes/class-au-ajax-reset-password.php',
			'includes/class-au-ajax-exportar-usuarios.php',
			'includes/class-au-ajax-comparar-usuarios.php',
			'includes/class-au-ajax-usuarios-externos.php',
			'includes/class-au-ajax-sync-programas.php',
			'includes/class-au-ajax-resultado-test.php',
			'includes/class-au-ajax-crear-empresa.php',
		);

		foreach ( $includes as $relative_path ) {
			$path = AU_WMS_PLUGIN_DIR . $relative_path;
			if ( file_exists( $path ) ) {
				require_once $path;
			}
		}
	}
}
