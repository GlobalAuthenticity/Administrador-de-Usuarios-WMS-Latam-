<?php
/**
 * Controlador AJAX del modal "Comparar usuarios" (Tab Empresas).
 *
 * @package Administrador_Usuarios_WMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AU_Ajax_Comparar_Usuarios {

	/**
	 * Límite defensivo de correos por petición: el input es de texto
	 * libre pegado por el usuario, así que se acota para evitar una
	 * consulta desproporcionada por error o abuso.
	 */
	const MAX_CORREOS = 2000;

	/**
	 * Instancia única (singleton).
	 *
	 * @var AU_Ajax_Comparar_Usuarios|null
	 */
	private static $instance = null;

	/**
	 * Devuelve la instancia única y engancha las acciones AJAX.
	 *
	 * @return AU_Ajax_Comparar_Usuarios
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
			self::$instance->register_hooks();
		}

		return self::$instance;
	}

	/**
	 * Registra el endpoint AJAX del modal.
	 *
	 * @return void
	 */
	private function register_hooks() {
		add_action( 'wp_ajax_au_wms_comparar_usuarios_verificar', array( $this, 'handle_verificar' ) );
	}

	/**
	 * Recibe una lista de correos y devuelve, para cada uno, si
	 * pertenece a la empresa indicada y a qué área(s).
	 *
	 * @return void
	 */
	public function handle_verificar() {
		AU_Security::guard();

		$empresa_id = isset( $_POST['empresa_id'] ) ? AU_Security::sanitize_int( $_POST['empresa_id'] ) : 0;

		$correos = array();
		if ( isset( $_POST['correos'] ) && is_array( $_POST['correos'] ) ) {
			$correos = array_map( 'sanitize_text_field', wp_unslash( $_POST['correos'] ) );
		}

		if ( ! $empresa_id || ! get_userdata( $empresa_id ) ) {
			wp_send_json_error( array( 'message' => __( 'La empresa seleccionada no existe.', 'au-wms' ) ) );
		}

		if ( empty( $correos ) ) {
			wp_send_json_error( array( 'message' => __( 'Agrega al menos un correo para continuar.', 'au-wms' ) ) );
		}

		if ( count( $correos ) > self::MAX_CORREOS ) {
			$correos = array_slice( $correos, 0, self::MAX_CORREOS );
		}

		$resultado = AU_Repository_Usuarios::verificar_pertenencia_por_correo( $empresa_id, $correos );

		wp_send_json_success( array( 'resultado' => $resultado ) );
	}
}
