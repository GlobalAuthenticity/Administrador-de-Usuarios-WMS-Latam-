<?php
/**
 * Controlador AJAX del asistente "Crear Empresa" (Tab Empresas).
 *
 * Saneado y validación de servidor de todo lo que llega del asistente;
 * la lógica vive en `AU_Crear_Empresa_Service`.
 *
 * @package Administrador_Usuarios_WMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AU_Ajax_Crear_Empresa {

	/**
	 * Instancia única (singleton).
	 *
	 * @var AU_Ajax_Crear_Empresa|null
	 */
	private static $instance = null;

	/**
	 * Mensaje de la primera fecha de expiración inválida encontrada al
	 * leer las áreas, para poder decir cuál es sin abortar a medias la
	 * lectura del arreglo.
	 *
	 * @var string
	 */
	private $error_fecha = '';

	/**
	 * Devuelve la instancia única y engancha las acciones AJAX.
	 *
	 * @return AU_Ajax_Crear_Empresa
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
			add_action( 'wp_ajax_au_wms_crear_empresa', array( self::$instance, 'handle_crear' ) );
			add_action( 'wp_ajax_au_wms_crear_empresa_reintentar', array( self::$instance, 'handle_reintentar' ) );
			add_action( 'wp_ajax_au_wms_crear_empresa_previsualizar', array( self::$instance, 'handle_previsualizar' ) );
		}

		return self::$instance;
	}

	/**
	 * Paso "Resumen": devuelve los datos finales (con los valores por
	 * defecto ya aplicados y el correo que se usará) SIN crear nada.
	 *
	 * El correo y el NIT se calculan aquí y no en el navegador porque
	 * dependen de lo que ya exista en la base de datos.
	 *
	 * @return void
	 */
	public function handle_previsualizar() {
		AU_Security::guard();

		$empresa = AU_Crear_Empresa_Service::aplicar_defaults( $this->leer_empresa() );

		if ( '' === $empresa['nombre_empresa'] ) {
			wp_send_json_error( array( 'message' => __( 'El nombre de la empresa es obligatorio.', 'au-wms' ) ) );
		}

		wp_send_json_success( array( 'empresa' => $empresa ) );
	}

	/**
	 * Crea la empresa en los programas seleccionados y envía las
	 * credenciales al webhook.
	 *
	 * @return void
	 */
	public function handle_crear() {
		AU_Security::guard();

		$programas = isset( $_POST['programas'] ) ? (array) wp_unslash( $_POST['programas'] ) : array();
		$programas = array_map( 'sanitize_key', $programas );

		if ( ! $programas ) {
			wp_send_json_error( array( 'message' => __( 'Debes seleccionar al menos un programa.', 'au-wms' ) ) );
		}

		$empresa = $this->leer_empresa();

		if ( '' === $empresa['nombre_empresa'] ) {
			wp_send_json_error( array( 'message' => __( 'El nombre de la empresa es obligatorio.', 'au-wms' ) ) );
		}

		if ( '' !== $empresa['email'] && ! is_email( $empresa['email'] ) ) {
			wp_send_json_error( array( 'message' => __( 'El correo electrónico no tiene un formato válido.', 'au-wms' ) ) );
		}

		$areas_wms      = $this->leer_areas( 'areas_wms', false );
		$areas_inspira  = $this->leer_areas( 'areas_inspira', true );
		$areas_octagono = $this->leer_areas( 'areas_octagono', true );

		// Igual que las dos APIs externas: una sola área mal formada
		// rechaza la petición completa, antes de crear nada.
		if ( '' !== $this->error_fecha ) {
			wp_send_json_error( array( 'message' => $this->error_fecha ) );
		}

		// Cada programa seleccionado necesita al menos un área válida:
		// se valida todo antes de tocar nada, igual que hacen las dos
		// APIs externas con su arreglo de áreas.
		$requeridas = array(
			'wms'      => $areas_wms,
			'inspira'  => $areas_inspira,
			'octagono' => $areas_octagono,
		);

		foreach ( $requeridas as $programa => $areas ) {
			if ( in_array( $programa, $programas, true ) && ! $areas ) {
				wp_send_json_error(
					array(
						'message' => sprintf(
							/* translators: %s: program name. */
							__( 'Debes definir al menos un área válida para %s.', 'au-wms' ),
							AU_Crear_Empresa_Service::PROGRAMAS[ $programa ]
						),
					)
				);
			}
		}

		$resultado = AU_Crear_Empresa_Service::crear(
			array(
				'programas'      => $programas,
				'empresa'        => $empresa,
				'licencia_id'    => isset( $_POST['licencia_id'] ) ? AU_Security::sanitize_int( $_POST['licencia_id'] ) : 0,
				'areas_wms'      => $areas_wms,
				'areas_inspira'  => $areas_inspira,
				'areas_octagono' => $areas_octagono,
			)
		);

		// Un fallo de WMS es el único que corta por completo: no hay
		// empresa que mostrar ni credenciales que entregar.
		if ( empty( $resultado['wms']['success'] ) ) {
			wp_send_json_error( array( 'message' => $resultado['message'] ) );
		}

		wp_send_json_success( $resultado );
	}

	/**
	 * Reintenta solo una operación fallida (un programa externo o el
	 * webhook) de una creación anterior.
	 *
	 * @return void
	 */
	public function handle_reintentar() {
		AU_Security::guard();

		$op_id    = isset( $_POST['op_id'] ) ? sanitize_text_field( wp_unslash( $_POST['op_id'] ) ) : '';
		$objetivo = isset( $_POST['objetivo'] ) ? sanitize_key( wp_unslash( $_POST['objetivo'] ) ) : '';

		if ( '' === $op_id ) {
			wp_send_json_error( array( 'message' => __( 'Falta la referencia de la operación.', 'au-wms' ) ) );
		}

		$resultado = AU_Crear_Empresa_Service::reintentar( $op_id, $objetivo );

		if ( isset( $resultado['success'] ) && false === $resultado['success'] && ! isset( $resultado['wms'] ) ) {
			wp_send_json_error( array( 'message' => $resultado['message'] ) );
		}

		wp_send_json_success( $resultado );
	}

	/**
	 * Campos de la empresa, saneados.
	 *
	 * @return array
	 */
	private function leer_empresa() {
		$campos = array(
			'nombre_empresa',
			'nit_empresa',
			'nombre_encargado',
			'apellidos_encargado',
			'contacto',
			'ocupacion',
		);

		$empresa = array();

		foreach ( $campos as $campo ) {
			$empresa[ $campo ] = isset( $_POST[ $campo ] ) ? AU_Security::sanitize_text( $_POST[ $campo ] ) : '';
		}

		$empresa['email'] = isset( $_POST['email'] ) ? sanitize_email( wp_unslash( $_POST['email'] ) ) : '';

		return $empresa;
	}

	/**
	 * Áreas de un programa, saneadas y filtrando las inválidas.
	 *
	 * @param string $campo          Clave del POST con el JSON de áreas.
	 * @param bool   $con_expiracion true para Inspira/Octágono (fecha), false para Liderazgo (licencia).
	 * @return array
	 */
	private function leer_areas( $campo, $con_expiracion ) {
		$crudo  = isset( $_POST[ $campo ] ) ? wp_unslash( $_POST[ $campo ] ) : '[]';
		$filas  = json_decode( $crudo, true );
		$filas  = is_array( $filas ) ? $filas : array();
		$areas  = array();

		foreach ( $filas as $fila ) {
			$fila   = is_array( $fila ) ? $fila : array();
			$nombre = sanitize_text_field( (string) ( $fila['nombre'] ?? '' ) );

			if ( '' === $nombre ) {
				continue;
			}

			$cupos = absint( $fila['cupos'] ?? 0 );
			$area  = array(
				'nombre' => $nombre,
				'cupos'  => $cupos > 0 ? $cupos : 1,
			);

			if ( $con_expiracion ) {
				$fecha = sanitize_text_field( (string) ( $fila['fecha_expiracion'] ?? '' ) );

				// Las dos APIs externas exigen YYYY-MM-DD y rechazan una
				// fecha anterior a hoy. Vacía se completa con el plazo
				// configurado; escrita pero inválida se avisa, no se
				// sustituye en silencio por otra distinta a la que puso
				// el administrador.
				if ( '' === $fecha ) {
					$area['fecha_expiracion'] = self::fecha_expiracion_por_defecto();
				} elseif ( $this->fecha_valida( $fecha ) ) {
					$area['fecha_expiracion'] = $fecha;
				} else {
					$this->error_fecha = sprintf(
						/* translators: %s: area name. */
						__( 'La fecha de expiración del área "%s" no es válida o es anterior a hoy.', 'au-wms' ),
						$nombre
					);

					return array();
				}
			} else {
				$area['licencia_id'] = absint( $fila['licencia_id'] ?? 0 );
			}

			$areas[] = $area;
		}

		return $areas;
	}

	/**
	 * ¿Es una fecha YYYY-MM-DD real y no anterior a hoy?
	 *
	 * @param string $fecha Fecha recibida.
	 * @return bool
	 */
	private function fecha_valida( $fecha ) {
		if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $fecha ) ) {
			return false;
		}

		$partes = explode( '-', $fecha );

		if ( ! checkdate( (int) $partes[1], (int) $partes[2], (int) $partes[0] ) ) {
			return false;
		}

		return $fecha >= current_time( 'Y-m-d' );
	}

	/**
	 * Fecha de expiración por defecto: hoy + los meses configurados, en
	 * la zona horaria de WordPress.
	 *
	 * @return string YYYY-MM-DD
	 */
	public static function fecha_expiracion_por_defecto() {
		$meses = (int) AU_Settings::get( 'crear_empresa_area_meses_expiracion', 6 );
		$meses = $meses > 0 ? $meses : 6;

		$fecha = new DateTimeImmutable( current_time( 'Y-m-d' ) );

		return $fecha->modify( '+' . $meses . ' months' )->format( 'Y-m-d' );
	}
}
