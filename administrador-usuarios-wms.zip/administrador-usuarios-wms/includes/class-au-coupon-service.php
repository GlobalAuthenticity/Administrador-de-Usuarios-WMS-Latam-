<?php
/**
 * Servicio encargado de mantener sincronizado el contador de usos de
 * los cupones de WooCommerce con los registros reales existentes en
 * `wp_correos_configurados`.
 *
 * Regla de negocio: nunca se decrementa manualmente el contador, siempre
 * se recalcula desde la base de datos para evitar inconsistencias.
 *
 * @package Administrador_Usuarios_WMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AU_Coupon_Service {

	/**
	 * Recalcula y sincroniza el `usage_count` del cupón de WooCommerce
	 * asociado a un `codigo_area`.
	 *
	 * @param string $codigo_area Código de área/paquete.
	 * @return void
	 */
	public static function recalcular_por_codigo_area( $codigo_area ) {
		$paquete = AU_Repository_Empresas::get_paquete_por_codigo( $codigo_area );

		if ( empty( $paquete['cupon_id'] ) ) {
			// El paquete no tiene un cupón de WooCommerce asociado.
			return;
		}

		$cupon_id = absint( $paquete['cupon_id'] );

		if ( ! function_exists( 'wc_get_coupon_id_by_code' ) && ! class_exists( 'WC_Coupon' ) ) {
			// WooCommerce no está activo; nada que sincronizar.
			return;
		}

		$consumos_reales = AU_Repository_Usuarios::contar_por_codigo_area( $codigo_area );

		try {
			$coupon = new WC_Coupon( $cupon_id );

			if ( ! $coupon->get_id() ) {
				return;
			}

			$coupon->set_usage_count( $consumos_reales );
			$coupon->save();
		} catch ( Exception $e ) {
			// Se registra en el log de errores de WordPress sin interrumpir
			// el flujo de eliminación del usuario.
			if ( function_exists( 'error_log' ) ) {
				error_log(
					sprintf(
						'[AU-WMS] Error al recalcular cupón #%d (codigo_area: %s): %s',
						$cupon_id,
						$codigo_area,
						$e->getMessage()
					)
				);
			}
		}
	}

	/**
	 * Recalcula todos los cupones afectados por la eliminación de un
	 * usuario (uno por cada `codigo_area` que tenía asignado).
	 *
	 * @param array<int,string> $codigos_area Lista de códigos de área.
	 * @return void
	 */
	public static function recalcular_multiples( array $codigos_area ) {
		foreach ( array_unique( $codigos_area ) as $codigo_area ) {
			self::recalcular_por_codigo_area( $codigo_area );
		}
	}
}
