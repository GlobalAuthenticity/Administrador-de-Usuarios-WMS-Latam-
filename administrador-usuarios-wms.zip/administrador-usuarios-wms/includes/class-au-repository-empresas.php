<?php
/**
 * Repositorio de acceso a datos para Empresas (usuarios con rol `company`)
 * y sus Áreas/Paquetes (tabla `wp_paquetes`).
 *
 * Toda consulta usa $wpdb->prepare() y evita ciclos con consultas N+1.
 *
 * @package Administrador_Usuarios_WMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AU_Repository_Empresas {

	/**
	 * Devuelve el listado de empresas (usuarios con rol `company`).
	 *
	 * @return array<int, array{id:int,nombre:string}>
	 */
	public static function get_empresas() {
		global $wpdb;

		$cache_key = 'au_wms_empresas_list';
		$cached    = wp_cache_get( $cache_key, 'au_wms' );
		if ( false !== $cached ) {
			return $cached;
		}

		$capabilities_key = $wpdb->prefix . 'capabilities';

		$sql = "
			SELECT u.ID AS id,
			       u.display_name AS display_name,
			       u.user_login AS user_login
			FROM {$wpdb->users} u
			INNER JOIN {$wpdb->usermeta} um
			        ON um.user_id = u.ID
			       AND um.meta_key = %s
			WHERE um.meta_value LIKE %s
			ORDER BY u.display_name ASC
		";

		$like  = '%' . $wpdb->esc_like( 's:7:"company"' ) . '%';
		$query = $wpdb->prepare( $sql, $capabilities_key, $like );
		$rows  = $wpdb->get_results( $query, ARRAY_A );

		$empresas = array();
		foreach ( (array) $rows as $row ) {
			$empresas[] = array(
				'id'     => (int) $row['id'],
				'nombre' => $row['display_name'] ? $row['display_name'] : $row['user_login'],
			);
		}

		wp_cache_set( $cache_key, $empresas, 'au_wms', 5 * MINUTE_IN_SECONDS );

		return $empresas;
	}

	/**
	 * Devuelve los paquetes (áreas) pertenecientes a una empresa.
	 *
	 * @param int $empresa_id ID de la empresa (wp_users.ID).
	 * @return array<int, array{id:int,nombre:string,codigo:string}>
	 */
	public static function get_paquetes_por_empresa( $empresa_id ) {
		global $wpdb;

		$empresa_id = absint( $empresa_id );
		if ( ! $empresa_id ) {
			return array();
		}

		$table = $wpdb->prefix . 'paquetes';

		$sql  = "
			SELECT id, nombre, codigo
			FROM {$table}
			WHERE empresa_id = %d
			ORDER BY nombre ASC
		";
		$rows = $wpdb->get_results( $wpdb->prepare( $sql, $empresa_id ), ARRAY_A );

		$paquetes = array();
		foreach ( (array) $rows as $row ) {
			$paquetes[] = array(
				'id'     => (int) $row['id'],
				'nombre' => $row['nombre'],
				'codigo' => $row['codigo'],
			);
		}

		return $paquetes;
	}

	/**
	 * Obtiene un paquete por su código (usado al recalcular cupones).
	 *
	 * @param string $codigo Código del paquete.
	 * @return array|null
	 */
	public static function get_paquete_por_codigo( $codigo ) {
		global $wpdb;

		$codigo = sanitize_text_field( $codigo );
		if ( '' === $codigo ) {
			return null;
		}

		$table = $wpdb->prefix . 'paquetes';
		$row   = $wpdb->get_row(
			$wpdb->prepare( "SELECT * FROM {$table} WHERE codigo = %s", $codigo ),
			ARRAY_A
		);

		return $row ? $row : null;
	}

	/**
	 * Obtiene un paquete por su ID.
	 *
	 * @param int $paquete_id ID del paquete.
	 * @return array|null
	 */
	public static function get_paquete( $paquete_id ) {
		global $wpdb;

		$paquete_id = absint( $paquete_id );
		if ( ! $paquete_id ) {
			return null;
		}

		$table = $wpdb->prefix . 'paquetes';
		$row   = $wpdb->get_row(
			$wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", $paquete_id ),
			ARRAY_A
		);

		return $row ? $row : null;
	}

	/**
	 * Devuelve la información resumen de un área/paquete para el modal
	 * de importación masiva: nombre, cupo total, cupos utilizados
	 * (registros reales en wp_correos_configurados) y cupos disponibles.
	 *
	 * @param int $paquete_id ID del paquete.
	 * @return array{id:int,nombre:string,codigo:string,cupo:int,utilizados:int,disponibles:int}|null
	 */
	public static function get_area_info( $paquete_id ) {
		$paquete = self::get_paquete( $paquete_id );

		if ( ! $paquete ) {
			return null;
		}

		$cupo       = (int) $paquete['cupo'];
		$utilizados = AU_Repository_Usuarios::contar_por_codigo_area( $paquete['codigo'] );

		return array(
			'id'          => (int) $paquete['id'],
			'nombre'      => $paquete['nombre'],
			'codigo'      => $paquete['codigo'],
			'cupo'        => $cupo,
			'utilizados'  => $utilizados,
			'disponibles' => max( 0, $cupo - $utilizados ),
		);
	}

	/**
	 * Devuelve todas las licencias disponibles (`wp_licencias`), para
	 * poblar el filtro "Licencia" del Tab Empresas.
	 *
	 * @return array<int, array{id:int,nombre:string}>
	 */
	public static function get_licencias() {
		global $wpdb;

		$table = $wpdb->prefix . 'licencias';
		$rows  = $wpdb->get_results( "SELECT id, nombre FROM {$table} ORDER BY nombre ASC", ARRAY_A );

		$licencias = array();
		foreach ( (array) $rows as $row ) {
			$licencias[] = array(
				'id'     => (int) $row['id'],
				'nombre' => $row['nombre'],
			);
		}

		return $licencias;
	}

	/**
	 * Busca/pagina empresas (usuarios con rol `company`) para el Tab
	 * "Empresas", con búsqueda por nombre de empresa (`first_name`) o
	 * nombre de encargado (`nombre_encargado`).
	 *
	 * @param array $args {
	 *     @type string $search   Texto de búsqueda.
	 *     @type int    $page     Página actual (1-indexed).
	 *     @type int    $per_page Registros por página.
	 * }
	 * @return array{items:array,total:int}
	 */
	public static function buscar_listado( array $args ) {
		global $wpdb;

		$search   = isset( $args['search'] ) ? trim( (string) $args['search'] ) : '';
		$page     = isset( $args['page'] ) ? max( 1, absint( $args['page'] ) ) : 1;
		$per_page = isset( $args['per_page'] ) ? absint( $args['per_page'] ) : 10;

		$allowed_per_page = array( 10, 25, 50, 100 );
		if ( ! in_array( $per_page, $allowed_per_page, true ) ) {
			$per_page = 10;
		}

		$offset            = ( $page - 1 ) * $per_page;
		$paquetes_table    = $wpdb->prefix . 'paquetes';
		$capabilities_key  = $wpdb->prefix . 'capabilities';
		$licencias_table   = $wpdb->prefix . 'licencias';

		$where  = array( 'cap.meta_value LIKE %s' );
		$params = array( '%' . $wpdb->esc_like( 's:7:"company"' ) . '%' );

		if ( '' !== $search ) {
			$like     = '%' . $wpdb->esc_like( $search ) . '%';
			$where[]  = '(fn.meta_value LIKE %s OR enc.meta_value LIKE %s)';
			$params[] = $like;
			$params[] = $like;
		}

		// Filtro de licencia: se resuelve con EXISTS/NOT EXISTS (sin
		// necesitar más LEFT JOIN en ninguna de las dos consultas), igual
		// que el filtro de "Perfil" en Integrantes.
		$licencia_filtro = isset( $args['licencia_id'] ) ? trim( (string) $args['licencia_id'] ) : '';

		if ( 'sin_licencia' === $licencia_filtro ) {
			$where[] = "NOT EXISTS (
				SELECT 1 FROM {$wpdb->usermeta} lm
				INNER JOIN {$licencias_table} l2 ON l2.id = CAST(lm.meta_value AS UNSIGNED) AND lm.meta_value REGEXP '^[0-9]+$'
				WHERE lm.user_id = u.ID AND lm.meta_key = 'licencia'
			)";
		} elseif ( '' !== $licencia_filtro && ctype_digit( $licencia_filtro ) ) {
			$where[]  = "EXISTS (SELECT 1 FROM {$wpdb->usermeta} lm WHERE lm.user_id = u.ID AND lm.meta_key = 'licencia' AND lm.meta_value = %s)";
			$params[] = $licencia_filtro;
		}

		// Filtro de Programa (Inspira / Octagono / Todas / Ninguna) —
		// misma lógica EXISTS/NOT EXISTS usada en Integrantes.
		$programa_filtro = isset( $args['programa_filtro'] ) ? sanitize_key( $args['programa_filtro'] ) : '';

		if ( '' !== $programa_filtro ) {
			$existe_inspira  = "EXISTS (SELECT 1 FROM {$wpdb->usermeta} pi WHERE pi.user_id = u.ID AND pi.meta_key = 'inspira' AND TRIM(pi.meta_value) != '')";
			$existe_octagono = "EXISTS (SELECT 1 FROM {$wpdb->usermeta} po WHERE po.user_id = u.ID AND po.meta_key = 'octagono' AND TRIM(po.meta_value) != '')";

			if ( 'inspira' === $programa_filtro ) {
				$where[] = $existe_inspira;
			} elseif ( 'octagono' === $programa_filtro ) {
				$where[] = $existe_octagono;
			} elseif ( 'todas' === $programa_filtro ) {
				$where[] = "({$existe_inspira} AND {$existe_octagono})";
			} elseif ( 'ninguna' === $programa_filtro ) {
				$where[] = "(NOT {$existe_inspira} AND NOT {$existe_octagono})";
			}
		}

		$where_sql = implode( ' AND ', $where );

		$count_sql = "
			SELECT COUNT(DISTINCT u.ID)
			FROM {$wpdb->users} u
			LEFT JOIN {$wpdb->usermeta} cap ON cap.user_id = u.ID AND cap.meta_key = '{$capabilities_key}'
			LEFT JOIN {$wpdb->usermeta} fn ON fn.user_id = u.ID AND fn.meta_key = 'first_name'
			LEFT JOIN {$wpdb->usermeta} enc ON enc.user_id = u.ID AND enc.meta_key = 'nombre_encargado'
			WHERE {$where_sql}
		";

		$total = (int) $wpdb->get_var( $wpdb->prepare( $count_sql, $params ) );

		$select_sql = "
			SELECT
				u.ID AS id,
				u.user_email,
				u.user_registered,
				MAX(fn.meta_value) AS empresa_nombre,
				MAX(enc.meta_value) AS encargado_nombre,
				MAX(inspira.meta_value) AS inspira_valor,
				MAX(octagono.meta_value) AS octagono_valor,
				MAX(lic.nombre) AS licencia_nombre,
				MAX(lic.id) AS licencia_id,
				MAX(api_flag.meta_value) AS created_by_api,
				COUNT(DISTINCT p.id) AS num_areas
			FROM {$wpdb->users} u
			LEFT JOIN {$wpdb->usermeta} cap ON cap.user_id = u.ID AND cap.meta_key = '{$capabilities_key}'
			LEFT JOIN {$wpdb->usermeta} fn ON fn.user_id = u.ID AND fn.meta_key = 'first_name'
			LEFT JOIN {$wpdb->usermeta} enc ON enc.user_id = u.ID AND enc.meta_key = 'nombre_encargado'
			LEFT JOIN {$wpdb->usermeta} inspira ON inspira.user_id = u.ID AND inspira.meta_key = 'inspira'
			LEFT JOIN {$wpdb->usermeta} octagono ON octagono.user_id = u.ID AND octagono.meta_key = 'octagono'
			LEFT JOIN {$wpdb->usermeta} licmeta ON licmeta.user_id = u.ID AND licmeta.meta_key = 'licencia'
			LEFT JOIN {$licencias_table} lic ON lic.id = CAST(licmeta.meta_value AS UNSIGNED) AND licmeta.meta_value REGEXP '^[0-9]+$'
			LEFT JOIN {$wpdb->usermeta} api_flag ON api_flag.user_id = u.ID AND api_flag.meta_key = 'created_by_api'
			LEFT JOIN {$paquetes_table} p ON p.empresa_id = u.ID
			WHERE {$where_sql}
			GROUP BY u.ID
			ORDER BY u.ID DESC
			LIMIT %d OFFSET %d
		";

		$select_params   = $params;
		$select_params[] = $per_page;
		$select_params[] = $offset;

		$rows = $wpdb->get_results( $wpdb->prepare( $select_sql, $select_params ), ARRAY_A );

		$items = array();
		foreach ( (array) $rows as $row ) {
			$items[] = self::formatear_fila_empresa( $row );
		}

		return array(
			'items' => $items,
			'total' => $total,
		);
	}

	/**
	 * Da formato a una fila cruda de `buscar_listado()` para la vista.
	 *
	 * Usa las mismas claves `inspira_valor`/`octagono_valor` que
	 * `AU_Repository_Usuarios::format_row()`, para poder reutilizar tal
	 * cual la misma lógica de renderizado de la columna "Programas" en
	 * el JS del Tab Integrantes.
	 *
	 * @param array $row Fila devuelta por $wpdb.
	 * @return array
	 */
	private static function formatear_fila_empresa( array $row ) {
		return array(
			'id'               => (int) $row['id'],
			'empresa_nombre'   => ! empty( $row['empresa_nombre'] ) ? $row['empresa_nombre'] : '',
			'encargado_nombre' => ! empty( $row['encargado_nombre'] ) ? $row['encargado_nombre'] : '',
			'user_email'       => $row['user_email'],
			'rol'              => 'company',
			'user_registered'  => $row['user_registered'],
			'num_areas'        => (int) $row['num_areas'],
			'licencia_nombre'  => ! empty( $row['licencia_nombre'] ) ? $row['licencia_nombre'] : '',
			// Sale del JOIN con `wp_licencias`, no de la meta: si la meta
			// apunta a una licencia borrada, llega 0 y el modal "Cambiar
			// Licencia" abre en "Sin licencia" en vez de preseleccionar un
			// id que ya no existe.
			'licencia_id'      => ! empty( $row['licencia_id'] ) ? (int) $row['licencia_id'] : 0,
			'inspira_valor'    => trim( (string) ( $row['inspira_valor'] ?? '' ) ),
			'octagono_valor'   => trim( (string) ( $row['octagono_valor'] ?? '' ) ),
			'created_by_api'   => ( 'true' === trim( (string) ( $row['created_by_api'] ?? '' ) ) ),
		);
	}

	/**
	 * Obtiene todos los usuarios que deben sincronizarse para
	 * "Refrescar programas": el administrador de la empresa (rol
	 * `company`) más todos los integrantes de sus áreas con rol
	 * `subscriber` o `group_leader`.
	 *
	 * Reutiliza la misma relación Empresa → Áreas → Integrantes ya usada
	 * en el resto del plugin (`wp_paquetes.empresa_id` /
	 * `wp_correos_configurados.codigo_area` / `wp_correos_configurados.email`).
	 *
	 * @param int $empresa_id ID de la empresa (usuario con rol `company`).
	 * @return array<int, array{id:int,email:string}>
	 */
	public static function obtener_usuarios_para_sincronizar( $empresa_id ) {
		global $wpdb;

		$empresa_id = absint( $empresa_id );
		if ( ! $empresa_id ) {
			return array();
		}

		$capabilities_key = $wpdb->prefix . 'capabilities';
		$correos_table    = $wpdb->prefix . 'correos_configurados';

		$usuarios = array();

		// 1. El administrador de la empresa.
		$admin = get_userdata( $empresa_id );
		if ( $admin ) {
			$usuarios[ $admin->ID ] = array(
				'id'    => (int) $admin->ID,
				'email' => $admin->user_email,
			);
		}

		// 2. Integrantes (subscriber o group_leader) de las áreas de la empresa.
		$sql = "
			SELECT DISTINCT u.ID AS id, u.user_email AS email
			FROM {$wpdb->users} u
			INNER JOIN {$wpdb->usermeta} cap ON cap.user_id = u.ID AND cap.meta_key = %s
			INNER JOIN {$correos_table} cc ON cc.email = u.user_email
			WHERE cc.empresa_id = %d
			AND (cap.meta_value LIKE %s OR cap.meta_value LIKE %s)
		";

		$rows = $wpdb->get_results(
			$wpdb->prepare(
				$sql,
				$capabilities_key,
				$empresa_id,
				'%' . $wpdb->esc_like( 's:10:"subscriber"' ) . '%',
				'%' . $wpdb->esc_like( 's:12:"group_leader"' ) . '%'
			),
			ARRAY_A
		);

		foreach ( (array) $rows as $row ) {
			$id = (int) $row['id'];
			if ( ! isset( $usuarios[ $id ] ) ) {
				$usuarios[ $id ] = array(
					'id'    => $id,
					'email' => $row['email'],
				);
			}
		}

		return array_values( $usuarios );
	}

	/**
	 * Obtiene TODAS las cuentas con rol `company` para la acción global
	 * "Refrescar programas" del botón "Acciones" del Tab Empresas.
	 *
	 * A diferencia de `obtener_usuarios_para_sincronizar()` (acción por
	 * fila), esta lista NO incluye a los integrantes de cada empresa:
	 * solo las cuentas de empresa en sí, que son las filas que muestra
	 * este tab — igual que el botón del Tab Usuarios Externos, que
	 * sincroniza únicamente los `external_user`. Para refrescar también
	 * a los integrantes de una empresa sigue estando la acción por fila.
	 *
	 * @return array<int, array{id:int,email:string}>
	 */
	public static function obtener_todas_las_empresas_para_sincronizar() {
		global $wpdb;

		$capabilities_key = $wpdb->prefix . 'capabilities';

		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"
				SELECT u.ID AS id, u.user_email AS email
				FROM {$wpdb->users} u
				INNER JOIN {$wpdb->usermeta} cap ON cap.user_id = u.ID AND cap.meta_key = %s
				WHERE cap.meta_value LIKE %s
				ORDER BY u.ID DESC
				",
				$capabilities_key,
				'%' . $wpdb->esc_like( 's:7:"company"' ) . '%'
			),
			ARRAY_A
		);

		$usuarios = array();
		foreach ( (array) $rows as $row ) {
			$usuarios[] = array(
				'id'    => (int) $row['id'],
				'email' => $row['email'],
			);
		}

		return $usuarios;
	}

	/**
	 * Datos "en crudo" de un área/paquete por su ID (sin líder, cursos ni
	 * licencia heredada de la empresa) — usado para precargar el modal
	 * "Editar Área" con el valor real guardado, no el que se muestra por
	 * herencia en el listado.
	 *
	 * @param int $area_id ID del área (wp_paquetes.id).
	 * @return array{id:int,nombre:string,cupos:int,licencia_id:int}|null
	 */
	public static function obtener_area_por_id( $area_id ) {
		global $wpdb;

		$area_id = absint( $area_id );

		if ( ! $area_id ) {
			return null;
		}

		$table = $wpdb->prefix . 'paquetes';
		$row   = $wpdb->get_row(
			$wpdb->prepare( "SELECT id, nombre, cupo, licencia_id FROM {$table} WHERE id = %d", $area_id ),
			ARRAY_A
		);

		if ( ! $row ) {
			return null;
		}

		return array(
			'id'          => (int) $row['id'],
			'nombre'      => $row['nombre'],
			'cupos'       => (int) $row['cupo'],
			'licencia_id' => $row['licencia_id'] ? (int) $row['licencia_id'] : 0,
		);
	}

	/**
	 * Busca/pagina las áreas (`wp_paquetes`) de una empresa, con
	 * búsqueda por nombre y el uso real (integrantes activos en
	 * `wp_correos_configurados`) frente al cupo configurado.
	 *
	 * Usada por el modal "Ver más" de la columna Áreas del Tab Empresas.
	 *
	 * @param array $args {
	 *     @type int    $empresa_id    ID de la empresa.
	 *     @type string $search        Texto de búsqueda: nombre del área, nombre/correo del líder, o nombre de licencia (opcional).
	 *     @type string $lider_filtro  'con_lider' | 'sin_lider' | '' (todos).
	 *     @type string $licencia_id   ID de licencia, 'sin_licencia', o '' (todas).
	 *     @type string $cursos_filtro 'con_cursos' | 'sin_cursos' | '' (todos).
	 *     @type int    $page          Página actual (1-indexed).
	 *     @type int    $per_page      Registros por página.
	 * }
	 * @return array{items:array,total:int}
	 */
	public static function buscar_areas_empresa( array $args ) {
		global $wpdb;

		$empresa_id   = isset( $args['empresa_id'] ) ? absint( $args['empresa_id'] ) : 0;
		$search       = isset( $args['search'] ) ? trim( (string) $args['search'] ) : '';
		$lider_filtro = isset( $args['lider_filtro'] ) ? trim( (string) $args['lider_filtro'] ) : '';
		$page         = isset( $args['page'] ) ? max( 1, absint( $args['page'] ) ) : 1;
		$per_page     = isset( $args['per_page'] ) ? absint( $args['per_page'] ) : 10;

		$allowed_per_page = array( 10, 25, 50, 100 );
		if ( ! in_array( $per_page, $allowed_per_page, true ) ) {
			$per_page = 10;
		}

		if ( ! $empresa_id ) {
			return array(
				'items' => array(),
				'total' => 0,
			);
		}

		$offset         = ( $page - 1 ) * $per_page;
		$paquetes_table = $wpdb->prefix . 'paquetes';
		$correos_table  = $wpdb->prefix . 'correos_configurados';
		$licencias_table = $wpdb->prefix . 'licencias';

		$where  = array( 'p.empresa_id = %d' );
		$params = array( $empresa_id );

		if ( '' !== $search ) {
			$like = '%' . $wpdb->esc_like( $search ) . '%';

			// Busca por nombre del área, o por nombre/correo del líder
			// asignada, o por el nombre de la licencia (propia del área
			// o heredada de la empresa) — todo con EXISTS/subconsultas
			// para no tener que arrastrar los JOIN de líder/licencia
			// también al count_sql.
			$where[] = "(
				p.nombre LIKE %s
				OR EXISTS (
					SELECT 1 FROM {$wpdb->users} lu2
					LEFT JOIN {$wpdb->usermeta} lfn2 ON lfn2.user_id = lu2.ID AND lfn2.meta_key = 'first_name'
					LEFT JOIN {$wpdb->usermeta} lln2 ON lln2.user_id = lu2.ID AND lln2.meta_key = 'last_name'
					WHERE lu2.ID = p.leader_id
					AND (
						lu2.display_name LIKE %s
						OR lu2.user_email LIKE %s
						OR lu2.user_login LIKE %s
						OR CONCAT( COALESCE( lfn2.meta_value, '' ), ' ', COALESCE( lln2.meta_value, '' ) ) LIKE %s
					)
				)
				OR EXISTS (
					SELECT 1 FROM {$licencias_table} lic2
					WHERE lic2.id = p.licencia_id AND p.licencia_id > 0 AND lic2.nombre LIKE %s
				)
				OR EXISTS (
					SELECT 1 FROM {$wpdb->usermeta} lm3
					INNER JOIN {$licencias_table} lic3 ON lic3.id = CAST(lm3.meta_value AS UNSIGNED) AND lm3.meta_value REGEXP '^[0-9]+$'
					WHERE lm3.user_id = p.empresa_id AND lm3.meta_key = 'licencia'
					AND ( p.licencia_id IS NULL OR p.licencia_id = 0 )
					AND lic3.nombre LIKE %s
				)
			)";

			$params[] = $like; // p.nombre
			$params[] = $like; // lu2.display_name
			$params[] = $like; // lu2.user_email
			$params[] = $like; // lu2.user_login
			$params[] = $like; // nombre + apellido concatenados
			$params[] = $like; // licencia propia del área
			$params[] = $like; // licencia heredada de la empresa
		}

		if ( 'con_lider' === $lider_filtro ) {
			$where[] = 'p.leader_id > 0';
		} elseif ( 'sin_lider' === $lider_filtro ) {
			$where[] = '( p.leader_id IS NULL OR p.leader_id = 0 )';
		}

		// Filtro de licencia: coincide si es la licencia propia del área,
		// o si el área no tiene licencia propia (hereda) y esa es la
		// licencia configurada en la empresa dueña — mismo criterio de
		// herencia que se usa para mostrar la columna.
		$licencia_filtro = isset( $args['licencia_id'] ) ? trim( (string) $args['licencia_id'] ) : '';

		if ( 'sin_licencia' === $licencia_filtro ) {
			$where[] = "(
				( p.licencia_id IS NULL OR p.licencia_id = 0 )
				AND NOT EXISTS (
					SELECT 1 FROM {$wpdb->usermeta} lm
					WHERE lm.user_id = p.empresa_id AND lm.meta_key = 'licencia' AND lm.meta_value REGEXP '^[0-9]+$'
				)
			)";
		} elseif ( '' !== $licencia_filtro && ctype_digit( $licencia_filtro ) ) {
			$where[] = "(
				p.licencia_id = %d
				OR (
					( p.licencia_id IS NULL OR p.licencia_id = 0 )
					AND EXISTS (
						SELECT 1 FROM {$wpdb->usermeta} lm
						WHERE lm.user_id = p.empresa_id AND lm.meta_key = 'licencia' AND lm.meta_value = %s
					)
				)
			)";
			$params[] = (int) $licencia_filtro;
			$params[] = $licencia_filtro;
		}

		// Filtro de "Cursos asignados": course_ids es un string plano
		// (sin normalizar a filas separadas), así que basta con
		// comprobar si está vacío o no — el conteo exacto de IDs
		// válidos se resuelve en PHP (`parse_course_ids()`) solo para
		// mostrar el número, no hace falta aquí.
		$cursos_filtro = isset( $args['cursos_filtro'] ) ? trim( (string) $args['cursos_filtro'] ) : '';

		if ( 'con_cursos' === $cursos_filtro ) {
			$where[] = "( p.course_ids IS NOT NULL AND TRIM(p.course_ids) != '' )";
		} elseif ( 'sin_cursos' === $cursos_filtro ) {
			$where[] = "( p.course_ids IS NULL OR TRIM(p.course_ids) = '' )";
		}

		$where_sql = implode( ' AND ', $where );

		$count_sql = "
			SELECT COUNT(*)
			FROM {$paquetes_table} p
			WHERE {$where_sql}
		";

		$total = (int) $wpdb->get_var( $wpdb->prepare( $count_sql, $params ) );

		$select_sql = "
			SELECT
				p.id,
				p.nombre,
				p.cupo,
				p.leader_id,
				p.course_ids,
				MAX(lu.display_name) AS lider_display_name,
				MAX(lu.user_login) AS lider_user_login,
				MAX(lu.user_email) AS lider_email,
				MAX(lfn.meta_value) AS lider_first_name,
				MAX(lln.meta_value) AS lider_last_name,
				MAX(lic_area.nombre) AS licencia_area_nombre,
				MAX(lic_empresa.nombre) AS licencia_empresa_nombre,
				COUNT(DISTINCT cc.email) AS usados
			FROM {$paquetes_table} p
			LEFT JOIN {$correos_table} cc ON cc.codigo_area = p.codigo
			LEFT JOIN {$wpdb->users} lu ON lu.ID = p.leader_id
			LEFT JOIN {$wpdb->usermeta} lfn ON lfn.user_id = p.leader_id AND lfn.meta_key = 'first_name'
			LEFT JOIN {$wpdb->usermeta} lln ON lln.user_id = p.leader_id AND lln.meta_key = 'last_name'
			LEFT JOIN {$licencias_table} lic_area ON lic_area.id = p.licencia_id AND p.licencia_id > 0
			LEFT JOIN {$wpdb->usermeta} licmeta ON licmeta.user_id = p.empresa_id AND licmeta.meta_key = 'licencia'
			LEFT JOIN {$licencias_table} lic_empresa ON lic_empresa.id = CAST(licmeta.meta_value AS UNSIGNED) AND licmeta.meta_value REGEXP '^[0-9]+$'
			WHERE {$where_sql}
			GROUP BY p.id
			ORDER BY p.id DESC
			LIMIT %d OFFSET %d
		";

		$select_params   = $params;
		$select_params[] = $per_page;
		$select_params[] = $offset;

		$rows = $wpdb->get_results( $wpdb->prepare( $select_sql, $select_params ), ARRAY_A );

		$items = array();
		foreach ( (array) $rows as $row ) {
			$items[] = array(
				'id'               => (int) $row['id'],
				'nombre'           => $row['nombre'],
				'usados'           => (int) $row['usados'],
				'cupo'             => (int) $row['cupo'],
				'lider'            => self::format_lider( $row ),
				'licencia_nombre'  => self::format_licencia_area( $row ),
				'num_cursos'       => count( self::parse_course_ids( $row['course_ids'] ?? '' ) ),
			);
		}

		return array(
			'items' => $items,
			'total' => $total,
		);
	}

	/**
	 * Da formato al líder de un área a partir de la fila cruda
	 * devuelta por `buscar_areas_empresa()`.
	 *
	 * `leader_id` en `wp_paquetes` guarda `0` cuando el área no tiene
	 * líder asignado. Si tiene un valor pero el usuario ya no existe
	 * (fue borrado), se informa igualmente el ID para no ocultar el
	 * dato huérfano.
	 *
	 * @param array $row Fila cruda con `leader_id`, `lider_display_name`,
	 *                   `lider_user_login`, `lider_email`, `lider_first_name`,
	 *                   `lider_last_name`.
	 * @return array{asignado:bool,nombre:string,email:string}
	 */
	private static function format_lider( array $row ) {
		$leader_id = isset( $row['leader_id'] ) ? (int) $row['leader_id'] : 0;

		if ( $leader_id <= 0 ) {
			return array(
				'asignado' => false,
				'nombre'   => __( 'Sin líder asignado', 'au-wms' ),
				'email'    => '',
			);
		}

		$first_name = trim( (string) ( $row['lider_first_name'] ?? '' ) );
		$last_name  = trim( (string) ( $row['lider_last_name'] ?? '' ) );

		if ( $first_name || $last_name ) {
			$nombre = trim( $first_name . ' ' . $last_name );
		} elseif ( ! empty( $row['lider_display_name'] ) ) {
			$nombre = $row['lider_display_name'];
		} elseif ( ! empty( $row['lider_user_login'] ) ) {
			$nombre = $row['lider_user_login'];
		} else {
			// leader_id > 0 pero no corresponde a ningún usuario existente.
			/* translators: %d: ID de usuario del líder que ya no existe. */
			$nombre = sprintf( __( 'Usuario no encontrado (#%d)', 'au-wms' ), $leader_id );
		}

		return array(
			'asignado' => true,
			'nombre'   => $nombre,
			'email'    => ! empty( $row['lider_email'] ) ? $row['lider_email'] : '',
		);
	}

	/**
	 * Resuelve el nombre de la licencia mostrada para un área.
	 *
	 * `wp_paquetes.licencia_id` es la licencia propia del área. Cuando
	 * vale `0`, el área hereda la licencia de la empresa dueña
	 * (`wp_usermeta` con `meta_key = 'licencia'` para el `empresa_id`
	 * del paquete). La consulta ya resuelve ambas en columnas
	 * separadas (`licencia_area_nombre`/`licencia_empresa_nombre`);
	 * aquí solo se elige cuál mostrar.
	 *
	 * @param array $row Fila cruda con `licencia_area_nombre` y
	 *                   `licencia_empresa_nombre`.
	 * @return string
	 */
	private static function format_licencia_area( array $row ) {
		if ( ! empty( $row['licencia_area_nombre'] ) ) {
			return $row['licencia_area_nombre'];
		}

		if ( ! empty( $row['licencia_empresa_nombre'] ) ) {
			return $row['licencia_empresa_nombre'];
		}

		return '';
	}

	/**
	 * Convierte el string `course_ids` de `wp_paquetes` (IDs separados
	 * por comas) en un array de enteros únicos, ignorando espacios y
	 * fragmentos no numéricos.
	 *
	 * @param string $course_ids Valor crudo de la columna `course_ids`.
	 * @return int[]
	 */
	private static function parse_course_ids( $course_ids ) {
		$course_ids = trim( (string) $course_ids );

		if ( '' === $course_ids ) {
			return array();
		}

		$ids = array_map( 'trim', explode( ',', $course_ids ) );
		$ids = array_filter( $ids, 'ctype_digit' );
		$ids = array_map( 'absint', $ids );
		$ids = array_values( array_unique( array_filter( $ids ) ) );

		return $ids;
	}

	/**
	 * Devuelve los cursos de LearnDash asignados a un área (`wp_paquetes.
	 * course_ids`), con su título, para el modal "Ver cursos".
	 *
	 * Se relee `course_ids` directamente de la base de datos a partir
	 * del `area_id` (en vez de confiar en una lista de IDs recibida
	 * del navegador), y se resuelven los títulos en un solo `IN (...)`
	 * contra `wp_posts` (post_type `sfwd-courses`). Si algún ID ya no
	 * corresponde a un curso existente (fue borrado), se informa igual
	 * con un título de reemplazo en vez de omitirlo en silencio.
	 *
	 * @param int $area_id ID del área (`wp_paquetes.id`).
	 * @return array{area_nombre:string,cursos:array<int, array{id:int,titulo:string}>}
	 */
	public static function obtener_cursos_area( $area_id ) {
		global $wpdb;

		$area_id        = absint( $area_id );
		$paquetes_table = $wpdb->prefix . 'paquetes';

		if ( ! $area_id ) {
			return array(
				'area_nombre' => '',
				'cursos'      => array(),
			);
		}

		$area = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT nombre, course_ids FROM {$paquetes_table} WHERE id = %d",
				$area_id
			),
			ARRAY_A
		);

		if ( ! $area ) {
			return array(
				'area_nombre' => '',
				'cursos'      => array(),
			);
		}

		$course_ids = self::parse_course_ids( $area['course_ids'] );

		if ( empty( $course_ids ) ) {
			return array(
				'area_nombre' => $area['nombre'],
				'cursos'      => array(),
			);
		}

		$placeholders = implode( ', ', array_fill( 0, count( $course_ids ), '%d' ) );

		$posts = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT ID, post_title FROM {$wpdb->posts} WHERE ID IN ({$placeholders}) AND post_type = 'sfwd-courses'",
				$course_ids
			),
			ARRAY_A
		);

		$titulos_por_id = array();
		foreach ( (array) $posts as $post ) {
			$titulos_por_id[ (int) $post['ID'] ] = $post['post_title'];
		}

		$cursos = array();
		foreach ( $course_ids as $course_id ) {
			$cursos[] = array(
				'id'     => $course_id,
				/* translators: %d: ID de un curso de LearnDash que ya no existe. */
				'titulo' => isset( $titulos_por_id[ $course_id ] )
					? $titulos_por_id[ $course_id ]
					: sprintf( __( 'Curso no encontrado (#%d)', 'au-wms' ), $course_id ),
			);
		}

		return array(
			'area_nombre' => $area['nombre'],
			'cursos'      => $cursos,
		);
	}

	/**
	 * Obtiene, por cada usuario de una empresa, su `codigo_area` más
	 * antiguo (el de menor `id` en `wp_correos_configurados`) cuando el
	 * usuario tiene más de una área asignada dentro de esa misma
	 * empresa. Usado por la acción "Actualizar id empresa usuario".
	 *
	 * @param int $empresa_id ID de la empresa.
	 * @return array<int, array{user_id:int,email:string,codigo_area:string}>
	 */
	public static function obtener_codigo_area_mas_antiguo_por_usuario( $empresa_id ) {
		global $wpdb;

		$empresa_id = absint( $empresa_id );
		if ( ! $empresa_id ) {
			return array();
		}

		$correos_table = $wpdb->prefix . 'correos_configurados';

		$sql = "
			SELECT cc.email, cc.codigo_area, u.ID AS user_id
			FROM {$correos_table} cc
			INNER JOIN {$wpdb->users} u ON u.user_email = cc.email
			INNER JOIN (
				SELECT email, MIN(id) AS min_id
				FROM {$correos_table}
				WHERE empresa_id = %d
				GROUP BY email
			) primero ON primero.email = cc.email AND primero.min_id = cc.id
			WHERE cc.empresa_id = %d
		";

		$rows = $wpdb->get_results( $wpdb->prepare( $sql, $empresa_id, $empresa_id ), ARRAY_A );

		$resultado = array();
		foreach ( (array) $rows as $row ) {
			$resultado[] = array(
				'user_id'     => (int) $row['user_id'],
				'email'       => $row['email'],
				'codigo_area' => $row['codigo_area'],
			);
		}

		return $resultado;
	}
}
