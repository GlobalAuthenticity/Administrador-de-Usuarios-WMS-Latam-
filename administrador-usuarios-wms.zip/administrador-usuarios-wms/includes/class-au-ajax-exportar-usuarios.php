<?php
/**
 * Controlador AJAX del modal "Exportar usuarios" (Tab Empresas).
 *
 * @package Administrador_Usuarios_WMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AU_Ajax_Exportar_Usuarios {

	/**
	 * Instancia única (singleton).
	 *
	 * @var AU_Ajax_Exportar_Usuarios|null
	 */
	private static $instance = null;

	/**
	 * Devuelve la instancia única y engancha las acciones AJAX.
	 *
	 * @return AU_Ajax_Exportar_Usuarios
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
			self::$instance->register_hooks();
		}

		return self::$instance;
	}

	/**
	 * Registra los endpoints AJAX del modal.
	 *
	 * @return void
	 */
	private function register_hooks() {
		add_action( 'wp_ajax_au_wms_exportar_usuarios_areas', array( $this, 'handle_areas' ) );
		add_action( 'wp_ajax_au_wms_exportar_usuarios_listar', array( $this, 'handle_listar' ) );
	}

	/**
	 * Devuelve las áreas/paquetes de una empresa, para poblar el
	 * listado de checkboxes del Paso 1.
	 *
	 * @return void
	 */
	public function handle_areas() {
		AU_Security::guard();

		$empresa_id = isset( $_POST['empresa_id'] ) ? AU_Security::sanitize_int( $_POST['empresa_id'] ) : 0;

		if ( ! $empresa_id || ! get_userdata( $empresa_id ) ) {
			wp_send_json_error( array( 'message' => __( 'La empresa seleccionada no existe.', 'au-wms' ) ) );
		}

		wp_send_json_success(
			array( 'areas' => AU_Repository_Empresas::get_paquetes_por_empresa( $empresa_id ) )
		);
	}

	/**
	 * Lista los usuarios (correo, nombre, área, estado del test) de
	 * las áreas seleccionadas, ordenados por área (alfabético), para
	 * la previsualización del Paso 2 y la generación del Excel.
	 *
	 * @return void
	 */
	public function handle_listar() {
		AU_Security::guard();

		$empresa_id = isset( $_POST['empresa_id'] ) ? AU_Security::sanitize_int( $_POST['empresa_id'] ) : 0;

		$paquete_ids = array();
		if ( isset( $_POST['paquete_ids'] ) && is_array( $_POST['paquete_ids'] ) ) {
			$paquete_ids = array_map( 'absint', $_POST['paquete_ids'] );
		}

		if ( ! $empresa_id || ! get_userdata( $empresa_id ) ) {
			wp_send_json_error( array( 'message' => __( 'La empresa seleccionada no existe.', 'au-wms' ) ) );
		}

		if ( empty( $paquete_ids ) ) {
			wp_send_json_error( array( 'message' => __( 'Selecciona al menos un área para continuar.', 'au-wms' ) ) );
		}

		// Revalida en el servidor que las áreas realmente pertenecen a
		// esta empresa (nunca se confía en los IDs tal como llegan del
		// navegador); las que no pertenezcan simplemente no producirán
		// resultados, ya que la consulta exige `p.empresa_id = %d`.
		$usuarios = AU_Repository_Usuarios::buscar_para_exportar( $empresa_id, $paquete_ids );

		wp_send_json_success( array( 'usuarios' => $usuarios ) );
	}
}
