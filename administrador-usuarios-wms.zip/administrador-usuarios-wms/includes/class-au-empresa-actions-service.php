<?php
/**
 * Servicio de la acción "Actualizar id empresa usuario" (Tab Empresas):
 * para cada usuario de la empresa, toma su `codigo_area` más antiguo en
 * `wp_correos_configurados` y lo guarda en `wp_usermeta` bajo el
 * meta_key `user_code_company`.
 *
 * @package Administrador_Usuarios_WMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AU_Empresa_Actions_Service {

	/**
	 * Ejecuta la actualización para todos los usuarios de una empresa.
	 *
	 * Usa `update_user_meta()` (no un INSERT crudo) porque
	 * `wp_usermeta` no tiene una llave única en (user_id, meta_key):
	 * `update_user_meta()` crea el registro si no existe o lo actualiza
	 * si ya existe, evitando duplicados si la acción se vuelve a correr.
	 *
	 * @param int $empresa_id ID de la empresa.
	 * @return array{success:bool,message?:string,actualizados?:int}
	 */
	public static function actualizar_codigo_empresa_usuarios( $empresa_id ) {
		$empresa_id = absint( $empresa_id );

		if ( ! $empresa_id || ! get_userdata( $empresa_id ) ) {
			return array(
				'success' => false,
				'message' => __( 'La empresa seleccionada no existe.', 'au-wms' ),
			);
		}

		$filas = AU_Repository_Empresas::obtener_codigo_area_mas_antiguo_por_usuario( $empresa_id );

		$actualizados = 0;
		foreach ( $filas as $fila ) {
			update_user_meta( $fila['user_id'], 'user_code_company', $fila['codigo_area'] );
			++$actualizados;
		}

		return array(
			'success'      => true,
			'actualizados' => $actualizados,
		);
	}

	/**
	 * Campos editables de una empresa: meta_key => etiqueta.
	 *
	 * El correo y la licencia NO están aquí a propósito: el correo es la
	 * identidad de la cuenta en los tres programas y la licencia tiene su
	 * propia acción ("Cambiar Licencia"), que además recalcula vigencias.
	 * Por eso `editar()` no los toca aunque lleguen en la petición.
	 *
	 * @var array<string,string>
	 */
	const CAMPOS_EDITABLES = array(
		'nombre_empresa'   => 'Razón social o nombre de la empresa',
		'nit_empresa'      => 'NIT',
		'nombre_encargado' => 'Nombres del encargado',
		'last_name'        => 'Apellidos del encargado',
		'contacto'         => 'Número de contacto',
		'ocupacion'        => 'Ocupación / Cargo',
	);

	/**
	 * Datos actuales de una empresa, para precargar el modal "Editar
	 * empresa".
	 *
	 * El nombre sale de `first_name` y no de la meta `nombre_empresa`
	 * porque es lo que muestra el listado (y lo que escribe el
	 * formulario "Registrar Empresa" del tema, que no siempre guarda
	 * `nombre_empresa`); si `first_name` está vacío se cae a la meta.
	 *
	 * @param int $empresa_id ID de la empresa.
	 * @return array|null
	 */
	public static function obtener( $empresa_id ) {
		$empresa_id = absint( $empresa_id );
		$usuario    = $empresa_id ? get_userdata( $empresa_id ) : null;

		if ( ! $usuario ) {
			return null;
		}

		$nombre = trim( (string) get_user_meta( $empresa_id, 'first_name', true ) );

		if ( '' === $nombre ) {
			$nombre = trim( (string) get_user_meta( $empresa_id, 'nombre_empresa', true ) );
		}

		return array(
			'id'               => $empresa_id,
			'email'            => $usuario->user_email,
			'nombre_empresa'   => $nombre,
			'nit_empresa'      => (string) get_user_meta( $empresa_id, 'nit_empresa', true ),
			'nombre_encargado' => (string) get_user_meta( $empresa_id, 'nombre_encargado', true ),
			'last_name'        => (string) get_user_meta( $empresa_id, 'last_name', true ),
			'contacto'         => (string) get_user_meta( $empresa_id, 'contacto', true ),
			'ocupacion'        => (string) get_user_meta( $empresa_id, 'ocupacion', true ),
		);
	}

	/**
	 * Actualiza los datos de una empresa ya existente (modal "Editar
	 * empresa").
	 *
	 * Solo escribe las metas de CAMPOS_EDITABLES: no toca el correo, la
	 * licencia, las áreas, los integrantes ni el rol. Mantiene las
	 * mismas reglas de unicidad que la creación (nombre y NIT), pero
	 * excluyéndose a sí misma para que guardar sin cambios no falle.
	 *
	 * @param int   $empresa_id ID de la empresa.
	 * @param array $datos      Valores ya saneados por el controlador AJAX.
	 * @return array{success:bool,message?:string,empresa?:array}
	 */
	public static function editar( $empresa_id, array $datos ) {
		global $wpdb;

		$empresa_id = absint( $empresa_id );

		if ( ! $empresa_id || ! get_userdata( $empresa_id ) ) {
			return array(
				'success' => false,
				'message' => __( 'La empresa seleccionada no existe.', 'au-wms' ),
			);
		}

		$nombre = trim( (string) ( $datos['nombre_empresa'] ?? '' ) );

		if ( '' === $nombre ) {
			return array(
				'success' => false,
				'message' => __( 'La razón social o nombre de la empresa es obligatorio.', 'au-wms' ),
			);
		}

		$nit = trim( (string) ( $datos['nit_empresa'] ?? '' ) );

		// Unicidad: mismas reglas que al crear, descontando a la propia
		// empresa (si no, guardar sin tocar el nombre daría "ya existe").
		$duplicado = self::meta_en_uso( 'nombre_empresa', $nombre, $empresa_id, $wpdb )
			|| self::meta_en_uso( 'first_name', $nombre, $empresa_id, $wpdb, true );

		if ( $duplicado ) {
			return array(
				'success' => false,
				'message' => __( 'Ya existe otra empresa registrada con este nombre.', 'au-wms' ),
			);
		}

		if ( '' !== $nit && self::meta_en_uso( 'nit_empresa', $nit, $empresa_id, $wpdb ) ) {
			return array(
				'success' => false,
				'message' => __( 'Este NIT ya está registrado en otra empresa.', 'au-wms' ),
			);
		}

		// `first_name`/`nickname` son lo que muestra el listado;
		// `nombre_empresa` es lo que comprueban la API y el asistente.
		// Se escriben los tres para que no se desincronicen.
		wp_update_user(
			array(
				'ID'         => $empresa_id,
				'first_name' => $nombre,
				'nickname'   => $nombre,
			)
		);

		update_user_meta( $empresa_id, 'nombre_empresa', $nombre );

		foreach ( array( 'nit_empresa', 'nombre_encargado', 'last_name', 'contacto', 'ocupacion' ) as $campo ) {
			update_user_meta( $empresa_id, $campo, trim( (string) ( $datos[ $campo ] ?? '' ) ) );
		}

		return array(
			'success' => true,
			'empresa' => self::obtener( $empresa_id ),
		);
	}

	/**
	 * ¿Otro usuario (distinto de $excluir_id) ya tiene ese valor en esa
	 * meta?
	 *
	 * @param string $meta_key   Clave de la meta.
	 * @param string $valor      Valor a buscar.
	 * @param int    $excluir_id Usuario que no cuenta (la propia empresa).
	 * @param wpdb   $wpdb       Instancia global de wpdb.
	 * @param bool   $solo_empresas true para limitar la búsqueda a usuarios
	 *                              marcados como empresa (`first_name` lo
	 *                              usa cualquier usuario, no solo ellas).
	 * @return bool
	 */
	private static function meta_en_uso( $meta_key, $valor, $excluir_id, $wpdb, $solo_empresas = false ) {
		$sql = "SELECT COUNT(*) FROM {$wpdb->usermeta} m
				WHERE m.meta_key = %s AND m.meta_value = %s AND m.user_id <> %d";

		if ( $solo_empresas ) {
			$sql .= " AND EXISTS (
						SELECT 1 FROM {$wpdb->usermeta} e
						 WHERE e.user_id = m.user_id AND e.meta_key = 'empresa' AND e.meta_value = 'true'
					)";
		}

		return (int) $wpdb->get_var( $wpdb->prepare( $sql, $meta_key, $valor, $excluir_id ) ) > 0;
	}

	/**
	 * Cambia la licencia de una empresa (acción "Cambiar Licencia" del
	 * dropdown de cada fila del Tab Empresas).
	 *
	 * Escribe la meta `licencia` con el id de `wp_licencias`, que es lo
	 * que leen el listado, las áreas que heredan licencia y el front-end
	 * del tema. Un id 0 significa "Sin licencia" y borra la meta, para
	 * que la empresa quede igual que una que nunca tuvo licencia y no
	 * como una que apunta a un id inexistente.
	 *
	 * @param int $empresa_id  ID de la empresa (usuario con rol `company`).
	 * @param int $licencia_id ID de la licencia, o 0 para quitarla.
	 * @return array{success:bool,message?:string,licencia_id?:int,licencia_nombre?:string}
	 */
	public static function cambiar_licencia( $empresa_id, $licencia_id ) {
		$empresa_id  = absint( $empresa_id );
		$licencia_id = absint( $licencia_id );

		if ( ! $empresa_id || ! get_userdata( $empresa_id ) ) {
			return array(
				'success' => false,
				'message' => __( 'La empresa seleccionada no existe.', 'au-wms' ),
			);
		}

		$licencia = $licencia_id ? AU_Repository_Licencias::obtener_por_id( $licencia_id ) : null;

		if ( $licencia_id && ! $licencia ) {
			return array(
				'success' => false,
				'message' => __( 'La licencia indicada no existe.', 'au-wms' ),
			);
		}

		if ( $licencia_id ) {
			update_user_meta( $empresa_id, 'licencia', $licencia_id );
		} else {
			delete_user_meta( $empresa_id, 'licencia' );
		}

		return array(
			'success'         => true,
			'licencia_id'     => $licencia_id,
			'licencia_nombre' => $licencia ? $licencia['nombre'] : '',
		);
	}
}
