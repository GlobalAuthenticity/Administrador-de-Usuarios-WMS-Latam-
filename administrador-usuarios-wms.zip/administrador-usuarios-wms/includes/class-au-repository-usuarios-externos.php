<?php
/**
 * Repositorio de acceso a datos para el Tab "Usuarios Externos"
 * (usuarios con rol `external_user`).
 *
 * @package Administrador_Usuarios_WMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AU_Repository_Usuarios_Externos {

	/**
	 * Busca/pagina usuarios con rol `external_user`, con búsqueda libre
	 * (username, correo, nombre o apellido) y filtro opcional de
	 * "Programa" (misma lógica que Integrantes/Empresas).
	 *
	 * @param array $args {
	 *     @type string $search          Texto de búsqueda (opcional).
	 *     @type string $programa_filtro Inspira|Octagono|Todas|Ninguna (vacío = sin filtro).
	 *     @type int    $page            Página actual (1-indexed).
	 *     @type int    $per_page        Registros por página.
	 * }
	 * @return array{items:array,total:int}
	 */
	public static function buscar_listado( array $args ) {
		global $wpdb;

		$search   = isset( $args['search'] ) ? trim( (string) $args['search'] ) : '';
		$page     = isset( $args['page'] ) ? max( 1, absint( $args['page'] ) ) : 1;
		$per_page = isset( $args['per_page'] ) ? absint( $args['per_page'] ) : 10;

		$allowed_per_page = array( 10, 25, 50, 100 );
		if ( ! in_array( $per_page, $allowed_per_page, true ) ) {
			$per_page = 10;
		}

		$offset           = ( $page - 1 ) * $per_page;
		$capabilities_key = $wpdb->prefix . 'capabilities';

		$where  = array( 'cap.meta_value LIKE %s' );
		$params = array( '%' . $wpdb->esc_like( 's:13:"external_user"' ) . '%' );

		if ( '' !== $search ) {
			$like     = '%' . $wpdb->esc_like( $search ) . '%';
			$where[]  = '(u.user_login LIKE %s OR u.user_email LIKE %s OR fn.meta_value LIKE %s OR ln.meta_value LIKE %s)';
			$params[] = $like;
			$params[] = $like;
			$params[] = $like;
			$params[] = $like;
		}

		// Filtro de Programa (Inspira / Octagono / Todas / Ninguna) —
		// misma lógica EXISTS/NOT EXISTS usada en Integrantes/Empresas.
		$programa_filtro = isset( $args['programa_filtro'] ) ? sanitize_key( $args['programa_filtro'] ) : '';

		if ( '' !== $programa_filtro ) {
			$existe_inspira  = "EXISTS (SELECT 1 FROM {$wpdb->usermeta} pi WHERE pi.user_id = u.ID AND pi.meta_key = 'inspira' AND TRIM(pi.meta_value) != '')";
			$existe_octagono = "EXISTS (SELECT 1 FROM {$wpdb->usermeta} po WHERE po.user_id = u.ID AND po.meta_key = 'octagono' AND TRIM(po.meta_value) != '')";

			if ( 'inspira' === $programa_filtro ) {
				$where[] = $existe_inspira;
			} elseif ( 'octagono' === $programa_filtro ) {
				$where[] = $existe_octagono;
			} elseif ( 'todas' === $programa_filtro ) {
				$where[] = "({$existe_inspira} AND {$existe_octagono})";
			} elseif ( 'ninguna' === $programa_filtro ) {
				$where[] = "(NOT {$existe_inspira} AND NOT {$existe_octagono})";
			}
		}

		$where_sql = implode( ' AND ', $where );

		$count_sql = "
			SELECT COUNT(DISTINCT u.ID)
			FROM {$wpdb->users} u
			LEFT JOIN {$wpdb->usermeta} cap ON cap.user_id = u.ID AND cap.meta_key = '{$capabilities_key}'
			LEFT JOIN {$wpdb->usermeta} fn ON fn.user_id = u.ID AND fn.meta_key = 'first_name'
			LEFT JOIN {$wpdb->usermeta} ln ON ln.user_id = u.ID AND ln.meta_key = 'last_name'
			WHERE {$where_sql}
		";

		$total = (int) $wpdb->get_var( $wpdb->prepare( $count_sql, $params ) );

		$select_sql = "
			SELECT
				u.ID AS id,
				u.user_login,
				u.user_email,
				u.display_name,
				MAX(fn.meta_value) AS first_name,
				MAX(ln.meta_value) AS last_name,
				MAX(inspira.meta_value) AS inspira_valor,
				MAX(octagono.meta_value) AS octagono_valor
			FROM {$wpdb->users} u
			LEFT JOIN {$wpdb->usermeta} cap ON cap.user_id = u.ID AND cap.meta_key = '{$capabilities_key}'
			LEFT JOIN {$wpdb->usermeta} fn ON fn.user_id = u.ID AND fn.meta_key = 'first_name'
			LEFT JOIN {$wpdb->usermeta} ln ON ln.user_id = u.ID AND ln.meta_key = 'last_name'
			LEFT JOIN {$wpdb->usermeta} inspira ON inspira.user_id = u.ID AND inspira.meta_key = 'inspira'
			LEFT JOIN {$wpdb->usermeta} octagono ON octagono.user_id = u.ID AND octagono.meta_key = 'octagono'
			WHERE {$where_sql}
			GROUP BY u.ID
			ORDER BY u.ID DESC
			LIMIT %d OFFSET %d
		";

		$select_params   = $params;
		$select_params[] = $per_page;
		$select_params[] = $offset;

		$rows = $wpdb->get_results( $wpdb->prepare( $select_sql, $select_params ), ARRAY_A );

		$items = array();
		foreach ( (array) $rows as $row ) {
			$items[] = self::formatear_fila( $row );
		}

		return array(
			'items' => $items,
			'total' => $total,
		);
	}

	/**
	 * Da formato a una fila cruda para la vista. Usa las mismas claves
	 * `inspira_valor`/`octagono_valor` que en Integrantes/Empresas, para
	 * reutilizar tal cual el JS de renderizado de "Programas".
	 *
	 * @param array $row Fila devuelta por $wpdb.
	 * @return array
	 */
	private static function formatear_fila( array $row ) {
		$first_name = trim( (string) ( $row['first_name'] ?? '' ) );
		$last_name  = trim( (string) ( $row['last_name'] ?? '' ) );

		if ( '' !== $first_name && '' !== $last_name ) {
			$nombre = trim( $first_name . ' ' . $last_name );
		} else {
			$nombre = $row['user_login'];
		}

		return array(
			'id'             => (int) $row['id'],
			'nombre'         => $nombre,
			'user_email'     => $row['user_email'],
			'user_login'     => $row['user_login'],
			'rol'            => 'external_user',
			'inspira_valor'  => trim( (string) ( $row['inspira_valor'] ?? '' ) ),
			'octagono_valor' => trim( (string) ( $row['octagono_valor'] ?? '' ) ),
		);
	}

	/**
	 * Devuelve TODOS los usuarios con rol `external_user` (sin
	 * paginación ni filtros), para la acción global "Refrescar
	 * programas" del Tab Usuarios Externos.
	 *
	 * @return array<int, array{id:int,email:string}>
	 */
	public static function obtener_todos_para_sincronizar() {
		global $wpdb;

		$capabilities_key = $wpdb->prefix . 'capabilities';

		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"
				SELECT u.ID AS id, u.user_email AS email
				FROM {$wpdb->users} u
				INNER JOIN {$wpdb->usermeta} cap ON cap.user_id = u.ID AND cap.meta_key = %s
				WHERE cap.meta_value LIKE %s
				ORDER BY u.ID DESC
				",
				$capabilities_key,
				'%' . $wpdb->esc_like( 's:13:"external_user"' ) . '%'
			),
			ARRAY_A
		);

		$usuarios = array();
		foreach ( (array) $rows as $row ) {
			$usuarios[] = array(
				'id'    => (int) $row['id'],
				'email' => $row['email'],
			);
		}

		return $usuarios;
	}
}
