<?php
/**
 * Servicio de negocio para vincular a un usuario existente con una
 * nueva área/paquete (modal "Agregar área" dentro de "Áreas del
 * usuario", Tab Integrantes).
 *
 * A propósito, sigue el mismo principio ya establecido para
 * "Usuarios que se agregarán a esta área" en el asistente de
 * importación masiva: solo se inserta la nueva fila en
 * `wp_correos_configurados`, sin tocar el rol del usuario, su
 * "empresa principal" (`empresa_id`), sus metadatos opcionales, ni
 * `user_code_company`, y sin disparar ningún webhook.
 *
 * @package Administrador_Usuarios_WMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AU_Area_Usuario_Service {

	/**
	 * Vincula a un usuario con un área/paquete, y refresca el
	 * `usage_count` del cupón de WooCommerce asociado a esa área
	 * contando los registros reales que quedan en
	 * `wp_correos_configurados` para su `codigo_area`.
	 *
	 * @param int $user_id    ID del usuario.
	 * @param int $paquete_id ID del área/paquete a vincular.
	 * @return array{success:bool,message?:string,nombre_usuario?:string,area_nombre?:string}
	 */
	public static function vincular( $user_id, $paquete_id ) {
		$user_id    = absint( $user_id );
		$paquete_id = absint( $paquete_id );

		$usuario = get_userdata( $user_id );

		if ( ! $usuario ) {
			return array(
				'success' => false,
				'message' => __( 'El usuario no existe.', 'au-wms' ),
			);
		}

		$paquete = AU_Repository_Empresas::get_paquete( $paquete_id );

		if ( ! $paquete ) {
			return array(
				'success' => false,
				'message' => __( 'El área seleccionada no es válida.', 'au-wms' ),
			);
		}

		global $wpdb;
		$correos_table = $wpdb->prefix . 'correos_configurados';

		// Revalidación de seguridad: el usuario no debe pertenecer ya a
		// esta área. El select del frontend ya la excluye, pero no se
		// confía únicamente en eso (por ejemplo, si el usuario abrió
		// dos veces el modal, o si otro proceso lo agregó justo antes).
		$ya_pertenece = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT 1 FROM {$correos_table} WHERE email = %s AND codigo_area = %s LIMIT 1",
				$usuario->user_email,
				$paquete['codigo']
			)
		);

		if ( $ya_pertenece ) {
			return array(
				'success' => false,
				'message' => __( 'El usuario ya pertenece a esta área.', 'au-wms' ),
			);
		}

		// No se permite vincular si el área ya no tiene cupos
		// disponibles. Se recalcula en tiempo real (no se confía en la
		// foto que el frontend cargó al abrir el modal, que pudo haber
		// quedado desactualizada mientras el administrador decidía).
		$cupo       = (int) $paquete['cupo'];
		$utilizados = AU_Repository_Usuarios::contar_por_codigo_area( $paquete['codigo'] );

		if ( $utilizados >= $cupo ) {
			return array(
				'success' => false,
				'message' => __( 'Esta área ya no tiene cupos disponibles.', 'au-wms' ),
			);
		}

		// Se usa @ para suprimir el warning nativo de $wpdb en la
		// colisión de la clave única (email + codigo_area); si ya
		// existía por una condición de carrera, no se considera error.
		$insertado = @$wpdb->insert(
			$correos_table,
			array(
				'codigo_area' => $paquete['codigo'],
				'empresa_id'  => (int) $paquete['empresa_id'],
				'email'       => $usuario->user_email,
				'estado'      => 0,
				'test'        => 0,
			),
			array( '%s', '%d', '%s', '%d', '%d' )
		);

		if ( false === $insertado && false === strpos( (string) $wpdb->last_error, 'Duplicate entry' ) ) {
			return array(
				'success' => false,
				'message' => __( 'No fue posible vincular al usuario con el área seleccionada.', 'au-wms' ),
			);
		}

		// Refresca el usage_count del cupón de WooCommerce asociado a
		// esta área (codigo_area), contando los registros reales que
		// quedaron en wp_correos_configurados para ese código.
		AU_Coupon_Service::recalcular_por_codigo_area( $paquete['codigo'] );

		return array(
			'success'        => true,
			'nombre_usuario' => self::nombre_para_mostrar( $usuario ),
			'area_nombre'    => $paquete['nombre'],
		);
	}

	/**
	 * Desvincula a un usuario de un área/paquete (elimina su fila en
	 * `wp_correos_configurados` para ese `codigo_area`), y refresca el
	 * `usage_count` del cupón de WooCommerce asociado a esa área
	 * contando los registros reales que quedan tras el borrado.
	 *
	 * @param int $user_id    ID del usuario.
	 * @param int $paquete_id ID del área/paquete a desvincular.
	 * @return array{success:bool,message?:string,nombre_usuario?:string,area_nombre?:string}
	 */
	public static function desvincular( $user_id, $paquete_id ) {
		$user_id    = absint( $user_id );
		$paquete_id = absint( $paquete_id );

		$usuario = get_userdata( $user_id );

		if ( ! $usuario ) {
			return array(
				'success' => false,
				'message' => __( 'El usuario no existe.', 'au-wms' ),
			);
		}

		$paquete = AU_Repository_Empresas::get_paquete( $paquete_id );

		if ( ! $paquete ) {
			return array(
				'success' => false,
				'message' => __( 'El área seleccionada no es válida.', 'au-wms' ),
			);
		}

		global $wpdb;
		$correos_table = $wpdb->prefix . 'correos_configurados';

		// No se permite desvincular si esta es la única área del
		// usuario: no puede quedar sin ninguna. Se revalida aquí (no
		// solo en el frontend) por si, por ejemplo, el usuario abrió
		// el modal en dos pestañas o ya se había desvinculado de sus
		// otras áreas mientras tenía este modal abierto.
		$total_areas_usuario = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$correos_table} WHERE email = %s",
				$usuario->user_email
			)
		);

		if ( $total_areas_usuario <= 1 ) {
			return array(
				'success' => false,
				'message' => __( 'No puedes desvincular al usuario de su única área.', 'au-wms' ),
			);
		}

		$eliminado = $wpdb->delete(
			$correos_table,
			array(
				'email'       => $usuario->user_email,
				'codigo_area' => $paquete['codigo'],
			),
			array( '%s', '%s' )
		);

		if ( ! $eliminado ) {
			return array(
				'success' => false,
				'message' => __( 'El usuario no pertenece a esta área (o ya fue desvinculado).', 'au-wms' ),
			);
		}

		// Refresca el usage_count del cupón de WooCommerce asociado a
		// esta área (codigo_area), contando los registros reales que
		// quedaron en wp_correos_configurados para ese código después
		// del borrado.
		AU_Coupon_Service::recalcular_por_codigo_area( $paquete['codigo'] );

		return array(
			'success'        => true,
			'nombre_usuario' => self::nombre_para_mostrar( $usuario ),
			'area_nombre'    => $paquete['nombre'],
		);
	}

	/**
	 * Nombre legible del usuario para el mensaje de confirmación:
	 * nombre + apellido si existen, si no `display_name`, si no
	 * `user_login` (mismo criterio usado en el Tab Integrantes).
	 *
	 * @param WP_User $usuario Usuario.
	 * @return string
	 */
	private static function nombre_para_mostrar( $usuario ) {
		$first_name = trim( (string) get_user_meta( $usuario->ID, 'first_name', true ) );
		$last_name  = trim( (string) get_user_meta( $usuario->ID, 'last_name', true ) );

		if ( $first_name || $last_name ) {
			return trim( $first_name . ' ' . $last_name );
		}

		if ( ! empty( $usuario->display_name ) ) {
			return $usuario->display_name;
		}

		return $usuario->user_login;
	}
}
