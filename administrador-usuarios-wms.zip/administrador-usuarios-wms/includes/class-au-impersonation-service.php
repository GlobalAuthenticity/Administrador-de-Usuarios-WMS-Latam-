<?php
/**
 * Mecanismo de "volver al administrador" tras usar "Iniciar sesión
 * como usuario" (impersonación) desde el Tab Empresas o el Tab
 * Integrantes — ambos flujos pasan por
 * `AU_User_Service::iniciar_sesion_como()`, así que esta clase cubre
 * los dos puntos de entrada por igual.
 *
 * Funcionamiento:
 * 1. Justo antes de cambiar de sesión, se guarda una cookie propia
 *    (httponly, nunca accesible desde JS) con el ID del administrador
 *    y el ID del usuario impersonado, firmada con `wp_hash()` (mismo
 *    mecanismo de firma que usan las cookies de autenticación del
 *    núcleo de WordPress) para que no se pueda falsificar sin conocer
 *    las claves secretas de la instalación.
 * 2. Mientras esa cookie siga siendo válida (coincide con el usuario
 *    actualmente conectado), se muestra un aviso — en la barra de
 *    administración de WordPress si está visible, y además una franja
 *    fija al pie de página como respaldo por si el tema la oculta o
 *    el usuario impersonado no la tiene habilitada — con un enlace
 *    para volver a la cuenta del administrador.
 * 3. Ese enlace no usa AJAX (para no depender de que el tema cargue
 *    jQuery en el front-end): es un enlace normal protegido con nonce
 *    que un hook en `init` intercepta, valida y resuelve el cambio de
 *    sesión de vuelta al administrador.
 *
 * @package Administrador_Usuarios_WMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AU_Impersonation_Service {

	/**
	 * Nombre de la cookie que recuerda quién impersonó a quién.
	 */
	const COOKIE_NAME = 'au_wms_switchback';

	/**
	 * Duración de la cookie: si el administrador no vuelve por su
	 * cuenta en este tiempo, deja de ofrecerse la opción (más allá de
	 * eso, la sesión del usuario impersonado sigue su curso normal).
	 */
	const COOKIE_DURATION = 12 * HOUR_IN_SECONDS;

	/**
	 * Engancha los hooks necesarios. Se llama una vez desde
	 * `AU_Loader::init()`, en cada petición (front-end y admin), ya
	 * que la impersonación redirige al usuario al sitio público.
	 *
	 * @return void
	 */
	public static function init_hooks() {
		add_action( 'init', array( __CLASS__, 'manejar_peticion_volver' ) );
		add_action( 'wp_footer', array( __CLASS__, 'render_banner' ) );
		add_action( 'admin_footer', array( __CLASS__, 'render_banner' ) );
		add_action( 'admin_bar_menu', array( __CLASS__, 'agregar_nodo_admin_bar' ), 999 );
	}

	/**
	 * Guarda la cookie de retorno. Debe llamarse ANTES de cambiar de
	 * sesión (mientras `get_current_user_id()` todavía sea el
	 * administrador), y antes de cualquier salida — `setcookie()` no
	 * funciona si ya se enviaron cabeceras.
	 *
	 * @param int $admin_id  ID del administrador que impersona.
	 * @param int $target_id ID del usuario que va a impersonarse.
	 * @return void
	 */
	public static function guardar_retorno( $admin_id, $target_id ) {
		$admin_id  = absint( $admin_id );
		$target_id = absint( $target_id );

		if ( ! $admin_id || ! $target_id ) {
			return;
		}

		$valor = $admin_id . '|' . $target_id . '|' . self::calcular_hash( $admin_id, $target_id );

		self::set_cookie( $valor, time() + self::COOKIE_DURATION );

		// setcookie() solo tiene efecto en la SIGUIENTE petición; se
		// refleja también en $_COOKIE por si algo más adelante en
		// esta misma petición necesitara leerlo.
		$_COOKIE[ self::COOKIE_NAME ] = $valor;
	}

	/**
	 * Borra la cookie de retorno (tras volver, o si resulta inválida).
	 *
	 * @return void
	 */
	public static function limpiar_retorno() {
		self::set_cookie( '', time() - HOUR_IN_SECONDS );
		unset( $_COOKIE[ self::COOKIE_NAME ] );
	}

	/**
	 * Envoltorio de `setcookie()` con los mismos parámetros de
	 * alcance (path/domain/secure) que usa el propio núcleo de
	 * WordPress para sus cookies.
	 *
	 * @param string $valor       Valor de la cookie.
	 * @param int    $expiracion  Timestamp Unix de expiración.
	 * @return void
	 */
	private static function set_cookie( $valor, $expiracion ) {
		setcookie(
			self::COOKIE_NAME,
			$valor,
			array(
				'expires'  => $expiracion,
				'path'     => COOKIEPATH,
				'domain'   => COOKIE_DOMAIN,
				'secure'   => is_ssl(),
				'httponly' => true,
				'samesite' => 'Lax',
			)
		);
	}

	/**
	 * Firma `admin_id|target_id` con `wp_hash()` (usa las claves
	 * secretas de `wp-config.php`, igual que las cookies de auth del
	 * núcleo), para que la cookie no se pueda falsificar desde fuera.
	 *
	 * @param int $admin_id  ID del administrador.
	 * @param int $target_id ID del usuario impersonado.
	 * @return string
	 */
	private static function calcular_hash( $admin_id, $target_id ) {
		return wp_hash( 'au_wms_switchback|' . $admin_id . '|' . $target_id, 'auth' );
	}

	/**
	 * Lee y valida la cookie de retorno contra el usuario actualmente
	 * conectado. Devuelve el WP_User del administrador solo si:
	 * - la cookie existe y su firma es correcta,
	 * - el usuario actualmente conectado es justo el que se
	 *   impersonó (si cerró sesión o inició sesión como otra persona,
	 *   la cookie queda obsoleta y se ignora),
	 * - el administrador todavía existe y sigue teniendo capacidad
	 *   `manage_options` (por si se le revocó el rol mientras tanto).
	 *
	 * @return WP_User|null
	 */
	public static function obtener_admin_para_retorno() {
		if ( empty( $_COOKIE[ self::COOKIE_NAME ] ) ) {
			return null;
		}

		$partes = explode( '|', sanitize_text_field( wp_unslash( $_COOKIE[ self::COOKIE_NAME ] ) ) );

		if ( 3 !== count( $partes ) ) {
			return null;
		}

		list( $admin_id, $target_id, $hash ) = $partes;

		$admin_id  = absint( $admin_id );
		$target_id = absint( $target_id );

		if ( ! $admin_id || ! $target_id ) {
			return null;
		}

		if ( ! hash_equals( self::calcular_hash( $admin_id, $target_id ), (string) $hash ) ) {
			return null;
		}

		if ( ! is_user_logged_in() || get_current_user_id() !== $target_id ) {
			return null;
		}

		$admin = get_userdata( $admin_id );

		if ( ! $admin || ! user_can( $admin, 'manage_options' ) ) {
			return null;
		}

		return $admin;
	}

	/**
	 * Genera la URL del enlace "Volver a {administrador}", protegida
	 * con un nonce atado al usuario actualmente conectado (el
	 * impersonado) — válido porque se genera y se verifica dentro de
	 * esa misma sesión, sin necesitar el contexto del administrador.
	 *
	 * @return string
	 */
	private static function url_volver() {
		return add_query_arg(
			array(
				'au_wms_volver_admin' => '1',
				'_wpnonce'             => wp_create_nonce( 'au_wms_volver_admin_' . get_current_user_id() ),
			),
			home_url( '/' )
		);
	}

	/**
	 * Hook `init`: si la petición trae `?au_wms_volver_admin=1`,
	 * intenta resolver el regreso a la cuenta del administrador y
	 * redirige — al panel de "Usuarios WMS" si funcionó, o al home si
	 * el enlace ya no era válido (cookie expirada, nonce vencido,
	 * etc.), para no dejar una pantalla en blanco.
	 *
	 * @return void
	 */
	public static function manejar_peticion_volver() {
		if ( empty( $_GET['au_wms_volver_admin'] ) ) {
			return;
		}

		$admin = self::obtener_admin_para_retorno();

		$nonce_valido = $admin && isset( $_GET['_wpnonce'] ) && wp_verify_nonce(
			sanitize_text_field( wp_unslash( $_GET['_wpnonce'] ) ),
			'au_wms_volver_admin_' . get_current_user_id()
		);

		if ( $admin && $nonce_valido ) {
			wp_clear_auth_cookie();
			wp_destroy_current_session();

			wp_set_current_user( $admin->ID );
			wp_set_auth_cookie( $admin->ID, false );

			self::limpiar_retorno();

			/**
			 * Se dispara al volver de una impersonación a la cuenta
			 * del administrador — por si se quiere registrar
			 * auditoría (mismo criterio que `au_wms_user_impersonated`).
			 */
			do_action( 'au_wms_volvio_a_administrador', $admin->ID );

			wp_safe_redirect( admin_url( 'admin.php?page=' . AU_Admin::PAGE_SLUG ) );
			exit;
		}

		// Enlace inválido u obsoleto: se limpia cualquier resto de
		// cookie y se manda al home en vez de dejar la petición sin
		// respuesta.
		self::limpiar_retorno();
		wp_safe_redirect( home_url( '/' ) );
		exit;
	}

	/**
	 * Nodo "⇦ Volver a {administrador}" en la barra de administración
	 * de WordPress, si está visible para el usuario impersonado.
	 *
	 * @param WP_Admin_Bar $wp_admin_bar Instancia de la admin bar.
	 * @return void
	 */
	public static function agregar_nodo_admin_bar( $wp_admin_bar ) {
		$admin = self::obtener_admin_para_retorno();

		if ( ! $admin ) {
			return;
		}

		$wp_admin_bar->add_node(
			array(
				'id'    => 'au-wms-volver-admin',
				'title' => sprintf(
					/* translators: %s: nombre del administrador */
					esc_html__( '⇦ Volver a %s', 'au-wms' ),
					esc_html( $admin->display_name ? $admin->display_name : $admin->user_login )
				),
				'href'  => esc_url( self::url_volver() ),
				'meta'  => array(
					'title' => __( 'Salir de esta cuenta y volver a tu sesión de administrador', 'au-wms' ),
				),
			)
		);
	}

	/**
	 * Franja fija al pie de página (front-end y wp-admin) con el
	 * mismo enlace de retorno — respaldo por si la admin bar no está
	 * visible (tema que la oculta, o preferencia del usuario
	 * impersonado con "Mostrar barra de administración" desactivado).
	 *
	 * @return void
	 */
	public static function render_banner() {
		$admin = self::obtener_admin_para_retorno();

		if ( ! $admin ) {
			return;
		}

		$usuario_actual  = wp_get_current_user();
		$nombre_actual   = $usuario_actual->display_name ? $usuario_actual->display_name : $usuario_actual->user_login;
		$nombre_admin    = $admin->display_name ? $admin->display_name : $admin->user_login;
		$url             = self::url_volver();
		?>
		<div id="au-wms-switchback-banner" style="position:fixed;left:0;right:0;bottom:0;z-index:2147483647;display:flex;align-items:center;justify-content:center;gap:12px;flex-wrap:wrap;padding:10px 16px;background:#131A1E;color:#fff;font:13px/1.4 -apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;box-shadow:0 -2px 10px rgba(0,0,0,.2);">
			<span>
				<?php
				printf(
					/* translators: %s: nombre del usuario impersonado */
					esc_html__( 'Sesión iniciada como %s.', 'au-wms' ),
					esc_html( $nombre_actual )
				);
				?>
			</span>
			<a href="<?php echo esc_url( $url ); ?>" style="background:#F7F05E;color:#0B0F0E;padding:6px 16px;border-radius:999px;text-decoration:none;font-weight:600;white-space:nowrap;">
				<?php
				printf(
					/* translators: %s: nombre del administrador */
					esc_html__( 'Volver a %s', 'au-wms' ),
					esc_html( $nombre_admin )
				);
				?>
			</a>
		</div>
		<?php
	}
}
