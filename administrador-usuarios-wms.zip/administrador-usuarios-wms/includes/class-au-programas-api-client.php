<?php
/**
 * Cliente de las APIs "User Data API" de Inspira y de Octágono del
 * sentido, usadas por el asistente "Crear Empresa".
 *
 * Las dos exponen `POST /wp-json/user-data-api/v1/company` con Bearer
 * token, pero NO tienen el mismo contrato: Inspira acepta `apellidos`
 * como campo propio y Octágono no (allá el encargado va completo en
 * `nombre_encargado`). Esta clase solo transporta lo que le arma
 * `AU_Crear_Empresa_Service`; no inventa campos.
 *
 * Ninguna de las dos acepta recibir una contraseña: cada sitio genera la
 * suya y la devuelve una sola vez en la respuesta. Por eso el resultado
 * de `crear_empresa()` incluye `password`, y el asistente muestra una
 * credencial por plataforma en vez de prometer una sola compartida.
 *
 * Las peticiones salen siempre desde el servidor: los tokens viven en
 * "Usuarios WMS → Configuración" y nunca se localizan en el navegador.
 *
 * @package Administrador_Usuarios_WMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AU_Programas_Api_Client {

	/**
	 * Claves de configuración de cada programa.
	 *
	 * @var array<string, array{url:string, token:string, etiqueta:string}>
	 */
	const PROGRAMAS = array(
		'inspira'  => array(
			'url'      => 'crear_empresa_inspira_url',
			'token'    => 'crear_empresa_inspira_token',
			'etiqueta' => 'Inspira',
		),
		'octagono' => array(
			'url'      => 'crear_empresa_octagono_url',
			'token'    => 'crear_empresa_octagono_token',
			'etiqueta' => 'Octágono del sentido',
		),
	);

	/**
	 * Crea una empresa (y sus áreas) en el programa indicado.
	 *
	 * @param string $programa 'inspira' u 'octagono'.
	 * @param array  $payload  Cuerpo JSON ya armado para ESA API.
	 * @return array {
	 *     @type bool   $success
	 *     @type string $message
	 *     @type int    $codigo   Código HTTP de la respuesta (0 si no hubo).
	 *     @type string $email    Correo final en esa plataforma.
	 *     @type string $password Contraseña generada allá.
	 *     @type array  $areas    Resultado por área, tal como lo devuelve la API.
	 * }
	 */
	public static function crear_empresa( $programa, array $payload ) {
		if ( ! isset( self::PROGRAMAS[ $programa ] ) ) {
			return self::error( __( 'Programa desconocido.', 'au-wms' ) );
		}

		$config   = self::PROGRAMAS[ $programa ];
		$url      = trim( (string) AU_Settings::get( $config['url'], '' ) );
		$token    = trim( (string) AU_Settings::get( $config['token'], '' ) );
		$etiqueta = $config['etiqueta'];

		if ( '' === $url ) {
			return self::error(
				/* translators: %s: program name. */
				sprintf( __( 'Falta la URL de la API de %s (Usuarios WMS → Configuración).', 'au-wms' ), $etiqueta )
			);
		}

		if ( '' === $token ) {
			return self::error(
				/* translators: %s: program name. */
				sprintf( __( 'Falta el token de la API de %s (Usuarios WMS → Configuración).', 'au-wms' ), $etiqueta )
			);
		}

		$respuesta = wp_remote_post(
			$url,
			array(
				'timeout' => 45,
				'headers' => array(
					'Authorization' => 'Bearer ' . $token,
					'Content-Type'  => 'application/json',
					'Accept'        => 'application/json',
				),
				'body'    => wp_json_encode( $payload ),
			)
		);

		if ( is_wp_error( $respuesta ) ) {
			return self::error( $respuesta->get_error_message() );
		}

		$codigo = (int) wp_remote_retrieve_response_code( $respuesta );
		$cuerpo = json_decode( wp_remote_retrieve_body( $respuesta ), true );
		$cuerpo = is_array( $cuerpo ) ? $cuerpo : array();

		// Las dos APIs responden {success:false, message:"..."} en sus
		// errores de negocio (400/409) y {code,message} en el 401 del
		// token; se muestra el mensaje que venga, sin inventar uno.
		if ( $codigo < 200 || $codigo >= 300 || empty( $cuerpo['success'] ) ) {
			$mensaje = isset( $cuerpo['message'] ) && '' !== $cuerpo['message']
				? (string) $cuerpo['message']
				/* translators: 1: program name, 2: HTTP status code. */
				: sprintf( __( '%1$s respondió con el código %2$d.', 'au-wms' ), $etiqueta, $codigo );

			return array(
				'success' => false,
				'codigo'  => $codigo,
				'message' => $mensaje,
			);
		}

		$empresa = isset( $cuerpo['empresa'] ) && is_array( $cuerpo['empresa'] ) ? $cuerpo['empresa'] : array();

		return array(
			'success'            => true,
			'codigo'             => $codigo,
			'message'            => isset( $cuerpo['message'] ) ? (string) $cuerpo['message'] : '',
			'user_id'            => isset( $empresa['user_id'] ) ? (int) $empresa['user_id'] : 0,
			'email'              => isset( $empresa['email'] ) ? (string) $empresa['email'] : '',
			'password'           => isset( $empresa['password'] ) ? (string) $empresa['password'] : '',
			'rol'                => isset( $empresa['rol'] ) ? (string) $empresa['rol'] : '',
			'areas'              => isset( $cuerpo['areas'] ) && is_array( $cuerpo['areas'] ) ? $cuerpo['areas'] : array(),
			'defaults_aplicados' => isset( $cuerpo['defaults_aplicados'] ) && is_array( $cuerpo['defaults_aplicados'] )
				? $cuerpo['defaults_aplicados']
				: array(),
		);
	}

	/**
	 * ¿Qué programas externos no tienen token configurado todavía?
	 *
	 * @return array<string,string> clave => etiqueta.
	 */
	public static function tokens_faltantes() {
		$faltantes = array();

		foreach ( self::PROGRAMAS as $clave => $config ) {
			if ( '' === trim( (string) AU_Settings::get( $config['token'], '' ) ) ) {
				$faltantes[ $clave ] = $config['etiqueta'];
			}
		}

		return $faltantes;
	}

	/**
	 * Respuesta de error sin llamada HTTP (configuración incompleta).
	 *
	 * @param string $mensaje Mensaje para el administrador.
	 * @return array
	 */
	private static function error( $mensaje ) {
		return array(
			'success' => false,
			'codigo'  => 0,
			'message' => $mensaje,
		);
	}
}
