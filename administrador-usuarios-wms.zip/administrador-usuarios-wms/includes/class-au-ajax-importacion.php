<?php
/**
 * Controlador AJAX para la importación masiva de usuarios (modal
 * "Importar usuarios" dentro del Tab Integrantes).
 *
 * @package Administrador_Usuarios_WMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AU_Ajax_Importacion {

	/**
	 * Instancia única (singleton).
	 *
	 * @var AU_Ajax_Importacion|null
	 */
	private static $instance = null;

	/**
	 * Extensiones de archivo permitidas para la importación.
	 *
	 * @var array<int,string>
	 */
	const EXTENSIONES_PERMITIDAS = array( 'csv', 'xls', 'xlsx' );

	/**
	 * Devuelve la instancia única y engancha las acciones AJAX.
	 *
	 * @return AU_Ajax_Importacion
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
			self::$instance->register_hooks();
		}

		return self::$instance;
	}

	/**
	 * Registra los endpoints AJAX del asistente de importación.
	 *
	 * @return void
	 */
	private function register_hooks() {
		add_action( 'wp_ajax_au_wms_import_area_info', array( $this, 'handle_area_info' ) );
		add_action( 'wp_ajax_au_wms_import_upload', array( $this, 'handle_upload' ) );
		add_action( 'wp_ajax_au_wms_import_validar', array( $this, 'handle_validar' ) );
		add_action( 'wp_ajax_au_wms_import_procesar_lote', array( $this, 'handle_procesar_lote' ) );
	}

	/**
	 * Devuelve el resumen de cupos del área seleccionada.
	 *
	 * @return void
	 */
	public function handle_area_info() {
		AU_Security::guard();

		$paquete_id = isset( $_POST['paquete_id'] ) ? AU_Security::sanitize_int( $_POST['paquete_id'] ) : 0;

		$info = AU_Repository_Empresas::get_area_info( $paquete_id );

		if ( ! $info ) {
			wp_send_json_error( array( 'message' => __( 'El área seleccionada no es válida.', 'au-wms' ) ) );
		}

		wp_send_json_success( array( 'area' => $info ) );
	}

	/**
	 * Recibe el archivo subido (CSV/XLS/XLSX), lo parsea y devuelve los
	 * encabezados detectados junto con una sugerencia de mapeo.
	 *
	 * @return void
	 */
	public function handle_upload() {
		AU_Security::guard();

		if ( empty( $_FILES['archivo'] ) || UPLOAD_ERR_OK !== $_FILES['archivo']['error'] ) {
			wp_send_json_error( array( 'message' => __( 'No se recibió ningún archivo válido.', 'au-wms' ) ) );
		}

		$nombre_original = sanitize_file_name( $_FILES['archivo']['name'] );
		$extension       = strtolower( pathinfo( $nombre_original, PATHINFO_EXTENSION ) );

		if ( ! in_array( $extension, self::EXTENSIONES_PERMITIDAS, true ) ) {
			wp_send_json_error( array( 'message' => __( 'Solo se permiten archivos CSV, XLS o XLSX.', 'au-wms' ) ) );
		}

		if ( ! function_exists( 'wp_handle_upload' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
		}

		$archivo_subido = wp_handle_upload(
			$_FILES['archivo'],
			array(
				'test_form' => false,
				'mimes'     => array(
					'csv'  => 'text/csv',
					'xls'  => 'application/vnd.ms-excel',
					'xlsx' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
				),
			)
		);

		if ( isset( $archivo_subido['error'] ) ) {
			wp_send_json_error( array( 'message' => $archivo_subido['error'] ) );
		}

		try {
			$parseado = AU_File_Parser::parse( $archivo_subido['file'], $extension );
		} catch ( Exception $e ) {
			wp_delete_file( $archivo_subido['file'] );
			wp_send_json_error( array( 'message' => $e->getMessage() ) );
		}

		// El archivo ya fue leído en memoria; no es necesario conservarlo.
		wp_delete_file( $archivo_subido['file'] );

		if ( empty( $parseado['rows'] ) ) {
			wp_send_json_error( array( 'message' => __( 'El archivo no contiene filas de datos.', 'au-wms' ) ) );
		}

		$import_id = AU_Import_Validator::guardar_archivo_parseado( $parseado['headers'], $parseado['rows'] );
		$mapeo     = AU_Column_Mapper::sugerir_mapeo( $parseado['headers'] );

		wp_send_json_success(
			array(
				'import_id'      => $import_id,
				'headers'        => $parseado['headers'],
				'total_filas'    => count( $parseado['rows'] ),
				'mapeo_sugerido' => $mapeo,
				'campos'         => AU_Column_Mapper::campos_disponibles(),
				'muestra'        => array_slice( $parseado['rows'], 0, 5 ),
			)
		);
	}

	/**
	 * Ejecuta la validación previa (sin escribir en base de datos) y
	 * devuelve la previsualización de los 3 grupos + conteos + cupos.
	 *
	 * @return void
	 */
	public function handle_validar() {
		AU_Security::guard();

		$import_id  = isset( $_POST['import_id'] ) ? AU_Security::sanitize_text( $_POST['import_id'] ) : '';
		$empresa_id = isset( $_POST['empresa_id'] ) ? AU_Security::sanitize_int( $_POST['empresa_id'] ) : 0;
		$paquete_id = isset( $_POST['paquete_id'] ) ? AU_Security::sanitize_int( $_POST['paquete_id'] ) : 0;
		$mapping    = isset( $_POST['mapping'] ) && is_array( $_POST['mapping'] ) ? $_POST['mapping'] : array();

		$mapping_sanitizado = array();
		foreach ( $mapping as $campo => $indice ) {
			$campo_key = sanitize_key( $campo );
			$mapping_sanitizado[ $campo_key ] = ( '' === $indice ) ? '' : absint( $indice );
		}

		if ( ! $empresa_id || ! $paquete_id ) {
			wp_send_json_error( array( 'message' => __( 'Debes seleccionar una empresa y un área antes de continuar.', 'au-wms' ) ) );
		}

		try {
			$resultado = AU_Import_Validator::validar( $import_id, $mapping_sanitizado, $empresa_id, $paquete_id );
		} catch ( Exception $e ) {
			wp_send_json_error( array( 'message' => $e->getMessage() ) );
		}

		wp_send_json_success( $resultado );
	}

	/**
	 * Procesa un lote de la importación ya validada.
	 *
	 * @return void
	 */
	public function handle_procesar_lote() {
		AU_Security::guard();

		$import_id  = isset( $_POST['import_id'] ) ? AU_Security::sanitize_text( $_POST['import_id'] ) : '';
		$offset     = isset( $_POST['offset'] ) ? AU_Security::sanitize_int( $_POST['offset'] ) : 0;
		$batch_size = isset( $_POST['batch_size'] ) ? AU_Security::sanitize_int( $_POST['batch_size'] ) : 20;

		$batch_size = max( 1, min( 50, $batch_size ) );

		try {
			$resultado = AU_Import_Service::procesar_lote( $import_id, $offset, $batch_size );
		} catch ( Exception $e ) {
			wp_send_json_error( array( 'message' => $e->getMessage() ) );
		}

		wp_send_json_success( $resultado );
	}
}
