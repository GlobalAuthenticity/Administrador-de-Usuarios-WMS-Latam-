<?php
/**
 * Controlador AJAX para el modal "Áreas del usuario" (Tab Integrantes):
 * lista, con búsqueda por nombre y paginación, todas las áreas a las
 * que pertenece un usuario específico.
 *
 * @package Administrador_Usuarios_WMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AU_Ajax_Areas_Usuario {

	/**
	 * Instancia única (singleton).
	 *
	 * @var AU_Ajax_Areas_Usuario|null
	 */
	private static $instance = null;

	/**
	 * Devuelve la instancia única y engancha las acciones AJAX.
	 *
	 * @return AU_Ajax_Areas_Usuario
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
			self::$instance->register_hooks();
		}

		return self::$instance;
	}

	/**
	 * Registra el endpoint AJAX del modal.
	 *
	 * @return void
	 */
	private function register_hooks() {
		add_action( 'wp_ajax_au_wms_usuario_areas_listar', array( $this, 'handle_listar' ) );
		add_action( 'wp_ajax_au_wms_usuario_areas_disponibles', array( $this, 'handle_areas_disponibles' ) );
		add_action( 'wp_ajax_au_wms_usuario_area_vincular', array( $this, 'handle_vincular' ) );
		add_action( 'wp_ajax_au_wms_usuario_area_desvincular', array( $this, 'handle_desvincular' ) );
	}

	/**
	 * Busca/pagina las áreas a las que pertenece un usuario.
	 *
	 * @return void
	 */
	public function handle_listar() {
		AU_Security::guard();

		$args = array(
			'user_id'  => isset( $_POST['user_id'] ) ? AU_Security::sanitize_int( $_POST['user_id'] ) : 0,
			'search'   => isset( $_POST['search'] ) ? AU_Security::sanitize_text( $_POST['search'] ) : '',
			'page'     => isset( $_POST['page'] ) ? AU_Security::sanitize_int( $_POST['page'] ) : 1,
			'per_page' => isset( $_POST['per_page'] ) ? AU_Security::sanitize_int( $_POST['per_page'] ) : 10,
		);

		$resultado = AU_Repository_Usuarios::buscar_areas_usuario( $args );

		$per_page    = ! empty( $args['per_page'] ) ? $args['per_page'] : 10;
		$total_pages = $per_page > 0 ? (int) ceil( $resultado['total'] / $per_page ) : 1;

		wp_send_json_success(
			array(
				'items'       => $resultado['items'],
				'total'       => $resultado['total'],
				'page'        => max( 1, (int) $args['page'] ),
				'per_page'    => $per_page,
				'total_pages' => max( 1, $total_pages ),
			)
		);
	}

	/**
	 * Devuelve las áreas de la empresa del usuario que todavía no
	 * tiene vinculadas, para poblar el select del modal "Agregar área".
	 *
	 * @return void
	 */
	public function handle_areas_disponibles() {
		AU_Security::guard();

		$user_id = isset( $_POST['user_id'] ) ? AU_Security::sanitize_int( $_POST['user_id'] ) : 0;

		$areas = AU_Repository_Usuarios::obtener_areas_disponibles_para_vincular( $user_id );

		wp_send_json_success( array( 'areas' => $areas ) );
	}

	/**
	 * Vincula al usuario con el área/paquete seleccionada.
	 *
	 * @return void
	 */
	public function handle_vincular() {
		AU_Security::guard();

		$user_id    = isset( $_POST['user_id'] ) ? AU_Security::sanitize_int( $_POST['user_id'] ) : 0;
		$paquete_id = isset( $_POST['paquete_id'] ) ? AU_Security::sanitize_int( $_POST['paquete_id'] ) : 0;

		if ( ! $user_id || ! $paquete_id ) {
			wp_send_json_error( array( 'message' => __( 'Debes seleccionar un área.', 'au-wms' ) ) );
		}

		AU_Security::exigir_usuario_gestionable( $user_id );

		$resultado = AU_Area_Usuario_Service::vincular( $user_id, $paquete_id );

		if ( empty( $resultado['success'] ) ) {
			wp_send_json_error( array( 'message' => $resultado['message'] ) );
		}

		wp_send_json_success( $resultado );
	}

	/**
	 * Desvincula al usuario del área/paquete seleccionada.
	 *
	 * @return void
	 */
	public function handle_desvincular() {
		AU_Security::guard();

		$user_id    = isset( $_POST['user_id'] ) ? AU_Security::sanitize_int( $_POST['user_id'] ) : 0;
		$paquete_id = isset( $_POST['paquete_id'] ) ? AU_Security::sanitize_int( $_POST['paquete_id'] ) : 0;

		if ( ! $user_id || ! $paquete_id ) {
			wp_send_json_error( array( 'message' => __( 'Debes seleccionar un área.', 'au-wms' ) ) );
		}

		AU_Security::exigir_usuario_gestionable( $user_id );

		$resultado = AU_Area_Usuario_Service::desvincular( $user_id, $paquete_id );

		if ( empty( $resultado['success'] ) ) {
			wp_send_json_error( array( 'message' => $resultado['message'] ) );
		}

		wp_send_json_success( $resultado );
	}
}
