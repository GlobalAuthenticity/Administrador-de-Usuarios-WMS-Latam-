<?php
/**
 * Servicio de la acción "Refrescar programas" (Tab Empresas): consulta
 * las APIs de Inspira y Octágono por cada usuario de la empresa y
 * actualiza/elimina los metadatos `inspira`/`octagono` en consecuencia.
 *
 * El procesamiento se hace por lotes (llamados repetidamente desde
 * JavaScript), igual que el asistente de importación masiva, para no
 * agotar el tiempo máximo de ejecución de PHP con decenas de usuarios
 * × 2 llamadas HTTP externas cada uno.
 *
 * @package Administrador_Usuarios_WMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AU_Sync_Programas_Service {

	/**
	 * Tiempo de vida del transient de sincronización (30 minutos).
	 */
	const TTL = 30 * MINUTE_IN_SECONDS;

	/**
	 * Inicia una sincronización para una empresa completa: obtiene el
	 * administrador + todos sus integrantes y guarda la lista en un
	 * transient identificado por un `sync_id`.
	 *
	 * @param int $empresa_id ID de la empresa (usuario con rol `company`).
	 * @return array{sync_id:string,total:int,empresa_nombre:string,emails:array}
	 * @throws Exception Si la empresa no existe.
	 */
	public static function iniciar( $empresa_id ) {
		$empresa = get_userdata( $empresa_id );

		if ( ! $empresa ) {
			throw new Exception( __( 'La empresa seleccionada no existe.', 'au-wms' ) );
		}

		$usuarios = AU_Repository_Empresas::obtener_usuarios_para_sincronizar( $empresa_id );

		$empresa_nombre = get_user_meta( $empresa_id, 'first_name', true );
		if ( '' === trim( (string) $empresa_nombre ) ) {
			$empresa_nombre = $empresa->display_name ? $empresa->display_name : $empresa->user_login;
		}

		return self::crear_sync( $usuarios, $empresa_nombre );
	}

	/**
	 * Inicia una sincronización para un único usuario (acción
	 * "Refrescar programas" del Tab Integrantes, aplicada solo a ese
	 * correo, en vez de a toda la empresa).
	 *
	 * @param int $user_id ID del usuario.
	 * @return array{sync_id:string,total:int,empresa_nombre:string,emails:array}
	 * @throws Exception Si el usuario no existe.
	 */
	public static function iniciar_usuario( $user_id ) {
		$usuario = get_userdata( $user_id );

		if ( ! $usuario ) {
			throw new Exception( __( 'El usuario seleccionado no existe.', 'au-wms' ) );
		}

		$nombre = get_user_meta( $user_id, 'first_name', true );
		$nombre = trim( (string) $nombre ) !== '' ? $nombre : ( $usuario->display_name ? $usuario->display_name : $usuario->user_login );

		$usuarios = array(
			array(
				'id'    => (int) $usuario->ID,
				'email' => $usuario->user_email,
			),
		);

		return self::crear_sync( $usuarios, $nombre );
	}

	/**
	 * Inicia una sincronización para TODAS las cuentas con rol
	 * `company` (opción "Refrescar programas" del botón "Acciones" del
	 * Tab Empresas).
	 *
	 * Solo sincroniza las cuentas de empresa, NO a sus integrantes: esta
	 * acción cubre las filas que muestra el tab, igual que el botón
	 * equivalente de Usuarios Externos. Para refrescar una empresa junto
	 * con todos sus integrantes está la acción por fila (`iniciar()`).
	 *
	 * @return array{sync_id:string,total:int,empresa_nombre:string,emails:array}
	 */
	public static function iniciar_empresas() {
		$usuarios = AU_Repository_Empresas::obtener_todas_las_empresas_para_sincronizar();

		return self::crear_sync( $usuarios, __( 'Empresas', 'au-wms' ) );
	}

	/**
	 * Inicia una sincronización para TODOS los usuarios con rol
	 * `external_user` (botón "Refrescar programas" del Tab Usuarios
	 * Externos, aplicado globalmente en vez de a un solo usuario).
	 *
	 * @return array{sync_id:string,total:int,empresa_nombre:string,emails:array}
	 */
	public static function iniciar_externos() {
		$usuarios = AU_Repository_Usuarios_Externos::obtener_todos_para_sincronizar();

		return self::crear_sync( $usuarios, __( 'Usuarios Externos', 'au-wms' ) );
	}

	/**
	 * Genera un `sync_id`, guarda la lista de usuarios a sincronizar en
	 * un transient, y devuelve el payload inicial que consume el JS.
	 *
	 * @param array  $usuarios Lista de usuarios ({id, email}) a sincronizar.
	 * @param string $etiqueta Nombre a mostrar en el resumen final (empresa o usuario).
	 * @return array{sync_id:string,total:int,empresa_nombre:string,emails:array}
	 */
	private static function crear_sync( array $usuarios, $etiqueta ) {
		$sync_id = wp_generate_uuid4();

		set_transient(
			self::key( $sync_id ),
			array(
				'empresa_nombre' => $etiqueta,
				'usuarios'       => $usuarios,
			),
			self::TTL
		);

		return array(
			'sync_id'        => $sync_id,
			'total'          => count( $usuarios ),
			'empresa_nombre' => $etiqueta,
			'emails'         => wp_list_pluck( $usuarios, 'email' ),
		);
	}

	/**
	 * Procesa un lote de usuarios: para cada uno, consulta ambas APIs y
	 * actualiza/elimina los metadatos correspondientes.
	 *
	 * @param string $sync_id    ID de sincronización.
	 * @param int    $offset     Posición inicial del lote.
	 * @param int    $batch_size Tamaño del lote.
	 * @return array{results:array,offset:int,total:int,done:bool}
	 * @throws Exception Si la sesión de sincronización expiró.
	 */
	public static function procesar_lote( $sync_id, $offset, $batch_size ) {
		$data = get_transient( self::key( $sync_id ) );

		if ( ! $data ) {
			throw new Exception( __( 'La sesión de sincronización expiró. Vuelve a iniciar el proceso.', 'au-wms' ) );
		}

		$usuarios = $data['usuarios'];
		$total    = count( $usuarios );
		$lote     = array_slice( $usuarios, $offset, $batch_size );

		$results = self::sincronizar_lote_en_paralelo( $lote );

		$nuevo_offset = $offset + count( $lote );

		return array(
			'results' => $results,
			'offset'  => $nuevo_offset,
			'total'   => $total,
			'done'    => $nuevo_offset >= $total,
		);
	}

	/**
	 * Sincroniza un lote completo de usuarios EN PARALELO: las llamadas a
	 * Inspira y Octágono de TODOS los usuarios del lote se disparan al
	 * mismo tiempo (curl_multi), en vez de una por una. Con un lote de 5
	 * usuarios, por ejemplo, corren hasta 10 llamadas HTTP simultáneas y
	 * el tiempo total del lote es aproximadamente el de la más lenta de
	 * todas, no la suma de todas. Si `curl_multi` no está disponible, cae
	 * de vuelta a procesar el lote de forma secuencial. Un error en una
	 * llamada nunca impide procesar las demás.
	 *
	 * @param array $usuarios Lote de usuarios ({id, email}) a sincronizar.
	 * @return array Resultado por usuario (mismo formato que antes).
	 */
	private static function sincronizar_lote_en_paralelo( array $usuarios ) {
		$inspira_url    = AU_Settings::get( 'inspira_sync_url', AU_Settings::DEFAULT_INSPIRA_SYNC_URL );
		$inspira_token  = AU_Settings::get( 'inspira_sync_token', '' );
		$octagono_url   = AU_Settings::get( 'octagono_sync_url', AU_Settings::DEFAULT_OCTAGONO_SYNC_URL );
		$octagono_token = AU_Settings::get( 'octagono_sync_token', '' );

		if ( ! function_exists( 'curl_multi_init' ) ) {
			$resultados = array();
			foreach ( $usuarios as $usuario ) {
				$resultados[] = array(
					'user_id'  => (int) $usuario['id'],
					'email'    => $usuario['email'],
					'inspira'  => self::aplicar_resultado( $usuario['id'], 'inspira', self::llamar_api( $inspira_url, $inspira_token, $usuario['email'] ) ),
					'octagono' => self::aplicar_resultado( $usuario['id'], 'octagono', self::llamar_api( $octagono_url, $octagono_token, $usuario['email'] ) ),
				);
			}
			return $resultados;
		}

		$mh      = curl_multi_init();
		$handles = array();

		foreach ( array_values( $usuarios ) as $idx => $usuario ) {
			$body = wp_json_encode( array( 'email' => $usuario['email'] ) );

			$configuraciones = array(
				'inspira'  => array( $inspira_url, $inspira_token ),
				'octagono' => array( $octagono_url, $octagono_token ),
			);

			foreach ( $configuraciones as $programa => $config ) {
				list( $url, $token ) = $config;

				// Sin URL o sin token no se llama a la API: el programa
				// queda con error y su usermeta no se toca.
				if ( empty( $url ) || '' === trim( (string) $token ) ) {
					continue;
				}

				$ch = curl_init( $url );
				curl_setopt( $ch, CURLOPT_POST, true );
				curl_setopt( $ch, CURLOPT_POSTFIELDS, $body );
				curl_setopt(
					$ch,
					CURLOPT_HTTPHEADER,
					array( 'Authorization: Bearer ' . $token, 'Content-Type: application/json' )
				);
				curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true );
				curl_setopt( $ch, CURLOPT_TIMEOUT, 15 );
				curl_setopt( $ch, CURLOPT_SSL_VERIFYPEER, true );

				curl_multi_add_handle( $mh, $ch );
				$handles[ $idx . '_' . $programa ] = array(
					'ch'      => $ch,
					'idx'     => $idx,
					'programa' => $programa,
				);
			}
		}

		if ( ! empty( $handles ) ) {
			$en_ejecucion = null;
			do {
				$estado = curl_multi_exec( $mh, $en_ejecucion );
				if ( $en_ejecucion ) {
					curl_multi_select( $mh );
				}
			} while ( $en_ejecucion > 0 && CURLM_OK === $estado );
		}

		$respuestas_por_indice = array();

		foreach ( $handles as $info ) {
			$ch         = $info['ch'];
			$error_curl = curl_error( $ch );

			if ( '' !== $error_curl ) {
				$resultado_api = array(
					'ok'    => false,
					'error' => $error_curl,
				);
			} else {
				$codigo = (int) curl_getinfo( $ch, CURLINFO_HTTP_CODE );
				$cuerpo = json_decode( curl_multi_getcontent( $ch ), true );

				if ( self::es_codigo_http_de_error( $codigo ) ) {
					$resultado_api = array(
						'ok'    => false,
						/* translators: %d: código de respuesta HTTP */
						'error' => sprintf( __( 'La API rechazó la petición (HTTP %d). Revisa el token en Configuración.', 'au-wms' ), $codigo ),
					);
				} elseif ( ! is_array( $cuerpo ) ) {
					$resultado_api = array(
						'ok'    => false,
						/* translators: %d: código de respuesta HTTP */
						'error' => sprintf( __( 'Respuesta inválida del servidor (HTTP %d).', 'au-wms' ), $codigo ),
					);
				} else {
					$resultado_api = array(
						'ok'   => true,
						'data' => $cuerpo,
					);
				}
			}

			curl_multi_remove_handle( $mh, $ch );
			curl_close( $ch );

			$respuestas_por_indice[ $info['idx'] ][ $info['programa'] ] = $resultado_api;
		}

		curl_multi_close( $mh );

		$sin_url = array(
			'ok'    => false,
			'error' => __( 'URL o token de la API no configurados.', 'au-wms' ),
		);

		$resultados = array();

		foreach ( array_values( $usuarios ) as $idx => $usuario ) {
			$inspira_resp  = isset( $respuestas_por_indice[ $idx ]['inspira'] ) ? $respuestas_por_indice[ $idx ]['inspira'] : $sin_url;
			$octagono_resp = isset( $respuestas_por_indice[ $idx ]['octagono'] ) ? $respuestas_por_indice[ $idx ]['octagono'] : $sin_url;

			$resultados[] = array(
				'user_id'  => (int) $usuario['id'],
				'email'    => $usuario['email'],
				'inspira'  => self::aplicar_resultado( $usuario['id'], 'inspira', $inspira_resp ),
				'octagono' => self::aplicar_resultado( $usuario['id'], 'octagono', $octagono_resp ),
			);
		}

		return $resultados;
	}

	/**
	 * Llama a una API de verificación de programa (POST con Bearer token
	 * y `{"email": ...}` como body). Usada como respaldo secuencial
	 * cuando `curl_multi` no está disponible en el servidor.
	 *
	 * @param string $url   URL del endpoint.
	 * @param string $token Token de autorización.
	 * @param string $email Correo a verificar.
	 * @return array{ok:bool,data?:array,error?:string}
	 */
	private static function llamar_api( $url, $token, $email ) {
		if ( empty( $url ) || '' === trim( (string) $token ) ) {
			return array(
				'ok'    => false,
				'error' => __( 'URL o token de la API no configurados.', 'au-wms' ),
			);
		}

		$response = wp_remote_post(
			$url,
			array(
				'method'  => 'POST',
				'timeout' => 15,
				'headers' => array(
					'Authorization' => 'Bearer ' . $token,
					'Content-Type'  => 'application/json',
				),
				'body'    => wp_json_encode( array( 'email' => $email ) ),
			)
		);

		if ( is_wp_error( $response ) ) {
			return array(
				'ok'    => false,
				'error' => $response->get_error_message(),
			);
		}

		$codigo = (int) wp_remote_retrieve_response_code( $response );
		$cuerpo = json_decode( wp_remote_retrieve_body( $response ), true );

		if ( self::es_codigo_http_de_error( $codigo ) ) {
			return array(
				'ok'    => false,
				/* translators: %d: código de respuesta HTTP */
				'error' => sprintf( __( 'La API rechazó la petición (HTTP %d). Revisa el token en Configuración.', 'au-wms' ), $codigo ),
			);
		}

		if ( ! is_array( $cuerpo ) ) {
			return array(
				'ok'    => false,
				/* translators: %d: código de respuesta HTTP */
				'error' => sprintf( __( 'Respuesta inválida del servidor (HTTP %d).', 'au-wms' ), $codigo ),
			);
		}

		return array(
			'ok'   => true,
			'data' => $cuerpo,
		);
	}

	/**
	 * Códigos HTTP que nunca deben interpretarse como "el usuario no
	 * tiene el programa": errores de autenticación/autorización y
	 * errores del servidor. Sin esta verificación, un 401 con cuerpo
	 * JSON (p. ej. `{"code":"rest_forbidden"}`) llegaba a
	 * aplicar_resultado() como `success` vacío y borraba el usermeta.
	 *
	 * Los demás códigos (incluido 404) se siguen evaluando por su
	 * cuerpo, porque las APIs pueden usarlos para "usuario no encontrado".
	 *
	 * @param int $codigo Código HTTP.
	 * @return bool
	 */
	private static function es_codigo_http_de_error( $codigo ) {
		$codigo = (int) $codigo;

		return 0 === $codigo || 401 === $codigo || 403 === $codigo || 429 === $codigo || $codigo >= 500;
	}

	/**
	 * Aplica el resultado de la API al usermeta correspondiente:
	 * actualiza si `success == true`, elimina si `success == false` y el
	 * metadato ya existía, o reporta el error de conexión sin tocar nada.
	 *
	 * @param int    $user_id  ID del usuario.
	 * @param string $meta_key `inspira` u `octagono`.
	 * @param array  $api      Resultado de llamar_api().
	 * @return array{status:string,mensaje?:string}
	 */
	private static function aplicar_resultado( $user_id, $meta_key, array $api ) {
		if ( ! $api['ok'] ) {
			error_log(
				sprintf( '[AU-WMS] Error al refrescar %s para el usuario #%d: %s', $meta_key, $user_id, $api['error'] )
			);

			return array(
				'status'  => 'error',
				'mensaje' => $api['error'],
			);
		}

		$data = $api['data'];

		if ( ! empty( $data['success'] ) ) {
			$rol = isset( $data['role'] ) ? sanitize_text_field( $data['role'] ) : '';
			update_user_meta( $user_id, $meta_key, $rol );

			return array( 'status' => 'actualizado' );
		}

		if ( metadata_exists( 'user', $user_id, $meta_key ) ) {
			delete_user_meta( $user_id, $meta_key );
			return array( 'status' => 'eliminado' );
		}

		return array( 'status' => 'sin_cambios' );
	}

	/**
	 * Clave de transient para una sincronización.
	 *
	 * @param string $sync_id ID de sincronización.
	 * @return string
	 */
	private static function key( $sync_id ) {
		return 'au_wms_sync_programas_' . sanitize_key( $sync_id );
	}
}
