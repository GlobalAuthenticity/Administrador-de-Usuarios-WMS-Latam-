<?php
/**
 * Generador de contraseñas aleatorias con reglas fijas para el
 * ecosistema WMS Latam (asistente "Importar usuarios" y "Actualizar
 * correos").
 *
 * A diferencia de `wp_generate_password()` (que solo garantiza un
 * pool de caracteres posibles, sin asegurar que cada categoría
 * aparezca), esta clase construye la contraseña garantizando al
 * menos un carácter de cada categoría exigida y evitando el espacio
 * en blanco.
 *
 * @package Administrador_Usuarios_WMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AU_Password_Generator {

	/**
	 * Longitud fija de las contraseñas generadas por el plugin.
	 */
	const LONGITUD = 8;

	/**
	 * Alfabetos sin caracteres ambiguos: se excluyen `0`/`O`, `1`/`l`/`I`
	 * para que la contraseña sea fácil de leer y transcribir a mano
	 * (mismo criterio que `generarPasswordAleatoria()` en admin.js).
	 */
	const CHARS_MINUSCULAS = 'abcdefghijkmnpqrstuvwxyz';
	const CHARS_MAYUSCULAS = 'ABCDEFGHJKLMNPQRSTUVWXYZ';
	const CHARS_NUMEROS    = '23456789';

	/**
	 * Caracteres especiales permitidos. Deliberadamente NO incluye el
	 * espacio (" ") para evitar contraseñas confusas al copiar/pegar.
	 */
	const CHARS_ESPECIALES = '!@#$%&*+-=?';

	/**
	 * Genera una contraseña de 8 caracteres que incluye al menos una
	 * mayúscula, una minúscula, un número y un carácter especial (sin
	 * espacio), en orden final aleatorio.
	 *
	 * @return string
	 */
	public static function generar() {
		// 1) Un carácter garantizado de cada categoría obligatoria.
		$obligatorios = array(
			self::caracter_aleatorio( self::CHARS_MAYUSCULAS ),
			self::caracter_aleatorio( self::CHARS_MINUSCULAS ),
			self::caracter_aleatorio( self::CHARS_NUMEROS ),
			self::caracter_aleatorio( self::CHARS_ESPECIALES ),
		);

		// 2) El resto de la longitud se completa desde el pool combinado.
		$pool = self::CHARS_MAYUSCULAS . self::CHARS_MINUSCULAS . self::CHARS_NUMEROS . self::CHARS_ESPECIALES;

		$restantes = self::LONGITUD - count( $obligatorios );
		$relleno   = array();
		for ( $i = 0; $i < $restantes; $i++ ) {
			$relleno[] = self::caracter_aleatorio( $pool );
		}

		// 3) Mezclar para que las categorías garantizadas no queden
		// siempre en las mismas posiciones (primeros 4 caracteres).
		$caracteres = array_merge( $obligatorios, $relleno );
		self::mezclar( $caracteres );

		return implode( '', $caracteres );
	}

	/**
	 * Devuelve un carácter aleatorio de una cadena dada, usando
	 * `wp_rand()` (WordPress usa `random_int()` internamente cuando
	 * está disponible).
	 *
	 * @param string $charset Conjunto de caracteres candidatos.
	 * @return string
	 */
	private static function caracter_aleatorio( $charset ) {
		$indice = wp_rand( 0, strlen( $charset ) - 1 );
		return substr( $charset, $indice, 1 );
	}

	/**
	 * Baraja un array de caracteres in-place usando `wp_rand()` en
	 * lugar de `shuffle()` nativo (no criptográficamente seguro).
	 *
	 * @param array $items Array de caracteres a mezclar (por referencia).
	 * @return void
	 */
	private static function mezclar( array &$items ) {
		for ( $i = count( $items ) - 1; $i > 0; $i-- ) {
			$j = wp_rand( 0, $i );

			$temp        = $items[ $i ];
			$items[ $i ] = $items[ $j ];
			$items[ $j ] = $temp;
		}
	}
}
