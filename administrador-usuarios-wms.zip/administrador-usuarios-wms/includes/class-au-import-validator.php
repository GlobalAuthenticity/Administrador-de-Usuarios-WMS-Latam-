<?php
/**
 * Ejecuta la validación previa de la importación masiva (sección 7-8
 * del requerimiento): clasifica cada correo en Usuario nuevo /
 * Actualizar / Agregar a esta área / Omitido, detecta duplicados
 * dentro del mismo archivo y valida cupos disponibles. NO escribe
 * nada en la base de datos.
 *
 * @package Administrador_Usuarios_WMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AU_Import_Validator {

	/**
	 * Tiempo de vida de los transients de importación (30 minutos).
	 */
	const TTL = 30 * MINUTE_IN_SECONDS;

	/**
	 * Roles que, al importarse, deben actualizarse a `subscriber` en
	 * vez de omitirse.
	 */
	const ROL_ACTUALIZABLE = 'external_user';

	/**
	 * Rol de un usuario ya activo que, a partir de ahora, puede
	 * pertenecer a varias áreas simultáneamente: si ya tiene este rol
	 * pero NO pertenece todavía al área que se está importando, se le
	 * agrega esa relación adicional (nueva fila en
	 * `wp_correos_configurados`) sin tocar su rol, su empresa
	 * "principal" ni sus metadatos, y sin disparar ningún webhook.
	 */
	const ROL_MULTI_AREA = 'subscriber';

	/**
	 * Guarda los datos crudos del archivo parseado en un transient y
	 * genera un ID único de importación.
	 *
	 * @param array $headers Encabezados del archivo.
	 * @param array $rows    Filas del archivo.
	 * @return string ID de importación.
	 */
	public static function guardar_archivo_parseado( array $headers, array $rows ) {
		$import_id = wp_generate_uuid4();

		set_transient(
			self::key_raw( $import_id ),
			array(
				'headers' => $headers,
				'rows'    => $rows,
			),
			self::TTL
		);

		return $import_id;
	}

	/**
	 * Recupera los datos crudos guardados de un import_id.
	 *
	 * @param string $import_id ID de importación.
	 * @return array|null
	 */
	public static function get_archivo_parseado( $import_id ) {
		$data = get_transient( self::key_raw( $import_id ) );
		return $data ? $data : null;
	}

	/**
	 * Ejecuta la validación previa completa: aplica el mapeo de
	 * columnas, clasifica cada correo y valida cupos disponibles.
	 *
	 * @param string $import_id  ID de importación.
	 * @param array  $mapping    Mapa campo => índice de columna (ej. array('correo' => 2, ...)).
	 * @param int    $empresa_id ID de la empresa seleccionada.
	 * @param int    $paquete_id ID del área/paquete seleccionada.
	 * @return array Resultado de la validación (ver estructura de retorno abajo).
	 * @throws Exception Si faltan datos obligatorios o el archivo no existe.
	 */
	public static function validar( $import_id, array $mapping, $empresa_id, $paquete_id ) {
		if ( empty( $mapping['correo'] ) && '0' !== (string) ( $mapping['correo'] ?? '' ) ) {
			throw new Exception( __( 'Debes asignar una columna al campo obligatorio "Correo".', 'au-wms' ) );
		}

		$archivo = self::get_archivo_parseado( $import_id );
		if ( ! $archivo ) {
			throw new Exception( __( 'La sesión de importación expiró. Vuelve a subir el archivo.', 'au-wms' ) );
		}

		$area_info = AU_Repository_Empresas::get_area_info( $paquete_id );
		if ( ! $area_info ) {
			throw new Exception( __( 'El área seleccionada no es válida.', 'au-wms' ) );
		}

		$nuevos       = array();
		$actualizar   = array();
		$agregar_area = array();
		$omitidos     = array();
		$duplicados   = array();
		$correos_ok   = array(); // Para detectar duplicados dentro del archivo.

		foreach ( $archivo['rows'] as $fila_num => $fila ) {
			$datos = self::extraer_datos_fila( $fila, $mapping );

			if ( '' === $datos['correo'] && self::fila_vacia( $fila ) ) {
				continue; // Ignorar filas completamente vacías.
			}

			if ( '' === $datos['correo'] ) {
				$omitidos[] = array_merge(
					$datos,
					array( 'motivo' => __( 'La fila no tiene un correo asignado.', 'au-wms' ) )
				);
				continue;
			}

			if ( ! is_email( $datos['correo'] ) ) {
				$omitidos[] = array_merge(
					$datos,
					array( 'motivo' => __( 'El formato del correo no es válido.', 'au-wms' ) )
				);
				continue;
			}

			if ( isset( $correos_ok[ $datos['correo'] ] ) ) {
				$duplicados[] = array_merge(
					$datos,
					array( 'motivo' => __( 'Correo duplicado dentro del archivo (se procesará solo la primera aparición).', 'au-wms' ) )
				);
				continue;
			}

			$correos_ok[ $datos['correo'] ] = true;

			$usuario_existente = get_user_by( 'email', $datos['correo'] );

			if ( ! $usuario_existente ) {
				$nuevos[] = $datos;
				continue;
			}

			if ( in_array( self::ROL_ACTUALIZABLE, (array) $usuario_existente->roles, true ) ) {
				$datos['user_id'] = $usuario_existente->ID;
				$actualizar[]     = $datos;
				continue;
			}

			// Usuario ya activo (subscriber): a partir de ahora puede
			// pertenecer a varias áreas. Si todavía NO pertenece al
			// área que se está importando, se le agrega esa relación
			// adicional en vez de omitirlo.
			if ( in_array( self::ROL_MULTI_AREA, (array) $usuario_existente->roles, true ) ) {
				if ( self::usuario_pertenece_al_area( $datos['correo'], $area_info['codigo'] ) ) {
					$omitidos[] = array_merge(
						$datos,
						array( 'motivo' => __( 'El usuario ya pertenece a esta área.', 'au-wms' ) )
					);
					continue;
				}

				$areas_actuales = self::obtener_nombres_area_por_email( $datos['correo'] );

				$datos['user_id']       = $usuario_existente->ID;
				$datos['areas_actuales'] = $areas_actuales;
				$datos['motivo']         = $areas_actuales
					? sprintf(
						/* translators: 1: nombres de las áreas actuales del usuario, 2: nombre del área nueva. */
						__( 'Ya existe en el sistema (área actual: %1$s) — se agregará también al área: %2$s.', 'au-wms' ),
						implode( ', ', $areas_actuales ),
						$area_info['nombre']
					)
					: sprintf(
						/* translators: %s: nombre del área nueva. */
						__( 'Ya existe en el sistema — se agregará al área: %s.', 'au-wms' ),
						$area_info['nombre']
					);

				$agregar_area[] = $datos;
				continue;
			}

			$omitidos[] = array_merge(
				$datos,
				array( 'motivo' => __( 'El usuario ya existe.', 'au-wms' ) )
			);
		}

		$necesarios   = count( $nuevos ) + count( $actualizar ) + count( $agregar_area );
		$disponibles  = $area_info['disponibles'];

		// Solo se bloquea por completo cuando NO queda ningún cupo
		// disponible. Si hay cupos aunque sean insuficientes para todos,
		// se permite continuar y se importa únicamente lo que sí cabe.
		$bloqueado    = ( $disponibles <= 0 ) && ( $necesarios > 0 );
		$parcial      = ! $bloqueado && ( $necesarios > $disponibles );
		$faltan_cupos = ( $bloqueado || $parcial ) ? ( $necesarios - $disponibles ) : 0;

		// Marca, en el mismo orden en que se procesarían (nuevos, luego
		// actualizar, luego agregar_area), cuáles registros caben dentro
		// de los cupos disponibles y cuáles quedarían fuera por falta de
		// cupo. Los marcados como false NO se procesan en el paso de
		// importación.
		$posicion = 0;
		foreach ( $nuevos as &$item ) {
			$item['cabe_en_cupos'] = ( $posicion < $disponibles );
			++$posicion;
		}
		unset( $item );
		foreach ( $actualizar as &$item ) {
			$item['cabe_en_cupos'] = ( $posicion < $disponibles );
			++$posicion;
		}
		unset( $item );
		foreach ( $agregar_area as &$item ) {
			$item['cabe_en_cupos'] = ( $posicion < $disponibles );
			++$posicion;
		}
		unset( $item );

		set_transient(
			self::key_preview( $import_id ),
			array(
				'nuevos'       => $nuevos,
				'actualizar'   => $actualizar,
				'agregar_area' => $agregar_area,
				'empresa_id'   => absint( $empresa_id ),
				'paquete_id'   => absint( $paquete_id ),
				'codigo_area'  => $area_info['codigo'],
			),
			self::TTL
		);

		return array(
			'area'         => $area_info,
			'nuevos'       => $nuevos,
			'actualizar'   => $actualizar,
			'agregar_area' => $agregar_area,
			'omitidos'     => $omitidos,
			'duplicados'   => $duplicados,
			'resumen'      => array(
				'nuevos'       => count( $nuevos ),
				'actualizar'   => count( $actualizar ),
				'agregar_area' => count( $agregar_area ),
				'omitidos'     => count( $omitidos ),
				'duplicados'   => count( $duplicados ),
				'total'        => count( $archivo['rows'] ),
			),
			'bloqueado'    => $bloqueado,
			'parcial'      => $parcial,
			'faltan_cupos' => $faltan_cupos,
		);
	}

	/**
	 * Recupera el conjunto ya validado (nuevos + actualizar) listo para
	 * procesarse por lotes.
	 *
	 * @param string $import_id ID de importación.
	 * @return array|null
	 */
	public static function get_preview( $import_id ) {
		$data = get_transient( self::key_preview( $import_id ) );
		return $data ? $data : null;
	}

	/**
	 * Extrae y normaliza los datos de una fila según el mapeo de
	 * columnas configurado.
	 *
	 * @param array $fila    Fila cruda del archivo.
	 * @param array $mapping Mapa campo => índice de columna.
	 * @return array
	 */
	private static function extraer_datos_fila( array $fila, array $mapping ) {
		$obtener = function ( $campo ) use ( $fila, $mapping ) {
			if ( ! isset( $mapping[ $campo ] ) || '' === $mapping[ $campo ] || null === $mapping[ $campo ] ) {
				return '';
			}
			$indice = (int) $mapping[ $campo ];
			return isset( $fila[ $indice ] ) ? trim( (string) $fila[ $indice ] ) : '';
		};

		return array(
			'correo'   => strtolower( $obtener( 'correo' ) ),
			'nombre'   => $obtener( 'nombre' ),
			'apellido' => $obtener( 'apellido' ),
			'edad'     => $obtener( 'edad' ),
			'genero'   => $obtener( 'genero' ),
			'pais'     => $obtener( 'pais' ),
			'telefono' => $obtener( 'telefono' ),
			'cargo'    => $obtener( 'cargo' ),
		);
	}

	/**
	 * Determina si una fila cruda está completamente vacía.
	 *
	 * @param array $fila Fila cruda.
	 * @return bool
	 */
	private static function fila_vacia( array $fila ) {
		foreach ( $fila as $valor ) {
			if ( '' !== trim( (string) $valor ) ) {
				return false;
			}
		}
		return true;
	}

	/**
	 * Indica si un correo ya tiene un registro en
	 * `wp_correos_configurados` para un `codigo_area` específico (es
	 * decir, si ya pertenece a esa área exacta).
	 *
	 * @param string $email       Correo a verificar.
	 * @param string $codigo_area Código del área a verificar.
	 * @return bool
	 */
	private static function usuario_pertenece_al_area( $email, $codigo_area ) {
		global $wpdb;

		$correos_table = $wpdb->prefix . 'correos_configurados';

		$existe = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT 1 FROM {$correos_table} WHERE email = %s AND codigo_area = %s LIMIT 1",
				$email,
				$codigo_area
			)
		);

		return ! empty( $existe );
	}

	/**
	 * Devuelve los nombres de TODAS las áreas (`wp_paquetes.nombre`) a
	 * las que un correo ya pertenece actualmente, para mostrarlos en
	 * la previsualización cuando se le va a agregar una nueva área.
	 *
	 * @param string $email Correo a consultar.
	 * @return array<int,string>
	 */
	private static function obtener_nombres_area_por_email( $email ) {
		global $wpdb;

		$paquetes_table = $wpdb->prefix . 'paquetes';
		$correos_table  = $wpdb->prefix . 'correos_configurados';

		$nombres = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT DISTINCT p.nombre
				FROM {$correos_table} cc
				INNER JOIN {$paquetes_table} p ON p.codigo = cc.codigo_area
				WHERE cc.email = %s
				ORDER BY p.nombre ASC",
				$email
			)
		);

		return (array) $nombres;
	}

	/**
	 * Clave de transient para los datos crudos del archivo.
	 *
	 * @param string $import_id ID de importación.
	 * @return string
	 */
	private static function key_raw( $import_id ) {
		return 'au_wms_import_raw_' . sanitize_key( $import_id );
	}

	/**
	 * Clave de transient para el resultado ya validado.
	 *
	 * @param string $import_id ID de importación.
	 * @return string
	 */
	private static function key_preview( $import_id ) {
		return 'au_wms_import_preview_' . sanitize_key( $import_id );
	}
}
