<?php
/**
 * Registra el menú de administración y renderiza la vista principal
 * con las 3 pestañas (Empresas, Integrantes, Usuarios Externos).
 *
 * @package Administrador_Usuarios_WMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AU_Admin {

	/**
	 * Slug de la página de administración.
	 */
	const PAGE_SLUG = 'au-wms-administrador-usuarios';

	/**
	 * Slug de la página de configuración (APIs / Webhooks).
	 */
	const SETTINGS_SLUG = 'au-wms-configuracion';

	/**
	 * Instancia única (singleton).
	 *
	 * @var AU_Admin|null
	 */
	private static $instance = null;

	/**
	 * Devuelve la instancia única y engancha los hooks de admin.
	 *
	 * @return AU_Admin
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
			self::$instance->register_hooks();
		}

		return self::$instance;
	}

	/**
	 * Engancha los hooks necesarios en el área de administración.
	 *
	 * @return void
	 */
	private function register_hooks() {
		add_action( 'admin_menu', array( $this, 'register_menu' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );
		// El menú lateral está en todo el administrador, no solo aquí.
		add_action( 'admin_head', array( $this, 'estilos_icono_menu' ) );
	}

	/**
	 * Icono del menú lateral: el logo del plugin como data URI.
	 *
	 * WordPress lo pinta dentro de un `<img>`, así que el SVG no puede
	 * tomar el color del tema por CSS como lo hace un dashicon. El color
	 * real se lo da `estilos_icono_menu()` con un filtro; aquí solo
	 * importa que el trazo no sea transparente.
	 *
	 * @return string Data URI del SVG, o un dashicon si falta el archivo.
	 */
	private static function icono_menu() {
		$ruta = AU_WMS_PLUGIN_DIR . 'assets/img/logo.svg';

		if ( ! file_exists( $ruta ) ) {
			return 'dashicons-groups';
		}

		$svg = file_get_contents( $ruta ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents

		// `currentColor` no resuelve dentro de un <img> (no hereda de la
		// página), así que se fija un color concreto; el filtro de CSS lo
		// convierte luego en el gris/blanco que toque.
		$svg = str_replace( 'currentColor', '#a7aaad', $svg );

		return 'data:image/svg+xml;base64,' . base64_encode( $svg );
	}

	/**
	 * Hace que el logo del menú se comporte como un dashicon: gris
	 * apagado en reposo y blanco en hover o cuando la página está
	 * activa. `brightness(0) invert(1)` lleva cualquier color a blanco
	 * puro, y la opacidad —la misma que usa WordPress para sus iconos—
	 * hace el resto.
	 *
	 * Va en `admin_head` y no en el encolado del plugin porque el menú
	 * lateral se ve en todo el administrador, no solo en estas pantallas.
	 *
	 * @return void
	 */
	public function estilos_icono_menu() {
		$selector = '#adminmenu #toplevel_page_' . self::PAGE_SLUG . ' .wp-menu-image img';
		?>
		<style>
			<?php echo esc_html( $selector ); ?> {
				width: 20px;
				height: 20px;
				padding: 7px 0 0;
				filter: brightness(0) invert(1);
				opacity: 0.6;
			}

			#adminmenu #toplevel_page_<?php echo esc_html( self::PAGE_SLUG ); ?>:hover .wp-menu-image img,
			#adminmenu #toplevel_page_<?php echo esc_html( self::PAGE_SLUG ); ?>.wp-has-current-submenu .wp-menu-image img,
			#adminmenu #toplevel_page_<?php echo esc_html( self::PAGE_SLUG ); ?>.current .wp-menu-image img {
				opacity: 1;
			}
		</style>
		<?php
	}

	/**
	 * Registra la entrada de menú principal en el panel de administración.
	 *
	 * @return void
	 */
	public function register_menu() {
		$main_hook = add_menu_page(
			__( 'Administrador de Usuarios (WMS Latam)', 'au-wms' ),
			__( 'Usuarios WMS', 'au-wms' ),
			'manage_options',
			self::PAGE_SLUG,
			array( $this, 'render_page' ),
			self::icono_menu(),
			26
		);

		$settings_hook = add_submenu_page(
			self::PAGE_SLUG,
			__( 'Configuración (APIs / Webhooks)', 'au-wms' ),
			__( 'Configuración', 'au-wms' ),
			'manage_options',
			self::SETTINGS_SLUG,
			array( $this, 'render_settings_page' )
		);

		// 'load-{hook}' es el hook que WordPress dispara únicamente cuando
		// esa página exacta se está cargando (wp-admin/admin.php lo hace
		// con el hook_suffix real que devuelven add_menu_page()/
		// add_submenu_page() arriba) — a diferencia de comparar
		// current_screen()->id a mano, esto no puede desajustarse. Corre
		// antes de que wp-admin/admin-header.php imprima
		// 'admin_notices'/'all_admin_notices', así que alcanza a quitar
		// cualquier aviso ya registrado (Wordfence, Site Kit, Turnstile,
		// núcleo de WP), sin afectar el resto de wp-admin.
		add_action( "load-{$main_hook}", array( $this, 'suppress_admin_notices' ) );
		add_action( "load-{$settings_hook}", array( $this, 'suppress_admin_notices' ) );
	}

	/**
	 * Quita todos los avisos de admin (Turnstile, Site Kit, actualizaciones
	 * del núcleo/plugins, Wordfence, etc.) en las páginas propias del
	 * plugin. No afecta a esos avisos en el resto de `wp-admin`.
	 *
	 * @return void
	 */
	public function suppress_admin_notices() {
		remove_all_actions( 'admin_notices' );
		remove_all_actions( 'all_admin_notices' );
	}

	/**
	 * Encola los estilos y scripts únicamente en la pantalla del plugin.
	 *
	 * @param string $hook Hook de la pantalla actual de administración.
	 * @return void
	 */
	public function enqueue_assets( $hook ) {
		$es_pagina_principal = ( 'toplevel_page_' . self::PAGE_SLUG === $hook );
		$es_pagina_config    = ( false !== strpos( (string) $hook, self::SETTINGS_SLUG ) );

		if ( ! $es_pagina_principal && ! $es_pagina_config ) {
			return;
		}

		// SweetAlert2 (misma librería usada por el resto del ecosistema WMS Latam).
		wp_enqueue_script(
			'sweetalert2',
			'https://cdn.jsdelivr.net/npm/sweetalert2@11',
			array(),
			'11',
			true
		);

		// Tipografías de wmslatam.com: Inter (interfaz y texto) y Plus
		// Jakarta Sans (títulos), para que el panel se sienta parte del
		// mismo ecosistema visual.
		wp_enqueue_style(
			'au-wms-inter-font',
			'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Plus+Jakarta+Sans:wght@500;600;700&display=swap',
			array(),
			null
		);

		if ( $es_pagina_config ) {
			self::encolar_estilos_admin( array( 'au-wms-inter-font' ) );

			wp_enqueue_script(
				'au-wms-settings',
				AU_WMS_PLUGIN_URL . 'assets/js/settings.js',
				array( 'jquery', 'sweetalert2' ),
				AU_WMS_VERSION,
				true
			);

			wp_localize_script(
				'au-wms-settings',
				'AU_WMS_SETTINGS',
				array(
					'ajaxUrl' => admin_url( 'admin-ajax.php' ),
					'nonce'   => AU_Security::create_nonce(),
					'i18n'    => array(
						'saved'        => __( 'Configuración guardada correctamente.', 'au-wms' ),
						'genericError' => __( 'Ocurrió un error inesperado. Inténtalo de nuevo.', 'au-wms' ),
						'saving'       => __( 'Guardando...', 'au-wms' ),
					),
				)
			);

			return;
		}

		// Tom Select (misma librería usada en Administrador de Cupones y
		// WMS Product Webhooks) para dar buscador a los selects de
		// Empresa y Área/Paquete. Solo se necesita en la página principal.
		wp_enqueue_style(
			'tom-select',
			'https://cdn.jsdelivr.net/npm/tom-select@2.3.1/dist/css/tom-select.css',
			array(),
			'2.3.1'
		);

		wp_enqueue_script(
			'tom-select',
			'https://cdn.jsdelivr.net/npm/tom-select@2.3.1/dist/js/tom-select.complete.min.js',
			array(),
			'2.3.1',
			true
		);

		self::encolar_estilos_admin( array( 'tom-select', 'au-wms-inter-font' ) );

		// Módulos del panel principal (ver cabecera de cada archivo). Los
		// tres primeros son dependencias de `au-wms-admin` (Integrantes),
		// así que cualquier script que dependa de `au-wms-admin` los recibe.
		wp_enqueue_script(
			'au-wms-admin-core',
			AU_WMS_PLUGIN_URL . 'assets/js/admin-core.js',
			array( 'jquery', 'sweetalert2' ),
			AU_WMS_VERSION,
			true
		);

		wp_enqueue_script(
			'au-wms-acciones-usuario',
			AU_WMS_PLUGIN_URL . 'assets/js/acciones-usuario.js',
			array( 'jquery', 'sweetalert2', 'au-wms-admin-core' ),
			AU_WMS_VERSION,
			true
		);

		wp_enqueue_script(
			'au-wms-borrado-masivo',
			AU_WMS_PLUGIN_URL . 'assets/js/borrado-masivo.js',
			array( 'jquery', 'sweetalert2', 'au-wms-admin-core', 'au-wms-acciones-usuario' ),
			AU_WMS_VERSION,
			true
		);

		wp_enqueue_script(
			'au-wms-admin',
			AU_WMS_PLUGIN_URL . 'assets/js/admin.js',
			array( 'jquery', 'sweetalert2', 'tom-select', 'au-wms-admin-core', 'au-wms-acciones-usuario', 'au-wms-borrado-masivo' ),
			AU_WMS_VERSION,
			true
		);

		// SheetJS + estilos básicos ("xlsx-js-style", mismo API y misma
		// versión base 0.18.5 que la librería original, con soporte
		// adicional de colores/fuentes/bordes por celda vía `cell.s`).
		// Se usa el mismo handle 'au-wms-sheetjs' en todos los scripts
		// que generan Excel (import.js, reset-password.js,
		// exportar-usuarios.js) para no cargar dos copias de `XLSX` en
		// la misma página — la copia community-only nunca sobrescribe
		// `window.XLSX` si ya existe, así que solo puede haber una.
		wp_enqueue_script(
			'au-wms-sheetjs',
			'https://cdn.jsdelivr.net/npm/xlsx-js-style@1.2.0/dist/xlsx.min.js',
			array(),
			'1.2.0',
			true
		);

		wp_enqueue_script(
			'au-wms-import',
			AU_WMS_PLUGIN_URL . 'assets/js/import.js',
			array( 'jquery', 'sweetalert2', 'tom-select', 'au-wms-admin', 'au-wms-sheetjs' ),
			AU_WMS_VERSION,
			true
		);

		wp_enqueue_script(
			'au-wms-reset-password',
			AU_WMS_PLUGIN_URL . 'assets/js/reset-password.js',
			array( 'jquery', 'sweetalert2', 'au-wms-admin', 'au-wms-sheetjs' ),
			AU_WMS_VERSION,
			true
		);

		wp_enqueue_script(
			'au-wms-export-usuarios',
			AU_WMS_PLUGIN_URL . 'assets/js/exportar-usuarios.js',
			array( 'jquery', 'sweetalert2', 'au-wms-admin', 'au-wms-sheetjs' ),
			AU_WMS_VERSION,
			true
		);

		wp_enqueue_script(
			'au-wms-comparar-usuarios',
			AU_WMS_PLUGIN_URL . 'assets/js/comparar-usuarios.js',
			array( 'jquery', 'sweetalert2', 'tom-select', 'au-wms-admin', 'au-wms-sheetjs' ),
			AU_WMS_VERSION,
			true
		);

		wp_enqueue_script(
			'au-wms-mailupdate',
			AU_WMS_PLUGIN_URL . 'assets/js/actualizar-correos.js',
			array( 'jquery', 'sweetalert2', 'au-wms-admin' ),
			AU_WMS_VERSION,
			true
		);

		wp_enqueue_script(
			'au-wms-usermeta',
			AU_WMS_PLUGIN_URL . 'assets/js/usermeta.js',
			array( 'jquery', 'sweetalert2', 'au-wms-admin' ),
			AU_WMS_VERSION,
			true
		);

		wp_enqueue_script(
			'au-wms-areas-usuario',
			AU_WMS_PLUGIN_URL . 'assets/js/areas-usuario.js',
			array( 'jquery', 'sweetalert2', 'au-wms-admin' ),
			AU_WMS_VERSION,
			true
		);

		wp_enqueue_script(
			'au-wms-empresas',
			AU_WMS_PLUGIN_URL . 'assets/js/empresas.js',
			array( 'jquery', 'sweetalert2', 'au-wms-admin', 'au-wms-usermeta' ),
			AU_WMS_VERSION,
			true
		);

		wp_enqueue_script(
			'au-wms-licencias',
			AU_WMS_PLUGIN_URL . 'assets/js/licencias.js',
			// 'au-wms-sheetjs': "Descargar matriz comparativa" genera el
			// .xlsx con SheetJS, igual que exportar-usuarios.js.
			array( 'jquery', 'sweetalert2', 'au-wms-admin', 'au-wms-sheetjs' ),
			AU_WMS_VERSION,
			true
		);

		wp_enqueue_script(
			'au-wms-usuarios-externos',
			AU_WMS_PLUGIN_URL . 'assets/js/usuarios-externos.js',
			array( 'jquery', 'sweetalert2', 'au-wms-admin', 'au-wms-usermeta', 'au-wms-empresas' ),
			AU_WMS_VERSION,
			true
		);

		wp_enqueue_script(
			'au-wms-editar-perfil',
			AU_WMS_PLUGIN_URL . 'assets/js/editar-perfil.js',
			array( 'jquery', 'sweetalert2', 'au-wms-admin' ),
			AU_WMS_VERSION,
			true
		);

		wp_enqueue_script(
			'au-wms-crear-empresa',
			AU_WMS_PLUGIN_URL . 'assets/js/crear-empresa.js',
			array( 'jquery', 'sweetalert2', 'au-wms-admin', 'au-wms-empresas' ),
			AU_WMS_VERSION,
			true
		);

		// Valores iniciales del asistente "Crear Empresa". Los tokens de
		// las APIs externas NUNCA se localizan: las llamadas salen del
		// servidor; aquí solo viaja qué programas aún no tienen token,
		// para poder avisarlo en el paso 1.
		$config_crear_empresa = AU_Settings::crear_empresa();

		wp_localize_script(
			'au-wms-crear-empresa',
			'AU_WMS_CREAR_EMPRESA',
			array(
				'areaNombre'               => $config_crear_empresa['crear_empresa_area_nombre'],
				'areaCuposWms'             => (int) $config_crear_empresa['crear_empresa_area_cupos_wms'],
				'areaCuposInspira'         => (int) $config_crear_empresa['crear_empresa_area_cupos_inspira'],
				'areaCuposOctagono'        => (int) $config_crear_empresa['crear_empresa_area_cupos_octagono'],
				'areaLicenciaId'           => (int) $config_crear_empresa['crear_empresa_area_licencia_id'],
				'fechaExpiracionPorDefecto' => AU_Ajax_Crear_Empresa::fecha_expiracion_por_defecto(),
				'tokensFaltantes'          => AU_Programas_Api_Client::tokens_faltantes(),
			)
		);

		// Accesos de cada licencia (id => { duracion, incluir_* }), para
		// que el modal "Cambiar Licencia" los muestre al vuelo sin una
		// consulta por cada cambio del select.
		wp_localize_script(
			'au-wms-empresas',
			'AU_WMS_EMPRESAS',
			array(
				'licenciasAccesos' => self::licencias_accesos_por_id(),
			)
		);

		// Se adjunta al primer módulo para que `AU_WMS` exista antes de
		// cualquier script del panel.
		wp_localize_script(
			'au-wms-admin-core',
			'AU_WMS',
			array(
				'ajaxUrl' => admin_url( 'admin-ajax.php' ),
				'nonce'   => AU_Security::create_nonce(),
				// Nombres legibles de los roles (de WordPress y de los
				// programas Inspira/Octágono). Solo cambian lo que se ve en
				// pantalla: el valor técnico sigue disponible en el tooltip.
				'rolesEtiquetas' => array(
					'subscriber'    => __( 'Integrante', 'au-wms' ),
					'group_leader'  => __( 'Líder de grupo', 'au-wms' ),
					'company'       => __( 'Empresa', 'au-wms' ),
					'external_user' => __( 'Usuario externo', 'au-wms' ),
					'administrator' => __( 'Administrador', 'au-wms' ),
					'participante'  => __( 'Participante', 'au-wms' ),
				),
				'i18n'    => array(
					'confirmDeleteTitle'   => __( '¿Está seguro de eliminar este usuario?', 'au-wms' ),
					'confirmDeleteText'    => __( 'Esta acción es irreversible.', 'au-wms' ),
					'confirmDeleteButton'  => __( 'Eliminar', 'au-wms' ),
					'confirmLoginTitle'    => __( '¿Desea iniciar sesión como este usuario?', 'au-wms' ),
					'confirmLoginText'     => __( 'Su sesión actual será reemplazada por la del usuario seleccionado.', 'au-wms' ),
					'confirmLoginButton'   => __( 'Continuar', 'au-wms' ),
					'cancelButton'         => __( 'Cancelar', 'au-wms' ),
					'genericError'         => __( 'Ocurrió un error inesperado. Inténtalo de nuevo.', 'au-wms' ),
					'emptyState'           => __( 'No se encontraron usuarios con los filtros seleccionados.', 'au-wms' ),
					'loading'              => __( 'Cargando...', 'au-wms' ),
					'allCompanies'         => __( 'Todas las empresas', 'au-wms' ),
					'allAreas'             => __( 'Todas las áreas', 'au-wms' ),
					'selectCompanyFirst'   => __( 'Selecciona una empresa primero', 'au-wms' ),
					'incompleteProfile'    => __( 'Perfil incompleto', 'au-wms' ),
					'testOk'                => __( 'Test OK', 'au-wms' ),
					'sinTest'               => __( 'Sin test', 'au-wms' ),
					'descargarResultado'    => __( 'Descargar resultado', 'au-wms' ),
					'descargandoResultado'  => __( 'Generando PDF...', 'au-wms' ),
					'importadoBadge'        => __( 'Importado', 'au-wms' ),
					'encargadoLabel'        => __( 'Encargado', 'au-wms' ),
					'sinLicencia'           => __( 'Sin licencia', 'au-wms' ),
					'licenciaSingular'      => __( 'licencia', 'au-wms' ),
					'licenciasPlural'       => __( 'licencias', 'au-wms' ),
					'licenciaCamposObligatorios' => __( 'El nombre y la duración (días) son obligatorios.', 'au-wms' ),
					'licenciaCreadaTitulo'  => __( 'Licencia creada', 'au-wms' ),
					'licenciaActualizadaTitulo' => __( 'Licencia actualizada', 'au-wms' ),
					'licenciaMatrizColAtributo' => __( 'Atributo', 'au-wms' ),
					'licenciaMatrizSinDatos' => __( 'No hay licencias para generar la matriz.', 'au-wms' ),
					'licenciaMatrizTitulo'  => __( 'Matriz comparativa de licencias  —  SI (incluido) en verde, NO en rojo', 'au-wms' ),
					'cambiarLicenciaExitoTitulo' => __( 'Licencia actualizada', 'au-wms' ),
					// Modal "Editar empresa".
					'eeCorreo'              => __( 'Correo de la cuenta', 'au-wms' ),
					'eeNombreObligatorio'   => __( 'La razón social o nombre de la empresa es obligatorio.', 'au-wms' ),
					'eeGuardando'           => __( 'Guardando…', 'au-wms' ),
					'eeExito'               => __( 'Los datos de la empresa se actualizaron correctamente', 'au-wms' ),
					// Modal "Editar perfil de usuario".
					'epCorreo'              => __( 'Correo de la cuenta', 'au-wms' ),
					'epCamposRequeridos'    => __( 'Todos los campos son obligatorios.', 'au-wms' ),
					'epGuardando'           => __( 'Guardando…', 'au-wms' ),
					'epExito'               => __( 'El perfil del usuario se actualizó correctamente', 'au-wms' ),
					// Asistente "Crear Empresa".
					'ceSinProgramas'        => __( 'Debes seleccionar al menos un programa.', 'au-wms' ),
					'ceNombreObligatorio'   => __( 'El nombre de la empresa es obligatorio.', 'au-wms' ),
					'ceSinAreas'            => __( 'Debes dejar al menos un área con nombre.', 'au-wms' ),
					'ceCreando'             => __( 'Creando…', 'au-wms' ),
					'ceCrear'               => __( 'Crear la empresa', 'au-wms' ),
					'ceReintentar'          => __( 'Reintentar', 'au-wms' ),
					'ceReintentando'        => __( 'Reintentando…', 'au-wms' ),
					'ceEmpresa'             => __( 'Empresa', 'au-wms' ),
					'ceEncargado'           => __( 'Encargado', 'au-wms' ),
					'ceContacto'            => __( 'Contacto', 'au-wms' ),
					'ceOcupacion'           => __( 'Ocupación', 'au-wms' ),
					'ceCorreo'              => __( 'Correo que se usará', 'au-wms' ),
					'ceCorreoCol'           => __( 'Correo', 'au-wms' ),
					'ceProgramas'           => __( 'Programas', 'au-wms' ),
					'ceRolWms'              => __( 'Rol en WMS', 'au-wms' ),
					'ceRolAsignado'         => __( 'Rol asignado', 'au-wms' ),
					'ceLicencia'            => __( 'Licencia de la empresa', 'au-wms' ),
					'ceDefaults'            => __( 'Se completaron automáticamente', 'au-wms' ),
					'ceNombreEncargado'     => __( 'nombre del encargado', 'au-wms' ),
					'ceApellidos'           => __( 'apellidos', 'au-wms' ),
					'ceAreasDe'             => __( 'Áreas de', 'au-wms' ),
					'ceCupos'               => __( 'cupos', 'au-wms' ),
					'ceExpira'              => __( 'Expira', 'au-wms' ),
					'cePassword'            => __( 'Contraseña', 'au-wms' ),
					'ceCredenciales'        => __( 'Credenciales de acceso (WMS)', 'au-wms' ),
					'ceWebhook'             => __( 'Envío de credenciales', 'au-wms' ),
					'ceAvisoWebhook'        => __( 'Al crear, las credenciales se enviarán al webhook configurado.', 'au-wms' ),
					'cePendientes'          => __( 'La empresa se creó en WMS, pero quedaron operaciones pendientes:', 'au-wms' ),
					'ceTodoOk'              => __( 'Todo se creó correctamente y las credenciales se enviaron.', 'au-wms' ),
					'ceCopiado'             => __( 'Información copiada', 'au-wms' ),
					'cePaso'                => __( 'Paso', 'au-wms' ),
					'ceDe'                  => __( 'de', 'au-wms' ),
					'cePasoProgramas'       => __( 'Programas', 'au-wms' ),
					'cePasoEmpresa'         => __( 'Datos de la empresa', 'au-wms' ),
					'cePasoResumen'         => __( 'Resumen', 'au-wms' ),
					'cePasoResultado'       => __( 'Resultado', 'au-wms' ),
					'ceCupo'                => __( 'cupo', 'au-wms' ),
					'ceCodigo'              => __( 'Código', 'au-wms' ),
					'cePasswordUnicaVez'    => __( 'Esta contraseña no se vuelve a mostrar: cópiala antes de cerrar.', 'au-wms' ),
					'ceCopiarCampo'         => __( 'Copiar', 'au-wms' ),
					'ceCopiarTodo'          => __( 'Copiar información', 'au-wms' ),
					'ceCreandoAviso'        => __( 'Creando la empresa… no cierres esta ventana.', 'au-wms' ),
					'ceEnEspera'            => __( 'En proceso…', 'au-wms' ),
					'ceTokensFaltantes'     => __( 'Falta el token de esta API.', 'au-wms' ),
					'ceTokensDonde'         => __( 'Cárgalo en Usuarios WMS → Configuración antes de crear.', 'au-wms' ),
					'licenciaDuracionSufijo' => __( 'días de vigencia', 'au-wms' ),
					'creadoPorApiLabel'     => __( 'Creado por API', 'au-wms' ),
					'crearAreaFilasInvalidas' => __( 'Revisa los campos marcados: el nombre del área es obligatorio, y si escribes un número de cupos debe ser mayor a 0.', 'au-wms' ),
					'crearAreaEstadoPendiente' => __( 'Por crear', 'au-wms' ),
					'crearAreaEstadoCreando' => __( 'Creando…', 'au-wms' ),
					'crearAreaEstadoCreada' => __( 'Creada', 'au-wms' ),
					'crearAreaEstadoError'  => __( 'Error', 'au-wms' ),
					'crearAreaExitoTitulo'  => __( 'Áreas creadas', 'au-wms' ),
					'editarAreaExitoTitulo' => __( 'Área actualizada', 'au-wms' ),
					'refrescarConfirmTitle' => __( '¿Refrescar programas?', 'au-wms' ),
					'refrescarConfirmText'  => __( 'Esta acción refrescará el tipo de programa al que está vinculada esta empresa (Inspira y Octágono), incluyendo la empresa y todos sus integrantes. ¿Desea continuar?', 'au-wms' ),
					'refrescarConfirmTitleUsuario' => __( '¿Refrescar programas de este usuario?', 'au-wms' ),
					'refrescarConfirmTextUsuario'  => __( 'Esta acción refrescará el tipo de programa (Inspira y Octágono) únicamente para este usuario. ¿Desea continuar?', 'au-wms' ),
					'refrescarConfirmTitleEmpresas' => __( '¿Refrescar programas de todas las empresas?', 'au-wms' ),
					'refrescarConfirmTextEmpresas'  => __( 'Esta acción refrescará el tipo de programa (Inspira y Octágono) para todas las cuentas con rol company. No incluye a sus integrantes: para refrescar una empresa junto con todos sus integrantes usa la acción "Refrescar programas" de esa fila. ¿Desea continuar?', 'au-wms' ),
					'refrescarEmpresasLabel' => __( 'Empresas', 'au-wms' ),
					'refrescarConfirmTitleExternos' => __( '¿Refrescar programas de todos los usuarios externos?', 'au-wms' ),
					'refrescarConfirmTextExternos'  => __( 'Esta acción refrescará el tipo de programa (Inspira y Octágono) para todos los usuarios con rol external_user. ¿Desea continuar?', 'au-wms' ),
					'refrescarUsuariosExternosLabel' => __( 'Usuarios Externos', 'au-wms' ),
					'areasTitulo'           => __( 'Áreas', 'au-wms' ),
					'areaSingular'          => __( 'área', 'au-wms' ),
					'areasPlural'           => __( 'áreas', 'au-wms' ),
					'cursosAsignadosTitulo' => __( 'Cursos asignados', 'au-wms' ),
					'areasUsuarioTitulo'    => __( 'Áreas del usuario', 'au-wms' ),
					'agregarAreaTitulo'     => __( 'Agregar área', 'au-wms' ),
					'desvincularAreaTitulo' => __( '¿Desvincular al usuario de esta área?', 'au-wms' ),
					'desvincularAreaTexto'  => __( 'El usuario {usuario} dejará de ser parte del área {area}.', 'au-wms' ),
					'desvincularAreaBoton'  => __( 'Desvincular usuario', 'au-wms' ),
					'desvincularAreaUnicaTitulo' => __( 'El usuario debe pertenecer al menos a un área.', 'au-wms' ),
					'areaDesvinculadaTitulo' => __( 'Área desvinculada', 'au-wms' ),
					'areaDesvinculadaTexto'  => __( 'El usuario {usuario} se ha desvinculado del área {area}.', 'au-wms' ),
					'selectAreaPlaceholder' => __( 'Selecciona un área', 'au-wms' ),
					'areaVinculadaTitulo'   => __( 'Área agregada', 'au-wms' ),
					'areaVinculadaTexto'    => __( 'El usuario {usuario} ha sido agregado al área {area}.', 'au-wms' ),
					'codigoEmpresaConfirmTitle' => __( '¿Actualizar el id de empresa de los usuarios?', 'au-wms' ),
					'codigoEmpresaConfirmText'  => __( 'Se guardará el código de área más antiguo de cada usuario de esta empresa como "user_code_company" en su perfil.', 'au-wms' ),
					'codigoEmpresaExito'    => __( 'Se actualizaron {N} usuarios correctamente.', 'au-wms' ),
					'accesoDeshabilitadoBadge' => __( 'Acceso deshabilitado', 'au-wms' ),
					'habilitarAcceso'       => __( 'Habilitar acceso', 'au-wms' ),
					'deshabilitarAcceso'    => __( 'Deshabilitar acceso', 'au-wms' ),
					'habilitarAccesoConfirmTitle' => __( '¿Habilitar el acceso de este usuario?', 'au-wms' ),
					'habilitarAccesoConfirmText'  => __( 'El usuario podrá volver a iniciar sesión con normalidad.', 'au-wms' ),
					'deshabilitarAccesoConfirmTitle' => __( '¿Deshabilitar el acceso de este usuario?', 'au-wms' ),
					'deshabilitarAccesoConfirmText'  => __( 'El usuario no podrá iniciar sesión y se cerrará cualquier sesión activa que tenga en este momento.', 'au-wms' ),
					'accesoDeshabilitadoExito' => __( 'El acceso del usuario fue deshabilitado.', 'au-wms' ),
					'accesoHabilitadoExito' => __( 'El acceso del usuario fue habilitado.', 'au-wms' ),
					'cambiarCorreoTitulo'   => __( 'Cambiar correo del usuario', 'au-wms' ),
					'cambiarCorreoLabel'    => __( 'Nuevo correo', 'au-wms' ),
					'cambiarCorreoConfirmar' => __( 'Guardar', 'au-wms' ),
					'cambiarCorreoObligatorio' => __( 'El correo es obligatorio.', 'au-wms' ),
					'cambiarCorreoExito'    => __( 'El correo del usuario fue actualizado correctamente.', 'au-wms' ),
					'cambiarPasswordTitulo' => __( 'Cambiar Contraseña', 'au-wms' ),
					'cambiarPasswordPlaceholder' => __( 'Nueva contraseña', 'au-wms' ),
					'cambiarPasswordGenerar' => __( 'Generar contraseña aleatoria', 'au-wms' ),
					'cambiarPasswordConfirmar' => __( 'Cambiar Contraseña', 'au-wms' ),
					'cambiarPasswordObligatoria' => __( 'La contraseña no puede estar vacía.', 'au-wms' ),
					'cambiarPasswordExito' => __( 'El correo {EMAIL} ha cambiado y la contraseña es {PASSWORD} y se le ha notificado al correo {EMAIL2}.', 'au-wms' ),
					'refrescandoProgramasUsuario' => __( 'Refrescando programas del usuario...', 'au-wms' ),
					'escenarioOctagonoTitulo' => __( 'Este usuario tiene asignado el programa Octágono', 'au-wms' ),
					'escenarioOctagonoTexto'  => __( 'Por lo tanto no puede eliminarse definitivamente para conservar su acceso al programa. El usuario dejará de pertenecer a WMS, se desvinculará del área/paquete actual y pasará a tener el rol external_user.', 'au-wms' ),
					'escenarioInspiraTitulo'  => __( 'Este usuario tiene asignado el programa Inspira', 'au-wms' ),
					'escenarioInspiraTexto'   => __( 'Por lo tanto no puede eliminarse definitivamente para conservar su acceso al programa. El usuario dejará de pertenecer a WMS, se desvinculará del área/paquete actual y pasará a tener el rol external_user.', 'au-wms' ),
					'escenarioAmbosTitulo'    => __( 'Este usuario tiene asignados los programas Inspira y Octágono', 'au-wms' ),
					'escenarioAmbosTexto'     => __( 'Por lo tanto no puede eliminarse definitivamente para conservar su acceso a ambos programas. El usuario dejará de pertenecer a WMS, se desvinculará del área/paquete actual y pasará a tener el rol external_user.', 'au-wms' ),
					'escenarioSoloWmsTitulo'  => __( 'Este usuario solamente pertenece a WMS', 'au-wms' ),
					'escenarioSoloWmsTexto'   => __( 'Puedes desvincularlo de WMS (conservando su cuenta con rol external_user) o eliminarlo definitivamente de WordPress.', 'au-wms' ),
					'btnDejarWms'             => __( 'Dejar de ser usuario WMS', 'au-wms' ),
					'btnBorrarDefinitivo'     => __( 'Borrar definitivamente', 'au-wms' ),
					'exitoOctagono' => __( 'El usuario "{EMAIL}" se ha desvinculado correctamente de WMS y continuará utilizando el programa Octágono.', 'au-wms' ),
					'exitoInspira'  => __( 'El usuario "{EMAIL}" se ha desvinculado correctamente de WMS y continuará utilizando el programa Inspira.', 'au-wms' ),
					'exitoAmbos'    => __( 'El usuario "{EMAIL}" se ha desvinculado correctamente de WMS y continuará utilizando los programas Inspira y Octágono.', 'au-wms' ),
					'exitoSoloWms'  => __( 'El usuario "{EMAIL}" se ha desvinculado correctamente de WMS y continuará existiendo en WordPress con el rol external_user.', 'au-wms' ),
					'actualizandoListaIntegrantes' => __( 'Actualizando lista de integrantes...', 'au-wms' ),
					'errorActualizarLista' => __( 'El proceso se completó correctamente, pero no fue posible actualizar la lista de integrantes. Recarga la página para ver los cambios.', 'au-wms' ),
					'aceptar'               => __( 'Aceptar', 'au-wms' ),
					'externoTieneOctagono'  => __( 'Este usuario tiene el programa Octágono y no se puede borrar definitivamente para seguir permitiendo su acceso a dicho programa.', 'au-wms' ),
					'externoTieneInspira'   => __( 'Este usuario tiene el programa Inspira y no se puede borrar definitivamente para seguir permitiendo su acceso a dicho programa.', 'au-wms' ),
					'externoTieneAmbos'     => __( 'Este usuario tiene los programas Inspira y Octágono, por lo tanto no se puede borrar definitivamente para seguir permitiendo su acceso a dichos programas.', 'au-wms' ),
					'externoConfirmarBorrado' => __( '¿Desea borrar de forma permanente este usuario?', 'au-wms' ),
					'externoEliminadoExito' => __( 'El usuario fue eliminado permanentemente.', 'au-wms' ),
					'borradoMasivoConfirmTitle' => __( '¿Procesar la eliminación de los usuarios seleccionados?', 'au-wms' ),
					'borradoMasivoConfirmText'  => __( 'Se procesarán {N} usuarios: a los que tengan Inspira/Octágono se les aplicará "Dejar de ser usuario WMS"; al resto se les eliminará definitivamente.', 'au-wms' ),
					'borradoMasivoConfirmButton' => __( 'Continuar', 'au-wms' ),
					'borradoMasivoProcesando'   => __( 'Procesando usuarios seleccionados...', 'au-wms' ),
					'borradoMasivoDesvinculados' => __( 'desvinculados de WMS (conservan sus programas)', 'au-wms' ),
					'borradoMasivoEliminados'   => __( 'eliminados definitivamente', 'au-wms' ),
					'borradoMasivoErrores'      => __( 'con errores', 'au-wms' ),
					'borradoMasivoFinalizado'   => __( 'Proceso finalizado', 'au-wms' ),
					'borradoMasivoRefrescando'  => __( 'Refrescando programas de los usuarios seleccionados...', 'au-wms' ),
					'refrescarConfirmButton' => __( 'Sí, refrescar', 'au-wms' ),
					'refrescarIniciando'   => __( 'Preparando sincronización...', 'au-wms' ),
					'refrescarProcesando'  => __( 'Sincronizando programas...', 'au-wms' ),
					'refrescarFinalizado'  => __( 'Sincronización finalizada correctamente', 'au-wms' ),
					'refrescarEmpresaLabel' => __( 'Empresa', 'au-wms' ),
					'refrescarUsuariosProcesados' => __( 'Usuarios procesados', 'au-wms' ),
					'refrescarActualizados' => __( 'Actualizados', 'au-wms' ),
					'refrescarEliminados'  => __( 'Eliminados', 'au-wms' ),
					'refrescarConErrores'  => __( 'Con errores', 'au-wms' ),
					'refrescarDetalleErrores' => __( 'Detalle de errores', 'au-wms' ),
					'refrescarCerrar'      => __( 'Cerrar', 'au-wms' ),
					'refrescarNinguno'     => __( 'Ninguno', 'au-wms' ),
					'refrescarLote'        => __( 'Lote', 'au-wms' ),
					'refrescarLoteDe'      => __( 'de', 'au-wms' ),
					'refrescarCorreos'     => __( 'correos', 'au-wms' ),
					'importSelectCompanyArea' => __( 'Selecciona una empresa y un área para continuar.', 'au-wms' ),
					'importNoFile'          => __( 'Selecciona un archivo antes de continuar.', 'au-wms' ),
					'importMappingRequired' => __( 'Debes asignar una columna al campo obligatorio "Correo".', 'au-wms' ),
					'importCuposUsados'     => __( 'cupos utilizados', 'au-wms' ),
					'importCuposExceeded'   => __( 'No hay cupos suficientes para importar todos estos usuarios. Faltan', 'au-wms' ),
					'importCupos'           => __( 'cupos', 'au-wms' ),
					'importUploading'       => __( 'Subiendo y analizando archivo...', 'au-wms' ),
					'importValidating'      => __( 'Validando datos, un momento...', 'au-wms' ),
					'importProcessing'      => __( 'Procesando importación...', 'au-wms' ),
					'importConfirmCancelTitle' => __( '¿Cancelar la importación?', 'au-wms' ),
					'importConfirmCancelText' => __( 'Se perderá todo el progreso del asistente.', 'au-wms' ),
					'importDoneTitle'       => __( 'Importación finalizada', 'au-wms' ),
					'importNoResults'       => __( 'No hay registros en este grupo.', 'au-wms' ),
					'importSinCupo'         => __( 'Sin cupo disponible', 'au-wms' ),
					'importAlcanzanImportar' => __( 'alcanzan a importarse', 'au-wms' ),
					'importQuedanFuera'     => __( 'quedan por fuera por falta de cupo', 'au-wms' ),
					'importSoloDisponibles' => __( 'Al continuar, solo se importarán los usuarios que sí tienen cupo disponible.', 'au-wms' ),
					'importSinCupoFinal'    => __( 'sin cupo disponible al momento de procesar', 'au-wms' ),
					'importCredencialesTitulo' => __( 'Cuentas creadas — credenciales de acceso', 'au-wms' ),
					'importCredencialesColCorreo' => __( 'Correo electrónico', 'au-wms' ),
					'importCredencialesColPassword' => __( 'Contraseña', 'au-wms' ),
					'importCredencialesColArea' => __( 'Área', 'au-wms' ),
					'importCredencialesCopiar' => __( 'Copiar al portapapeles', 'au-wms' ),
					'importCredencialesDescargarExcel' => __( 'Descargar Excel', 'au-wms' ),
					'importCredencialesCopiadoOk' => __( 'Lista copiada correctamente al portapapeles.', 'au-wms' ),
					'importCredencialesCopiadoError' => __( 'No fue posible copiar la lista. Selecciónala e inténtalo manualmente.', 'au-wms' ),
					'importCredencialesCorreoLabel' => __( 'Correo', 'au-wms' ),
					'importCredencialesPasswordLabel' => __( 'Contraseña', 'au-wms' ),
					'importCredencialesEmpresaFallback' => __( 'Empresa', 'au-wms' ),
					'resetPwdTitulo' => __( 'Resetear contraseñas', 'au-wms' ),
					'resetPwdSubtitulo' => __( 'Empresa', 'au-wms' ),
					'resetPwdFiltroArea' => __( 'Área', 'au-wms' ),
					'resetPwdFiltroAreaTodas' => __( 'Todas las áreas', 'au-wms' ),
					'resetPwdFiltroAreasSeleccionadas' => __( 'áreas seleccionadas', 'au-wms' ),
					'resetPwdFiltroPerfil' => __( 'Estado del perfil', 'au-wms' ),
					'resetPwdPerfilTodos' => __( 'Todos', 'au-wms' ),
					'resetPwdPerfilCompleto' => __( 'Perfil completado', 'au-wms' ),
					'resetPwdPerfilIncompleto' => __( 'Perfil incompleto', 'au-wms' ),
					'resetPwdColUsuario' => __( 'Usuario', 'au-wms' ),
					'resetPwdColArea' => __( 'Área', 'au-wms' ),
					'resetPwdColSeleccion' => __( 'Selección', 'au-wms' ),
					'resetPwdSeleccionarTodos' => __( 'Seleccionar todos', 'au-wms' ),
					'resetPwdDeseleccionarTodos' => __( 'Deseleccionar todos', 'au-wms' ),
					'resetPwdSinUsuarios' => __( 'No hay usuarios que coincidan con los filtros seleccionados.', 'au-wms' ),
					'resetPwdSeleccionados' => __( 'seleccionados', 'au-wms' ),
					'resetPwdPaso2Titulo' => __( 'Confirmar reseteo de contraseñas', 'au-wms' ),
					'resetPwdPaso2Resumen' => __( 'Se generará una contraseña nueva para {N} usuarios. Esta acción no se puede deshacer.', 'au-wms' ),
					'resetPwdColCorreo' => __( 'Correo electrónico', 'au-wms' ),
					'resetPwdColNombre' => __( 'Nombre', 'au-wms' ),
					'resetPwdColPassword' => __( 'Nueva contraseña', 'au-wms' ),
					'resetPwdProcesando' => __( 'Reseteando contraseñas...', 'au-wms' ),
					'resetPwdFinalizado' => __( 'Proceso finalizado', 'au-wms' ),
					'resetPwdResumenSeleccionados' => __( 'Usuarios seleccionados', 'au-wms' ),
					'resetPwdResumenActualizados' => __( 'Contraseñas actualizadas', 'au-wms' ),
					'resetPwdResumenErrores' => __( 'Errores', 'au-wms' ),
					'resetPwdEstadoError' => __( 'Error', 'au-wms' ),
					'resetPwdCopiarLista' => __( 'Copiar lista', 'au-wms' ),
					'resetPwdDescargarExcel' => __( 'Descargar Excel', 'au-wms' ),
					'resetPwdCopiadoOk' => __( 'Lista copiada correctamente al portapapeles.', 'au-wms' ),
					'resetPwdCopiadoError' => __( 'No fue posible copiar la lista. Selecciónala e inténtalo manualmente.', 'au-wms' ),
					'resetPwdBtnSiguiente' => __( 'Siguiente', 'au-wms' ),
					'resetPwdBtnAtras' => __( 'Atrás', 'au-wms' ),
					'resetPwdBtnEjecutar' => __( 'Resetear contraseñas', 'au-wms' ),
					'resetPwdBtnFinalizar' => __( 'Finalizar', 'au-wms' ),
					'resetPwdBtnCancelar' => __( 'Cancelar', 'au-wms' ),
					'resetPwdConfirmTitle' => __( '¿Resetear {N} contraseñas?', 'au-wms' ),
					'resetPwdConfirmText' => __( 'Cada usuario seleccionado recibirá una contraseña nueva y aleatoria. La contraseña anterior dejará de funcionar de inmediato. Esta acción no se puede deshacer.', 'au-wms' ),
					'resetPwdSinSeleccion' => __( 'Selecciona al menos un usuario para continuar.', 'au-wms' ),
					'resetPwdEnviarCorreos' => __( 'Enviar correos', 'au-wms' ),
					'resetPwdEnviandoCorreos' => __( 'Enviando...', 'au-wms' ),
					'resetPwdCorreosEnviados' => __( 'Correos enviados', 'au-wms' ),
					'resetPwdCorreosEnviadosOk' => __( 'Los correos se enviaron correctamente.', 'au-wms' ),
					'resetPwdCorreosEnviadosError' => __( 'No fue posible enviar los correos.', 'au-wms' ),
					'resetPwdSinResultadosParaEnviar' => __( 'No hay contraseñas generadas correctamente para enviar.', 'au-wms' ),
					'exportUsersAreasSeleccionadas' => __( 'áreas seleccionadas', 'au-wms' ),
					'exportUsersAreaSinNombre' => __( 'Sin área', 'au-wms' ),
					'exportUsersSinUsuarios' => __( 'No hay usuarios que exportar en las áreas seleccionadas.', 'au-wms' ),
					'exportUsersResumen' => __( 'Se exportarán {N} usuarios de {AREAS} área(s).', 'au-wms' ),
					'exportUsersColCorreo' => __( 'Correo electrónico', 'au-wms' ),
					'exportUsersColNombre' => __( 'Nombre', 'au-wms' ),
					'exportUsersColArea' => __( 'Área', 'au-wms' ),
					'exportUsersColPerfil' => __( 'Perfil', 'au-wms' ),
					'exportUsersColTest' => __( 'Test', 'au-wms' ),
					'exportUsersExcelTitulo' => __( 'Usuarios exportados — {EMPRESA} ({AREAS} área(s), {N} usuarios)', 'au-wms' ),
					'compareUsersTitle' => __( 'Comparar usuarios', 'au-wms' ),
					'compareUsersHelp' => __( 'Pega los correos que quieras comparar (separados por saltos de línea, comas o espacios). Cada uno se convertirá en una etiqueta.', 'au-wms' ),
					'compareUsersPlaceholder' => __( 'Pega o escribe correos y presiona Enter…', 'au-wms' ),
					'compareUsersContador' => __( 'correos', 'au-wms' ),
					'compareUsersSinCorreos' => __( 'Agrega al menos un correo para continuar.', 'au-wms' ),
					'compareUsersResumen' => __( 'De {TOTAL} correos: {ESTA} en {EMPRESA}, {OTRA} en otra empresa, {NINGUNA} sin registrar.', 'au-wms' ),
					'compareUsersColCorreo' => __( 'Correo', 'au-wms' ),
					'compareUsersColEstado' => __( 'Estado', 'au-wms' ),
					'compareUsersColDetalle' => __( 'Detalle', 'au-wms' ),
					'compareUsersColTest' => __( 'Test', 'au-wms' ),
					'compareUsersEstaEmpresa' => __( 'Ya está en esta empresa', 'au-wms' ),
					'compareUsersOtraEmpresa' => __( 'Registrado en otra empresa', 'au-wms' ),
					'compareUsersNoExiste' => __( 'No está registrado', 'au-wms' ),
					'compareUsersInvalido' => __( '{N} texto(s) pegado(s) no parecían un correo válido y se ignoraron.', 'au-wms' ),
					'selectColumnPlaceholder' => __( '— No asignar —', 'au-wms' ),
					'usermetaAgregarTitulo' => __( 'Agregar atributo', 'au-wms' ),
					'usermetaEditarTitulo'  => __( 'Editar atributo', 'au-wms' ),
					'usermetaKeyObligatorio' => __( 'El Meta Key es obligatorio.', 'au-wms' ),
					'usermetaConfirmDeleteTitle' => __( '¿Está seguro de eliminar este atributo?', 'au-wms' ),
					'usermetaConfirmDeleteText' => __( 'Esta acción no se puede deshacer.', 'au-wms' ),
					'usermetaProtegido'     => __( 'Campo reservado por WordPress, no se puede editar ni eliminar desde aquí.', 'au-wms' ),
					'mailupdateInvalidFile' => __( 'Solo se permiten archivos XLS o XLSX.', 'au-wms' ),
					'mailupdateResumenTotal' => __( 'registros en el archivo', 'au-wms' ),
					'mailupdateResumenListos' => __( 'listos', 'au-wms' ),
					'mailupdateResumenErrores' => __( 'con errores', 'au-wms' ),
					'mailupdateResumenOmitidos' => __( 'omitidos', 'au-wms' ),
					'mailupdateEstadoListo' => __( 'Listo para actualizar', 'au-wms' ),
					'mailupdateEstadoError' => __( 'No se puede actualizar', 'au-wms' ),
					'mailupdateEstadoOmitido' => __( 'Omitido', 'au-wms' ),
					'mailupdateConfirmTitle' => __( 'Se actualizarán {N} usuarios.', 'au-wms' ),
					'mailupdateConfirmText' => __( 'Esta acción modificará el correo electrónico de los usuarios seleccionados y no podrá deshacerse. ¿Deseas continuar?', 'au-wms' ),
					'mailupdateConfirmButton' => __( 'Sí, actualizar', 'au-wms' ),
					'mailupdateDoneTitle'   => __( 'Actualización finalizada', 'au-wms' ),
					'mailupdateProcesados'  => __( 'Se procesaron {N} registros.', 'au-wms' ),
					'mailupdateActualizadosOk' => __( 'actualizados correctamente', 'au-wms' ),
					'mailupdateConErrores'  => __( 'con errores', 'au-wms' ),
					'mailupdateResultadoActualizado' => __( 'Actualizado', 'au-wms' ),
					'mailupdateResultadoError' => __( 'Error', 'au-wms' ),
				),
			)
		);
	}

	/**
	 * Indexa por id las licencias con su duración y sus 9 atributos
	 * "incluir_*", tal como los necesita el modal "Cambiar Licencia".
	 *
	 * @return array<int, array>
	 */
	private static function licencias_accesos_por_id() {
		$licencias = array();

		foreach ( AU_Repository_Licencias::listar_todas() as $licencia ) {
			$datos = array( 'duracion' => (int) $licencia['duracion'] );

			foreach ( array_keys( AU_Repository_Licencias::CAMPOS_ACCESO ) as $campo ) {
				$datos[ $campo ] = ! empty( $licencia[ $campo ] );
			}

			$licencias[ (int) $licencia['id'] ] = $datos;
		}

		return $licencias;
	}

	/**
	 * Hojas de estilo del plugin, en el orden en que deben cargarse.
	 * El orden importa para la cascada: cada archivo puede sobrescribir
	 * a los anteriores (07-responsive.css va al final a propósito).
	 *
	 * @return string[] Nombres de archivo dentro de assets/css/admin/.
	 */
	private static function hojas_de_estilo() {
		return array(
			'01-base.css',
			'02-tablas.css',
			'03-componentes.css',
			'04-importacion.css',
			'05-configuracion.css',
			'06-modales.css',
			'07-responsive.css',
		);
	}

	/**
	 * Encola las hojas de estilo encadenadas (cada una depende de la
	 * anterior, lo que garantiza el orden) y registra `au-wms-admin` como
	 * alias de todas, para quien dependa de ese handle.
	 *
	 * @param string[] $deps Dependencias externas (fuentes, Tom Select).
	 * @return void
	 */
	private static function encolar_estilos_admin( array $deps ) {
		$anterior = null;

		foreach ( self::hojas_de_estilo() as $archivo ) {
			$handle = 'au-wms-admin-' . sanitize_key( basename( $archivo, '.css' ) );

			wp_enqueue_style(
				$handle,
				AU_WMS_PLUGIN_URL . 'assets/css/admin/' . $archivo,
				$anterior ? array( $anterior ) : $deps,
				AU_WMS_VERSION
			);

			$anterior = $handle;
		}

		wp_enqueue_style( 'au-wms-admin', false, array( $anterior ), AU_WMS_VERSION );
	}

	/**
	 * Renderiza la vista principal del plugin (tabs).
	 *
	 * @return void
	 */
	public function render_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'No tienes permisos suficientes para acceder a esta página.', 'au-wms' ) );
		}

		$empresas  = AU_Repository_Empresas::get_empresas();
		$licencias = AU_Repository_Empresas::get_licencias();

		// Valores iniciales del asistente "Crear Empresa" (modal-crear-empresa.php).
		$config_crear_empresa = AU_Settings::crear_empresa();

		require AU_WMS_PLUGIN_DIR . 'views/admin-page.php';
	}

	/**
	 * Renderiza la página de Configuración (APIs / Webhooks).
	 *
	 * @return void
	 */
	public function render_settings_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'No tienes permisos suficientes para acceder a esta página.', 'au-wms' ) );
		}

		$config = AU_Settings::get_all();

		// El bloque del asistente "Crear Empresa" ofrece elegir la
		// licencia inicial de las áreas de Liderazgo.
		$licencias = AU_Repository_Empresas::get_licencias();

		require AU_WMS_PLUGIN_DIR . 'views/admin-settings-page.php';
	}
}
