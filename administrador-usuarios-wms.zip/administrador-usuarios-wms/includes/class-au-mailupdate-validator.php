<?php
/**
 * Ejecuta la validación previa del asistente "Actualizar correos"
 * (Tab Integrantes): clasifica cada fila del archivo en Lista para
 * actualizar / Con error / Omitida, SIN escribir nada en la base de
 * datos. La escritura real ocurre únicamente en
 * AU_Mail_Update_Service::procesar_lote(), una vez el administrador
 * confirma la previsualización.
 *
 * Validaciones aplicadas, en este orden (la primera que falla decide
 * el estado de la fila):
 *
 * 1. Fila completamente vacía → se ignora (no se cuenta).
 * 2. Correo actual con formato inválido → error.
 * 3. Correo nuevo con formato inválido → error.
 * 4. Correo nuevo igual al correo actual → error.
 * 5. Correo actual duplicado dentro del archivo → omitida (solo se
 *    procesará la primera aparición).
 * 6. Correo nuevo duplicado dentro del archivo → omitida (dos
 *    usuarios no pueden terminar con el mismo correo).
 * 7. Correo actual no existe como usuario en WordPress → error.
 * 8. Correo nuevo ya pertenece a otro usuario → error.
 * 9. Registro válido → listo para actualizar.
 *
 * NOTA: anteriormente había una regla adicional que bloqueaba la
 * actualización si el usuario ya tenía `question_test_ids` en
 * wp_usermeta ("ya realizó el test"). Se quitó a pedido explícito:
 * ahora se permite actualizar el correo de un usuario aunque ya haya
 * realizado el test.
 *
 * NOTA 2: también había una regla que bloqueaba la actualización si
 * el usuario ya tenía su perfil completo (nombre, apellido, edad,
 * género, país, teléfono, cargo). Se quitó a pedido explícito: el
 * correo se actualiza sin importar si el perfil está completo o no.
 *
 * @package Administrador_Usuarios_WMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AU_Mail_Update_Validator {

	/**
	 * Tiempo de vida de los transients del asistente (30 minutos).
	 */
	const TTL = 30 * MINUTE_IN_SECONDS;

	/**
	 * Guarda los datos crudos del archivo parseado en un transient y
	 * genera un ID único para el asistente.
	 *
	 * @param array $headers Encabezados del archivo.
	 * @param array $rows    Filas del archivo.
	 * @return string ID del proceso de actualización.
	 */
	public static function guardar_archivo_parseado( array $headers, array $rows ) {
		$update_id = wp_generate_uuid4();

		set_transient(
			self::key_raw( $update_id ),
			array(
				'headers' => $headers,
				'rows'    => $rows,
			),
			self::TTL
		);

		return $update_id;
	}

	/**
	 * Recupera los datos crudos guardados de un update_id.
	 *
	 * @param string $update_id ID del proceso.
	 * @return array|null
	 */
	public static function get_archivo_parseado( $update_id ) {
		$data = get_transient( self::key_raw( $update_id ) );
		return $data ? $data : null;
	}

	/**
	 * Ejecuta la validación previa completa de todas las filas.
	 *
	 * @param string $update_id ID del proceso.
	 * @param int    $col_actual Índice de columna del correo actual.
	 * @param int    $col_nuevo  Índice de columna del correo nuevo.
	 * @return array{filas:array,resumen:array}
	 * @throws Exception Si faltan datos obligatorios o el archivo no existe.
	 */
	public static function validar( $update_id, $col_actual, $col_nuevo ) {
		$archivo = self::get_archivo_parseado( $update_id );
		if ( ! $archivo ) {
			throw new Exception( __( 'La sesión del asistente expiró. Vuelve a subir el archivo.', 'au-wms' ) );
		}

		$filas          = array();
		$listos         = array();
		$vistos_actual  = array();
		$vistos_nuevo   = array();

		foreach ( $archivo['rows'] as $fila_cruda ) {
			$correo_actual = isset( $fila_cruda[ $col_actual ] ) ? strtolower( trim( (string) $fila_cruda[ $col_actual ] ) ) : '';
			$correo_nuevo  = isset( $fila_cruda[ $col_nuevo ] ) ? strtolower( trim( (string) $fila_cruda[ $col_nuevo ] ) ) : '';

			if ( '' === $correo_actual && '' === $correo_nuevo ) {
				continue; // Fila completamente vacía: se ignora.
			}

			$fila = array(
				'correo_actual' => $correo_actual,
				'correo_nuevo'  => $correo_nuevo,
				'estado'        => '',
				'observacion'   => '',
				'user_id'       => 0,
			);

			// 1. Formato del correo actual.
			if ( '' === $correo_actual || ! is_email( $correo_actual ) ) {
				$fila['estado']      = 'error';
				$fila['observacion'] = __( 'El correo actual no tiene un formato válido.', 'au-wms' );
				$filas[]             = $fila;
				continue;
			}

			// 2. Formato del correo nuevo.
			if ( '' === $correo_nuevo || ! is_email( $correo_nuevo ) ) {
				$fila['estado']      = 'error';
				$fila['observacion'] = __( 'El correo nuevo no tiene un formato válido.', 'au-wms' );
				$filas[]             = $fila;
				continue;
			}

			// 3. El correo nuevo no puede ser igual al actual.
			if ( $correo_nuevo === $correo_actual ) {
				$fila['estado']      = 'error';
				$fila['observacion'] = __( 'El correo nuevo es igual al correo actual.', 'au-wms' );
				$filas[]             = $fila;
				continue;
			}

			// 4. Duplicado del correo actual dentro del archivo (protege
			// la integridad: dos filas no pueden mover al mismo usuario).
			if ( isset( $vistos_actual[ $correo_actual ] ) ) {
				$fila['estado']      = 'omitido';
				$fila['observacion'] = __( 'Correo actual duplicado dentro del archivo (se procesará solo la primera aparición).', 'au-wms' );
				$filas[]             = $fila;
				continue;
			}

			// 5. Duplicado del correo nuevo dentro del archivo (dos
			// usuarios no pueden terminar con el mismo correo nuevo).
			if ( isset( $vistos_nuevo[ $correo_nuevo ] ) ) {
				$fila['estado']      = 'omitido';
				$fila['observacion'] = __( 'Correo nuevo duplicado dentro del archivo (se procesará solo la primera aparición).', 'au-wms' );
				$filas[]             = $fila;
				continue;
			}

			// 6. El correo actual debe existir como usuario de WordPress.
			// NOTA IMPORTANTE: `user_email` en wp_users NO tiene una
			// restricción UNIQUE en este sitio (solo un índice normal),
			// así que puede haber más de un usuario con el mismo correo.
			// get_user_by('email', ...) devolvería arbitrariamente solo
			// uno de ellos, dejando ambigüedad sobre a cuál usuario
			// actualizar realmente. Por eso aquí se consultan TODOS los
			// IDs que comparten ese correo.
			$user_ids_coincidentes = self::obtener_user_ids_por_email( $correo_actual );

			if ( empty( $user_ids_coincidentes ) ) {
				$fila['estado']      = 'error';
				$fila['observacion'] = __( 'El correo actual no existe en WordPress.', 'au-wms' );
				$filas[]             = $fila;
				continue;
			}

			if ( count( $user_ids_coincidentes ) > 1 ) {
				$fila['estado']      = 'error';
				$fila['observacion'] = __( 'Existe más de un usuario de WordPress con este correo actual; no se puede determinar cuál actualizar.', 'au-wms' );
				$filas[]             = $fila;
				continue;
			}

			$usuario_actual = get_userdata( $user_ids_coincidentes[0] );

			// 6b. Nunca cambiar el correo de un administrador u otro rol
			// privilegiado, aunque su correo venga en el archivo.
			if ( ! AU_Security::puede_gestionar_usuario( $usuario_actual ) ) {
				$fila['estado']      = 'error';
				$fila['observacion'] = AU_Security::mensaje_usuario_protegido();
				$filas[]             = $fila;
				continue;
			}

			// 7. El correo nuevo NO debe existir ya registrado.
			if ( email_exists( $correo_nuevo ) ) {
				$fila['estado']      = 'error';
				$fila['observacion'] = __( 'El correo nuevo ya pertenece a otro usuario.', 'au-wms' );
				$filas[]             = $fila;
				continue;
			}

			// Registro válido. NOTA: anteriormente había una regla que
			// bloqueaba la actualización si el usuario ya tenía el
			// perfil completo (nombre, apellido, edad, género, país,
			// teléfono, cargo). Se quitó a pedido explícito: el correo
			// se actualiza siempre, sin importar si el perfil está
			// completo o no.
			$vistos_actual[ $correo_actual ] = true;
			$vistos_nuevo[ $correo_nuevo ]   = true;

			$fila['estado']      = 'listo';
			$fila['observacion'] = __( 'Listo para actualizar.', 'au-wms' );
			$fila['user_id']     = $usuario_actual->ID;

			$filas[]  = $fila;
			$listos[] = $fila;
		}

		$resumen = array(
			'total'   => count( $filas ),
			'listos'  => count( $listos ),
			'errores' => count(
				array_filter(
					$filas,
					function ( $f ) {
						return 'error' === $f['estado'];
					}
				)
			),
			'omitidos' => count(
				array_filter(
					$filas,
					function ( $f ) {
						return 'omitido' === $f['estado'];
					}
				)
			),
		);

		set_transient(
			self::key_preview( $update_id ),
			array( 'listos' => $listos ),
			self::TTL
		);

		return array(
			'filas'   => $filas,
			'resumen' => $resumen,
		);
	}

	/**
	 * Recupera el conjunto ya validado (solo filas "listo") para
	 * procesarse por lotes.
	 *
	 * @param string $update_id ID del proceso.
	 * @return array|null
	 */
	public static function get_preview( $update_id ) {
		$data = get_transient( self::key_preview( $update_id ) );
		return $data ? $data : null;
	}

	/**
	 * Devuelve TODOS los IDs de usuario que tienen exactamente ese
	 * correo en `wp_users`.
	 *
	 * Se usa una consulta directa en vez de `get_user_by('email', ...)`
	 * porque esa función solo devuelve un usuario aunque existan varios
	 * con el mismo correo (aquí `user_email` no tiene una restricción
	 * UNIQUE, solo un índice normal).
	 *
	 * @param string $email Correo a buscar (ya en minúsculas).
	 * @return array<int,int> Lista de IDs de usuario (vacía si no hay ninguno).
	 */
	private static function obtener_user_ids_por_email( $email ) {
		global $wpdb;

		$ids = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT ID FROM {$wpdb->users} WHERE user_email = %s",
				$email
			)
		);

		return array_map( 'absint', (array) $ids );
	}

	/**
	 * Indica si un usuario ya tiene su perfil completo: los 7 campos
	 * `first_name`, `last_name`, `user_age`, `user_gender`, `country`,
	 * `phone_number` y `user_position` existen en `wp_usermeta` y no
	 * están vacíos (misma regla usada para el badge "Perfil incompleto"
	 * del Tab Integrantes, ver AU_Repository_Usuarios). Público porque
	 * también lo reutiliza AU_Mail_Update_Service en su re-validación
	 * previa a escribir.
	 *
	 * @param int $user_id ID del usuario.
	 * @return bool
	 */
	public static function tiene_perfil_completo( $user_id ) {
		$campos_requeridos = array(
			'first_name',
			'last_name',
			'user_age',
			'user_gender',
			'country',
			'phone_number',
			'user_position',
		);

		foreach ( $campos_requeridos as $campo ) {
			$valor = get_user_meta( $user_id, $campo, true );
			if ( '' === trim( (string) $valor ) ) {
				return false;
			}
		}

		return true;
	}

	/**
	 * Clave de transient para los datos crudos del archivo.
	 *
	 * @param string $update_id ID del proceso.
	 * @return string
	 */
	private static function key_raw( $update_id ) {
		return 'au_wms_mailupdate_raw_' . sanitize_key( $update_id );
	}

	/**
	 * Clave de transient para el resultado ya validado.
	 *
	 * @param string $update_id ID del proceso.
	 * @return string
	 */
	private static function key_preview( $update_id ) {
		return 'au_wms_mailupdate_preview_' . sanitize_key( $update_id );
	}
}
