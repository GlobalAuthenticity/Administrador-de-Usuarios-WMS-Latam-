<?php
/**
 * Repositorio de acceso a datos para el Tab "Integrantes".
 *
 * Encapsula todas las consultas de búsqueda, filtrado y paginación de
 * usuarios, así como las consultas auxiliares requeridas por el flujo
 * de eliminación (correos_configurados por usuario).
 *
 * Todas las consultas usan $wpdb->prepare(), evitan N+1 y están
 * pensadas para paginarse desde SQL (LIMIT/OFFSET), soportando miles
 * de registros.
 *
 * @package Administrador_Usuarios_WMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AU_Repository_Usuarios {

	/**
	 * Busca usuarios aplicando búsqueda libre y filtros de empresa/área,
	 * con paginación nativa en SQL.
	 *
	 * @param array $args {
	 *     @type string $search      Texto de búsqueda (username, email, nombre, apellido).
	 *     @type int    $empresa_id  ID de la empresa (0 = sin filtro).
	 *     @type int    $paquete_id  ID del paquete/área (0 = sin filtro).
	 *     @type int    $page        Página actual (1-indexed).
	 *     @type int    $per_page    Registros por página.
	 * }
	 * @return array{items:array,total:int}
	 */
	public static function buscar( array $args ) {
		global $wpdb;

		$search     = isset( $args['search'] ) ? trim( (string) $args['search'] ) : '';
		$empresa_id = isset( $args['empresa_id'] ) ? absint( $args['empresa_id'] ) : 0;
		$paquete_id = isset( $args['paquete_id'] ) ? absint( $args['paquete_id'] ) : 0;
		$test_filtro = isset( $args['test_filtro'] ) ? sanitize_key( $args['test_filtro'] ) : '';
		$perfil_filtro = isset( $args['perfil_filtro'] ) ? sanitize_key( $args['perfil_filtro'] ) : '';
		$programa_filtro = isset( $args['programa_filtro'] ) ? sanitize_key( $args['programa_filtro'] ) : '';
		$page       = isset( $args['page'] ) ? max( 1, absint( $args['page'] ) ) : 1;
		$per_page   = isset( $args['per_page'] ) ? absint( $args['per_page'] ) : 10;

		$allowed_per_page = array( 10, 25, 50, 100 );
		if ( ! in_array( $per_page, $allowed_per_page, true ) ) {
			$per_page = 10;
		}

		$paquetes_table = $wpdb->prefix . 'paquetes';
		$correos_table  = $wpdb->prefix . 'correos_configurados';

		$where  = array( '1=1' );
		$params = array();

		if ( '' !== $search ) {
			$like     = '%' . $wpdb->esc_like( $search ) . '%';
			$where[]  = '(
				u.user_login LIKE %s
				OR u.user_email LIKE %s
				OR u.display_name LIKE %s
				OR fn.meta_value LIKE %s
				OR ln.meta_value LIKE %s
				OR CONCAT(fn.meta_value, " ", ln.meta_value) LIKE %s
			)';
			$params[] = $like;
			$params[] = $like;
			$params[] = $like;
			$params[] = $like;
			$params[] = $like;
			$params[] = $like;
		}

		if ( $empresa_id ) {
			$where[]  = 'cc.empresa_id = %d';
			$params[] = $empresa_id;
		}

		if ( $paquete_id ) {
			$where[]  = 'p.id = %d';
			$params[] = $paquete_id;
		}

		if ( 'con_test' === $test_filtro ) {
			$where[] = "(test.meta_value IS NOT NULL AND TRIM(test.meta_value) != '')";
		} elseif ( 'sin_test' === $test_filtro ) {
			$where[] = "(test.meta_value IS NULL OR TRIM(test.meta_value) = '')";
		}

		// Filtro de Programa (Inspira / Octagono / Todas / Ninguna), vía
		// EXISTS/NOT EXISTS para no necesitar más joins en ninguna de las
		// dos consultas (mismo criterio que el filtro de "Perfil").
		if ( '' !== $programa_filtro ) {
			$existe_inspira  = "EXISTS (SELECT 1 FROM {$wpdb->usermeta} pi WHERE pi.user_id = u.ID AND pi.meta_key = 'inspira' AND TRIM(pi.meta_value) != '')";
			$existe_octagono = "EXISTS (SELECT 1 FROM {$wpdb->usermeta} po WHERE po.user_id = u.ID AND po.meta_key = 'octagono' AND TRIM(po.meta_value) != '')";

			if ( 'inspira' === $programa_filtro ) {
				$where[] = $existe_inspira;
			} elseif ( 'octagono' === $programa_filtro ) {
				$where[] = $existe_octagono;
			} elseif ( 'todas' === $programa_filtro ) {
				$where[] = "({$existe_inspira} AND {$existe_octagono})";
			} elseif ( 'ninguna' === $programa_filtro ) {
				$where[] = "(NOT {$existe_inspira} AND NOT {$existe_octagono})";
			}
		}

		// Un perfil se considera "completo" cuando los 7 campos exigidos
		// en la columna Usuario (ver esta_perfil_completo()) existen y no
		// están vacíos en wp_usermeta. Se usa EXISTS/NOT EXISTS en vez de
		// más LEFT JOIN: con 7 joins adicionales sobre wp_usermeta, en un
		// sitio con muchos usuarios/metadatos la consulta se vuelve muy
		// lenta (o parece "colgada"); EXISTS se resuelve como semi-join y
		// no multiplica filas antes de agrupar.
		$campos_perfil_meta_keys = array(
			'first_name',
			'last_name',
			'user_age',
			'user_gender',
			'country',
			'phone_number',
			'user_position',
		);

		if ( 'completo' === $perfil_filtro ) {
			$condiciones = array();
			foreach ( $campos_perfil_meta_keys as $meta_key ) {
				$condiciones[] = $wpdb->prepare(
					"EXISTS (SELECT 1 FROM {$wpdb->usermeta} pf WHERE pf.user_id = u.ID AND pf.meta_key = %s AND TRIM(pf.meta_value) != '')",
					$meta_key
				);
			}
			$where[] = '(' . implode( ' AND ', $condiciones ) . ')';
		} elseif ( 'incompleto' === $perfil_filtro ) {
			$condiciones = array();
			foreach ( $campos_perfil_meta_keys as $meta_key ) {
				$condiciones[] = $wpdb->prepare(
					"NOT EXISTS (SELECT 1 FROM {$wpdb->usermeta} pf WHERE pf.user_id = u.ID AND pf.meta_key = %s AND TRIM(pf.meta_value) != '')",
					$meta_key
				);
			}
			$where[] = '(' . implode( ' OR ', $condiciones ) . ')';
		}

		// El listado de "Integrantes" solo debe mostrar usuarios con rol
		// subscriber o group_leader (se excluyen external_user, company,
		// administrator, etc.).
		$where[]  = '(cap.meta_value LIKE %s OR cap.meta_value LIKE %s)';
		$params[] = '%"subscriber"%';
		$params[] = '%"group_leader"%';

		$where_sql = implode( ' AND ', $where );

		// Consulta de conteo total (para la paginación).
		$count_sql = "
			SELECT COUNT(DISTINCT u.ID)
			FROM {$wpdb->users} u
			LEFT JOIN {$wpdb->usermeta} fn ON fn.user_id = u.ID AND fn.meta_key = 'first_name'
			LEFT JOIN {$wpdb->usermeta} ln ON ln.user_id = u.ID AND ln.meta_key = 'last_name'
			LEFT JOIN {$wpdb->usermeta} cap ON cap.user_id = u.ID AND cap.meta_key = '{$wpdb->prefix}capabilities'
			LEFT JOIN {$wpdb->usermeta} test ON test.user_id = u.ID AND test.meta_key = 'question_test_ids'
			LEFT JOIN {$correos_table} cc ON cc.email = u.user_email
			LEFT JOIN {$paquetes_table} p ON p.codigo = cc.codigo_area
			WHERE {$where_sql}
		";

		$total = $params
			? (int) $wpdb->get_var( $wpdb->prepare( $count_sql, $params ) )
			: (int) $wpdb->get_var( $count_sql );

		// Consulta principal paginada.
		$offset = ( $page - 1 ) * $per_page;

		// NOTA: aunque u.ID determina funcionalmente a todas estas columnas
		// (1 usuario = 1 login, 1 email, etc.), se envuelven explícitamente
		// en MAX() para ser compatibles con sql_mode=ONLY_FULL_GROUP_BY,
		// que es el valor por defecto en MySQL 5.7+/8.0. Sin esto, la
		// consulta fallaría en la mayoría de instalaciones de producción
		// aunque funcione en el dump local (que no tiene ese modo activo).
		$select_sql = "
			SELECT
				u.ID AS id,
				MAX(u.user_login) AS user_login,
				MAX(u.user_email) AS user_email,
				MAX(u.display_name) AS display_name,
				MAX(u.user_registered) AS user_registered,
				MAX(fn.meta_value) AS first_name,
				MAX(ln.meta_value) AS last_name,
				MAX(cap.meta_value) AS capabilities,
				MAX(age.meta_value) AS user_age,
				MAX(gender.meta_value) AS user_gender,
				MAX(country.meta_value) AS country,
				MAX(phone.meta_value) AS phone_number,
				MAX(position.meta_value) AS user_position,
				MAX(test.meta_value) AS question_test_ids,
				MAX(importado.meta_value) AS usuario_importado,
				MAX(login_disabled.meta_value) AS login_disabled,
				MAX(inspira.meta_value) AS inspira_valor,
				MAX(octagono.meta_value) AS octagono_valor,
				MAX(p.nombre) AS area_nombre,
				MAX(e.display_name) AS empresa_nombre,
				MAX(e.user_login) AS empresa_login
			FROM {$wpdb->users} u
			LEFT JOIN {$wpdb->usermeta} fn ON fn.user_id = u.ID AND fn.meta_key = 'first_name'
			LEFT JOIN {$wpdb->usermeta} ln ON ln.user_id = u.ID AND ln.meta_key = 'last_name'
			LEFT JOIN {$wpdb->usermeta} cap ON cap.user_id = u.ID AND cap.meta_key = '{$wpdb->prefix}capabilities'
			LEFT JOIN {$wpdb->usermeta} age ON age.user_id = u.ID AND age.meta_key = 'user_age'
			LEFT JOIN {$wpdb->usermeta} gender ON gender.user_id = u.ID AND gender.meta_key = 'user_gender'
			LEFT JOIN {$wpdb->usermeta} country ON country.user_id = u.ID AND country.meta_key = 'country'
			LEFT JOIN {$wpdb->usermeta} phone ON phone.user_id = u.ID AND phone.meta_key = 'phone_number'
			LEFT JOIN {$wpdb->usermeta} position ON position.user_id = u.ID AND position.meta_key = 'user_position'
			LEFT JOIN {$wpdb->usermeta} test ON test.user_id = u.ID AND test.meta_key = 'question_test_ids'
			LEFT JOIN {$wpdb->usermeta} importado ON importado.user_id = u.ID AND importado.meta_key = 'usuario_importado'
			LEFT JOIN {$wpdb->usermeta} login_disabled ON login_disabled.user_id = u.ID AND login_disabled.meta_key = 'au_wms_login_disabled'
			LEFT JOIN {$wpdb->usermeta} inspira ON inspira.user_id = u.ID AND inspira.meta_key = 'inspira'
			LEFT JOIN {$wpdb->usermeta} octagono ON octagono.user_id = u.ID AND octagono.meta_key = 'octagono'
			LEFT JOIN {$correos_table} cc ON cc.email = u.user_email
			LEFT JOIN {$paquetes_table} p ON p.codigo = cc.codigo_area
			LEFT JOIN {$wpdb->users} e ON e.ID = cc.empresa_id
			WHERE {$where_sql}
			GROUP BY u.ID
			ORDER BY u.ID DESC
			LIMIT %d OFFSET %d
		";

		$select_params   = $params;
		$select_params[] = $per_page;
		$select_params[] = $offset;

		$rows = $wpdb->get_results( $wpdb->prepare( $select_sql, $select_params ), ARRAY_A );

		$items = array();
		foreach ( (array) $rows as $row ) {
			$items[] = self::format_row( $row );
		}

		// La consulta principal, por rendimiento de paginación, solo
		// trae UNA área representativa por usuario (vía MAX(), ver
		// nota en el README). Aquí se completa con una segunda
		// consulta ligera, acotada a los correos de la página actual,
		// para listar TODAS las áreas a las que pertenece cada
		// usuario (un usuario puede tener varias filas en
		// wp_correos_configurados).
		if ( ! empty( $items ) ) {
			$emails_pagina    = wp_list_pluck( $items, 'user_email' );
			$areas_por_email  = self::obtener_areas_por_emails( $emails_pagina );

			foreach ( $items as &$item ) {
				$item['areas'] = isset( $areas_por_email[ $item['user_email'] ] )
					? $areas_por_email[ $item['user_email'] ]
					: array();
			}
			unset( $item );
		}

		return array(
			'items' => $items,
			'total' => $total,
		);
	}

	/**
	 * Devuelve TODAS las áreas (nombres de `wp_paquetes`) a las que
	 * pertenece cada correo, agrupadas por correo. Un usuario puede
	 * tener varias filas en `wp_correos_configurados` (una por cada
	 * área/paquete), por lo que puede pertenecer a una o varias áreas
	 * simultáneamente.
	 *
	 * Se limita explícitamente a los correos de la página actual (no
	 * a todos los usuarios) para no sacrificar el rendimiento de la
	 * paginación principal.
	 *
	 * @param array<int,string> $emails Correos a consultar.
	 * @return array<string,array<int,string>> Mapa email => lista de nombres de área (sin duplicados).
	 */
	private static function obtener_areas_por_emails( array $emails ) {
		global $wpdb;

		$emails = array_values( array_unique( array_filter( array_map( 'sanitize_email', $emails ) ) ) );

		if ( empty( $emails ) ) {
			return array();
		}

		$paquetes_table = $wpdb->prefix . 'paquetes';
		$correos_table  = $wpdb->prefix . 'correos_configurados';

		$placeholders = implode( ', ', array_fill( 0, count( $emails ), '%s' ) );

		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT cc.email, p.nombre AS area_nombre
				FROM {$correos_table} cc
				INNER JOIN {$paquetes_table} p ON p.codigo = cc.codigo_area
				WHERE cc.email IN ({$placeholders})
				ORDER BY p.nombre ASC",
				$emails
			),
			ARRAY_A
		);

		$areas_por_email = array();

		foreach ( (array) $rows as $row ) {
			$email = $row['email'];

			if ( ! isset( $areas_por_email[ $email ] ) ) {
				$areas_por_email[ $email ] = array();
			}

			// Evita duplicados exactos (mismo nombre de área repetido
			// por más de una fila en wp_correos_configurados).
			if ( ! in_array( $row['area_nombre'], $areas_por_email[ $email ], true ) ) {
				$areas_por_email[ $email ][] = $row['area_nombre'];
			}
		}

		return $areas_por_email;
	}

	/**
	 * Da formato a una fila cruda de la consulta principal para la vista.
	 *
	 * @param array $row Fila devuelta por $wpdb.
	 * @return array
	 */
	private static function format_row( array $row ) {
		$first_name = trim( (string) ( $row['first_name'] ?? '' ) );
		$last_name  = trim( (string) ( $row['last_name'] ?? '' ) );

		if ( $first_name || $last_name ) {
			$nombre = trim( $first_name . ' ' . $last_name );
		} elseif ( ! empty( $row['display_name'] ) ) {
			$nombre = $row['display_name'];
		} else {
			$nombre = $row['user_login'];
		}

		$role = self::extraer_rol_principal( $row['capabilities'] ?? '' );

		$perfil_completo = self::esta_perfil_completo( $row );
		$tiene_test      = isset( $row['question_test_ids'] ) && '' !== trim( (string) $row['question_test_ids'] );
		$es_importado    = isset( $row['usuario_importado'] ) && '' !== trim( (string) $row['usuario_importado'] );
		$acceso_deshabilitado = isset( $row['login_disabled'] ) && '' !== trim( (string) $row['login_disabled'] );
		$inspira_valor   = isset( $row['inspira_valor'] ) ? trim( (string) $row['inspira_valor'] ) : '';
		$octagono_valor  = isset( $row['octagono_valor'] ) ? trim( (string) $row['octagono_valor'] ) : '';

		return array(
			'id'               => (int) $row['id'],
			'nombre'           => $nombre,
			'user_email'       => $row['user_email'],
			'user_login'       => $row['user_login'],
			'empresa_nombre'   => ! empty( $row['empresa_nombre'] ) ? $row['empresa_nombre'] : ( $row['empresa_login'] ?? '' ),
			'area_nombre'      => ! empty( $row['area_nombre'] ) ? $row['area_nombre'] : '',
			'rol'              => $role,
			'user_registered'  => $row['user_registered'],
			'perfil_completo'  => $perfil_completo,
			'tiene_test'       => $tiene_test,
			'es_importado'     => $es_importado,
			'acceso_deshabilitado' => $acceso_deshabilitado,
			'inspira_valor'    => $inspira_valor,
			'octagono_valor'   => $octagono_valor,
		);
	}

	/**
	 * Determina si el usuario ha completado su perfil, verificando que
	 * existan (y no estén vacíos) los siguientes campos en wp_usermeta:
	 * first_name, last_name, user_age, user_gender, country,
	 * phone_number, user_position.
	 *
	 * @param array $row Fila cruda de la consulta principal.
	 * @return bool
	 */
	private static function esta_perfil_completo( array $row ) {
		$campos_requeridos = array(
			'first_name',
			'last_name',
			'user_age',
			'user_gender',
			'country',
			'phone_number',
			'user_position',
		);

		foreach ( $campos_requeridos as $campo ) {
			if ( ! isset( $row[ $campo ] ) || '' === trim( (string) $row[ $campo ] ) ) {
				return false;
			}
		}

		return true;
	}

	/**
	 * Lista los usuarios de una empresa (rol subscriber/group_leader),
	 * opcionalmente filtrados por una o varias áreas/paquetes y por
	 * estado de perfil, para el modal "Resetear contraseñas" del Tab
	 * Empresas. Sin paginación: la pantalla de selección necesita ver
	 * (y poder "seleccionar todos" sobre) el conjunto completo que
	 * cumple los filtros activos.
	 *
	 * @param int    $empresa_id    ID de la empresa (obligatorio).
	 * @param array  $paquete_ids   IDs de área/paquete a incluir (vacío = todas las de la empresa).
	 * @param string $perfil_filtro '', 'completo' o 'incompleto'.
	 * @return array<int, array{id:int,nombre:string,correo:string,area_nombre:string,perfil_completo:bool}>
	 */
	public static function buscar_para_reset_password( $empresa_id, array $paquete_ids, $perfil_filtro ) {
		global $wpdb;

		$empresa_id = absint( $empresa_id );
		if ( ! $empresa_id ) {
			return array();
		}

		$paquete_ids   = array_values( array_filter( array_map( 'absint', $paquete_ids ) ) );
		$perfil_filtro = sanitize_key( $perfil_filtro );

		$paquetes_table = $wpdb->prefix . 'paquetes';
		$correos_table  = $wpdb->prefix . 'correos_configurados';

		$where  = array( 'cc.empresa_id = %d' );
		$params = array( $empresa_id );

		if ( ! empty( $paquete_ids ) ) {
			$placeholders = implode( ',', array_fill( 0, count( $paquete_ids ), '%d' ) );
			$where[]      = "p.id IN ({$placeholders})";
			foreach ( $paquete_ids as $paquete_id ) {
				$params[] = $paquete_id;
			}
		}

		// Mismas reglas de "perfil completo/incompleto" que buscar().
		$campos_perfil_meta_keys = array(
			'first_name',
			'last_name',
			'user_age',
			'user_gender',
			'country',
			'phone_number',
			'user_position',
		);

		if ( 'completo' === $perfil_filtro ) {
			$condiciones = array();
			foreach ( $campos_perfil_meta_keys as $meta_key ) {
				$condiciones[] = $wpdb->prepare(
					"EXISTS (SELECT 1 FROM {$wpdb->usermeta} pf WHERE pf.user_id = u.ID AND pf.meta_key = %s AND TRIM(pf.meta_value) != '')",
					$meta_key
				);
			}
			$where[] = '(' . implode( ' AND ', $condiciones ) . ')';
		} elseif ( 'incompleto' === $perfil_filtro ) {
			$condiciones = array();
			foreach ( $campos_perfil_meta_keys as $meta_key ) {
				$condiciones[] = $wpdb->prepare(
					"NOT EXISTS (SELECT 1 FROM {$wpdb->usermeta} pf WHERE pf.user_id = u.ID AND pf.meta_key = %s AND TRIM(pf.meta_value) != '')",
					$meta_key
				);
			}
			$where[] = '(' . implode( ' OR ', $condiciones ) . ')';
		}

		// Solo integrantes (subscriber/group_leader), igual que el Tab
		// Integrantes: se excluyen cuentas company/external_user/admin.
		$where[]  = '(cap.meta_value LIKE %s OR cap.meta_value LIKE %s)';
		$params[] = '%"subscriber"%';
		$params[] = '%"group_leader"%';

		$where_sql = implode( ' AND ', $where );

		$sql = "
			SELECT
				u.ID AS id,
				MAX(u.user_login) AS user_login,
				MAX(u.user_email) AS user_email,
				MAX(u.display_name) AS display_name,
				MAX(fn.meta_value) AS first_name,
				MAX(ln.meta_value) AS last_name,
				MAX(cap.meta_value) AS capabilities,
				MAX(age.meta_value) AS user_age,
				MAX(gender.meta_value) AS user_gender,
				MAX(country.meta_value) AS country,
				MAX(phone.meta_value) AS phone_number,
				MAX(position.meta_value) AS user_position,
				MAX(p.nombre) AS area_nombre
			FROM {$wpdb->users} u
			LEFT JOIN {$wpdb->usermeta} fn ON fn.user_id = u.ID AND fn.meta_key = 'first_name'
			LEFT JOIN {$wpdb->usermeta} ln ON ln.user_id = u.ID AND ln.meta_key = 'last_name'
			LEFT JOIN {$wpdb->usermeta} cap ON cap.user_id = u.ID AND cap.meta_key = '{$wpdb->prefix}capabilities'
			LEFT JOIN {$wpdb->usermeta} age ON age.user_id = u.ID AND age.meta_key = 'user_age'
			LEFT JOIN {$wpdb->usermeta} gender ON gender.user_id = u.ID AND gender.meta_key = 'user_gender'
			LEFT JOIN {$wpdb->usermeta} country ON country.user_id = u.ID AND country.meta_key = 'country'
			LEFT JOIN {$wpdb->usermeta} phone ON phone.user_id = u.ID AND phone.meta_key = 'phone_number'
			LEFT JOIN {$wpdb->usermeta} position ON position.user_id = u.ID AND position.meta_key = 'user_position'
			LEFT JOIN {$correos_table} cc ON cc.email = u.user_email
			LEFT JOIN {$paquetes_table} p ON p.codigo = cc.codigo_area
			WHERE {$where_sql}
			GROUP BY u.ID
			ORDER BY first_name ASC, last_name ASC, display_name ASC
		";

		$rows = $wpdb->get_results( $wpdb->prepare( $sql, $params ), ARRAY_A );

		$items = array();
		foreach ( (array) $rows as $row ) {
			$first_name = trim( (string) ( $row['first_name'] ?? '' ) );
			$last_name  = trim( (string) ( $row['last_name'] ?? '' ) );

			if ( $first_name || $last_name ) {
				$nombre = trim( $first_name . ' ' . $last_name );
			} elseif ( ! empty( $row['display_name'] ) ) {
				$nombre = $row['display_name'];
			} else {
				$nombre = $row['user_login'];
			}

			$items[] = array(
				'id'              => (int) $row['id'],
				'nombre'          => $nombre,
				'correo'          => $row['user_email'],
				'area_nombre'     => ! empty( $row['area_nombre'] ) ? $row['area_nombre'] : '',
				'perfil_completo' => self::esta_perfil_completo( $row ),
			);
		}

		return $items;
	}

	/**
	 * Lista los integrantes (subscriber/group_leader) de una empresa
	 * pertenecientes a una o varias áreas/paquetes, para el modal
	 * "Exportar usuarios" del Tab Empresas.
	 *
	 * A diferencia de `buscar_para_reset_password()` (que agrupa por
	 * usuario y solo muestra un área representativa vía MAX()), esta
	 * consulta parte de `wp_correos_configurados` y agrupa por
	 * (usuario, área): si un usuario pertenece a varias áreas
	 * seleccionadas, aparece una fila por cada una — que es justo lo
	 * que necesita el Excel exportado (una fila = una pertenencia a
	 * un área). El resultado viene ordenado por nombre de área
	 * (alfabético) y luego por nombre de usuario.
	 *
	 * Tanto `empresa_id` como cada `paquete_id` se revalidan en la
	 * propia consulta (`p.empresa_id = %d`), así que aunque los IDs de
	 * área lleguen manipulados desde el navegador nunca se puede leer
	 * información de una empresa distinta a la indicada.
	 *
	 * @param int   $empresa_id  ID de la empresa (obligatorio).
	 * @param array $paquete_ids IDs de área/paquete a incluir (obligatorio, no vacío).
	 * @return array<int, array{id:int,nombre:string,correo:string,area_id:int,area_nombre:string,perfil_completo:bool,tiene_test:bool}>
	 */
	public static function buscar_para_exportar( $empresa_id, array $paquete_ids ) {
		global $wpdb;

		$empresa_id  = absint( $empresa_id );
		$paquete_ids = array_values( array_unique( array_filter( array_map( 'absint', $paquete_ids ) ) ) );

		if ( ! $empresa_id || empty( $paquete_ids ) ) {
			return array();
		}

		$paquetes_table = $wpdb->prefix . 'paquetes';
		$correos_table  = $wpdb->prefix . 'correos_configurados';

		$placeholders = implode( ',', array_fill( 0, count( $paquete_ids ), '%d' ) );

		$params   = array( $empresa_id, $empresa_id );
		$params   = array_merge( $params, $paquete_ids );
		$params[] = '%"subscriber"%';
		$params[] = '%"group_leader"%';

		// NOTA: los campos no funcionalmente dependientes de
		// (u.ID, p.id) se envuelven en MAX() por compatibilidad con
		// sql_mode=ONLY_FULL_GROUP_BY (MySQL 5.7+/8.0 por defecto en
		// producción), igual que el resto de consultas del plugin.
		//
		// Los 5 LEFT JOIN de user_age/user_gender/country/phone_number/
		// user_position son los mismos 7 campos (junto a first_name/
		// last_name) que usa `esta_perfil_completo()` para decidir
		// "perfil completo/incompleto" en el resto del plugin — se
		// reutiliza esa misma función aquí para que el criterio sea
		// idéntico al de la columna Usuario del Tab Integrantes y al
		// filtro de "Resetear contraseñas".
		$sql = "
			SELECT
				u.ID AS id,
				MAX(u.user_login) AS user_login,
				MAX(u.user_email) AS user_email,
				MAX(u.display_name) AS display_name,
				MAX(fn.meta_value) AS first_name,
				MAX(ln.meta_value) AS last_name,
				MAX(age.meta_value) AS user_age,
				MAX(gender.meta_value) AS user_gender,
				MAX(country.meta_value) AS country,
				MAX(phone.meta_value) AS phone_number,
				MAX(position.meta_value) AS user_position,
				MAX(test.meta_value) AS question_test_ids,
				p.id AS area_id,
				MAX(p.nombre) AS area_nombre
			FROM {$correos_table} cc
			INNER JOIN {$paquetes_table} p ON p.codigo = cc.codigo_area AND p.empresa_id = %d
			INNER JOIN {$wpdb->users} u ON u.user_email = cc.email
			LEFT JOIN {$wpdb->usermeta} fn ON fn.user_id = u.ID AND fn.meta_key = 'first_name'
			LEFT JOIN {$wpdb->usermeta} ln ON ln.user_id = u.ID AND ln.meta_key = 'last_name'
			LEFT JOIN {$wpdb->usermeta} age ON age.user_id = u.ID AND age.meta_key = 'user_age'
			LEFT JOIN {$wpdb->usermeta} gender ON gender.user_id = u.ID AND gender.meta_key = 'user_gender'
			LEFT JOIN {$wpdb->usermeta} country ON country.user_id = u.ID AND country.meta_key = 'country'
			LEFT JOIN {$wpdb->usermeta} phone ON phone.user_id = u.ID AND phone.meta_key = 'phone_number'
			LEFT JOIN {$wpdb->usermeta} position ON position.user_id = u.ID AND position.meta_key = 'user_position'
			LEFT JOIN {$wpdb->usermeta} test ON test.user_id = u.ID AND test.meta_key = 'question_test_ids'
			LEFT JOIN {$wpdb->usermeta} cap ON cap.user_id = u.ID AND cap.meta_key = '{$wpdb->prefix}capabilities'
			WHERE cc.empresa_id = %d
			  AND p.id IN ({$placeholders})
			  AND (cap.meta_value LIKE %s OR cap.meta_value LIKE %s)
			GROUP BY u.ID, p.id
			ORDER BY area_nombre ASC, first_name ASC, last_name ASC, display_name ASC
		";

		$rows = $wpdb->get_results( $wpdb->prepare( $sql, $params ), ARRAY_A );

		$items = array();
		foreach ( (array) $rows as $row ) {
			$first_name = trim( (string) ( $row['first_name'] ?? '' ) );
			$last_name  = trim( (string) ( $row['last_name'] ?? '' ) );

			if ( $first_name || $last_name ) {
				$nombre = trim( $first_name . ' ' . $last_name );
			} elseif ( ! empty( $row['display_name'] ) ) {
				$nombre = $row['display_name'];
			} else {
				$nombre = $row['user_login'];
			}

			$items[] = array(
				'id'              => (int) $row['id'],
				'nombre'          => $nombre,
				'correo'          => $row['user_email'],
				'area_id'         => (int) $row['area_id'],
				'area_nombre'     => $row['area_nombre'],
				'perfil_completo' => self::esta_perfil_completo( $row ),
				'tiene_test'      => isset( $row['question_test_ids'] ) && '' !== trim( (string) $row['question_test_ids'] ),
			);
		}

		return $items;
	}

	/**
	 * Compara una lista de correos (típicamente pegada desde el
	 * portapapeles en el modal "Comparar usuarios" del Tab Empresas)
	 * contra `wp_correos_configurados` de TODAS las empresas — no solo
	 * la indicada — para poder distinguir tres estados por correo:
	 *
	 * - `esta_empresa`: pertenece a la empresa indicada (ya sea a una
	 *   o varias de sus áreas).
	 * - `otra_empresa`: no pertenece a la empresa indicada, pero SÍ
	 *   está registrado en una o más áreas de otra(s) empresa(s).
	 * - `no_existe`: no aparece en `wp_correos_configurados` en
	 *   absoluto.
	 *
	 * Si el mismo correo aparece tanto en la empresa indicada como en
	 * otra, se prioriza `esta_empresa` (es la pregunta que importa
	 * primero) — el campo `detalle` en ese caso solo lista las áreas
	 * de la empresa indicada, no las de terceros.
	 *
	 * Para los correos con estado `esta_empresa`, `tiene_test` indica
	 * si el usuario ya realizó el test (`question_test_ids` en
	 * `wp_usermeta`, mismo criterio que el resto del plugin) — es
	 * `null` para `otra_empresa`/`no_existe`, donde no aplica.
	 *
	 * La comparación es case-insensitive (se normaliza todo a
	 * minúsculas, como suelen guardarse los correos).
	 *
	 * @param int   $empresa_id ID de la empresa contra la que se compara.
	 * @param array $correos    Lista de correos a verificar (se deduplican y normalizan).
	 * @return array<int, array{correo:string,estado:string,detalle:string,tiene_test:?bool}> Mismo orden que $correos (deduplicado). `estado` es 'esta_empresa'|'otra_empresa'|'no_existe'.
	 */
	public static function verificar_pertenencia_por_correo( $empresa_id, array $correos ) {
		global $wpdb;

		$empresa_id = absint( $empresa_id );

		$correos = array_values(
			array_unique(
				array_filter(
					array_map(
						function ( $correo ) {
							return strtolower( trim( (string) $correo ) );
						},
						$correos
					)
				)
			)
		);

		if ( ! $empresa_id || empty( $correos ) ) {
			return array();
		}

		$correos_table  = $wpdb->prefix . 'correos_configurados';
		$paquetes_table = $wpdb->prefix . 'paquetes';

		$placeholders = implode( ',', array_fill( 0, count( $correos ), '%s' ) );

		// Sin filtrar por empresa: se necesita ver en qué empresa(s)
		// está cada correo, sea la indicada o cualquier otra. El
		// estado del test (`question_test_ids`) solo se usa para los
		// que caen en "esta_empresa", pero se trae siempre — es la
		// misma fila, no cuesta una consulta aparte.
		$sql = "
			SELECT
				LOWER(cc.email) AS email,
				cc.empresa_id AS empresa_id,
				p.nombre AS area_nombre,
				test.meta_value AS question_test_ids
			FROM {$correos_table} cc
			INNER JOIN {$paquetes_table} p ON p.codigo = cc.codigo_area AND p.empresa_id = cc.empresa_id
			LEFT JOIN {$wpdb->users} u ON u.user_email = cc.email
			LEFT JOIN {$wpdb->usermeta} test ON test.user_id = u.ID AND test.meta_key = 'question_test_ids'
			WHERE LOWER(cc.email) IN ({$placeholders})
		";

		$rows = $wpdb->get_results( $wpdb->prepare( $sql, $correos ), ARRAY_A );

		// Agrupa las filas por correo, separando "áreas de la empresa
		// indicada" de "áreas por cada otra empresa" antes de decidir
		// el estado final de cada correo. `esta_empresa_test` se
		// calcula con OR: aunque el correo tenga varias filas (una por
		// área), todas comparten el mismo usuario y por lo tanto el
		// mismo estado de test.
		$por_correo = array();
		foreach ( (array) $rows as $row ) {
			$correo = $row['email'];

			if ( ! isset( $por_correo[ $correo ] ) ) {
				$por_correo[ $correo ] = array(
					'esta_empresa'      => array(),
					'esta_empresa_test' => false,
					'otras'             => array(), // [ empresa_id => [ área, área, ... ] ]
				);
			}

			if ( (int) $row['empresa_id'] === $empresa_id ) {
				$por_correo[ $correo ]['esta_empresa'][] = $row['area_nombre'];

				if ( '' !== trim( (string) $row['question_test_ids'] ) ) {
					$por_correo[ $correo ]['esta_empresa_test'] = true;
				}
			} else {
				$por_correo[ $correo ]['otras'][ (int) $row['empresa_id'] ][] = $row['area_nombre'];
			}
		}

		// Resuelve en un solo lote los nombres de las "otras" empresas
		// involucradas (evita N llamadas a get_userdata sueltas).
		$otras_empresa_ids = array();
		foreach ( $por_correo as $datos ) {
			foreach ( array_keys( $datos['otras'] ) as $otra_empresa_id ) {
				$otras_empresa_ids[ $otra_empresa_id ] = true;
			}
		}

		$nombres_empresas = array();
		foreach ( array_keys( $otras_empresa_ids ) as $otra_empresa_id ) {
			$otra_empresa = get_userdata( $otra_empresa_id );
			$nombres_empresas[ $otra_empresa_id ] = $otra_empresa
				? ( $otra_empresa->display_name ? $otra_empresa->display_name : $otra_empresa->user_login )
				: sprintf( '#%d', $otra_empresa_id );
		}

		$items = array();
		foreach ( $correos as $correo ) {
			$datos = isset( $por_correo[ $correo ] ) ? $por_correo[ $correo ] : array(
				'esta_empresa'      => array(),
				'esta_empresa_test' => false,
				'otras'             => array(),
			);

			if ( ! empty( $datos['esta_empresa'] ) ) {
				$areas = array_values( array_unique( $datos['esta_empresa'] ) );
				natcasesort( $areas );

				$items[] = array(
					'correo'     => $correo,
					'estado'     => 'esta_empresa',
					'detalle'    => implode( ', ', $areas ),
					'tiene_test' => $datos['esta_empresa_test'],
				);
				continue;
			}

			if ( ! empty( $datos['otras'] ) ) {
				$partes = array();

				foreach ( $datos['otras'] as $otra_empresa_id => $areas ) {
					$areas = array_values( array_unique( $areas ) );
					natcasesort( $areas );

					$partes[] = sprintf(
						'%s (%s)',
						$nombres_empresas[ $otra_empresa_id ],
						implode( ', ', $areas )
					);
				}

				$items[] = array(
					'correo'     => $correo,
					'estado'     => 'otra_empresa',
					'detalle'    => implode( '; ', $partes ),
					'tiene_test' => null,
				);
				continue;
			}

			$items[] = array(
				'correo'     => $correo,
				'estado'     => 'no_existe',
				'detalle'    => '',
				'tiene_test' => null,
			);
		}

		return $items;
	}

	/**
	 * De una lista de IDs de usuario propuesta por el cliente, devuelve
	 * únicamente los que realmente pertenecen a la empresa indicada
	 * (vía `wp_correos_configurados.empresa_id`). Se usa como
	 * verificación server-side antes de ejecutar el reseteo masivo de
	 * contraseñas: nunca se confía en la selección tal como llega del
	 * navegador.
	 *
	 * @param int   $empresa_id ID de la empresa.
	 * @param array $user_ids   IDs de usuario propuestos.
	 * @return array<int,int> Subconjunto válido de $user_ids.
	 */
	public static function filtrar_ids_pertenecientes_a_empresa( $empresa_id, array $user_ids ) {
		global $wpdb;

		$empresa_id = absint( $empresa_id );
		$user_ids   = array_values( array_unique( array_filter( array_map( 'absint', $user_ids ) ) ) );

		if ( ! $empresa_id || empty( $user_ids ) ) {
			return array();
		}

		$correos_table = $wpdb->prefix . 'correos_configurados';
		$placeholders  = implode( ',', array_fill( 0, count( $user_ids ), '%d' ) );

		$sql = "
			SELECT DISTINCT u.ID
			FROM {$wpdb->users} u
			INNER JOIN {$correos_table} cc ON cc.email = u.user_email
			WHERE cc.empresa_id = %d AND u.ID IN ({$placeholders})
		";

		$params = array_merge( array( $empresa_id ), $user_ids );
		$rows   = $wpdb->get_col( $wpdb->prepare( $sql, $params ) );

		return array_map( 'absint', $rows );
	}

	/**
	 * Extrae el rol principal a partir del meta_value serializado de
	 * `wp_capabilities`.
	 *
	 * @param string $serialized Valor serializado.
	 * @return string
	 */
	private static function extraer_rol_principal( $serialized ) {
		if ( empty( $serialized ) ) {
			return '';
		}

		$capabilities = maybe_unserialize( $serialized );
		if ( ! is_array( $capabilities ) ) {
			return '';
		}

		foreach ( $capabilities as $role => $enabled ) {
			if ( $enabled ) {
				return (string) $role;
			}
		}

		return '';
	}

	/**
	 * Obtiene todos los `codigo_area` asociados a un correo (usuario),
	 * necesarios para el flujo de eliminación (recalcular cupones).
	 *
	 * @param string $email Correo del usuario.
	 * @return array<int,string>
	 */
	public static function get_codigos_area_por_email( $email ) {
		global $wpdb;

		$email = sanitize_email( $email );
		if ( ! $email ) {
			return array();
		}

		$table = $wpdb->prefix . 'correos_configurados';

		$codigos = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT DISTINCT codigo_area FROM {$table} WHERE email = %s",
				$email
			)
		);

		return (array) $codigos;
	}

	/**
	 * Elimina todos los registros de `wp_correos_configurados` para un
	 * correo determinado.
	 *
	 * @param string $email Correo del usuario.
	 * @return int|false Número de filas eliminadas, o `false` si la
	 *                   consulta falló (necesario para que los flujos
	 *                   transaccionales puedan hacer ROLLBACK).
	 */
	public static function eliminar_correos_configurados( $email ) {
		global $wpdb;

		$email = sanitize_email( $email );
		if ( ! $email ) {
			return 0;
		}

		$table = $wpdb->prefix . 'correos_configurados';

		$resultado = $wpdb->delete( $table, array( 'email' => $email ), array( '%s' ) );

		return false === $resultado ? false : (int) $resultado;
	}

	/**
	 * Cuenta cuántos registros activos quedan en `wp_correos_configurados`
	 * para un `codigo_area` dado (usado para recalcular el consumo real
	 * del cupón asociado).
	 *
	 * @param string $codigo_area Código de área.
	 * @return int
	 */
	public static function contar_por_codigo_area( $codigo_area ) {
		global $wpdb;

		$table = $wpdb->prefix . 'correos_configurados';

		return (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$table} WHERE codigo_area = %s",
				$codigo_area
			)
		);
	}

	/**
	 * Busca/pagina TODAS las áreas (`wp_paquetes`) a las que pertenece
	 * un usuario específico, con búsqueda por nombre de área. Un
	 * usuario puede tener varias filas en `wp_correos_configurados`
	 * (una por cada área), por lo que puede pertenecer a una o varias
	 * áreas simultáneamente (ver modal "Áreas del usuario", Tab
	 * Integrantes).
	 *
	 * La columna "Uso / Límite" cuenta TODOS los usuarios de esa área
	 * (no solo el usuario actual), igual que en el modal de Áreas del
	 * Tab Empresas.
	 *
	 * @param array $args {
	 *     @type int    $user_id  ID del usuario.
	 *     @type string $search   Texto de búsqueda por nombre de área.
	 *     @type int    $page     Página actual (1-indexed).
	 *     @type int    $per_page Registros por página.
	 * }
	 * @return array{items:array,total:int}
	 */
	public static function buscar_areas_usuario( array $args ) {
		global $wpdb;

		$user_id  = isset( $args['user_id'] ) ? absint( $args['user_id'] ) : 0;
		$search   = isset( $args['search'] ) ? trim( (string) $args['search'] ) : '';
		$page     = isset( $args['page'] ) ? max( 1, absint( $args['page'] ) ) : 1;
		$per_page = isset( $args['per_page'] ) ? absint( $args['per_page'] ) : 10;

		$allowed_per_page = array( 10, 25, 50, 100 );
		if ( ! in_array( $per_page, $allowed_per_page, true ) ) {
			$per_page = 10;
		}

		if ( ! $user_id ) {
			return array(
				'items' => array(),
				'total' => 0,
			);
		}

		$usuario = get_userdata( $user_id );
		if ( ! $usuario ) {
			return array(
				'items' => array(),
				'total' => 0,
			);
		}

		$email = $usuario->user_email;

		$offset         = ( $page - 1 ) * $per_page;
		$paquetes_table = $wpdb->prefix . 'paquetes';
		$correos_table  = $wpdb->prefix . 'correos_configurados';

		// "propio" filtra las áreas a las que PERTENECE este usuario;
		// "todos" (alias distinto, sin filtrar por email) se usa aparte
		// para contar el uso total de cada área, igual que en el modal
		// de Áreas del Tab Empresas.
		$where  = array( 'propio.email = %s' );
		$params = array( $email );

		if ( '' !== $search ) {
			$where[]  = 'p.nombre LIKE %s';
			$params[] = '%' . $wpdb->esc_like( $search ) . '%';
		}

		$where_sql = implode( ' AND ', $where );

		$count_sql = "
			SELECT COUNT(DISTINCT p.id)
			FROM {$correos_table} propio
			INNER JOIN {$paquetes_table} p ON p.codigo = propio.codigo_area
			WHERE {$where_sql}
		";

		$total = (int) $wpdb->get_var( $wpdb->prepare( $count_sql, $params ) );

		$select_sql = "
			SELECT
				p.id,
				p.nombre,
				p.codigo,
				p.cupo,
				COUNT(DISTINCT todos.email) AS usados
			FROM {$correos_table} propio
			INNER JOIN {$paquetes_table} p ON p.codigo = propio.codigo_area
			LEFT JOIN {$correos_table} todos ON todos.codigo_area = p.codigo
			WHERE {$where_sql}
			GROUP BY p.id
			ORDER BY p.nombre ASC
			LIMIT %d OFFSET %d
		";

		$select_params   = $params;
		$select_params[] = $per_page;
		$select_params[] = $offset;

		$rows = $wpdb->get_results( $wpdb->prepare( $select_sql, $select_params ), ARRAY_A );

		$items = array();
		foreach ( (array) $rows as $row ) {
			$items[] = array(
				'id'     => (int) $row['id'],
				'nombre' => $row['nombre'],
				'codigo' => $row['codigo'],
				'cupo'   => (int) $row['cupo'],
				'usados' => (int) $row['usados'],
			);
		}

		return array(
			'items' => $items,
			'total' => $total,
		);
	}

	/**
	 * Determina la empresa "principal" de un usuario, para saber de
	 * qué empresa mostrar las áreas disponibles en el modal "Agregar
	 * área" (Tab Integrantes → Áreas del usuario).
	 *
	 * Primero intenta el meta_key `empresa_id` (guardado al crear o
	 * actualizar el usuario durante una importación masiva). Si no
	 * existe (por ejemplo, un usuario muy antiguo o que solo llegó por
	 * "Agregar área" a otra área sin ese metadato), cae al
	 * `empresa_id` de cualquiera de sus filas existentes en
	 * `wp_correos_configurados`.
	 *
	 * @param int $user_id ID del usuario.
	 * @return int 0 si no se pudo determinar ninguna empresa.
	 */
	public static function obtener_empresa_id_usuario( $user_id ) {
		$user_id = absint( $user_id );
		if ( ! $user_id ) {
			return 0;
		}

		$empresa_id_meta = (int) get_user_meta( $user_id, 'empresa_id', true );
		if ( $empresa_id_meta > 0 ) {
			return $empresa_id_meta;
		}

		$usuario = get_userdata( $user_id );
		if ( ! $usuario ) {
			return 0;
		}

		global $wpdb;
		$correos_table = $wpdb->prefix . 'correos_configurados';

		$empresa_id_fila = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT empresa_id FROM {$correos_table} WHERE email = %s ORDER BY id ASC LIMIT 1",
				$usuario->user_email
			)
		);

		return (int) $empresa_id_fila;
	}

	/**
	 * Devuelve las áreas de la empresa "principal" de un usuario a las
	 * que TODAVÍA no pertenece (para poblar el select del modal
	 * "Agregar área"). Incluye el resumen de cupos de cada área para
	 * mostrarlo al seleccionarla.
	 *
	 * @param int $user_id ID del usuario.
	 * @return array<int,array{id:int,nombre:string,codigo:string,cupo:int,utilizados:int,disponibles:int}>
	 */
	public static function obtener_areas_disponibles_para_vincular( $user_id ) {
		$user_id = absint( $user_id );
		$usuario = get_userdata( $user_id );

		if ( ! $usuario ) {
			return array();
		}

		$empresa_id = self::obtener_empresa_id_usuario( $user_id );
		if ( ! $empresa_id ) {
			return array();
		}

		global $wpdb;
		$paquetes_table = $wpdb->prefix . 'paquetes';
		$correos_table  = $wpdb->prefix . 'correos_configurados';

		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT p.id, p.nombre, p.codigo, p.cupo
				FROM {$paquetes_table} p
				WHERE p.empresa_id = %d
				AND NOT EXISTS (
					SELECT 1 FROM {$correos_table} cc
					WHERE cc.codigo_area = p.codigo AND cc.email = %s
				)
				ORDER BY p.nombre ASC",
				$empresa_id,
				$usuario->user_email
			),
			ARRAY_A
		);

		$areas = array();
		foreach ( (array) $rows as $row ) {
			$cupo       = (int) $row['cupo'];
			$utilizados = self::contar_por_codigo_area( $row['codigo'] );

			$areas[] = array(
				'id'          => (int) $row['id'],
				'nombre'      => $row['nombre'],
				'codigo'      => $row['codigo'],
				'cupo'        => $cupo,
				'utilizados'  => $utilizados,
				'disponibles' => max( 0, $cupo - $utilizados ),
			);
		}

		return $areas;
	}
}
