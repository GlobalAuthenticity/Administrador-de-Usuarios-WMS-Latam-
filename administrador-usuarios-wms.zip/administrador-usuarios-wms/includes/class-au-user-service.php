<?php
/**
 * Servicio de negocio para operaciones sobre usuarios: el flujo
 * completo de "Borrar usuario" (con sus dos caminos —
 * "Dejar de ser usuario WMS" y "Borrar definitivamente"— según los
 * programas Inspira/Octágono que el usuario tenga asignados) e inicio
 * de sesión como usuario (impersonación).
 *
 * @package Administrador_Usuarios_WMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AU_User_Service {

	/**
	 * Determina qué programas (Inspira/Octágono) tiene asignados un
	 * usuario en este momento, para decidir qué modal/flujo mostrar al
	 * hacer clic en "Borrar usuario".
	 *
	 * @param int $user_id ID del usuario.
	 * @return array{success:bool,message?:string,email?:string,tiene_inspira?:bool,tiene_octagono?:bool}
	 */
	public static function determinar_escenario_programas( $user_id ) {
		$user_id = absint( $user_id );
		$user    = get_userdata( $user_id );

		if ( ! $user ) {
			return array(
				'success' => false,
				'message' => __( 'El usuario no existe.', 'au-wms' ),
			);
		}

		if ( ! AU_Security::puede_gestionar_usuario( $user ) ) {
			return array(
				'success' => false,
				'message' => AU_Security::mensaje_usuario_protegido(),
			);
		}

		return array(
			'success'        => true,
			'email'          => $user->user_email,
			'tiene_inspira'  => metadata_exists( 'user', $user_id, 'inspira' ),
			'tiene_octagono' => metadata_exists( 'user', $user_id, 'octagono' ),
			'inspira_valor'  => get_user_meta( $user_id, 'inspira', true ),
			'octagono_valor' => get_user_meta( $user_id, 'octagono', true ),
		);
	}

	/**
	 * Flujo "Dejar de ser usuario WMS": el usuario se desvincula de WMS
	 * (correos_configurados, LearnDash, test, área/grupo) pero conserva
	 * su cuenta de WordPress con rol `external_user`, preservando los
	 * metadatos `inspira`/`octagono` si los tenía (para no perder su
	 * acceso a esos programas). Se ejecuta en este orden exacto:
	 *
	 * 1. Eliminar registros de wp_correos_configurados del usuario.
	 * 2. Recalcular los usos de cada cupón de WooCommerce afectado.
	 * 3. Eliminar toda la información académica de LearnDash.
	 * 4. Eliminar `question_test_ids` de wp_usermeta.
	 * 5. Dejar al usuario únicamente con el rol `external_user`
	 *    (esto ya lo desvincula de cualquier área/grupo, ya que esas
	 *    relaciones dependían de wp_correos_configurados, eliminado en
	 *    el paso 1).
	 *
	 * No dispara ningún correo ni notificación: solo usa
	 * `WP_User::set_role()`, que no tiene ningún hook de email en el
	 * núcleo de WordPress.
	 *
	 * @param int $user_id ID del usuario.
	 * @return array{success:bool,message?:string,email?:string,tiene_inspira?:bool,tiene_octagono?:bool}
	 */
	public static function dejar_de_ser_usuario_wms( $user_id ) {
		$user_id = absint( $user_id );
		$user    = get_userdata( $user_id );

		if ( ! $user ) {
			return array(
				'success' => false,
				'message' => __( 'El usuario no existe.', 'au-wms' ),
			);
		}

		if ( ! AU_Security::puede_gestionar_usuario( $user ) ) {
			return array(
				'success' => false,
				'message' => AU_Security::mensaje_usuario_protegido(),
			);
		}

		$email = $user->user_email;

		global $wpdb;

		// Paso 1: obtener los codigo_area ANTES de borrar (se necesitan
		// para recalcular los cupones después).
		$codigos_area = AU_Repository_Usuarios::get_codigos_area_por_email( $email );

		// IMPORTANTE: $wpdb no lanza excepciones; cuando una consulta
		// falla devuelve `false`. Por eso cada paso se verifica de forma
		// explícita y se lanza la excepción a mano: de lo contrario el
		// catch nunca se ejecuta y se haría COMMIT de un estado parcial.
		$wpdb->query( 'START TRANSACTION' );

		try {
			// Paso 1: eliminar los registros de wp_correos_configurados.
			if ( false === AU_Repository_Usuarios::eliminar_correos_configurados( $email ) ) {
				throw new Exception( 'No fue posible eliminar los registros de wp_correos_configurados: ' . $wpdb->last_error );
			}

			// Paso 3: eliminar toda la información de LearnDash (lanza
			// excepción si alguna consulta falla).
			self::eliminar_datos_learndash( $user_id );

			// Paso 4: eliminar únicamente el resultado del test.
			// delete_user_meta() devuelve false también cuando la clave no
			// existe, así que solo se trata como error si existía.
			if ( metadata_exists( 'user', $user_id, 'question_test_ids' ) && ! delete_user_meta( $user_id, 'question_test_ids' ) ) {
				throw new Exception( 'No fue posible eliminar question_test_ids.' );
			}

			// Paso 5: dejar al usuario solo con el rol external_user.
			// set_role() reemplaza TODOS los roles anteriores por uno
			// solo; no dispara ningún email ni notificación en el
			// núcleo de WordPress. No devuelve valor, así que se
			// comprueba leyendo el resultado real en la base de datos.
			$user->set_role( 'external_user' );

			if ( ! self::tiene_solo_rol_en_bd( $user_id, 'external_user' ) ) {
				throw new Exception( 'No fue posible asignar el rol external_user.' );
			}

			if ( false === $wpdb->query( 'COMMIT' ) ) {
				throw new Exception( 'COMMIT falló: ' . $wpdb->last_error );
			}
		} catch ( Exception $e ) {
			$wpdb->query( 'ROLLBACK' );
			// La caché de objetos pudo quedar con los valores modificados
			// antes del ROLLBACK; se invalida para releer de la BD.
			self::limpiar_cache_usuario( $user );
			error_log( '[AU-WMS] Error en dejar_de_ser_usuario_wms() para el usuario #' . $user_id . ': ' . $e->getMessage() );

			return array(
				'success' => false,
				'message' => __( 'Ocurrió un error al desvincular al usuario. No se realizaron cambios.', 'au-wms' ),
			);
		}

		// Paso 2: recalcular los cupones (fuera de la transacción de
		// wpdb, ya que interactúa con objetos de WooCommerce que
		// manejan su propio guardado).
		if ( ! empty( $codigos_area ) ) {
			AU_Coupon_Service::recalcular_multiples( $codigos_area );
		}

		return array(
			'success'        => true,
			'email'          => $email,
			// inspira/octagono no se tocan en este flujo: se
			// recalculan aquí solo para que el frontend arme el
			// mensaje de éxito correcto (qué programa conserva).
			'tiene_inspira'  => metadata_exists( 'user', $user_id, 'inspira' ),
			'tiene_octagono' => metadata_exists( 'user', $user_id, 'octagono' ),
		);
	}

	/**
	 * Flujo "Borrar definitivamente": solo debe invocarse cuando el
	 * usuario NO tiene asignado ni Inspira ni Octágono (se revalida
	 * aquí también, por seguridad, sin confiar únicamente en el
	 * frontend). Ejecuta el flujo completo de eliminación:
	 *
	 * 1. Eliminar registros de wp_correos_configurados.
	 * 2. Eliminar el usuario con wp_delete_user(), que dispara los hooks
	 *    de otros plugins (LearnDash, WooCommerce…) con sus datos aún
	 *    presentes y luego borra todos sus usermeta.
	 * 3. COMMIT (o ROLLBACK si cualquiera de los pasos anteriores falla).
	 * 4. Recalcular los usos de cada cupón de WooCommerce afectado.
	 *
	 * Solo opera sobre usuarios que AU_Security::puede_gestionar_usuario()
	 * permite (nunca administradores ni roles privilegiados).
	 *
	 * @param int $user_id ID del usuario a eliminar.
	 * @return array{success:bool,message:string}
	 */
	public static function eliminar_usuario( $user_id ) {
		$user_id = absint( $user_id );

		if ( ! $user_id ) {
			return array(
				'success' => false,
				'message' => __( 'ID de usuario inválido.', 'au-wms' ),
			);
		}

		$user = get_userdata( $user_id );

		if ( ! $user ) {
			return array(
				'success' => false,
				'message' => __( 'El usuario no existe.', 'au-wms' ),
			);
		}

		if ( ! AU_Security::puede_gestionar_usuario( $user ) ) {
			return array(
				'success' => false,
				'message' => AU_Security::mensaje_usuario_protegido(),
			);
		}

		// No permitir que un administrador se elimine a sí mismo desde este panel.
		if ( (int) $user_id === get_current_user_id() ) {
			return array(
				'success' => false,
				'message' => __( 'No puedes eliminar tu propio usuario desde este panel.', 'au-wms' ),
			);
		}

		// Revalidación de seguridad: "Borrar definitivamente" solo
		// aplica si el usuario no tiene Inspira ni Octágono asignados,
		// sin importar lo que haya decidido el frontend.
		if ( metadata_exists( 'user', $user_id, 'inspira' ) || metadata_exists( 'user', $user_id, 'octagono' ) ) {
			return array(
				'success' => false,
				'message' => __( 'Este usuario tiene programas asignados (Inspira/Octágono) y no puede eliminarse definitivamente. Usa "Dejar de ser usuario WMS".', 'au-wms' ),
			);
		}

		$email = $user->user_email;

		global $wpdb;

		$codigos_area = AU_Repository_Usuarios::get_codigos_area_por_email( $email );

		if ( ! function_exists( 'wp_delete_user' ) ) {
			require_once ABSPATH . 'wp-admin/includes/user.php';
		}

		// Orden pensado para que todo quede dentro de la transacción y
		// para que los hooks `delete_user`/`deleted_user` de LearnDash,
		// WooCommerce, etc. se ejecuten con los datos del usuario todavía
		// presentes (antes se borraban los usermeta primero y esos
		// hooks corrían sobre un usuario "vacío"):
		//
		// 1. Eliminar los registros de wp_correos_configurados.
		// 2. wp_delete_user(): dispara los hooks y borra TODOS los
		//    usermeta (incluidos los de LearnDash) de forma nativa.
		// 3. COMMIT.
		// 4. Recalcular cupones (fuera de la transacción).
		//
		// $wpdb no lanza excepciones: cada paso se verifica a mano.
		$wpdb->query( 'START TRANSACTION' );

		try {
			if ( false === AU_Repository_Usuarios::eliminar_correos_configurados( $email ) ) {
				throw new Exception( 'No fue posible eliminar los registros de wp_correos_configurados: ' . $wpdb->last_error );
			}

			if ( ! wp_delete_user( $user_id ) ) {
				throw new Exception( 'wp_delete_user() devolvió false.' );
			}

			// wp_delete_user() no revisa el resultado de sus propias
			// consultas: se confirma que la fila realmente desapareció.
			$sigue_existiendo = $wpdb->get_var(
				$wpdb->prepare( "SELECT ID FROM {$wpdb->users} WHERE ID = %d", $user_id )
			);

			if ( null !== $sigue_existiendo ) {
				throw new Exception( 'El usuario sigue existiendo en wp_users tras wp_delete_user().' );
			}

			if ( false === $wpdb->query( 'COMMIT' ) ) {
				throw new Exception( 'COMMIT falló: ' . $wpdb->last_error );
			}
		} catch ( Exception $e ) {
			$wpdb->query( 'ROLLBACK' );
			self::limpiar_cache_usuario( $user );
			error_log( '[AU-WMS] Error en eliminar_usuario() para el usuario #' . $user_id . ': ' . $e->getMessage() );

			return array(
				'success' => false,
				'message' => __( 'Ocurrió un error al eliminar al usuario. No se realizaron cambios.', 'au-wms' ),
			);
		}

		// Recalcular cupones (fuera de la transacción: interactúa con
		// objetos de WooCommerce que manejan su propio guardado). Solo se
		// llega aquí si la eliminación se confirmó por completo.
		if ( ! empty( $codigos_area ) ) {
			AU_Coupon_Service::recalcular_multiples( $codigos_area );
		}

		return array(
			'success' => true,
			'message' => __( 'El usuario se eliminó definitivamente. Para volver a participar en el programa deberá ser invitado nuevamente o creado como un nuevo usuario.', 'au-wms' ),
		);
	}

	/**
	 * Elimina toda la información académica de LearnDash asociada a un
	 * usuario: cursos inscritos/asignados, progreso, lecciones y temas
	 * completados, quizzes y certificados.
	 *
	 * NOTA IMPORTANTE (transparencia de la implementación): LearnDash no
	 * documenta una única función pública "borrar todo el progreso de
	 * un usuario". Esta limpieza se hace a nivel de `wp_usermeta` por
	 * patrones de `meta_key`, cubriendo las claves estándar conocidas de
	 * LearnDash (progreso de curso, quizzes, acceso a cursos, grupos) más
	 * un patrón amplio de respaldo (`%sfwd%`, `%certificate%`) para
	 * capturar variantes o addons. Si tu instalación de LearnDash guarda
	 * algo con un meta_key que no calce con ninguno de estos patrones, no
	 * se eliminará automáticamente; puedes ampliar el array `$patrones`
	 * de este método con cualquier clave adicional que identifiques.
	 *
	 * @param int $user_id ID del usuario.
	 * @return void
	 * @throws Exception Si alguna de las consultas DELETE falla.
	 */
	private static function eliminar_datos_learndash( $user_id ) {
		global $wpdb;

		$patrones = array(
			'course_%_access_from',     // Acceso a cursos individuales.
			'_sfwd-course_progress',    // Progreso de cursos (lecciones/temas completados).
			'_sfwd-quizzes',            // Intentos de quizzes.
			'learndash_group_users_%',  // Pertenencia a grupos.
			'learndash_group_leaders_%',
			'%certificate%',            // Certificados (por si el tema/addon los guarda en usermeta).
			'%sfwd%',                   // Respaldo: cualquier otra clave con el prefijo estándar de LearnDash.
			'%quiz%',                   // Respaldo: resultados de quizzes con otros nombres de clave.
		);

		foreach ( $patrones as $patron ) {
			$resultado = $wpdb->query(
				$wpdb->prepare(
					"DELETE FROM {$wpdb->usermeta} WHERE user_id = %d AND meta_key LIKE %s",
					$user_id,
					$patron
				)
			);

			if ( false === $resultado ) {
				throw new Exception( 'No fue posible eliminar los datos de LearnDash (' . $patron . '): ' . $wpdb->last_error );
			}
		}

		// Se borró directamente en la tabla: la caché de metadatos del
		// usuario debe invalidarse para que no siga devolviendo lo viejo.
		wp_cache_delete( $user_id, 'user_meta' );
	}

	/**
	 * Lee directamente de la base de datos (sin caché) los roles del
	 * usuario y confirma que tiene exactamente el rol indicado.
	 *
	 * @param int    $user_id ID del usuario.
	 * @param string $rol     Rol esperado.
	 * @return bool
	 */
	private static function tiene_solo_rol_en_bd( $user_id, $rol ) {
		global $wpdb;

		$valor = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT meta_value FROM {$wpdb->usermeta} WHERE user_id = %d AND meta_key = %s LIMIT 1",
				$user_id,
				$wpdb->get_blog_prefix() . 'capabilities'
			)
		);

		$capacidades = maybe_unserialize( $valor );

		if ( ! is_array( $capacidades ) ) {
			return false;
		}

		$roles = array_keys( array_filter( $capacidades ) );

		return array( $rol ) === $roles;
	}

	/**
	 * Invalida la caché de objetos de un usuario (datos + metadatos).
	 * Necesario tras un ROLLBACK: las funciones nativas de WordPress
	 * ya actualizaron la caché con valores que la BD acaba de revertir.
	 * Recibe el WP_User leído ANTES de modificar nada, para limpiar
	 * también las claves por login/email/nicename originales.
	 *
	 * @param WP_User $user Usuario (instantánea previa a los cambios).
	 * @return void
	 */
	private static function limpiar_cache_usuario( WP_User $user ) {
		clean_user_cache( $user );
		wp_cache_delete( $user->ID, 'user_meta' );
	}

	/**
	 * Habilita o deshabilita el acceso de inicio de sesión de un
	 * usuario (independiente de eliminarlo o cambiarle el rol). Se
	 * marca con el meta_key `au_wms_login_disabled`; el bloqueo real se
	 * aplica en el filtro `authenticate` (ver
	 * AU_Loader::bloquear_login_si_deshabilitado()). Al deshabilitar,
	 * además se cierran de inmediato sus sesiones activas.
	 *
	 * @param int $user_id ID del usuario.
	 * @return array{success:bool,message?:string,deshabilitado?:bool}
	 */
	public static function alternar_acceso_login( $user_id ) {
		$user_id = absint( $user_id );
		$user    = get_userdata( $user_id );

		if ( ! $user ) {
			return array(
				'success' => false,
				'message' => __( 'El usuario no existe.', 'au-wms' ),
			);
		}

		if ( ! AU_Security::puede_gestionar_usuario( $user ) ) {
			return array(
				'success' => false,
				'message' => AU_Security::mensaje_usuario_protegido(),
			);
		}

		if ( (int) $user_id === get_current_user_id() ) {
			return array(
				'success' => false,
				'message' => __( 'No puedes deshabilitar tu propio acceso desde este panel.', 'au-wms' ),
			);
		}

		$actualmente_deshabilitado = metadata_exists( 'user', $user_id, 'au_wms_login_disabled' );

		if ( $actualmente_deshabilitado ) {
			delete_user_meta( $user_id, 'au_wms_login_disabled' );
		} else {
			update_user_meta( $user_id, 'au_wms_login_disabled', true );

			// Cierra cualquier sesión activa de inmediato, para que el
			// bloqueo sea efectivo aunque ya haya iniciado sesión.
			$tokens = WP_Session_Tokens::get_instance( $user_id );
			$tokens->destroy_all();
		}

		return array(
			'success'       => true,
			'deshabilitado' => ! $actualmente_deshabilitado,
		);
	}

	/**
	 * Campos del perfil que edita el modal "Editar perfil de usuario",
	 * con su etiqueta para los mensajes de error.
	 *
	 * Son los mismos del formulario "Mi cuenta" del tema
	 * (woocommerce/myaccount/form-edit-account.php) salvo el correo y la
	 * contraseña, que no se editan desde aquí. `first_name` y
	 * `last_name` van en la tabla de usuarios; el resto, en usermeta —
	 * mismas claves que usa `save_aditional_account_details()`, para que
	 * lo que se guarde aquí se vea igual en el front-end.
	 *
	 * @var array<string,string>
	 */
	const CAMPOS_PERFIL = array(
		'first_name'    => 'El nombre',
		'last_name'     => 'Los apellidos',
		'user_age'      => 'La edad',
		'user_gender'   => 'El género',
		'country'       => 'El país',
		'phone_number'  => 'El número de contacto',
		'user_position' => 'El cargo',
	);

	/**
	 * Valores admitidos del select "Género" (mismos del formulario).
	 *
	 * @var string[]
	 */
	const GENEROS = array( 'Masculino', 'Femenino', 'Otro' );

	/**
	 * Datos del perfil de un usuario, para precargar el modal.
	 *
	 * @param int $user_id ID del usuario.
	 * @return array|null
	 */
	public static function obtener_perfil( $user_id ) {
		$user_id = absint( $user_id );
		$user    = $user_id ? get_userdata( $user_id ) : null;

		if ( ! $user ) {
			return null;
		}

		$perfil = array(
			'id'    => $user_id,
			'email' => $user->user_email,
		);

		foreach ( array_keys( self::CAMPOS_PERFIL ) as $campo ) {
			$perfil[ $campo ] = (string) get_user_meta( $user_id, $campo, true );
		}

		return $perfil;
	}

	/**
	 * Lista de países del select, en el mismo orden que el formulario
	 * del tema.
	 *
	 * Se lee del propio archivo del tema (config/countries.php) en vez
	 * de duplicar la lista: ese archivo advierte que los valores se
	 * guardan tal cual en `wp_usermeta` y se comparan por igualdad, así
	 * que mantener dos copias acabaría desincronizándolas. Se le suman
	 * los valores que ya existan en la base de datos y no estén en la
	 * lista, para que el país actual de un usuario nunca desaparezca del
	 * desplegable al editarlo.
	 *
	 * @return string[]
	 */
	public static function paises_disponibles() {
		global $wpdb;

		$paises = array();
		$ruta   = get_stylesheet_directory() . '/config/countries.php';

		if ( file_exists( $ruta ) ) {
			$desde_tema = require $ruta;
			$paises     = is_array( $desde_tema ) ? $desde_tema : array();
		}

		$guardados = $wpdb->get_col(
			"SELECT DISTINCT meta_value FROM {$wpdb->usermeta}
			  WHERE meta_key = 'country' AND meta_value <> ''"
		);

		foreach ( (array) $guardados as $pais ) {
			if ( ! in_array( $pais, $paises, true ) ) {
				$paises[] = $pais;
			}
		}

		return $paises;
	}

	/**
	 * Guarda el modal "Editar perfil de usuario".
	 *
	 * Solo escribe los campos de CAMPOS_PERFIL: no toca el correo, la
	 * contraseña, el rol, la empresa, las áreas, los programas ni los
	 * cursos. Mantiene las mismas validaciones del formulario del tema
	 * (todos obligatorios) y además comprueba que el género y el país
	 * estén entre los valores admitidos.
	 *
	 * @param int   $user_id ID del usuario.
	 * @param array $datos   Valores ya saneados por el controlador AJAX.
	 * @return array{success:bool,message?:string,perfil?:array}
	 */
	public static function editar_perfil( $user_id, array $datos ) {
		$user_id = absint( $user_id );

		if ( ! $user_id || ! get_userdata( $user_id ) ) {
			return array(
				'success' => false,
				'message' => __( 'El usuario indicado no existe.', 'au-wms' ),
			);
		}

		foreach ( self::CAMPOS_PERFIL as $campo => $etiqueta ) {
			if ( '' === trim( (string) ( $datos[ $campo ] ?? '' ) ) ) {
				return array(
					'success' => false,
					/* translators: %s: field label. */
					'message' => sprintf( __( '%s es un campo requerido.', 'au-wms' ), $etiqueta ),
				);
			}
		}

		if ( ! in_array( $datos['user_gender'], self::GENEROS, true ) ) {
			return array(
				'success' => false,
				'message' => __( 'El género seleccionado no es válido.', 'au-wms' ),
			);
		}

		if ( ! in_array( $datos['country'], self::paises_disponibles(), true ) ) {
			return array(
				'success' => false,
				'message' => __( 'El país seleccionado no es válido.', 'au-wms' ),
			);
		}

		// first_name/last_name por wp_update_user para que WordPress
		// recalcule también display_name si corresponde; el resto son
		// metas sueltas.
		$actualizado = wp_update_user(
			array(
				'ID'         => $user_id,
				'first_name' => $datos['first_name'],
				'last_name'  => $datos['last_name'],
			)
		);

		if ( is_wp_error( $actualizado ) ) {
			return array( 'success' => false, 'message' => $actualizado->get_error_message() );
		}

		foreach ( array( 'user_age', 'user_gender', 'country', 'phone_number', 'user_position' ) as $campo ) {
			update_user_meta( $user_id, $campo, $datos[ $campo ] );
		}

		return array(
			'success' => true,
			'perfil'  => self::obtener_perfil( $user_id ),
		);
	}

	/**
	 * Cambia la contraseña de un usuario y notifica el cambio vía
	 * webhook (correo + nueva contraseña).
	 *
	 * @param int    $user_id       ID del usuario.
	 * @param string $nueva_password Nueva contraseña en texto plano.
	 * @return array{success:bool,message?:string,email?:string,password?:string}
	 */
	public static function cambiar_password( $user_id, $nueva_password ) {
		$user_id = absint( $user_id );
		$user    = get_userdata( $user_id );

		if ( ! $user ) {
			return array(
				'success' => false,
				'message' => __( 'El usuario no existe.', 'au-wms' ),
			);
		}

		if ( ! AU_Security::puede_gestionar_usuario( $user ) ) {
			return array(
				'success' => false,
				'message' => AU_Security::mensaje_usuario_protegido(),
			);
		}

		$nueva_password = (string) $nueva_password;

		if ( '' === trim( $nueva_password ) ) {
			return array(
				'success' => false,
				'message' => __( 'La contraseña no puede estar vacía.', 'au-wms' ),
			);
		}

		// wp_set_password() actualiza el hash de la contraseña; WordPress
		// invalida automáticamente las sesiones activas del usuario al
		// cambiar su contraseña (no requiere pasos adicionales).
		wp_set_password( $nueva_password, $user_id );

		AU_Webhook_Service::notificar_cambio_password( $user->user_email, $nueva_password );

		return array(
			'success'  => true,
			'email'    => $user->user_email,
			'password' => $nueva_password,
		);
	}

	/**
	 * Cambia el correo de un usuario, actualizando tanto `wp_users`
	 * como todas las filas de `wp_correos_configurados` que tenían el
	 * correo anterior (esa tabla usa el correo como llave de relación,
	 * no el `user_id`).
	 *
	 * @param int    $user_id      ID del usuario.
	 * @param string $nuevo_correo Nuevo correo a asignar.
	 * @return array{success:bool,message?:string,correo?:string}
	 */
	public static function cambiar_correo( $user_id, $nuevo_correo ) {
		$user_id      = absint( $user_id );
		$nuevo_correo = sanitize_email( $nuevo_correo );
		$user         = get_userdata( $user_id );

		if ( ! $user ) {
			return array(
				'success' => false,
				'message' => __( 'El usuario no existe.', 'au-wms' ),
			);
		}

		if ( ! AU_Security::puede_gestionar_usuario( $user ) ) {
			return array(
				'success' => false,
				'message' => AU_Security::mensaje_usuario_protegido(),
			);
		}

		if ( ! is_email( $nuevo_correo ) ) {
			return array(
				'success' => false,
				'message' => __( 'El correo ingresado no tiene un formato válido.', 'au-wms' ),
			);
		}

		$correo_actual = $user->user_email;

		if ( strtolower( $nuevo_correo ) === strtolower( $correo_actual ) ) {
			return array(
				'success' => false,
				'message' => __( 'Ese ya es el correo actual del usuario.', 'au-wms' ),
			);
		}

		$usuario_existente = email_exists( $nuevo_correo );
		if ( $usuario_existente && (int) $usuario_existente !== $user_id ) {
			return array(
				'success' => false,
				'message' => __( 'Ese correo ya está en uso por otro usuario.', 'au-wms' ),
			);
		}

		global $wpdb;
		$correos_table = $wpdb->prefix . 'correos_configurados';

		$wpdb->query( 'START TRANSACTION' );

		try {
			$resultado = wp_update_user(
				array(
					'ID'         => $user_id,
					'user_email' => $nuevo_correo,
				)
			);

			if ( is_wp_error( $resultado ) ) {
				throw new Exception( $resultado->get_error_message() );
			}

			// wp_correos_configurados usa el correo (no el user_id) como
			// llave de relación, así que hay que actualizar ahí también
			// todas las filas que tenía con el correo anterior.
			$actualizado = @$wpdb->update(
				$correos_table,
				array( 'email' => $nuevo_correo ),
				array( 'email' => $correo_actual ),
				array( '%s' ),
				array( '%s' )
			);

			if ( false === $actualizado && ! empty( $wpdb->last_error ) && false === strpos( (string) $wpdb->last_error, 'Duplicate entry' ) ) {
				throw new Exception( __( 'No fue posible actualizar el correo en wp_correos_configurados.', 'au-wms' ) );
			}

			$wpdb->query( 'COMMIT' );
		} catch ( Exception $e ) {
			$wpdb->query( 'ROLLBACK' );
			error_log( '[AU-WMS] Error al cambiar el correo del usuario #' . $user_id . ': ' . $e->getMessage() );

			return array(
				'success' => false,
				'message' => __( 'Ocurrió un error al cambiar el correo. No se realizaron cambios.', 'au-wms' ),
			);
		}

		return array(
			'success' => true,
			'correo'  => $nuevo_correo,
		);
	}

	/**
	 * Inicia sesión como el usuario indicado (impersonación), cerrando
	 * primero la sesión del administrador actual.
	 *
	 * Antes de cambiar de sesión guarda una cookie (ver
	 * `AU_Impersonation_Service`) que permite al administrador volver
	 * a su propia cuenta más adelante desde un enlace en la barra de
	 * administración o en una franja al pie de página.
	 *
	 * Requiere que el llamador ya haya validado capacidad y nonce
	 * (ver AU_Security::guard()).
	 *
	 * @param int $target_user_id ID del usuario a impersonar.
	 * @return array{success:bool,message:string,redirect?:string}
	 */
	public static function iniciar_sesion_como( $target_user_id ) {
		$target_user_id = absint( $target_user_id );

		if ( ! $target_user_id ) {
			return array(
				'success' => false,
				'message' => __( 'ID de usuario inválido.', 'au-wms' ),
			);
		}

		$target_user = get_userdata( $target_user_id );

		if ( ! $target_user ) {
			return array(
				'success' => false,
				'message' => __( 'El usuario no existe.', 'au-wms' ),
			);
		}

		if ( ! AU_Security::puede_gestionar_usuario( $target_user ) ) {
			return array(
				'success' => false,
				'message' => AU_Security::mensaje_usuario_protegido(),
			);
		}

		if ( (int) $target_user_id === get_current_user_id() ) {
			return array(
				'success' => false,
				'message' => __( 'Ya has iniciado sesión como este usuario.', 'au-wms' ),
			);
		}

		// Se guarda ANTES de cambiar de sesión (todavía como
		// administrador) la cookie que permite volver a esta cuenta
		// más adelante — ver AU_Impersonation_Service.
		$admin_id_actual = get_current_user_id();
		AU_Impersonation_Service::guardar_retorno( $admin_id_actual, $target_user_id );

		// Cerrar la sesión actual del administrador.
		wp_clear_auth_cookie();
		wp_destroy_current_session();

		// Establecer el nuevo usuario actual y regenerar las cookies de auth.
		wp_set_current_user( $target_user_id );
		wp_set_auth_cookie( $target_user_id, false );

		/**
		 * Permite a otros plugins reaccionar a la impersonación
		 * (por ejemplo, para registrar auditoría).
		 */
		do_action( 'au_wms_user_impersonated', $target_user_id );

		return array(
			'success'  => true,
			'message'  => __( 'Sesión iniciada correctamente como el usuario seleccionado.', 'au-wms' ),
			'redirect' => home_url( '/' ),
		);
	}
}
