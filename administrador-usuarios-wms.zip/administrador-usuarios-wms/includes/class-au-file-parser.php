<?php
/**
 * Parser de archivos CSV/XLSX sin dependencias externas (sin Composer).
 *
 * XLSX es en realidad un .zip con XML dentro, así que se lee con
 * ZipArchive + SimpleXML (misma idea usada en el parser XLSX que ya
 * existe en "Eventin Attendees Manager").
 *
 * NOTA: el formato binario legado .xls (OLE2, pre-2007) NO se soporta
 * de forma nativa aquí — escribir un parser binario completo y correcto
 * está fuera del alcance razonable sin una librería como PhpSpreadsheet.
 * Si se sube un .xls se informa al usuario que lo convierta a .csv o
 * .xlsx (ambos formatos sí quedan 100% soportados).
 *
 * @package Administrador_Usuarios_WMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AU_File_Parser {

	/**
	 * Parsea un archivo subido según su extensión.
	 *
	 * @param string $filepath Ruta absoluta al archivo.
	 * @param string $ext      Extensión en minúsculas (csv|xls|xlsx).
	 * @return array{headers:array<int,string>,rows:array<int,array<int,string>>}
	 * @throws Exception Si el formato no es soportado o el archivo es inválido.
	 */
	public static function parse( $filepath, $ext ) {
		switch ( $ext ) {
			case 'csv':
				return self::parse_csv( $filepath );
			case 'xlsx':
				return self::parse_xlsx( $filepath );
			case 'xls':
				throw new Exception(
					__( 'El formato .xls (Excel 97-2003) no está soportado. Por favor guarda el archivo como .xlsx o .csv e inténtalo de nuevo.', 'au-wms' )
				);
			default:
				throw new Exception( __( 'Formato de archivo no soportado.', 'au-wms' ) );
		}
	}

	/**
	 * Parsea un archivo CSV, detectando el delimitador (coma o punto y
	 * coma) y normalizando la codificación a UTF-8.
	 *
	 * @param string $filepath Ruta absoluta al archivo.
	 * @return array{headers:array,rows:array}
	 * @throws Exception Si el archivo no puede abrirse o está vacío.
	 */
	private static function parse_csv( $filepath ) {
		$handle = fopen( $filepath, 'r' );

		if ( false === $handle ) {
			throw new Exception( __( 'No fue posible leer el archivo CSV.', 'au-wms' ) );
		}

		$primera_linea = fgets( $handle );
		if ( false === $primera_linea ) {
			fclose( $handle );
			throw new Exception( __( 'El archivo CSV está vacío.', 'au-wms' ) );
		}

		// Quitar BOM UTF-8 si existe.
		$primera_linea = preg_replace( '/^\xEF\xBB\xBF/', '', $primera_linea );

		$delimitador = ( substr_count( $primera_linea, ';' ) > substr_count( $primera_linea, ',' ) ) ? ';' : ',';

		rewind( $handle );
		// Volver a saltar el BOM tras el rewind.
		fgets( $handle, 4 );
		rewind( $handle );

		$headers = fgetcsv( $handle, 0, $delimitador );
		if ( ! $headers ) {
			fclose( $handle );
			throw new Exception( __( 'No fue posible leer los encabezados del archivo.', 'au-wms' ) );
		}
		$headers[0] = preg_replace( '/^\xEF\xBB\xBF/', '', $headers[0] );
		$headers    = array_map( array( __CLASS__, 'normalizar_valor' ), $headers );

		$rows = array();
		while ( false !== ( $line = fgetcsv( $handle, 0, $delimitador ) ) ) {
			if ( 1 === count( $line ) && null === $line[0] ) {
				continue; // Línea vacía.
			}
			$rows[] = array_map( array( __CLASS__, 'normalizar_valor' ), $line );
		}

		fclose( $handle );

		return array(
			'headers' => $headers,
			'rows'    => $rows,
		);
	}

	/**
	 * Parsea un archivo XLSX leyendo directamente el XML interno del
	 * paquete OOXML (primera hoja del libro).
	 *
	 * @param string $filepath Ruta absoluta al archivo.
	 * @return array{headers:array,rows:array}
	 * @throws Exception Si el archivo no es un XLSX válido.
	 */
	private static function parse_xlsx( $filepath ) {
		if ( ! class_exists( 'ZipArchive' ) ) {
			throw new Exception( __( 'El servidor no tiene la extensión ZipArchive de PHP necesaria para leer archivos XLSX.', 'au-wms' ) );
		}

		$zip = new ZipArchive();
		if ( true !== $zip->open( $filepath ) ) {
			throw new Exception( __( 'El archivo XLSX está dañado o no es válido.', 'au-wms' ) );
		}

		// 1. Cadenas compartidas (shared strings).
		$shared_strings = array();
		$shared_xml     = $zip->getFromName( 'xl/sharedStrings.xml' );
		if ( false !== $shared_xml ) {
			$shared_strings = self::leer_shared_strings( $shared_xml );
		}

		// 2. Determinar la ruta de la primera hoja (usualmente sheet1.xml).
		$sheet_path = 'xl/worksheets/sheet1.xml';
		if ( false === $zip->getFromName( $sheet_path ) ) {
			// Buscar cualquier hoja disponible como respaldo.
			for ( $i = 0; $i < $zip->numFiles; $i++ ) {
				$name = $zip->getNameIndex( $i );
				if ( preg_match( '#^xl/worksheets/sheet\d+\.xml$#', $name ) ) {
					$sheet_path = $name;
					break;
				}
			}
		}

		$sheet_xml = $zip->getFromName( $sheet_path );
		$zip->close();

		if ( false === $sheet_xml ) {
			throw new Exception( __( 'No fue posible encontrar una hoja de cálculo dentro del archivo XLSX.', 'au-wms' ) );
		}

		$filas = self::leer_filas_xlsx( $sheet_xml, $shared_strings );

		if ( empty( $filas ) ) {
			throw new Exception( __( 'El archivo XLSX está vacío.', 'au-wms' ) );
		}

		$headers = array_map( array( __CLASS__, 'normalizar_valor' ), array_shift( $filas ) );
		$rows    = array();
		foreach ( $filas as $fila ) {
			$rows[] = array_map( array( __CLASS__, 'normalizar_valor' ), $fila );
		}

		return array(
			'headers' => $headers,
			'rows'    => $rows,
		);
	}

	/**
	 * Extrae las cadenas compartidas del XML `sharedStrings.xml`.
	 *
	 * @param string $xml Contenido XML crudo.
	 * @return array<int,string>
	 */
	private static function leer_shared_strings( $xml ) {
		$strings = array();

		$sxml = simplexml_load_string( $xml, 'SimpleXMLElement', LIBXML_NOCDATA );
		if ( false === $sxml ) {
			return $strings;
		}

		foreach ( $sxml->si as $si ) {
			if ( isset( $si->t ) ) {
				$strings[] = (string) $si->t;
				continue;
			}

			// Texto con formato enriquecido (runs <r><t>...</t></r>).
			$texto = '';
			if ( isset( $si->r ) ) {
				foreach ( $si->r as $run ) {
					$texto .= (string) $run->t;
				}
			}
			$strings[] = $texto;
		}

		return $strings;
	}

	/**
	 * Extrae las filas/celdas del XML de una hoja (`sheetN.xml`).
	 *
	 * @param string $xml            Contenido XML crudo de la hoja.
	 * @param array  $shared_strings Cadenas compartidas ya extraídas.
	 * @return array<int,array<int,string>>
	 */
	private static function leer_filas_xlsx( $xml, array $shared_strings ) {
		$sxml = simplexml_load_string( $xml, 'SimpleXMLElement', LIBXML_NOCDATA );
		if ( false === $sxml || ! isset( $sxml->sheetData->row ) ) {
			return array();
		}

		$filas = array();

		foreach ( $sxml->sheetData->row as $row ) {
			$celdas_fila  = array();
			$ultima_col   = -1;

			foreach ( $row->c as $celda ) {
				$ref     = (string) $celda['r'];
				$col_idx = self::columna_a_indice( $ref );

				// Rellenar columnas vacías intermedias para mantener el
				// alineamiento posicional entre encabezados y valores.
				while ( $ultima_col < $col_idx - 1 ) {
					++$ultima_col;
					$celdas_fila[ $ultima_col ] = '';
				}

				$tipo  = (string) $celda['t'];
				$valor = '';

				if ( 's' === $tipo ) {
					$indice = (int) $celda->v;
					$valor  = isset( $shared_strings[ $indice ] ) ? $shared_strings[ $indice ] : '';
				} elseif ( 'inlineStr' === $tipo ) {
					$valor = isset( $celda->is->t ) ? (string) $celda->is->t : '';
				} elseif ( isset( $celda->v ) ) {
					$valor = (string) $celda->v;
				}

				$celdas_fila[ $col_idx ] = $valor;
				$ultima_col              = $col_idx;
			}

			ksort( $celdas_fila );
			$filas[] = array_values( $celdas_fila );
		}

		return $filas;
	}

	/**
	 * Convierte una referencia de celda tipo "C5" al índice de columna
	 * base 0 (A=0, B=1, C=2...).
	 *
	 * @param string $ref Referencia de celda (ej. "C5").
	 * @return int
	 */
	private static function columna_a_indice( $ref ) {
		preg_match( '/^([A-Z]+)/', $ref, $match );
		$letras = isset( $match[1] ) ? $match[1] : 'A';

		$indice = 0;
		for ( $i = 0; $i < strlen( $letras ); $i++ ) {
			$indice = $indice * 26 + ( ord( $letras[ $i ] ) - 64 );
		}

		return max( 0, $indice - 1 );
	}

	/**
	 * Limpia un valor de celda: recorta espacios y normaliza a UTF-8.
	 *
	 * @param mixed $valor Valor crudo.
	 * @return string
	 */
	private static function normalizar_valor( $valor ) {
		$valor = null === $valor ? '' : (string) $valor;
		$valor = trim( $valor );

		if ( ! mb_check_encoding( $valor, 'UTF-8' ) ) {
			$valor = mb_convert_encoding( $valor, 'UTF-8', 'ISO-8859-1' );
		}

		return $valor;
	}
}
