<?php
/**
 * Servicio de "Resetear contraseñas" (Tab Empresas): genera una
 * contraseña nueva y aleatoria para cada usuario seleccionado de una
 * empresa, usando `wp_set_password()` (WordPress se encarga del
 * hashing; en ningún momento se guarda la contraseña en texto plano
 * en la base de datos).
 *
 * @package Administrador_Usuarios_WMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AU_Reset_Password_Service {

	/**
	 * Lista los usuarios de una empresa que cumplen los filtros de
	 * área/perfil, para el Paso 1 del modal.
	 *
	 * @param int    $empresa_id    ID de la empresa.
	 * @param array  $paquete_ids   IDs de área/paquete a incluir.
	 * @param string $perfil_filtro '', 'completo' o 'incompleto'.
	 * @return array
	 */
	public static function listar_usuarios( $empresa_id, array $paquete_ids, $perfil_filtro ) {
		return AU_Repository_Usuarios::buscar_para_reset_password( $empresa_id, $paquete_ids, $perfil_filtro );
	}

	/**
	 * Ejecuta el reseteo de contraseña para los usuarios indicados.
	 *
	 * Antes de tocar nada, revalida en el servidor que cada usuario
	 * pertenece realmente a la empresa indicada (nunca se confía en la
	 * selección tal como llega del navegador). Cada contraseña se
	 * genera con `AU_Password_Generator` (8 caracteres, criptográfica
	 * vía `wp_rand()`, sin ambigüedades) y se garantiza que no se
	 * repita entre los usuarios de esta misma corrida.
	 *
	 * @param int   $empresa_id ID de la empresa.
	 * @param array $user_ids   IDs de usuario seleccionados en el navegador.
	 * @return array{seleccionados:int,actualizados:int,errores:int,resultados:array}
	 */
	public static function ejecutar( $empresa_id, array $user_ids ) {
		$empresa_id = absint( $empresa_id );
		$user_ids   = array_values( array_unique( array_filter( array_map( 'absint', $user_ids ) ) ) );

		$validos = AU_Repository_Usuarios::filtrar_ids_pertenecientes_a_empresa( $empresa_id, $user_ids );

		$resultados   = array();
		$actualizados = 0;
		$errores      = 0;

		/**
		 * Contraseñas ya asignadas en ESTA corrida (para no repetir
		 * ninguna entre los usuarios seleccionados).
		 *
		 * @var array<string,bool> $passwords_usadas
		 */
		$passwords_usadas = array();

		foreach ( $user_ids as $user_id ) {
			$usuario = get_userdata( $user_id );

			if ( ! $usuario || ! in_array( $user_id, $validos, true ) ) {
				$resultados[] = array(
					'id'     => $user_id,
					'email'  => $usuario ? $usuario->user_email : '',
					'status' => 'error',
					'motivo' => __( 'El usuario no pertenece a esta empresa o ya no existe.', 'au-wms' ),
				);
				++$errores;
				continue;
			}

			try {
				$password = self::generar_password_no_repetida( $passwords_usadas );

				wp_set_password( $password, $user_id );

				$passwords_usadas[ $password ] = true;

				$resultados[] = array(
					'id'       => $user_id,
					'email'    => $usuario->user_email,
					'password' => $password,
					'status'   => 'ok',
				);
				++$actualizados;
			} catch ( Exception $e ) {
				$resultados[] = array(
					'id'     => $user_id,
					'email'  => $usuario->user_email,
					'status' => 'error',
					'motivo' => __( 'No fue posible actualizar la contraseña de este usuario.', 'au-wms' ),
				);
				++$errores;
			}
		}

		return array(
			'seleccionados' => count( $user_ids ),
			'actualizados'  => $actualizados,
			'errores'       => $errores,
			'resultados'    => $resultados,
		);
	}

	/**
	 * Genera una contraseña con `AU_Password_Generator` que no esté ya
	 * en `$usadas` (contraseñas asignadas en esta misma corrida). La
	 * probabilidad de colisión es extremadamente baja (miles de
	 * combinaciones posibles de 8 caracteres), pero se verifica de
	 * todas formas para cumplir la regla de "no reutilizar contraseñas
	 * entre los usuarios del mismo proceso".
	 *
	 * @param array<string,bool> $usadas Contraseñas ya asignadas en esta corrida (por referencia).
	 * @return string
	 */
	private static function generar_password_no_repetida( array &$usadas ) {
		for ( $intento = 0; $intento < 15; $intento++ ) {
			$password = AU_Password_Generator::generar();

			if ( ! isset( $usadas[ $password ] ) ) {
				return $password;
			}
		}

		// Salvaguarda teórica: si 15 intentos no bastaron (no debería
		// ocurrir), se fuerza unicidad agregando un carácter extra.
		do {
			$password = AU_Password_Generator::generar() . (string) wp_rand( 2, 9 );
		} while ( isset( $usadas[ $password ] ) );

		return $password;
	}
}
