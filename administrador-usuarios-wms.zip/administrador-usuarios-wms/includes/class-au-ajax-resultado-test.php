<?php
/**
 * Controlador AJAX de "Descargar resultado" (columna Test del Tab Integrantes).
 *
 * Genera el mismo PDF que el botón "Descargar resultado" de
 * /resultado-test-trabajador/ (región 10 de astra-child/assets/js/scripts-ids.js)
 * y lo devuelve como archivo, para descargarlo sin salir del listado.
 *
 * @package Administrador_Usuarios_WMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AU_Ajax_Resultado_Test {

	/**
	 * Instancia única (singleton).
	 *
	 * @var AU_Ajax_Resultado_Test|null
	 */
	private static $instance = null;

	/**
	 * Devuelve la instancia única y engancha las acciones AJAX.
	 *
	 * @return AU_Ajax_Resultado_Test
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
			add_action( 'wp_ajax_au_wms_descargar_resultado_test', array( self::$instance, 'handle_descargar' ) );
		}

		return self::$instance;
	}

	/**
	 * Genera el PDF del test del usuario indicado y lo envía como descarga.
	 *
	 * @return void
	 */
	public function handle_descargar() {
		AU_Security::guard();

		$user_id = isset( $_POST['user_id'] ) ? AU_Security::sanitize_int( $_POST['user_id'] ) : 0;

		if ( ! $user_id || ! get_userdata( $user_id ) ) {
			wp_send_json_error( array( 'message' => __( 'Usuario inválido.', 'au-wms' ) ) );
		}

		// Las respuestas se leen del propio usuario solicitado: nunca se
		// acepta el contenido del test desde el cliente.
		$answers = get_user_meta( $user_id, 'question_test_ids', true );
		if ( ! $answers ) {
			wp_send_json_error( array( 'message' => __( 'Este integrante aún no ha realizado el test.', 'au-wms' ) ) );
		}

		if ( ! function_exists( 'proccessResultUserTestWMS' ) || ! function_exists( 'get_test_reglas' ) ) {
			wp_send_json_error( array( 'message' => __( 'No está disponible el cálculo de resultados del tema.', 'au-wms' ) ) );
		}

		$results = json_decode( stripslashes( $answers ), true );
		if ( ! is_array( $results ) ) {
			wp_send_json_error( array( 'message' => __( 'Las respuestas del test de este integrante no son válidas.', 'au-wms' ) ) );
		}

		$nombre  = trim( get_user_meta( $user_id, 'first_name', true ) . ' ' . get_user_meta( $user_id, 'last_name', true ) );
		$payload = self::build_payload( $nombre, proccessResultUserTestWMS( $results ) );

		$response = wp_remote_post(
			self::pdf_service_url(),
			array(
				'timeout' => 90,
				'headers' => array( 'Content-Type' => 'application/json' ),
				'body'    => wp_json_encode( $payload ),
			)
		);

		$body    = is_wp_error( $response ) ? null : json_decode( wp_remote_retrieve_body( $response ), true );
		$pdf_url = isset( $body['pdfUrl'] ) ? esc_url_raw( $body['pdfUrl'] ) : '';

		if ( ! $pdf_url ) {
			wp_send_json_error( array( 'message' => __( 'Ocurrió un error al generar el PDF.', 'au-wms' ) ) );
		}

		$pdf = wp_remote_get( $pdf_url, array( 'timeout' => 60 ) );

		if ( is_wp_error( $pdf ) || 200 !== wp_remote_retrieve_response_code( $pdf ) ) {
			wp_send_json_error( array( 'message' => __( 'No fue posible descargar el PDF generado.', 'au-wms' ) ) );
		}

		// Mismo nombre de archivo que el botón original.
		$file_name = preg_replace( '/[\\\\\/:*?"<>|]+/', '-', $nombre ? $nombre : 'informe' ) . '.pdf';

		nocache_headers();
		header( 'Content-Type: application/pdf' );
		header( "Content-Disposition: attachment; filename*=UTF-8''" . rawurlencode( $file_name ) );
		echo wp_remote_retrieve_body( $pdf ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		exit;
	}

	/**
	 * URL del microservicio de PDF configurada en "Configuración", con la
	 * de fábrica como respaldo: así el botón sigue funcionando aunque el
	 * campo se guarde vacío.
	 *
	 * @return string
	 */
	private static function pdf_service_url() {
		$url = trim( (string) AU_Settings::get( 'pdf_resultado_test_url', '' ) );

		return '' !== $url ? $url : AU_Settings::DEFAULT_PDF_RESULTADO_TEST_URL;
	}

	/**
	 * Arma el cuerpo que espera el microservicio de PDF para un informe
	 * individual. Debe mantenerse en sincronía con el click de
	 * `#pdf-test-trabajador` y con las constantes DIVISORES,
	 * DIVISORES_GENERAL, ETIQUETAS_GRAFICA y DEFINICIONES_ITEMS de scripts-ids.js.
	 *
	 * @param string $nombre    Nombre completo del integrante.
	 * @param array  $procesado Salida de proccessResultUserTestWMS().
	 * @return array
	 */
	private static function build_payload( $nombre, $procesado ) {
		$divisores = array(
			'insuficiencia'     => 3,
			'rechazo'           => 5,
			'desamor'           => 4,
			'desprecio'         => 5,
			'ineficiencia'      => 4,
			'exposicion_social' => 6,
			'traicion'          => 5,
			'desaprobacion'     => 8,
			'descalificacion'   => 7,
			'coercion'          => 4,
			'subestimacion'     => 3,
			'indiferencia'      => 3,
			'obsesividad'       => 2,
			'narcisismo'        => 2,
			'dependencia'       => 2,
			'evitacion'         => 3,
			'histrionismo'      => 3,
			'paranoia'          => 4,
			'antisocialidad'    => 2,
		);

		$categorias = array(
			'vulnerabilidades' => array( 'insuficiencia', 'rechazo', 'desamor', 'desprecio' ),
			'amenazas'         => array( 'ineficiencia', 'exposicion_social', 'traicion', 'desaprobacion', 'descalificacion', 'coercion', 'subestimacion', 'indiferencia' ),
			'estrategias2'     => array( 'obsesividad', 'narcisismo', 'dependencia', 'evitacion', 'histrionismo', 'paranoia', 'antisocialidad' ),
		);

		$definiciones = array(
			'insuficiencia'     => array( 'labels' => array( 'A', 'B', 'C', '', '' ), 'preguntas' => array( 40, 41, 42 ) ),
			'rechazo'           => array( 'labels' => array( 'A', 'B', 'C', 'D', 'E' ), 'preguntas' => array( 43, 44, 45, 46, 47 ) ),
			'desamor'           => array( 'labels' => array( 'A', 'B', 'C', 'D', '' ), 'preguntas' => array( 48, 49, 50, 51 ) ),
			'desprecio'         => array( 'labels' => array( 'A', 'B', 'C', 'D', 'E' ), 'preguntas' => array( 52, 53, 54, 55, 56 ) ),
			'ineficiencia'      => array( 'labels' => array( 'A', 'B', 'C', 'D', '' ), 'preguntas' => array( 0, 1, 4, 5 ) ),
			'exposicion_social' => array( 'labels' => array( 'A', 'B', 'C', 'D', 'E', '' ), 'preguntas' => array( 10, 17, 19, 20, 37 ) ),
			'traicion'          => array( 'labels' => array( 'A', 'B', 'C', 'D', 'E' ), 'preguntas' => array( 34, 35, 36, 38, 39 ) ),
			'desaprobacion'     => array( 'labels' => array( 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H' ), 'preguntas' => array( 2, 3, 6, 7, 8, 9, 16, 18 ) ),
			'descalificacion'   => array( 'labels' => array( 'A', 'B', 'C', 'D', 'E', 'F', 'G' ), 'preguntas' => array( 13, 14, 15, 25, 26, 27, 29 ) ),
			'coercion'          => array( 'labels' => array( 'A', 'B', 'C', 'D', '' ), 'preguntas' => array( 30, 31, 32, 33 ) ),
			'subestimacion'     => array( 'labels' => array( 'A', 'B', 'C', '', '' ), 'preguntas' => array( 22, 24, 28 ) ),
			'indiferencia'      => array( 'labels' => array( 'A', 'B', 'C', '', '' ), 'preguntas' => array( 11, 12, 23 ) ),
			'obsesividad'       => array( 'labels' => array( 'A', 'B', '', ' ', '' ), 'preguntas' => array( 57, 58 ) ),
			'narcisismo'        => array( 'labels' => array( 'A', 'B', '', ' ', '' ), 'preguntas' => array( 59, 60 ) ),
			'dependencia'       => array( 'labels' => array( 'A', 'B', '', ' ', '' ), 'preguntas' => array( 61, 62 ) ),
			'evitacion'         => array( 'labels' => array( 'A', 'B', 'C', ' ', '' ), 'preguntas' => array( 63, 64, 65 ) ),
			'histrionismo'      => array( 'labels' => array( 'A', 'B', 'C', ' ', '' ), 'preguntas' => array( 66, 67, 68 ) ),
			'paranoia'          => array( 'labels' => array( 'A', 'B', 'C', 'D', '' ), 'preguntas' => array( 69, 70, 71, 72 ) ),
			'antisocialidad'    => array( 'labels' => array( 'A', 'B', '', ' ', '' ), 'preguntas' => array( 73, 74 ) ),
		);

		$rt      = $procesado['results_type'];
		$general = $procesado['results_general'];
		$results = $procesado['results'];

		$normalizar = function ( $items ) use ( $rt, $divisores ) {
			return array_map(
				function ( $item ) use ( $rt, $divisores ) {
					return $rt[ $item ] / $divisores[ $item ];
				},
				$items
			);
		};

		$data = array(
			'name'             => $nombre,
			'general'          => array(
				'labels' => array( 'Áreas profundas de mejora', 'Amenazas', 'Estrategias', '', '' ),
				'values' => array(
					$general['vulnerabilidad_total'] / 4,
					$general['amenazas_total'] / 8,
					$general['estrategias_dos_total'] / 7,
					0,
					0,
				),
			),
			'vulnerabilidades' => array(
				'labels' => array( 'Insuficiencia', 'Rechazo', 'Desamor', 'Desprecio', '' ),
				'values' => array_merge( $normalizar( $categorias['vulnerabilidades'] ), array( 0 ) ),
			),
			'amenazas'         => array(
				'labels' => array( 'Ineficiencia', 'Exposición social', 'Traición', 'Desaprobación', 'Descalificación', 'Coerción', 'Subestimación', 'Indiferencia' ),
				'values' => $normalizar( $categorias['amenazas'] ),
			),
			'estrategias2'     => array(
				'labels' => array( 'Obsesividad', 'Narcisismo', 'Dependencia', 'Evitacion', 'Histrionismo', 'Paranoia', 'Antisocialidad' ),
				'values' => $normalizar( $categorias['estrategias2'] ),
			),
		);

		$reglas = get_test_reglas();

		foreach ( array_merge( $categorias['vulnerabilidades'], $categorias['amenazas'], $categorias['estrategias2'] ) as $key ) {
			$valor = $rt[ $key ];
			$regla = $reglas[ $key ];

			if ( $valor >= $regla['umbralAlto'] ) {
				$tipo = 'HIGH';
			} elseif ( $valor >= $regla['umbralMedio'] ) {
				$tipo = 'MEDIUM';
			} else {
				continue;
			}

			$def    = $definiciones[ $key ];
			$values = array();
			foreach ( $def['preguntas'] as $q ) {
				// Igual que getAnswer() en JS, donde el string "0" es truthy.
				$answer   = isset( $results[ $q ]['answer'] ) ? $results[ $q ]['answer'] : 0;
				$values[] = ( '0' === $answer || $answer ) ? $answer : 0;
			}
			// El microservicio exige que values y labels tengan la misma longitud.
			$values = array_pad( $values, count( $def['labels'] ), 0 );

			$data[ $key ] = array(
				'type'   => $tipo,
				'labels' => $def['labels'],
				'values' => $values,
			);
		}

		return $data;
	}
}
