<?php
/**
 * Acceso a datos: licencias (`wp_licencias`).
 *
 * Misma tabla y mismos campos que gestiona el tema (astra-child) en
 * `/wp-admin/admin.php?page=licenses` y `licenses-add`; este repositorio
 * replica esa lógica (listar, crear y editar) para exponerla dentro del
 * panel "Usuarios WMS" sin depender del tema.
 *
 * @package Administrador_Usuarios_WMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AU_Repository_Licencias {

	/**
	 * Campos "incluir_*" de `wp_licencias` mapeados a la etiqueta que se
	 * muestra en la columna "Accesos" — mismo texto y mismo orden que
	 * `astra-child/includes/companies/licenses.php`, para que una
	 * licencia se vea igual en ambas pantallas.
	 *
	 * @var array<string,string>
	 */
	const CAMPOS_ACCESO = array(
		'incluir_resultado_individual'  => 'Evaluación perfil personal',
		'incluir_resultado_grupal'      => 'Evaluación áreas empresariales',
		'incluir_resultado_global'      => 'Evaluación perfil empresarial',
		'incluir_cursos_individuales'   => 'Programa de fortalecimiento personal',
		'incluir_cursos_grupales'       => 'Programa cultural para líderes',
		'incluir_test_alineacion'       => 'Evaluación ajuste inter-áreas',
		'incluir_conferencia_induccion' => 'Conferencia de inducción',
		'incluir_acceso_adpropositum'   => 'Acceso a AdPropositum',
		'incluir_cruces'                => 'Evaluación ajuste perfiles personales/empresa/área',
	);

	/**
	 * Etiquetas de los interruptores del formulario "Crear Licencia" —
	 * mismo texto y mismo orden que
	 * `astra-child/includes/companies/licenses-add.php`.
	 *
	 * @var array<string,string>
	 */
	const CAMPOS_FORMULARIO = array(
		'incluir_resultado_individual'  => '¿Incluir resultados individuales?',
		'incluir_resultado_grupal'      => '¿Incluir resultados grupales?',
		'incluir_resultado_global'      => '¿Incluir el resultado global?',
		'incluir_cursos_individuales'   => '¿Incluir cursos individuales?',
		'incluir_cursos_grupales'       => '¿Incluir cursos grupales?',
		'incluir_test_alineacion'       => '¿Incluir test de alineación?',
		'incluir_conferencia_induccion' => '¿Incluir conferencia de inducción?',
		'incluir_acceso_adpropositum'   => '¿Incluir acceso a AdPropositum?',
		'incluir_cruces'                => '¿Incluir cruces de información?',
	);

	/**
	 * Lista/busca licencias por nombre, paginado (mismo criterio de
	 * búsqueda que el listado original del tema).
	 *
	 * @param array $args {
	 *     @type string $search   Texto de búsqueda (nombre de la licencia).
	 *     @type int    $page     Página actual (1-indexed).
	 *     @type int    $per_page Registros por página.
	 * }
	 * @return array {items:array, total:int}
	 */
	public static function listar( $args = array() ) {
		global $wpdb;

		$search   = isset( $args['search'] ) ? (string) $args['search'] : '';
		$page     = isset( $args['page'] ) ? max( 1, (int) $args['page'] ) : 1;
		$per_page = isset( $args['per_page'] ) ? max( 1, (int) $args['per_page'] ) : 10;
		$offset   = ( $page - 1 ) * $per_page;

		$table = $wpdb->prefix . 'licencias';

		if ( '' !== $search ) {
			$like  = '%' . $wpdb->esc_like( $search ) . '%';
			$total = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE nombre LIKE %s", $like ) );
			$rows  = $wpdb->get_results(
				$wpdb->prepare( "SELECT * FROM {$table} WHERE nombre LIKE %s ORDER BY id ASC LIMIT %d OFFSET %d", $like, $per_page, $offset )
			);
		} else {
			$total = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table}" );
			$rows  = $wpdb->get_results(
				$wpdb->prepare( "SELECT * FROM {$table} ORDER BY id ASC LIMIT %d OFFSET %d", $per_page, $offset )
			);
		}

		$items = array();

		foreach ( (array) $rows as $row ) {
			$accesos = array();

			foreach ( self::CAMPOS_ACCESO as $campo => $etiqueta ) {
				if ( ! empty( $row->$campo ) ) {
					$accesos[] = $etiqueta;
				}
			}

			$items[] = array(
				'id'       => (int) $row->id,
				'nombre'   => $row->nombre,
				'duracion' => (int) $row->duracion,
				'accesos'  => $accesos,
			);
		}

		return array(
			'items' => $items,
			'total' => $total,
		);
	}

	/**
	 * Devuelve TODAS las licencias (sin paginar ni filtrar) con el valor
	 * real de cada uno de los 9 atributos "incluir_*" — para la "Descargar
	 * matriz comparativa" del dropdown "Acciones": a diferencia de
	 * `listar()`, que solo entrega las etiquetas de los atributos
	 * activos de la página actual, aquí se necesita el estado (SI/NO) de
	 * cada atributo, de cada licencia, sin importar la búsqueda o página
	 * en la que esté el modal en ese momento.
	 *
	 * @return array
	 */
	public static function listar_todas() {
		global $wpdb;

		$table = $wpdb->prefix . 'licencias';
		$rows  = $wpdb->get_results( "SELECT * FROM {$table} ORDER BY id ASC" );

		$items = array();

		foreach ( (array) $rows as $row ) {
			$licencia = array(
				'id'       => (int) $row->id,
				'nombre'   => $row->nombre,
				'duracion' => (int) $row->duracion,
			);

			foreach ( array_keys( self::CAMPOS_ACCESO ) as $campo ) {
				$licencia[ $campo ] = ! empty( $row->$campo );
			}

			$items[] = $licencia;
		}

		return $items;
	}

	/**
	 * Devuelve los datos "en crudo" de una licencia (para precargar el
	 * modal "Editar Licencia" con el valor real guardado de cada
	 * interruptor, no solo su etiqueta si está activo).
	 *
	 * @param int $licencia_id ID de la licencia.
	 * @return array|null
	 */
	public static function obtener_por_id( $licencia_id ) {
		global $wpdb;

		$licencia_id = absint( $licencia_id );

		if ( ! $licencia_id ) {
			return null;
		}

		$table = $wpdb->prefix . 'licencias';
		$row   = $wpdb->get_row(
			$wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", $licencia_id )
		);

		if ( ! $row ) {
			return null;
		}

		$licencia = array(
			'id'       => (int) $row->id,
			'nombre'   => $row->nombre,
			'duracion' => (int) $row->duracion,
		);

		foreach ( array_keys( self::CAMPOS_ACCESO ) as $campo ) {
			$licencia[ $campo ] = ! empty( $row->$campo );
		}

		return $licencia;
	}

	/**
	 * Valida los campos comunes a crear/editar (nombre y duración
	 * obligatorios). Devuelve el nombre/duración ya normalizados o un
	 * mensaje de error.
	 *
	 * @param array $data Datos crudos.
	 * @return array {nombre?:string, duracion?:int, error?:string}
	 */
	private static function validar_campos_comunes( $data ) {
		$nombre   = isset( $data['nombre'] ) ? trim( (string) $data['nombre'] ) : '';
		$duracion = isset( $data['duracion'] ) && '' !== $data['duracion'] ? (int) $data['duracion'] : null;

		if ( '' === $nombre ) {
			return array( 'error' => __( 'El nombre es obligatorio.', 'au-wms' ) );
		}

		if ( null === $duracion ) {
			return array( 'error' => __( 'La duración (días) es obligatoria.', 'au-wms' ) );
		}

		return array(
			'nombre'   => $nombre,
			'duracion' => $duracion,
		);
	}

	/**
	 * Crea una licencia. Mismas validaciones que el formulario original:
	 * nombre y duración son obligatorios, el resto de campos son
	 * interruptores opcionales (ausentes = 0).
	 *
	 * @param array $data Datos crudos ya sanitizados por el llamador.
	 * @return array {success:bool, message:string, id?:int}
	 */
	public static function crear( $data ) {
		global $wpdb;

		$campos = self::validar_campos_comunes( $data );

		if ( isset( $campos['error'] ) ) {
			return array(
				'success' => false,
				'message' => $campos['error'],
			);
		}

		$table = $wpdb->prefix . 'licencias';
		$row   = array(
			'nombre'   => $campos['nombre'],
			'duracion' => $campos['duracion'],
		);

		foreach ( array_keys( self::CAMPOS_ACCESO ) as $campo ) {
			$row[ $campo ] = ! empty( $data[ $campo ] ) ? 1 : 0;
		}

		$insertado = $wpdb->insert( $table, $row );

		if ( false === $insertado ) {
			return array(
				'success' => false,
				'message' => __( 'No se pudo crear la licencia.', 'au-wms' ),
			);
		}

		return array(
			'success' => true,
			'message' => __( 'La licencia se creó correctamente.', 'au-wms' ),
			'id'      => (int) $wpdb->insert_id,
		);
	}

	/**
	 * Edita una licencia existente. Mismas validaciones que `crear()`;
	 * afecta a todas las empresas/áreas que ya tengan esta licencia
	 * asignada.
	 *
	 * @param int   $licencia_id ID de la licencia a editar.
	 * @param array $data        Datos crudos ya sanitizados por el llamador.
	 * @return array {success:bool, message:string}
	 */
	public static function actualizar( $licencia_id, $data ) {
		global $wpdb;

		$licencia_id = absint( $licencia_id );
		$table       = $wpdb->prefix . 'licencias';

		if ( ! $licencia_id || ! $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$table} WHERE id = %d", $licencia_id ) ) ) {
			return array(
				'success' => false,
				'message' => __( 'La licencia indicada no existe.', 'au-wms' ),
			);
		}

		$campos = self::validar_campos_comunes( $data );

		if ( isset( $campos['error'] ) ) {
			return array(
				'success' => false,
				'message' => $campos['error'],
			);
		}

		$row = array(
			'nombre'   => $campos['nombre'],
			'duracion' => $campos['duracion'],
		);

		foreach ( array_keys( self::CAMPOS_ACCESO ) as $campo ) {
			$row[ $campo ] = ! empty( $data[ $campo ] ) ? 1 : 0;
		}

		$actualizado = $wpdb->update( $table, $row, array( 'id' => $licencia_id ) );

		if ( false === $actualizado ) {
			return array(
				'success' => false,
				'message' => __( 'No se pudo actualizar la licencia.', 'au-wms' ),
			);
		}

		return array(
			'success' => true,
			'message' => __( 'La licencia se actualizó correctamente.', 'au-wms' ),
		);
	}
}
