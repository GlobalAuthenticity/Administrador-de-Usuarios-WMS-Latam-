<?php
/**
 * Controlador AJAX de la acción "Refrescar programas" (Tab Empresas).
 *
 * @package Administrador_Usuarios_WMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AU_Ajax_Sync_Programas {

	/**
	 * Instancia única (singleton).
	 *
	 * @var AU_Ajax_Sync_Programas|null
	 */
	private static $instance = null;

	/**
	 * Devuelve la instancia única y engancha las acciones AJAX.
	 *
	 * @return AU_Ajax_Sync_Programas
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
			self::$instance->register_hooks();
		}

		return self::$instance;
	}

	/**
	 * Registra los endpoints AJAX.
	 *
	 * @return void
	 */
	private function register_hooks() {
		add_action( 'wp_ajax_au_wms_sync_programas_iniciar', array( $this, 'handle_iniciar' ) );
		add_action( 'wp_ajax_au_wms_sync_programas_iniciar_usuario', array( $this, 'handle_iniciar_usuario' ) );
		add_action( 'wp_ajax_au_wms_sync_programas_iniciar_empresas', array( $this, 'handle_iniciar_empresas' ) );
		add_action( 'wp_ajax_au_wms_sync_programas_iniciar_externos', array( $this, 'handle_iniciar_externos' ) );
		add_action( 'wp_ajax_au_wms_sync_programas_procesar_lote', array( $this, 'handle_procesar_lote' ) );
	}

	/**
	 * Inicia la sincronización de una empresa.
	 *
	 * @return void
	 */
	public function handle_iniciar() {
		AU_Security::guard();
		$this->exigir_tokens_configurados();

		$empresa_id = isset( $_POST['empresa_id'] ) ? AU_Security::sanitize_int( $_POST['empresa_id'] ) : 0;

		try {
			$resultado = AU_Sync_Programas_Service::iniciar( $empresa_id );
		} catch ( Exception $e ) {
			wp_send_json_error( array( 'message' => $e->getMessage() ) );
		}

		wp_send_json_success( $resultado );
	}

	/**
	 * Inicia la sincronización de un único usuario (Tab Integrantes).
	 *
	 * @return void
	 */
	public function handle_iniciar_usuario() {
		AU_Security::guard();
		$this->exigir_tokens_configurados();

		$user_id = isset( $_POST['user_id'] ) ? AU_Security::sanitize_int( $_POST['user_id'] ) : 0;

		try {
			$resultado = AU_Sync_Programas_Service::iniciar_usuario( $user_id );
		} catch ( Exception $e ) {
			wp_send_json_error( array( 'message' => $e->getMessage() ) );
		}

		wp_send_json_success( $resultado );
	}

	/**
	 * Inicia la sincronización de TODAS las cuentas con rol `company`
	 * (opción "Refrescar programas" del botón "Acciones" del Tab
	 * Empresas). No incluye a los integrantes de cada empresa: para eso
	 * está la acción por fila (`handle_iniciar()`).
	 *
	 * @return void
	 */
	public function handle_iniciar_empresas() {
		AU_Security::guard();
		$this->exigir_tokens_configurados();

		$resultado = AU_Sync_Programas_Service::iniciar_empresas();

		wp_send_json_success( $resultado );
	}

	/**
	 * Inicia la sincronización de TODOS los usuarios con rol
	 * `external_user` (botón del Tab Usuarios Externos).
	 *
	 * @return void
	 */
	public function handle_iniciar_externos() {
		AU_Security::guard();
		$this->exigir_tokens_configurados();

		$resultado = AU_Sync_Programas_Service::iniciar_externos();

		wp_send_json_success( $resultado );
	}

	/**
	 * Procesa un lote de la sincronización ya iniciada.
	 *
	 * @return void
	 */
	public function handle_procesar_lote() {
		AU_Security::guard();
		$this->exigir_tokens_configurados();

		$sync_id    = isset( $_POST['sync_id'] ) ? AU_Security::sanitize_text( $_POST['sync_id'] ) : '';
		$offset     = isset( $_POST['offset'] ) ? AU_Security::sanitize_int( $_POST['offset'] ) : 0;
		$batch_size = isset( $_POST['batch_size'] ) ? AU_Security::sanitize_int( $_POST['batch_size'] ) : 5;

		$batch_size = max( 1, min( 10, $batch_size ) );

		try {
			$resultado = AU_Sync_Programas_Service::procesar_lote( $sync_id, $offset, $batch_size );
		} catch ( Exception $e ) {
			wp_send_json_error( array( 'message' => $e->getMessage() ) );
		}

		wp_send_json_success( $resultado );
	}

	/**
	 * Corta la petición con un error si falta algún token de
	 * sincronización. Sin token, las APIs responden 401/403 y el flujo
	 * podría interpretar esa respuesta como "el usuario ya no tiene el
	 * programa", borrando sus metadatos `inspira`/`octagono`.
	 *
	 * @return void
	 */
	private function exigir_tokens_configurados() {
		$faltantes = AU_Settings::tokens_sync_faltantes();

		if ( empty( $faltantes ) ) {
			return;
		}

		wp_send_json_error(
			array(
				'message' => sprintf(
					/* translators: %s: programas sin token (p. ej. "Inspira, Octágono"). */
					__( 'No se puede refrescar programas: falta configurar el token de %s en Usuarios WMS → Configuración.', 'au-wms' ),
					implode( ', ', $faltantes )
				),
			)
		);
	}
}
