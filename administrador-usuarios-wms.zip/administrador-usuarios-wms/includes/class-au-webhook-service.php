<?php
/**
 * Consume los webhooks externos requeridos tras crear o actualizar un
 * usuario importado. Las llamadas son "fire and forget" (no bloquean
 * el lote de importación); los errores se registran en el log de
 * WordPress sin detener el proceso.
 *
 * Las URLs, el token de autorización y el interruptor de activación
 * son configurables desde "Usuarios WMS → Configuración" (ver
 * AU_Settings); ya no están fijos en el código.
 *
 * @package Administrador_Usuarios_WMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AU_Webhook_Service {

	/**
	 * Notifica la creación de un usuario nuevo.
	 *
	 * @param string $email    Correo del usuario creado.
	 * @param string $password Password generada en texto plano.
	 * @return void
	 */
	public static function notificar_usuario_nuevo( $email, $password ) {
		if ( ! self::activos() ) {
			return;
		}

		self::post(
			AU_Settings::get( 'webhook_nuevo_usuario_url', AU_Settings::DEFAULT_WEBHOOK_NUEVO_USUARIO ),
			array(
				'email'    => $email,
				'password' => $password,
			)
		);
	}

	/**
	 * Notifica la actualización de un usuario (external_user → subscriber).
	 *
	 * @param string $email Correo del usuario actualizado.
	 * @return void
	 */
	public static function notificar_usuario_actualizado( $email ) {
		if ( ! self::activos() ) {
			return;
		}

		self::post(
			AU_Settings::get( 'webhook_usuario_actualizado_url', AU_Settings::DEFAULT_WEBHOOK_USUARIO_ACTUALIZADO ),
			array( 'email' => $email )
		);
	}

	/**
	 * Notifica el cambio de contraseña de un usuario (acción
	 * "Cambiar Contraseña" en Integrantes/Empresas/Usuarios Externos).
	 *
	 * @param string $email    Correo del usuario.
	 * @param string $password Nueva contraseña en texto plano.
	 * @return void
	 */
	public static function notificar_cambio_password( $email, $password ) {
		if ( ! self::activos() ) {
			return;
		}

		self::post(
			AU_Settings::get( 'webhook_recovery_pass_url', AU_Settings::DEFAULT_WEBHOOK_RECOVERY_PASS_URL ),
			array(
				'email'    => $email,
				'password' => $password,
			)
		);
	}

	/**
	 * Notifica la actualización masiva de correos (asistente
	 * "Actualizar correos" en Integrantes), únicamente cuando el
	 * administrador activó la generación de una nueva contraseña para
	 * ese registro.
	 *
	 * Esta llamada es "fire and forget" (no bloqueante): se envía la
	 * petición y no se espera ninguna respuesta, para no retrasar el
	 * procesamiento del lote mientras se actualizan muchos correos.
	 *
	 * @param string $email    Correo nuevo del usuario.
	 * @param string $password Nueva contraseña en texto plano.
	 * @return void
	 */
	public static function notificar_actualizacion_correo_masiva( $email, $password ) {
		if ( ! self::activos() ) {
			return;
		}

		self::post(
			AU_Settings::get( 'webhook_recovery_pass_url', AU_Settings::DEFAULT_WEBHOOK_RECOVERY_PASS_URL ),
			array(
				'email'    => $email,
				'password' => $password,
			),
			false
		);
	}

	/**
	 * Notifica el envío masivo de correo+contraseña tras un "Resetear
	 * contraseñas" (Tab Empresas → modal de reseteo masivo). A
	 * diferencia de los demás métodos de esta clase, es bloqueante y
	 * devuelve el resultado: el administrador está esperando en
	 * pantalla una confirmación de si el envío funcionó o no.
	 *
	 * @param array $usuarios Lista de `array{email:string,password:string,area:string}`.
	 * @return array{success:bool,message:string}
	 */
	public static function notificar_reset_password_masivo( array $usuarios ) {
		if ( ! self::activos() ) {
			return array(
				'success' => false,
				'message' => __( 'El envío de webhooks está desactivado en Configuración.', 'au-wms' ),
			);
		}

		$url = AU_Settings::get( 'webhook_reset_password_masivo_url', AU_Settings::DEFAULT_WEBHOOK_RESET_PASSWORD_MASIVO_URL );

		if ( empty( $url ) ) {
			return array(
				'success' => false,
				'message' => __( 'No hay una URL configurada para este webhook. Configúrala en "Usuarios WMS → Configuración".', 'au-wms' ),
			);
		}

		return self::post( $url, array( 'usuarios' => $usuarios ), true );
	}

	/**
	 * Indica si el envío de webhooks está activado en la configuración.
	 *
	 * @return bool
	 */
	private static function activos() {
		return (bool) AU_Settings::get( 'webhooks_activos', true );
	}

	/**
	 * Envía la petición POST en formato JSON, registrando errores sin
	 * interrumpir el flujo de importación. Si hay un token de
	 * autorización configurado, se envía como `Authorization: Bearer`.
	 *
	 * @param string $url      URL del webhook.
	 * @param array  $body     Cuerpo a enviar (se serializa a JSON).
	 * @param bool   $blocking Si es `false`, la petición se envía sin
	 *                         esperar respuesta ("fire and forget"):
	 *                         no se conoce el resultado ni se registra
	 *                         error si el webhook falla, ya que
	 *                         `wp_remote_post()` retorna de inmediato.
	 * @return array{success:bool,message:string} Resultado de la
	 *         llamada. Cuando `$blocking` es `false` siempre se
	 *         devuelve `success => true` (no hay forma de saberlo).
	 */
	private static function post( $url, array $body, $blocking = true ) {
		if ( empty( $url ) ) {
			return array(
				'success' => false,
				'message' => __( 'No hay una URL configurada para este webhook.', 'au-wms' ),
			);
		}

		$headers = array( 'Content-Type' => 'application/json' );

		$token = AU_Settings::get( 'token_autorizacion', '' );
		if ( '' !== $token ) {
			$headers['Authorization'] = 'Bearer ' . $token;
		}

		$response = wp_remote_post(
			$url,
			array(
				'method'   => 'POST',
				'timeout'  => $blocking ? 15 : 0.01,
				'blocking' => $blocking,
				'headers'  => $headers,
				'body'     => wp_json_encode( $body ),
			)
		);

		if ( ! $blocking ) {
			return array( 'success' => true, 'message' => '' );
		}

		if ( is_wp_error( $response ) ) {
			error_log(
				sprintf(
					'[AU-WMS] Error al llamar webhook %s: %s',
					$url,
					$response->get_error_message()
				)
			);

			return array(
				'success' => false,
				'message' => $response->get_error_message(),
			);
		}

		$codigo = (int) wp_remote_retrieve_response_code( $response );

		if ( $codigo < 200 || $codigo >= 300 ) {
			error_log(
				sprintf( '[AU-WMS] Webhook %s respondió con código %d', $url, $codigo )
			);

			return array(
				/* translators: %d: código de respuesta HTTP. */
				'success' => false,
				'message' => sprintf( __( 'El webhook respondió con un error (código %d).', 'au-wms' ), $codigo ),
			);
		}

		return array( 'success' => true, 'message' => '' );
	}
}
