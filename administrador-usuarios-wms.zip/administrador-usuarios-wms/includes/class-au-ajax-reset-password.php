<?php
/**
 * Controlador AJAX del modal "Resetear contraseñas" (Tab Empresas).
 *
 * @package Administrador_Usuarios_WMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AU_Ajax_Reset_Password {

	/**
	 * Instancia única (singleton).
	 *
	 * @var AU_Ajax_Reset_Password|null
	 */
	private static $instance = null;

	/**
	 * Cuánto tiempo se recuerda una `request_id` ya procesada, para
	 * rechazar un reintento (doble clic, recarga accidental) que
	 * volviera a enviar la misma solicitud.
	 */
	const VENTANA_ANTIDUPLICADO = 5 * MINUTE_IN_SECONDS;

	/**
	 * Devuelve la instancia única y engancha las acciones AJAX.
	 *
	 * @return AU_Ajax_Reset_Password
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
			self::$instance->register_hooks();
		}

		return self::$instance;
	}

	/**
	 * Registra los endpoints AJAX del modal.
	 *
	 * @return void
	 */
	private function register_hooks() {
		add_action( 'wp_ajax_au_wms_reset_password_areas', array( $this, 'handle_areas' ) );
		add_action( 'wp_ajax_au_wms_reset_password_listar', array( $this, 'handle_listar' ) );
		add_action( 'wp_ajax_au_wms_reset_password_ejecutar', array( $this, 'handle_ejecutar' ) );
		add_action( 'wp_ajax_au_wms_reset_password_enviar_correos', array( $this, 'handle_enviar_correos' ) );
	}

	/**
	 * Devuelve las áreas/paquetes de una empresa, para poblar el
	 * filtro múltiple del Paso 1.
	 *
	 * @return void
	 */
	public function handle_areas() {
		AU_Security::guard();

		$empresa_id = isset( $_POST['empresa_id'] ) ? AU_Security::sanitize_int( $_POST['empresa_id'] ) : 0;

		if ( ! $empresa_id || ! get_userdata( $empresa_id ) ) {
			wp_send_json_error( array( 'message' => __( 'La empresa seleccionada no existe.', 'au-wms' ) ) );
		}

		wp_send_json_success(
			array( 'areas' => AU_Repository_Empresas::get_paquetes_por_empresa( $empresa_id ) )
		);
	}

	/**
	 * Lista los usuarios de una empresa según los filtros de área y
	 * perfil activos (Paso 1).
	 *
	 * @return void
	 */
	public function handle_listar() {
		AU_Security::guard();

		$empresa_id = isset( $_POST['empresa_id'] ) ? AU_Security::sanitize_int( $_POST['empresa_id'] ) : 0;

		$paquete_ids = array();
		if ( isset( $_POST['paquete_ids'] ) && is_array( $_POST['paquete_ids'] ) ) {
			$paquete_ids = array_map( 'absint', $_POST['paquete_ids'] );
		}

		$perfil_filtro = isset( $_POST['perfil_filtro'] ) ? AU_Security::sanitize_text( $_POST['perfil_filtro'] ) : '';

		if ( ! $empresa_id || ! get_userdata( $empresa_id ) ) {
			wp_send_json_error( array( 'message' => __( 'La empresa seleccionada no existe.', 'au-wms' ) ) );
		}

		$usuarios = AU_Reset_Password_Service::listar_usuarios( $empresa_id, $paquete_ids, $perfil_filtro );

		wp_send_json_success( array( 'usuarios' => $usuarios ) );
	}

	/**
	 * Ejecuta el reseteo masivo para los usuarios seleccionados.
	 *
	 * @return void
	 */
	public function handle_ejecutar() {
		AU_Security::guard();

		$empresa_id = isset( $_POST['empresa_id'] ) ? AU_Security::sanitize_int( $_POST['empresa_id'] ) : 0;

		$user_ids = array();
		if ( isset( $_POST['user_ids'] ) && is_array( $_POST['user_ids'] ) ) {
			$user_ids = array_map( 'absint', $_POST['user_ids'] );
		}

		$request_id = isset( $_POST['request_id'] ) ? sanitize_key( wp_unslash( $_POST['request_id'] ) ) : '';

		if ( ! $empresa_id || ! get_userdata( $empresa_id ) ) {
			wp_send_json_error( array( 'message' => __( 'La empresa seleccionada no existe.', 'au-wms' ) ) );
		}

		if ( empty( $user_ids ) ) {
			wp_send_json_error( array( 'message' => __( 'No se seleccionó ningún usuario.', 'au-wms' ) ) );
		}

		if ( '' === $request_id ) {
			wp_send_json_error( array( 'message' => __( 'Solicitud inválida. Vuelve a intentarlo.', 'au-wms' ) ) );
		}

		// Evita que un doble clic o una recarga accidental repitan la
		// misma solicitud: la primera vez que se ve esta `request_id`
		// se reclama con un transient; cualquier repetición dentro de
		// la ventana se rechaza sin volver a tocar contraseñas.
		$claim_key = 'au_wms_reset_req_' . substr( md5( $request_id ), 0, 40 );

		if ( false !== get_transient( $claim_key ) ) {
			wp_send_json_error(
				array( 'message' => __( 'Esta solicitud ya fue procesada. Cierra el modal y vuelve a intentarlo si es necesario.', 'au-wms' ) ),
				409
			);
		}

		set_transient( $claim_key, 1, self::VENTANA_ANTIDUPLICADO );

		$resultado = AU_Reset_Password_Service::ejecutar( $empresa_id, $user_ids );

		wp_send_json_success( $resultado );
	}

	/**
	 * Envía a un webhook externo (configurable en "Usuarios WMS →
	 * Configuración") el listado de correo+contraseña resultante de un
	 * reseteo masivo ya ejecutado, para que un sistema externo se
	 * encargue de notificar a cada usuario por correo.
	 *
	 * Recibe el listado desde el propio navegador (el mismo que ya se
	 * mostró en pantalla al administrador en el Paso 4): no se
	 * regenera ni se vuelve a tocar ninguna contraseña aquí, solo se
	 * reenvía lo ya generado.
	 *
	 * @return void
	 */
	public function handle_enviar_correos() {
		AU_Security::guard();

		$usuarios_raw = isset( $_POST['usuarios'] ) && is_array( $_POST['usuarios'] ) ? wp_unslash( $_POST['usuarios'] ) : array();

		if ( empty( $usuarios_raw ) ) {
			wp_send_json_error( array( 'message' => __( 'No hay contraseñas para enviar.', 'au-wms' ) ) );
		}

		// Límite defensivo: esta acción solo debe recibir el resultado
		// de un reseteo que el propio administrador acaba de ver en
		// pantalla, nunca una lista arbitraria de gran tamaño.
		$usuarios_raw = array_slice( $usuarios_raw, 0, 1000 );

		$usuarios = array();
		foreach ( $usuarios_raw as $fila ) {
			if ( ! is_array( $fila ) || empty( $fila['email'] ) || empty( $fila['password'] ) ) {
				continue;
			}

			$email = sanitize_email( (string) $fila['email'] );
			if ( ! $email || ! is_email( $email ) ) {
				continue;
			}

			$usuarios[] = array(
				'email'    => $email,
				'password' => sanitize_text_field( (string) $fila['password'] ),
				'area'     => isset( $fila['area'] ) ? sanitize_text_field( (string) $fila['area'] ) : '',
			);
		}

		if ( empty( $usuarios ) ) {
			wp_send_json_error( array( 'message' => __( 'No hay contraseñas válidas para enviar.', 'au-wms' ) ) );
		}

		$resultado = AU_Webhook_Service::notificar_reset_password_masivo( $usuarios );

		if ( empty( $resultado['success'] ) ) {
			wp_send_json_error( array( 'message' => $resultado['message'] ) );
		}

		wp_send_json_success(
			array(
				'message' => __( 'Correos enviados correctamente.', 'au-wms' ),
				'enviados' => count( $usuarios ),
			)
		);
	}
}
