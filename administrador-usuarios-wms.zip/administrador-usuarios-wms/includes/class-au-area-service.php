<?php
/**
 * Servicio para crear áreas/paquetes de una empresa desde el panel de
 * administración, replicando exactamente las reglas del formulario
 * "Crear Área/Grupo" (`astra-child/includes/companies/ajax/companies-pack.php`):
 *
 * - Cada área es en realidad un cupón de WooCommerce (`WC_Coupon`): 100%
 *   de descuento, uso individual, `usage_limit_per_user = 1`, sin fecha
 *   de expiración, y `usage_limit` = el número de "cupos" del área.
 * - El código del área es el código del cupón (`sanitize_title()`, igual
 *   que el formulario original — por eso queda en minúsculas aunque se
 *   escriba en mayúsculas) y debe ser único en `wp_paquetes`.
 * - Se guarda en `wp_paquetes`: `empresa_id`, `nombre`, `codigo`, `cupo`,
 *   `cupon_id`, `licencia_id`, `estado = 'Activo'`, `tipo = 'companies'`.
 *
 * A diferencia del formulario original:
 * - El "código" es opcional: si se omite, o si el enviado ya existe, se
 *   genera uno aleatorio no repetido en vez de fallar (mismo criterio
 *   que `UDA_Area` en el plugin "User Data API", para que el
 *   comportamiento sea consistente en todo el ecosistema WMS Latam sin
 *   importar por dónde se cree el área).
 * - Los "cupos" también son opcionales: si llegan vacíos o en 0, se
 *   guarda 1 en vez de rechazar la petición. Solo "nombre" sigue siendo
 *   obligatorio.
 *
 * @package Administrador_Usuarios_WMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AU_Area_Service {

	/**
	 * Crea un área/paquete para una empresa ya existente.
	 *
	 * @param array $data empresa_id (int), nombre (string), cupos (int),
	 *                     codigo (string, puede ir vacío),
	 *                     licencia_id (int, puede ir 0/vacío).
	 * @return array {success:bool, message?:string, ...datos del área}
	 */
	public static function crear( array $data ) {
		global $wpdb;

		if ( ! class_exists( 'WC_Coupon' ) ) {
			return array(
				'success' => false,
				'message' => __( 'No se puede crear el área: WooCommerce no está activo en este sitio.', 'au-wms' ),
			);
		}

		if ( ! $data['empresa_id'] || ! get_userdata( $data['empresa_id'] ) ) {
			return array(
				'success' => false,
				'message' => __( 'La empresa indicada no existe.', 'au-wms' ),
			);
		}

		if ( '' === $data['nombre'] ) {
			return array(
				'success' => false,
				'message' => __( 'El nombre del área es obligatorio.', 'au-wms' ),
			);
		}

		// "cupos" es opcional: si llega vacío/0, se guarda como 1 en vez
		// de rechazar la petición.
		if ( $data['cupos'] < 1 ) {
			$data['cupos'] = 1;
		}

		if ( $data['licencia_id'] ) {
			$licencias_table = $wpdb->prefix . 'licencias';
			$existe          = (int) $wpdb->get_var(
				$wpdb->prepare( "SELECT COUNT(*) FROM {$licencias_table} WHERE id = %d", $data['licencia_id'] )
			);

			if ( ! $existe ) {
				return array(
					'success' => false,
					'message' => __( 'La licencia indicada no existe.', 'au-wms' ),
				);
			}
		}

		// Serializa por empresa+nombre: dos envíos casi simultáneos del
		// mismo formulario (doble clic, dos pestañas) no deben poder
		// crear dos áreas iguales. Mismo mecanismo (GET_LOCK de MySQL)
		// que ya usa AU_Cupos_Lock para consumo de cupos.
		$lock_key = 'crear_area_' . $data['empresa_id'] . '_' . strtolower( $data['nombre'] );

		if ( ! AU_Cupos_Lock::adquirir( $lock_key ) ) {
			return array(
				'success' => false,
				'message' => __( 'El servidor está ocupado procesando otra solicitud similar. Intenta de nuevo.', 'au-wms' ),
			);
		}

		try {
			$codigo_generado = false;
			$codigo          = '' !== $data['codigo'] ? sanitize_title( $data['codigo'] ) : '';

			if ( '' === $codigo || self::codigo_existe( $codigo, $wpdb ) ) {
				$codigo           = self::generar_codigo_unico( $wpdb );
				$codigo_generado = true;
			}

			$cupon = new WC_Coupon();
			$cupon->set_code( $codigo );
			$cupon->set_discount_type( 'percent' );
			$cupon->set_amount( 100 );
			$cupon->set_individual_use( true );
			$cupon->set_usage_limit( $data['cupos'] );
			$cupon->set_date_expires( null );
			$cupon->set_usage_limit_per_user( 1 );
			$cupon->save();

			$cupon_id = $cupon->get_id();
			$codigo   = $cupon->get_code(); // WooCommerce normaliza el código al guardar.

			$table_name = $wpdb->prefix . 'paquetes';

			$wpdb->insert(
				$table_name,
				array(
					'empresa_id'  => $data['empresa_id'],
					'nombre'      => $data['nombre'],
					'codigo'      => $codigo,
					'cupo'        => $data['cupos'],
					'cupon_id'    => $cupon_id,
					'licencia_id' => $data['licencia_id'] ? $data['licencia_id'] : null,
					'estado'      => 'Activo',
					'tipo'        => 'companies',
				)
			);

			return array(
				'success'         => true,
				'id'              => $wpdb->insert_id,
				'nombre'          => $data['nombre'],
				'codigo'          => $codigo,
				'cupos'           => $data['cupos'],
				'licencia_id'     => $data['licencia_id'] ? $data['licencia_id'] : null,
				'codigo_generado' => $codigo_generado,
			);
		} finally {
			AU_Cupos_Lock::liberar( $lock_key );
		}
	}

	/**
	 * Edita un área/paquete ya existente (nombre, cupos, licencia). El
	 * código del cupón NUNCA se toca aquí — sigue siendo el mismo que ya
	 * está en uso/distribuido; solo se actualiza su `usage_limit` para
	 * que coincida con los nuevos "cupos".
	 *
	 * @param array $data area_id (int), nombre (string), cupos (int),
	 *                     licencia_id (int, puede ir 0/vacío).
	 * @return array {success:bool, message?:string, ...datos del área}
	 */
	public static function editar( array $data ) {
		global $wpdb;

		if ( ! class_exists( 'WC_Coupon' ) ) {
			return array(
				'success' => false,
				'message' => __( 'No se puede editar el área: WooCommerce no está activo en este sitio.', 'au-wms' ),
			);
		}

		$area_id    = absint( $data['area_id'] );
		$table_name = $wpdb->prefix . 'paquetes';
		$area       = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table_name} WHERE id = %d", $area_id ), ARRAY_A );

		if ( ! $area ) {
			return array(
				'success' => false,
				'message' => __( 'El área indicada no existe.', 'au-wms' ),
			);
		}

		if ( '' === $data['nombre'] ) {
			return array(
				'success' => false,
				'message' => __( 'El nombre del área es obligatorio.', 'au-wms' ),
			);
		}

		// "cupos" es opcional: si llega vacío/0, se guarda como 1 en vez
		// de rechazar la petición (mismo criterio que crear()).
		if ( $data['cupos'] < 1 ) {
			$data['cupos'] = 1;
		}

		if ( $data['licencia_id'] ) {
			$licencias_table = $wpdb->prefix . 'licencias';
			$existe          = (int) $wpdb->get_var(
				$wpdb->prepare( "SELECT COUNT(*) FROM {$licencias_table} WHERE id = %d", $data['licencia_id'] )
			);

			if ( ! $existe ) {
				return array(
					'success' => false,
					'message' => __( 'La licencia indicada no existe.', 'au-wms' ),
				);
			}
		}

		// Serializa por área: dos ediciones casi simultáneas de la misma
		// área (doble clic, dos pestañas) no deben pisarse entre sí.
		// Mismo mecanismo (GET_LOCK de MySQL) que crear() y que
		// AU_Cupos_Lock para consumo de cupos.
		$lock_key = 'editar_area_' . $area_id;

		if ( ! AU_Cupos_Lock::adquirir( $lock_key ) ) {
			return array(
				'success' => false,
				'message' => __( 'El servidor está ocupado procesando otra solicitud similar. Intenta de nuevo.', 'au-wms' ),
			);
		}

		try {
			if ( $area['cupon_id'] ) {
				$cupon = new WC_Coupon( $area['cupon_id'] );

				if ( $cupon->get_id() ) {
					$cupon->set_usage_limit( $data['cupos'] );
					$cupon->save();
				}
			}

			$wpdb->update(
				$table_name,
				array(
					'nombre'      => $data['nombre'],
					'cupo'        => $data['cupos'],
					'licencia_id' => $data['licencia_id'] ? $data['licencia_id'] : null,
				),
				array( 'id' => $area_id )
			);

			return array(
				'success'     => true,
				'id'          => $area_id,
				'nombre'      => $data['nombre'],
				'cupos'       => $data['cupos'],
				'licencia_id' => $data['licencia_id'] ? $data['licencia_id'] : null,
			);
		} finally {
			AU_Cupos_Lock::liberar( $lock_key );
		}
	}

	/**
	 * @param string $codigo Código ya normalizado con sanitize_title().
	 * @param wpdb   $wpdb   Instancia global de wpdb.
	 * @return bool
	 */
	private static function codigo_existe( $codigo, $wpdb ) {
		$table_name = $wpdb->prefix . 'paquetes';

		return (int) $wpdb->get_var(
			$wpdb->prepare( "SELECT COUNT(*) FROM {$table_name} WHERE codigo = %s", $codigo )
		) > 0;
	}

	/**
	 * Genera un código de área aleatorio (12 caracteres, mismo alfabeto
	 * A-Z0-9 que usa el botón "Generar código") que no exista todavía en
	 * `wp_paquetes`, reintentando hasta encontrar uno libre.
	 *
	 * @param wpdb $wpdb Instancia global de wpdb.
	 * @return string
	 */
	private static function generar_codigo_unico( $wpdb ) {
		$chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
		$max   = strlen( $chars ) - 1;

		do {
			$raw = '';
			for ( $i = 0; $i < 12; $i++ ) {
				$raw .= $chars[ random_int( 0, $max ) ];
			}

			$candidate = sanitize_title( $raw );
		} while ( '' === $candidate || self::codigo_existe( $candidate, $wpdb ) );

		return $candidate;
	}
}
