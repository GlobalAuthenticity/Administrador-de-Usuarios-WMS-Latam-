<?php
/**
 * Detecta automáticamente a qué campo del sistema corresponde cada
 * columna del archivo importado, comparando contra un diccionario de
 * sinónimos. El administrador puede corregir el mapeo manualmente
 * desde la interfaz; esto solo genera una sugerencia inicial.
 *
 * @package Administrador_Usuarios_WMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AU_Column_Mapper {

	/**
	 * Campos del sistema disponibles para el mapeo, en el orden en que
	 * deben mostrarse en la interfaz.
	 *
	 * @return array<string,string>
	 */
	public static function campos_disponibles() {
		return array(
			'correo'   => __( 'Correo', 'au-wms' ),
			'nombre'   => __( 'Nombre', 'au-wms' ),
			'apellido' => __( 'Apellido', 'au-wms' ),
			'edad'     => __( 'Edad', 'au-wms' ),
			'genero'   => __( 'Género', 'au-wms' ),
			'pais'     => __( 'País', 'au-wms' ),
			'telefono' => __( 'Teléfono', 'au-wms' ),
			'cargo'    => __( 'Cargo', 'au-wms' ),
		);
	}

	/**
	 * Diccionario de sinónimos por campo, usado para la sugerencia
	 * automática de mapeo.
	 *
	 * @return array<string,array<int,string>>
	 */
	private static function sinonimos() {
		return array(
			'correo'   => array( 'correo', 'correo electronico', 'email', 'e mail', 'mail', 'correo_electronico' ),
			'nombre'   => array( 'nombre', 'nombres', 'first name', 'first_name', 'name' ),
			'apellido' => array( 'apellido', 'apellidos', 'last name', 'last_name', 'surname' ),
			'edad'     => array( 'edad', 'age', 'user_age' ),
			'genero'   => array( 'genero', 'sexo', 'gender', 'user_gender' ),
			'pais'     => array( 'pais', 'country', 'nacionalidad' ),
			'telefono' => array( 'telefono', 'phone', 'celular', 'movil', 'phone_number', 'whatsapp' ),
			'cargo'    => array( 'cargo', 'puesto', 'position', 'job title', 'user_position', 'ocupacion' ),
		);
	}

	/**
	 * Sugiere el índice de columna del archivo que corresponde a cada
	 * campo del sistema, a partir de los encabezados detectados.
	 *
	 * @param array<int,string> $headers Encabezados leídos del archivo.
	 * @return array<string,int|null> Mapa campo => índice de columna (o null si no se encontró).
	 */
	public static function sugerir_mapeo( array $headers ) {
		$normalizados = array();
		foreach ( $headers as $indice => $header ) {
			$normalizados[ $indice ] = self::normalizar( $header );
		}

		$mapeo = array();

		foreach ( self::sinonimos() as $campo => $sinonimos ) {
			$mapeo[ $campo ] = self::buscar_mejor_columna( $sinonimos, $normalizados );
		}

		return $mapeo;
	}

	/**
	 * Busca, entre los encabezados normalizados, la columna que mejor
	 * coincide con la lista de sinónimos de un campo (coincidencia
	 * exacta primero, luego coincidencia parcial como respaldo).
	 *
	 * @param array<int,string> $sinonimos    Sinónimos normalizados del campo.
	 * @param array<int,string> $normalizados Encabezados normalizados (índice => texto).
	 * @return int|null
	 */
	private static function buscar_mejor_columna( array $sinonimos, array $normalizados ) {
		// 1. Coincidencia exacta.
		foreach ( $normalizados as $indice => $header ) {
			if ( in_array( $header, $sinonimos, true ) ) {
				return $indice;
			}
		}

		// 2. Coincidencia parcial (el encabezado contiene el sinónimo o viceversa).
		foreach ( $normalizados as $indice => $header ) {
			foreach ( $sinonimos as $sinonimo ) {
				if ( '' !== $header && ( false !== strpos( $header, $sinonimo ) || false !== strpos( $sinonimo, $header ) ) ) {
					return $indice;
				}
			}
		}

		return null;
	}

	/**
	 * Normaliza un encabezado para compararlo: minúsculas, sin acentos,
	 * sin guiones/guiones bajos y con espacios simples.
	 *
	 * @param string $texto Encabezado crudo.
	 * @return string
	 */
	private static function normalizar( $texto ) {
		$texto = strtolower( trim( (string) $texto ) );

		$con_acentos = array( 'á', 'é', 'í', 'ó', 'ú', 'ñ', 'à', 'è', 'ì', 'ò', 'ù' );
		$sin_acentos = array( 'a', 'e', 'i', 'o', 'u', 'n', 'a', 'e', 'i', 'o', 'u' );
		$texto       = str_replace( $con_acentos, $sin_acentos, $texto );

		$texto = str_replace( array( '_', '-' ), ' ', $texto );
		$texto = preg_replace( '/\s+/', ' ', $texto );

		return trim( $texto );
	}
}
