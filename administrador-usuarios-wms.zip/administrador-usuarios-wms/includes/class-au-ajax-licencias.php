<?php
/**
 * Controlador AJAX del modal "Licencias" (dropdown "Acciones" del Tab
 * Empresas).
 *
 * @package Administrador_Usuarios_WMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AU_Ajax_Licencias {

	/**
	 * Instancia única (singleton).
	 *
	 * @var AU_Ajax_Licencias|null
	 */
	private static $instance = null;

	/**
	 * Devuelve la instancia única y engancha las acciones AJAX.
	 *
	 * @return AU_Ajax_Licencias
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
			self::$instance->register_hooks();
		}

		return self::$instance;
	}

	/**
	 * Registra los endpoints AJAX del modal "Licencias".
	 *
	 * @return void
	 */
	private function register_hooks() {
		add_action( 'wp_ajax_au_wms_licencias_listar', array( $this, 'handle_listar' ) );
		add_action( 'wp_ajax_au_wms_licencias_crear', array( $this, 'handle_crear' ) );
		add_action( 'wp_ajax_au_wms_licencias_obtener', array( $this, 'handle_obtener' ) );
		add_action( 'wp_ajax_au_wms_licencias_editar', array( $this, 'handle_editar' ) );
		add_action( 'wp_ajax_au_wms_licencias_listar_todas', array( $this, 'handle_listar_todas' ) );
	}

	/**
	 * Lista/busca licencias por nombre, paginado.
	 *
	 * @return void
	 */
	public function handle_listar() {
		AU_Security::guard();

		$args = array(
			'search'   => isset( $_POST['search'] ) ? AU_Security::sanitize_text( $_POST['search'] ) : '',
			'page'     => isset( $_POST['page'] ) ? AU_Security::sanitize_int( $_POST['page'] ) : 1,
			'per_page' => isset( $_POST['per_page'] ) ? AU_Security::sanitize_int( $_POST['per_page'] ) : 10,
		);

		$resultado = AU_Repository_Licencias::listar( $args );

		$per_page    = ! empty( $args['per_page'] ) ? $args['per_page'] : 10;
		$total_pages = $per_page > 0 ? (int) ceil( $resultado['total'] / $per_page ) : 1;

		wp_send_json_success(
			array(
				'items'       => $resultado['items'],
				'total'       => $resultado['total'],
				'page'        => max( 1, (int) $args['page'] ),
				'per_page'    => $per_page,
				'total_pages' => max( 1, $total_pages ),
			)
		);
	}

	/**
	 * Devuelve TODAS las licencias, con el estado real de cada atributo,
	 * para el botón "Descargar matriz comparativa" del dropdown
	 * "Acciones" (la matriz se arma en el navegador con SheetJS).
	 *
	 * @return void
	 */
	public function handle_listar_todas() {
		AU_Security::guard();

		wp_send_json_success(
			array(
				'items' => AU_Repository_Licencias::listar_todas(),
			)
		);
	}

	/**
	 * Crea una licencia nueva.
	 *
	 * @return void
	 */
	public function handle_crear() {
		AU_Security::guard();

		$data = array(
			'nombre'   => isset( $_POST['nombre'] ) ? AU_Security::sanitize_text( $_POST['nombre'] ) : '',
			'duracion' => isset( $_POST['duracion'] ) ? AU_Security::sanitize_text( $_POST['duracion'] ) : '',
		);

		foreach ( array_keys( AU_Repository_Licencias::CAMPOS_ACCESO ) as $campo ) {
			$data[ $campo ] = ! empty( $_POST[ $campo ] );
		}

		$resultado = AU_Repository_Licencias::crear( $data );

		if ( ! empty( $resultado['success'] ) ) {
			wp_send_json_success( $resultado );
		}

		wp_send_json_error( array( 'message' => $resultado['message'] ) );
	}

	/**
	 * Devuelve los datos "en crudo" de una licencia (para precargar el
	 * modal "Editar Licencia").
	 *
	 * @return void
	 */
	public function handle_obtener() {
		AU_Security::guard();

		$licencia_id = isset( $_POST['licencia_id'] ) ? AU_Security::sanitize_int( $_POST['licencia_id'] ) : 0;
		$licencia    = AU_Repository_Licencias::obtener_por_id( $licencia_id );

		if ( ! $licencia ) {
			wp_send_json_error( array( 'message' => __( 'La licencia indicada no existe.', 'au-wms' ) ) );
		}

		wp_send_json_success( $licencia );
	}

	/**
	 * Edita una licencia existente (botón "Editar Licencia" del listado).
	 *
	 * @return void
	 */
	public function handle_editar() {
		AU_Security::guard();

		$licencia_id = isset( $_POST['licencia_id'] ) ? AU_Security::sanitize_int( $_POST['licencia_id'] ) : 0;

		$data = array(
			'nombre'   => isset( $_POST['nombre'] ) ? AU_Security::sanitize_text( $_POST['nombre'] ) : '',
			'duracion' => isset( $_POST['duracion'] ) ? AU_Security::sanitize_text( $_POST['duracion'] ) : '',
		);

		foreach ( array_keys( AU_Repository_Licencias::CAMPOS_ACCESO ) as $campo ) {
			$data[ $campo ] = ! empty( $_POST[ $campo ] );
		}

		$resultado = AU_Repository_Licencias::actualizar( $licencia_id, $data );

		if ( ! empty( $resultado['success'] ) ) {
			wp_send_json_success( $resultado );
		}

		wp_send_json_error( array( 'message' => $resultado['message'] ) );
	}
}
