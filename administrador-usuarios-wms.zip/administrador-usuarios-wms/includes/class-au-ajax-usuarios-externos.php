<?php
/**
 * Controlador AJAX del Tab "Usuarios Externos".
 *
 * @package Administrador_Usuarios_WMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AU_Ajax_Usuarios_Externos {

	/**
	 * Instancia única (singleton).
	 *
	 * @var AU_Ajax_Usuarios_Externos|null
	 */
	private static $instance = null;

	/**
	 * Devuelve la instancia única y engancha las acciones AJAX.
	 *
	 * @return AU_Ajax_Usuarios_Externos
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
			self::$instance->register_hooks();
		}

		return self::$instance;
	}

	/**
	 * Registra el endpoint AJAX de búsqueda/paginación.
	 *
	 * @return void
	 */
	private function register_hooks() {
		add_action( 'wp_ajax_au_wms_buscar_usuarios_externos', array( $this, 'handle_buscar' ) );
	}

	/**
	 * Busca/pagina usuarios con rol `external_user` según los filtros
	 * recibidos.
	 *
	 * @return void
	 */
	public function handle_buscar() {
		AU_Security::guard();

		$args = array(
			'search'          => isset( $_POST['search'] ) ? AU_Security::sanitize_text( $_POST['search'] ) : '',
			'programa_filtro' => isset( $_POST['programa_filtro'] ) ? AU_Security::sanitize_text( $_POST['programa_filtro'] ) : '',
			'page'            => isset( $_POST['page'] ) ? AU_Security::sanitize_int( $_POST['page'] ) : 1,
			'per_page'        => isset( $_POST['per_page'] ) ? AU_Security::sanitize_int( $_POST['per_page'] ) : 10,
		);

		$resultado = AU_Repository_Usuarios_Externos::buscar_listado( $args );

		$per_page    = ! empty( $args['per_page'] ) ? $args['per_page'] : 10;
		$total_pages = $per_page > 0 ? (int) ceil( $resultado['total'] / $per_page ) : 1;

		wp_send_json_success(
			array(
				'items'       => $resultado['items'],
				'total'       => $resultado['total'],
				'page'        => max( 1, (int) $args['page'] ),
				'per_page'    => $per_page,
				'total_pages' => max( 1, $total_pages ),
			)
		);
	}
}
