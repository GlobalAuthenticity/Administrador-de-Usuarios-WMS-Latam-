<?php
/**
 * Bloqueo atómico basado en `GET_LOCK()`/`RELEASE_LOCK()` de MySQL,
 * usado para serializar el consumo de cupos de un área/paquete cuando
 * dos importaciones (o la importación y otra acción que consuma cupos)
 * corren al mismo tiempo.
 *
 * A diferencia de una transacción de tabla, `GET_LOCK()` es un lock con
 * nombre a nivel de servidor MySQL: cualquier conexión que pida el mismo
 * nombre queda bloqueada hasta que la primera lo libere (o expire el
 * timeout), lo que evita la condición de carrera de "ambos procesos ven
 * cupos disponibles y ambos proceden".
 *
 * @package Administrador_Usuarios_WMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AU_Cupos_Lock {

	/**
	 * Tiempo máximo (segundos) que se espera para adquirir el lock antes
	 * de desistir.
	 */
	const TIMEOUT_SEGUNDOS = 10;

	/**
	 * Intenta adquirir el lock exclusivo para un código de área.
	 *
	 * @param string $codigo_area Código del área/paquete.
	 * @return bool true si se adquirió el lock, false si se agotó el tiempo de espera.
	 */
	public static function adquirir( $codigo_area ) {
		global $wpdb;

		$nombre    = self::nombre_lock( $codigo_area );
		$resultado = $wpdb->get_var(
			$wpdb->prepare( 'SELECT GET_LOCK(%s, %d)', $nombre, self::TIMEOUT_SEGUNDOS )
		);

		// GET_LOCK() devuelve 1 (éxito), 0 (timeout) o NULL (error interno).
		return '1' === (string) $resultado;
	}

	/**
	 * Libera el lock previamente adquirido para un código de área.
	 *
	 * @param string $codigo_area Código del área/paquete.
	 * @return void
	 */
	public static function liberar( $codigo_area ) {
		global $wpdb;

		$nombre = self::nombre_lock( $codigo_area );
		$wpdb->query( $wpdb->prepare( 'SELECT RELEASE_LOCK(%s)', $nombre ) );
	}

	/**
	 * Genera un nombre de lock determinístico y dentro del límite de 64
	 * caracteres que exige MySQL para `GET_LOCK()`.
	 *
	 * @param string $codigo_area Código del área/paquete.
	 * @return string
	 */
	private static function nombre_lock( $codigo_area ) {
		return 'au_wms_cupos_' . substr( md5( (string) $codigo_area ), 0, 40 );
	}
}
