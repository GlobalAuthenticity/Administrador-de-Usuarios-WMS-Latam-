<?php
/**
 * Repositorio de configuración del plugin (APIs / Webhooks). Los
 * valores se guardan en una única opción de WordPress (`au_wms_settings`)
 * para no ensuciar la tabla `wp_options` con múltiples entradas sueltas.
 *
 * @package Administrador_Usuarios_WMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AU_Settings {

	/**
	 * Nombre de la opción en `wp_options`.
	 */
	const OPTION_KEY = 'au_wms_settings';

	/**
	 * Valores por defecto (los mismos que estaban antes codificados
	 * directamente en AU_Webhook_Service).
	 */
	const DEFAULT_WEBHOOK_NUEVO_USUARIO = 'https://api.efrenmartinezortiz-ia.com/webhook/creacion-usuario-wms-nuevo-usuario';
	const DEFAULT_WEBHOOK_USUARIO_ACTUALIZADO = 'https://api.efrenmartinezortiz-ia.com/webhook/creacion-usuario-wms-update-usuario';
	const DEFAULT_INSPIRA_SYNC_URL = 'https://inspira.wmslatam.com/wp-json/inspira-api/v1/verificar-usuario';
	const DEFAULT_OCTAGONO_SYNC_URL = 'https://octagono.wmslatam.com/wp-json/octagono/v1/update-subscriber';
	const DEFAULT_WEBHOOK_RECOVERY_PASS_URL = 'https://api.efrenmartinezortiz-ia.com/webhook/creacion-empresa-wms-recovery-pass';
	const DEFAULT_WEBHOOK_RESET_PASSWORD_MASIVO_URL = 'https://api.efrenmartinezortiz-ia.com/webhook/password-recovery-bulk';
	const DEFAULT_PDF_RESULTADO_TEST_URL = 'https://pdf.wmslatam.com/pdf/pdf/generate';
	const DEFAULT_CREAR_EMPRESA_WEBHOOK_URL = 'https://api.efrenmartinezortiz-ia.com/webhook/credenciales_para_wms';
	const DEFAULT_CREAR_EMPRESA_INSPIRA_URL = 'https://inspira.wmslatam.com/wp-json/user-data-api/v1/company';
	const DEFAULT_CREAR_EMPRESA_OCTAGONO_URL = 'https://octagono.wmslatam.com/wp-json/user-data-api/v1/company';

	/**
	 * Campos del asistente "Crear Empresa" (Tab Empresas): clave de
	 * configuración => tipo de saneado + valor de fábrica.
	 *
	 * Van en un registro y no en bloques `if ( isset() )` sueltos como el
	 * resto: son 16 claves, y repetirlas una a una en `guardar()`, en el
	 * controlador AJAX y en la validación multiplicaba por tres cada
	 * campo nuevo. El tipo lo usa AU_Ajax_Settings para sanear y validar.
	 *
	 * Tipos: 'url', 'texto', 'token', 'entero'.
	 *
	 * Los dos tokens salen vacíos de fábrica a propósito (igual que
	 * inspira_sync_token / octagono_sync_token desde la 1.39.0): no deben
	 * viajar dentro del ZIP del plugin, se cargan desde esta misma
	 * pantalla.
	 *
	 * @var array<string, array{tipo:string, default:mixed}>
	 */
	const CAMPOS_CREAR_EMPRESA = array(
		'crear_empresa_webhook_url'          => array( 'tipo' => 'url', 'default' => self::DEFAULT_CREAR_EMPRESA_WEBHOOK_URL ),
		'crear_empresa_inspira_url'          => array( 'tipo' => 'url', 'default' => self::DEFAULT_CREAR_EMPRESA_INSPIRA_URL ),
		'crear_empresa_inspira_token'        => array( 'tipo' => 'token', 'default' => '' ),
		'crear_empresa_octagono_url'         => array( 'tipo' => 'url', 'default' => self::DEFAULT_CREAR_EMPRESA_OCTAGONO_URL ),
		'crear_empresa_octagono_token'       => array( 'tipo' => 'token', 'default' => '' ),
		'crear_empresa_nombre_encargado'     => array( 'tipo' => 'texto', 'default' => 'José' ),
		'crear_empresa_apellidos_encargado'  => array( 'tipo' => 'texto', 'default' => 'Martinez' ),
		'crear_empresa_contacto'             => array( 'tipo' => 'texto', 'default' => '+573138529921' ),
		'crear_empresa_ocupacion'            => array( 'tipo' => 'texto', 'default' => 'Administrador WMS' ),
		'crear_empresa_email_plantilla'      => array( 'tipo' => 'texto', 'default' => 'admin.{nombre_empresa_normalizado}@wmslatam.com' ),
		'crear_empresa_area_nombre'          => array( 'tipo' => 'texto', 'default' => 'Área demo' ),
		'crear_empresa_area_cupos_wms'       => array( 'tipo' => 'entero', 'default' => 1 ),
		'crear_empresa_area_cupos_inspira'   => array( 'tipo' => 'entero', 'default' => 1 ),
		'crear_empresa_area_cupos_octagono'  => array( 'tipo' => 'entero', 'default' => 1 ),
		'crear_empresa_area_licencia_id'     => array( 'tipo' => 'entero', 'default' => 0 ),
		'crear_empresa_area_meses_expiracion' => array( 'tipo' => 'entero', 'default' => 6 ),
	);

	/**
	 * Valores por defecto de toda la configuración.
	 *
	 * @return array
	 */
	public static function defaults() {
		$defaults = array(
			'webhook_nuevo_usuario_url'       => self::DEFAULT_WEBHOOK_NUEVO_USUARIO,
			'webhook_usuario_actualizado_url' => self::DEFAULT_WEBHOOK_USUARIO_ACTUALIZADO,
			'token_autorizacion'              => '',
			'webhooks_activos'                => true,
			'inspira_sync_url'                => self::DEFAULT_INSPIRA_SYNC_URL,
			'inspira_sync_token'              => '', // Sin valor de fábrica: se configura en "Configuración".
			'octagono_sync_url'               => self::DEFAULT_OCTAGONO_SYNC_URL,
			'octagono_sync_token'             => '', // Sin valor de fábrica: se configura en "Configuración".
			'webhook_recovery_pass_url'       => self::DEFAULT_WEBHOOK_RECOVERY_PASS_URL,
			'webhook_reset_password_masivo_url' => self::DEFAULT_WEBHOOK_RESET_PASSWORD_MASIVO_URL,
			'pdf_resultado_test_url'          => self::DEFAULT_PDF_RESULTADO_TEST_URL,
		);

		foreach ( self::CAMPOS_CREAR_EMPRESA as $clave => $campo ) {
			$defaults[ $clave ] = $campo['default'];
		}

		return $defaults;
	}

	/**
	 * Configuración del asistente "Crear Empresa", solo con sus claves
	 * (sin el resto de webhooks del plugin).
	 *
	 * @return array
	 */
	public static function crear_empresa() {
		$todas  = self::get_all();
		$config = array();

		foreach ( array_keys( self::CAMPOS_CREAR_EMPRESA ) as $clave ) {
			$config[ $clave ] = $todas[ $clave ];
		}

		return $config;
	}

	/**
	 * Devuelve toda la configuración guardada, completando con los
	 * valores por defecto cualquier clave que aún no exista.
	 *
	 * @return array
	 */
	public static function get_all() {
		$guardado = get_option( self::OPTION_KEY, array() );
		if ( ! is_array( $guardado ) ) {
			$guardado = array();
		}

		return wp_parse_args( $guardado, self::defaults() );
	}

	/**
	 * Devuelve un valor de configuración puntual.
	 *
	 * @param string $clave   Clave de configuración.
	 * @param mixed  $default Valor de respaldo si no existe.
	 * @return mixed
	 */
	public static function get( $clave, $default = null ) {
		$todas = self::get_all();
		return array_key_exists( $clave, $todas ) ? $todas[ $clave ] : $default;
	}

	/**
	 * Devuelve los programas (Inspira/Octágono) cuyo token de
	 * sincronización todavía no está configurado.
	 *
	 * Desde la 1.39.0 los tokens ya no tienen valor de fábrica en el
	 * código (estaban expuestos en el ZIP del plugin): deben cargarse
	 * desde "Usuarios WMS → Configuración". Mientras falte alguno, la
	 * sincronización de programas se bloquea por completo para no
	 * llamar a las APIs sin autorización.
	 *
	 * @return string[] Lista de etiquetas legibles ('Inspira', 'Octágono').
	 */
	public static function tokens_sync_faltantes() {
		$faltantes = array();

		if ( '' === trim( (string) self::get( 'inspira_sync_token', '' ) ) ) {
			$faltantes[] = 'Inspira';
		}
		if ( '' === trim( (string) self::get( 'octagono_sync_token', '' ) ) ) {
			$faltantes[] = 'Octágono';
		}

		return $faltantes;
	}

	/**
	 * Valida y guarda la configuración enviada desde el formulario.
	 *
	 * @param array $datos Datos crudos recibidos (ya deben venir
	 *                     saneados por el llamador: AU_Ajax_Settings).
	 * @return array Configuración final guardada.
	 */
	public static function guardar( array $datos ) {
		$actuales = self::get_all();

		if ( isset( $datos['webhook_nuevo_usuario_url'] ) ) {
			$actuales['webhook_nuevo_usuario_url'] = $datos['webhook_nuevo_usuario_url'];
		}
		if ( isset( $datos['webhook_usuario_actualizado_url'] ) ) {
			$actuales['webhook_usuario_actualizado_url'] = $datos['webhook_usuario_actualizado_url'];
		}
		if ( isset( $datos['token_autorizacion'] ) ) {
			$actuales['token_autorizacion'] = $datos['token_autorizacion'];
		}
		if ( isset( $datos['webhooks_activos'] ) ) {
			$actuales['webhooks_activos'] = (bool) $datos['webhooks_activos'];
		}
		if ( isset( $datos['inspira_sync_url'] ) ) {
			$actuales['inspira_sync_url'] = $datos['inspira_sync_url'];
		}
		if ( isset( $datos['inspira_sync_token'] ) ) {
			$actuales['inspira_sync_token'] = $datos['inspira_sync_token'];
		}
		if ( isset( $datos['octagono_sync_url'] ) ) {
			$actuales['octagono_sync_url'] = $datos['octagono_sync_url'];
		}
		if ( isset( $datos['octagono_sync_token'] ) ) {
			$actuales['octagono_sync_token'] = $datos['octagono_sync_token'];
		}
		if ( isset( $datos['webhook_recovery_pass_url'] ) ) {
			$actuales['webhook_recovery_pass_url'] = $datos['webhook_recovery_pass_url'];
		}
		if ( isset( $datos['webhook_reset_password_masivo_url'] ) ) {
			$actuales['webhook_reset_password_masivo_url'] = $datos['webhook_reset_password_masivo_url'];
		}
		if ( isset( $datos['pdf_resultado_test_url'] ) ) {
			$actuales['pdf_resultado_test_url'] = $datos['pdf_resultado_test_url'];
		}

		foreach ( array_keys( self::CAMPOS_CREAR_EMPRESA ) as $clave ) {
			if ( isset( $datos[ $clave ] ) ) {
				$actuales[ $clave ] = $datos[ $clave ];
			}
		}

		update_option( self::OPTION_KEY, $actuales );

		return $actuales;
	}
}
