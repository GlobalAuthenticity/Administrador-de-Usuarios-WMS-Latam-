<?php
/**
 * Utilidades de seguridad centralizadas: nonces, verificación de
 * capacidades y sanitización de entradas.
 *
 * @package Administrador_Usuarios_WMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AU_Security {

	/**
	 * Acción usada para el nonce de todas las peticiones AJAX del plugin.
	 */
	const NONCE_ACTION = 'au_wms_nonce';

	/**
	 * Capacidad mínima requerida para administrar el plugin.
	 */
	const REQUIRED_CAPABILITY = 'manage_options';

	/**
	 * Genera el nonce para usar en el frontend/admin (localizado en JS).
	 *
	 * @return string
	 */
	public static function create_nonce() {
		return wp_create_nonce( self::NONCE_ACTION );
	}

	/**
	 * Verifica el nonce recibido por AJAX. Termina la ejecución con un
	 * error JSON si no es válido.
	 *
	 * @param string $nonce_field Nombre del campo POST que contiene el nonce.
	 * @return void
	 */
	public static function verify_ajax_nonce( $nonce_field = 'nonce' ) {
		$nonce = isset( $_POST[ $nonce_field ] ) ? sanitize_text_field( wp_unslash( $_POST[ $nonce_field ] ) ) : '';

		if ( ! wp_verify_nonce( $nonce, self::NONCE_ACTION ) ) {
			wp_send_json_error(
				array( 'message' => __( 'La sesión ha expirado. Por favor recarga la página e inténtalo de nuevo.', 'au-wms' ) ),
				403
			);
		}
	}

	/**
	 * Verifica que el usuario actual tenga permisos de administración.
	 * Termina la ejecución con un error JSON si no los tiene.
	 *
	 * @return void
	 */
	public static function verify_capability() {
		if ( ! current_user_can( self::REQUIRED_CAPABILITY ) ) {
			wp_send_json_error(
				array( 'message' => __( 'No tienes permisos suficientes para realizar esta acción.', 'au-wms' ) ),
				403
			);
		}
	}

	/**
	 * Verifica nonce + capacidad en una sola llamada (caso más común).
	 *
	 * @param string $nonce_field Nombre del campo POST que contiene el nonce.
	 * @return void
	 */
	public static function guard( $nonce_field = 'nonce' ) {
		self::verify_capability();
		self::verify_ajax_nonce( $nonce_field );
	}

	/**
	 * Roles sobre los que el panel puede operar (eliminar, impersonar,
	 * cambiar correo/contraseña, deshabilitar acceso, editar usermeta,
	 * vincular áreas). Cualquier otro rol —administrator, editor,
	 * shop_manager, etc.— queda fuera aunque se envíe su ID a mano.
	 *
	 * Ampliable desde otro plugin o el tema:
	 *     add_filter( 'au_wms_roles_gestionables', function ( $roles ) {
	 *         $roles[] = 'mi_rol';
	 *         return $roles;
	 *     } );
	 *
	 * @return string[]
	 */
	public static function roles_gestionables() {
		$roles = array( 'subscriber', 'group_leader', 'external_user', 'company' );

		return array_values( array_filter( (array) apply_filters( 'au_wms_roles_gestionables', $roles ), 'is_string' ) );
	}

	/**
	 * Indica si el panel puede operar sobre un usuario.
	 *
	 * Reglas (en orden):
	 * 1. El usuario debe existir.
	 * 2. Nunca un super admin (multisitio) ni un usuario con
	 *    capacidades de administración de usuarios o del sitio, sin
	 *    importar el nombre de su rol (cubre roles personalizados con
	 *    permisos elevados).
	 * 3. Si tiene roles, al menos uno debe estar en roles_gestionables().
	 *    Un usuario sin ningún rol no tiene privilegios y se permite.
	 *
	 * @param WP_User|int $user Usuario u ID.
	 * @return bool
	 */
	public static function puede_gestionar_usuario( $user ) {
		if ( ! ( $user instanceof WP_User ) ) {
			$user = get_userdata( absint( $user ) );
		}

		if ( ! $user || ! $user->exists() ) {
			return false;
		}

		if ( is_multisite() && is_super_admin( $user->ID ) ) {
			return false;
		}

		$capacidades_privilegiadas = (array) apply_filters(
			'au_wms_capacidades_privilegiadas',
			array(
				'manage_options',
				'promote_users',
				'edit_users',
				'delete_users',
				'manage_woocommerce',
			)
		);

		foreach ( $capacidades_privilegiadas as $capacidad ) {
			if ( user_can( $user, $capacidad ) ) {
				return false;
			}
		}

		$roles = (array) $user->roles;

		if ( empty( $roles ) ) {
			return true;
		}

		return (bool) array_intersect( $roles, self::roles_gestionables() );
	}

	/**
	 * Mensaje estándar cuando el usuario destino está protegido.
	 *
	 * @return string
	 */
	public static function mensaje_usuario_protegido() {
		return __( 'Este usuario tiene un rol protegido (administrador u otro rol con privilegios) y no puede gestionarse desde este panel.', 'au-wms' );
	}

	/**
	 * Variante para controladores AJAX: termina la petición con un error
	 * JSON 403 si el usuario destino no puede gestionarse desde el panel.
	 *
	 * @param int $user_id ID del usuario destino.
	 * @return void
	 */
	public static function exigir_usuario_gestionable( $user_id ) {
		if ( ! self::puede_gestionar_usuario( $user_id ) ) {
			wp_send_json_error(
				array( 'message' => self::mensaje_usuario_protegido() ),
				403
			);
		}
	}

	/**
	 * Sanitiza un entero positivo proveniente de una petición.
	 *
	 * @param mixed $value Valor recibido.
	 * @return int
	 */
	public static function sanitize_int( $value ) {
		return absint( $value );
	}

	/**
	 * Sanitiza una cadena de texto simple (búsquedas, códigos, etc).
	 *
	 * @param mixed $value Valor recibido.
	 * @return string
	 */
	public static function sanitize_text( $value ) {
		return sanitize_text_field( wp_unslash( $value ) );
	}
}
