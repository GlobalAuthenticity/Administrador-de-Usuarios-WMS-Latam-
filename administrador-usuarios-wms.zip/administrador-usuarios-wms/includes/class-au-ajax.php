<?php
/**
 * Controlador de peticiones AJAX del plugin.
 *
 * Cada método valida capacidad + nonce mediante AU_Security::guard()
 * antes de delegar en el repositorio o servicio correspondiente.
 *
 * @package Administrador_Usuarios_WMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AU_Ajax {

	/**
	 * Instancia única (singleton).
	 *
	 * @var AU_Ajax|null
	 */
	private static $instance = null;

	/**
	 * Devuelve la instancia única y engancha las acciones AJAX.
	 *
	 * @return AU_Ajax
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
			self::$instance->register_hooks();
		}

		return self::$instance;
	}

	/**
	 * Registra todos los endpoints AJAX del plugin.
	 *
	 * @return void
	 */
	private function register_hooks() {
		$endpoints = array(
			'au_wms_get_paquetes'   => 'handle_get_paquetes',
			'au_wms_buscar_usuarios' => 'handle_buscar_usuarios',
			'au_wms_eliminar_usuario' => 'handle_eliminar_usuario',
			'au_wms_login_como_usuario' => 'handle_login_como_usuario',
			'au_wms_usuario_obtener_escenario' => 'handle_obtener_escenario',
			'au_wms_usuario_dejar_wms' => 'handle_dejar_wms',
			'au_wms_alternar_acceso_login' => 'handle_alternar_acceso_login',
			'au_wms_cambiar_correo' => 'handle_cambiar_correo',
			'au_wms_cambiar_password' => 'handle_cambiar_password',
			'au_wms_obtener_perfil' => 'handle_obtener_perfil',
			'au_wms_editar_perfil' => 'handle_editar_perfil',
		);

		foreach ( $endpoints as $action => $callback ) {
			add_action( 'wp_ajax_' . $action, array( $this, $callback ) );
		}
	}

	/**
	 * Devuelve los paquetes (áreas) de una empresa para poblar el
	 * segundo select del filtro dinámicamente.
	 *
	 * @return void
	 */
	public function handle_get_paquetes() {
		AU_Security::guard();

		$empresa_id = isset( $_POST['empresa_id'] ) ? AU_Security::sanitize_int( $_POST['empresa_id'] ) : 0;

		$paquetes = AU_Repository_Empresas::get_paquetes_por_empresa( $empresa_id );

		wp_send_json_success( array( 'paquetes' => $paquetes ) );
	}

	/**
	 * Busca/pagina usuarios según los filtros recibidos.
	 *
	 * @return void
	 */
	public function handle_buscar_usuarios() {
		AU_Security::guard();

		$args = array(
			'search'          => isset( $_POST['search'] ) ? AU_Security::sanitize_text( $_POST['search'] ) : '',
			'empresa_id'      => isset( $_POST['empresa_id'] ) ? AU_Security::sanitize_int( $_POST['empresa_id'] ) : 0,
			'paquete_id'      => isset( $_POST['paquete_id'] ) ? AU_Security::sanitize_int( $_POST['paquete_id'] ) : 0,
			'test_filtro'     => isset( $_POST['test_filtro'] ) ? AU_Security::sanitize_text( $_POST['test_filtro'] ) : '',
			'perfil_filtro'   => isset( $_POST['perfil_filtro'] ) ? AU_Security::sanitize_text( $_POST['perfil_filtro'] ) : '',
			'programa_filtro' => isset( $_POST['programa_filtro'] ) ? AU_Security::sanitize_text( $_POST['programa_filtro'] ) : '',
			'page'            => isset( $_POST['page'] ) ? AU_Security::sanitize_int( $_POST['page'] ) : 1,
			'per_page'        => isset( $_POST['per_page'] ) ? AU_Security::sanitize_int( $_POST['per_page'] ) : 10,
		);

		$resultado = AU_Repository_Usuarios::buscar( $args );

		$per_page    = ! empty( $args['per_page'] ) ? $args['per_page'] : 10;
		$total_pages = $per_page > 0 ? (int) ceil( $resultado['total'] / $per_page ) : 1;

		wp_send_json_success(
			array(
				'items'       => $resultado['items'],
				'total'       => $resultado['total'],
				'page'        => max( 1, (int) $args['page'] ),
				'per_page'    => $per_page,
				'total_pages' => max( 1, $total_pages ),
			)
		);
	}

	/**
	 * Elimina un usuario ejecutando el flujo completo de negocio.
	 *
	 * @return void
	 */
	public function handle_eliminar_usuario() {
		AU_Security::guard();

		$user_id = isset( $_POST['user_id'] ) ? AU_Security::sanitize_int( $_POST['user_id'] ) : 0;

		$resultado = AU_User_Service::eliminar_usuario( $user_id );

		if ( ! empty( $resultado['success'] ) ) {
			wp_send_json_success( array( 'message' => $resultado['message'] ) );
		}

		wp_send_json_error( array( 'message' => $resultado['message'] ) );
	}

	/**
	 * Determina qué programas (Inspira/Octágono) tiene asignados un
	 * usuario, para decidir qué modal mostrar en el flujo de
	 * "Borrar usuario".
	 *
	 * @return void
	 */
	public function handle_obtener_escenario() {
		AU_Security::guard();

		$user_id = isset( $_POST['user_id'] ) ? AU_Security::sanitize_int( $_POST['user_id'] ) : 0;

		$resultado = AU_User_Service::determinar_escenario_programas( $user_id );

		if ( ! empty( $resultado['success'] ) ) {
			wp_send_json_success( $resultado );
		}

		wp_send_json_error( array( 'message' => $resultado['message'] ) );
	}

	/**
	 * Ejecuta el flujo "Dejar de ser usuario WMS".
	 *
	 * @return void
	 */
	public function handle_dejar_wms() {
		AU_Security::guard();

		$user_id = isset( $_POST['user_id'] ) ? AU_Security::sanitize_int( $_POST['user_id'] ) : 0;

		$resultado = AU_User_Service::dejar_de_ser_usuario_wms( $user_id );

		if ( ! empty( $resultado['success'] ) ) {
			wp_send_json_success( $resultado );
		}

		wp_send_json_error( array( 'message' => $resultado['message'] ) );
	}

	/**
	 * Habilita/deshabilita el acceso de inicio de sesión de un usuario.
	 *
	 * @return void
	 */
	public function handle_alternar_acceso_login() {
		AU_Security::guard();

		$user_id = isset( $_POST['user_id'] ) ? AU_Security::sanitize_int( $_POST['user_id'] ) : 0;

		$resultado = AU_User_Service::alternar_acceso_login( $user_id );

		if ( ! empty( $resultado['success'] ) ) {
			wp_send_json_success( $resultado );
		}

		wp_send_json_error( array( 'message' => $resultado['message'] ) );
	}

	/**
	 * Cambia el correo de un usuario (wp_users + wp_correos_configurados).
	 *
	 * @return void
	 */
	public function handle_cambiar_correo() {
		AU_Security::guard();

		$user_id      = isset( $_POST['user_id'] ) ? AU_Security::sanitize_int( $_POST['user_id'] ) : 0;
		$nuevo_correo = isset( $_POST['nuevo_correo'] ) ? sanitize_email( wp_unslash( $_POST['nuevo_correo'] ) ) : '';

		$resultado = AU_User_Service::cambiar_correo( $user_id, $nuevo_correo );

		if ( ! empty( $resultado['success'] ) ) {
			wp_send_json_success( $resultado );
		}

		wp_send_json_error( array( 'message' => $resultado['message'] ) );
	}

	/**
	 * Cambia la contraseña de un usuario y notifica el cambio vía
	 * webhook. Compartido entre Integrantes, Empresas y Usuarios Externos.
	 *
	 * @return void
	 */
	public function handle_cambiar_password() {
		AU_Security::guard();

		$user_id        = isset( $_POST['user_id'] ) ? AU_Security::sanitize_int( $_POST['user_id'] ) : 0;
		$nueva_password = isset( $_POST['nueva_password'] ) ? (string) wp_unslash( $_POST['nueva_password'] ) : '';

		$resultado = AU_User_Service::cambiar_password( $user_id, $nueva_password );

		if ( ! empty( $resultado['success'] ) ) {
			wp_send_json_success( $resultado );
		}

		wp_send_json_error( array( 'message' => $resultado['message'] ) );
	}

	/**
	 * Datos del perfil de un usuario, para precargar el modal "Editar
	 * perfil de usuario".
	 *
	 * @return void
	 */
	public function handle_obtener_perfil() {
		AU_Security::guard();

		$user_id = isset( $_POST['user_id'] ) ? AU_Security::sanitize_int( $_POST['user_id'] ) : 0;
		$perfil  = AU_User_Service::obtener_perfil( $user_id );

		if ( ! $perfil ) {
			wp_send_json_error( array( 'message' => __( 'El usuario indicado no existe.', 'au-wms' ) ) );
		}

		wp_send_json_success( $perfil );
	}

	/**
	 * Guarda el modal "Editar perfil de usuario".
	 *
	 * Del POST solo se leen los campos de `CAMPOS_PERFIL`: un `email` o
	 * una contraseña enviados a mano no llegan a tocarse en ningún
	 * punto, ni aquí ni en el servicio.
	 *
	 * @return void
	 */
	public function handle_editar_perfil() {
		AU_Security::guard();

		$user_id = isset( $_POST['user_id'] ) ? AU_Security::sanitize_int( $_POST['user_id'] ) : 0;
		$datos   = array();

		foreach ( array_keys( AU_User_Service::CAMPOS_PERFIL ) as $campo ) {
			$datos[ $campo ] = isset( $_POST[ $campo ] ) ? AU_Security::sanitize_text( $_POST[ $campo ] ) : '';
		}

		$resultado = AU_User_Service::editar_perfil( $user_id, $datos );

		if ( ! empty( $resultado['success'] ) ) {
			wp_send_json_success( $resultado );
		}

		wp_send_json_error( array( 'message' => $resultado['message'] ) );
	}

	/**
	 * Inicia sesión como el usuario seleccionado (impersonación).
	 *
	 * @return void
	 */
	public function handle_login_como_usuario() {
		AU_Security::guard();

		$user_id = isset( $_POST['user_id'] ) ? AU_Security::sanitize_int( $_POST['user_id'] ) : 0;

		$resultado = AU_User_Service::iniciar_sesion_como( $user_id );

		if ( ! empty( $resultado['success'] ) ) {
			wp_send_json_success(
				array(
					'message'  => $resultado['message'],
					'redirect' => $resultado['redirect'],
				)
			);
		}

		wp_send_json_error( array( 'message' => $resultado['message'] ) );
	}
}
