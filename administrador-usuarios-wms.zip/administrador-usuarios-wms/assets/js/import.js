/**
 * Administrador de Usuarios (WMS Latam) — Asistente de importación
 * masiva de usuarios ("Importar usuarios").
 *
 * Depende de jQuery, SweetAlert2 y Tom Select (ya cargados por
 * admin.js), y del objeto global `AU_WMS` localizado desde PHP.
 */
( function ( $ ) {
	'use strict';

	var wizard = {
		step: 1,
		empresaId: '',
		empresaNombre: '',
		paqueteId: '',
		areaInfo: null,
		file: null,
		importId: '',
		headers: [],
		campos: {},
		mapeoSugerido: {},
		preview: null,
		procesando: false,
		resultadosAcumulados: [],
		usuariosCreados: [],
	};

	var importEmpresaTS = null;
	var importAreaTS = null;

	$( document ).ready( function () {
		if ( ! $( '#au-wms-import-overlay' ).length ) {
			return;
		}

		initModalTriggers();
		initStep1();
		initStep2();
		initFooterNavigation();
		initCredencialesActions();
	} );

	/**
	 * Abre/cierra el modal y cablea el botón principal "Importar usuarios".
	 */
	function initModalTriggers() {
		$( '#au-wms-btn-importar' ).on( 'click', function () {
			resetWizard();
			$( '#au-wms-import-overlay' ).addClass( 'is-open' );
		} );

		$( '#au-wms-import-close, #au-wms-import-btn-cancelar' ).on( 'click', function () {
			solicitarCierre();
		} );

		// Cerrar al hacer clic fuera del contenido del modal (en el overlay).
		$( '#au-wms-import-overlay' ).on( 'click', function ( event ) {
			if ( event.target === this ) {
				solicitarCierre();
			}
		} );
	}

	/**
	 * Pide confirmación antes de cerrar si ya hay progreso en el
	 * asistente (a partir del paso 2).
	 */
	function solicitarCierre() {
		if ( wizard.step <= 1 ) {
			cerrarModal();
			return;
		}

		Swal.fire( {
			title: AU_WMS.i18n.importConfirmCancelTitle,
			text: AU_WMS.i18n.importConfirmCancelText,
			icon: 'warning',
			showCancelButton: true,
			confirmButtonText: AU_WMS.i18n.confirmDeleteButton,
			cancelButtonText: AU_WMS.i18n.cancelButton,
			customClass: { confirmButton: 'au-wms-swal-danger' },
			reverseButtons: true,
		} ).then( function ( result ) {
			if ( result.isConfirmed ) {
				cerrarModal();
			}
		} );
	}

	function cerrarModal() {
		$( '#au-wms-import-overlay' ).removeClass( 'is-open' );
		if ( wizard.procesando ) {
			// Si se cerró tras terminar una importación, refresca la tabla.
			if ( 'function' === typeof window.AU_WMS_refrescarTabla ) {
				window.AU_WMS_refrescarTabla();
			}
		}
	}

	/**
	 * Reinicia todo el estado del asistente y vuelve al paso 1.
	 */
	function resetWizard() {
		wizard = {
			step: 1,
			empresaId: '',
			empresaNombre: '',
			paqueteId: '',
			areaInfo: null,
			file: null,
			importId: '',
			headers: [],
			campos: {},
			mapeoSugerido: {},
			preview: null,
			procesando: false,
			resultadosAcumulados: [],
			usuariosCreados: [],
		};

		$( '#au-wms-import-area-info' ).hide();
		$( '#au-wms-import-file-selected' ).hide();
		$( '#au-wms-import-dropzone' ).show();
		$( '#au-wms-import-file-input' ).val( '' );
		$( '#au-wms-import-mapping-body' ).empty();
		$( '#au-wms-import-cupos-warning' ).hide().empty();
		$( '#au-wms-import-progress-fill' ).css( 'width', '0%' );
		$( '#au-wms-import-final-summary' ).hide().empty();
		$( '#au-wms-import-credenciales' ).hide();
		$( '#au-wms-import-credenciales-body' ).empty();

		if ( importEmpresaTS ) {
			importEmpresaTS.clear( true );
		}
		if ( importAreaTS ) {
			importAreaTS.clear( true );
			importAreaTS.clearOptions();
			importAreaTS.disable();
		}

		irAPaso( 1 );
	}

	/**
	 * Paso 1: selección de Empresa y Área, con resumen de cupos.
	 */
	function initStep1() {
		importEmpresaTS = new TomSelect( '#au-wms-import-empresa', {
			placeholder: AU_WMS.i18n.allCompanies,
		} );

		importAreaTS = new TomSelect( '#au-wms-import-area', {
			placeholder: AU_WMS.i18n.selectCompanyFirst,
		} );

		importEmpresaTS.on( 'change', function ( empresaId ) {
			wizard.empresaId = empresaId;
			wizard.empresaNombre = ( empresaId && importEmpresaTS.options[ empresaId ] ) ? importEmpresaTS.options[ empresaId ].text : '';
			wizard.paqueteId = '';
			wizard.areaInfo = null;
			$( '#au-wms-import-area-info' ).hide();

			importAreaTS.clear( true );
			importAreaTS.clearOptions();

			if ( ! empresaId ) {
				importAreaTS.disable();
				return;
			}

			importAreaTS.addOption( { value: '', text: AU_WMS.i18n.loading } );
			importAreaTS.disable();

			$.post( AU_WMS.ajaxUrl, {
				action: 'au_wms_get_paquetes',
				nonce: AU_WMS.nonce,
				empresa_id: empresaId,
			} ).done( function ( response ) {
				importAreaTS.clearOptions();

				if ( ! response || ! response.success ) {
					mostrarErrorSwal( response && response.data ? response.data.message : AU_WMS.i18n.genericError );
					return;
				}

				response.data.paquetes.forEach( function ( paquete ) {
					importAreaTS.addOption( { value: String( paquete.id ), text: paquete.nombre } );
				} );

				importAreaTS.refreshOptions( false );
				importAreaTS.enable();
			} );
		} );

		importAreaTS.on( 'change', function ( paqueteId ) {
			wizard.paqueteId = paqueteId;

			if ( ! paqueteId ) {
				$( '#au-wms-import-area-info' ).hide();
				return;
			}

			$.post( AU_WMS.ajaxUrl, {
				action: 'au_wms_import_area_info',
				nonce: AU_WMS.nonce,
				paquete_id: paqueteId,
			} ).done( function ( response ) {
				if ( ! response || ! response.success ) {
					mostrarErrorSwal( response && response.data ? response.data.message : AU_WMS.i18n.genericError );
					return;
				}

				wizard.areaInfo = response.data.area;

				$( '#au-wms-import-area-nombre' ).text( wizard.areaInfo.nombre );
				$( '#au-wms-import-area-cupos' ).text(
					' — ' + wizard.areaInfo.utilizados + ' / ' + wizard.areaInfo.cupo + ' ' + AU_WMS.i18n.importCuposUsados
				);
				$( '#au-wms-import-area-info' ).show();
			} );
		} );
	}

	/**
	 * Paso 2: dropzone de subida de archivo (click y drag & drop).
	 */
	function initStep2() {
		var $dropzone = $( '#au-wms-import-dropzone' );
		var $fileInput = $( '#au-wms-import-file-input' );

		$dropzone.on( 'click', function () {
			$fileInput.get( 0 ).click();
		} );

		$dropzone.on( 'dragover', function ( event ) {
			event.preventDefault();
			$dropzone.addClass( 'is-dragover' );
		} );

		$dropzone.on( 'dragleave', function () {
			$dropzone.removeClass( 'is-dragover' );
		} );

		$dropzone.on( 'drop', function ( event ) {
			event.preventDefault();
			$dropzone.removeClass( 'is-dragover' );

			var files = event.originalEvent.dataTransfer.files;
			if ( files && files.length ) {
				seleccionarArchivo( files[ 0 ] );
			}
		} );

		$fileInput.on( 'change', function () {
			if ( this.files && this.files.length ) {
				seleccionarArchivo( this.files[ 0 ] );
			}
		} );

		$( '#au-wms-import-file-remove' ).on( 'click', function ( event ) {
			event.stopPropagation();
			wizard.file = null;
			$( '#au-wms-import-file-selected' ).hide();
			$( '#au-wms-import-dropzone' ).show();
			$fileInput.val( '' );
		} );
	}

	/**
	 * Guarda el archivo seleccionado y actualiza la vista previa del nombre.
	 *
	 * @param {File} file Archivo seleccionado.
	 */
	function seleccionarArchivo( file ) {
		var extension = file.name.split( '.' ).pop().toLowerCase();

		if ( [ 'csv', 'xls', 'xlsx' ].indexOf( extension ) === -1 ) {
			mostrarErrorSwal( AU_WMS.i18n.genericError );
			return;
		}

		wizard.file = file;
		$( '#au-wms-import-file-name' ).text( file.name );
		$( '#au-wms-import-dropzone' ).hide();
		$( '#au-wms-import-file-selected' ).show();
	}

	/**
	 * Cablea los botones del pie del modal (Atrás / Siguiente / Continuar / Finalizar).
	 */
	function initFooterNavigation() {
		$( '#au-wms-import-btn-atras' ).on( 'click', function () {
			irAPaso( wizard.step - 1 );
		} );

		$( '#au-wms-import-btn-siguiente' ).on( 'click', function () {
			avanzarDesdePaso( wizard.step );
		} );

		$( '#au-wms-import-btn-continuar' ).on( 'click', function () {
			irAPaso( 5 );
			iniciarProcesamiento();
		} );

		$( '#au-wms-import-btn-finalizar' ).on( 'click', function () {
			cerrarModal();
		} );
	}

	/**
	 * Ejecuta la validación/acción correspondiente al paso actual antes
	 * de avanzar al siguiente.
	 *
	 * @param {number} paso Paso actual.
	 */
	function avanzarDesdePaso( paso ) {
		if ( 1 === paso ) {
			if ( ! wizard.empresaId || ! wizard.paqueteId ) {
				mostrarErrorSwal( AU_WMS.i18n.importSelectCompanyArea );
				return;
			}
			irAPaso( 2 );
			return;
		}

		if ( 2 === paso ) {
			if ( ! wizard.file ) {
				mostrarErrorSwal( AU_WMS.i18n.importNoFile );
				return;
			}
			subirArchivo();
			return;
		}

		if ( 3 === paso ) {
			var mapping = leerMapeoActual();

			if ( '' === mapping.correo ) {
				mostrarErrorSwal( AU_WMS.i18n.importMappingRequired );
				return;
			}

			validarImportacion( mapping );
		}
	}

	/**
	 * Sube el archivo seleccionado vía AJAX (multipart/form-data) y, si
	 * el análisis es exitoso, construye la tabla de mapeo del paso 3.
	 */
	function subirArchivo() {
		mostrarCargandoSwal( AU_WMS.i18n.importUploading );

		var formData = new FormData();
		formData.append( 'action', 'au_wms_import_upload' );
		formData.append( 'nonce', AU_WMS.nonce );
		formData.append( 'archivo', wizard.file );

		$.ajax( {
			url: AU_WMS.ajaxUrl,
			type: 'POST',
			data: formData,
			processData: false,
			contentType: false,
		} )
			.done( function ( response ) {
				Swal.close();

				if ( ! response || ! response.success ) {
					mostrarErrorSwal( response && response.data ? response.data.message : AU_WMS.i18n.genericError );
					return;
				}

				wizard.importId = response.data.import_id;
				wizard.headers = response.data.headers;
				wizard.campos = response.data.campos;
				wizard.mapeoSugerido = response.data.mapeo_sugerido;

				construirTablaMapeo();
				irAPaso( 3 );
			} )
			.fail( function () {
				Swal.close();
				mostrarErrorSwal( AU_WMS.i18n.genericError );
			} );
	}

	/**
	 * Construye la tabla de mapeo de columnas del paso 3 a partir de los
	 * encabezados detectados y la sugerencia automática.
	 */
	function construirTablaMapeo() {
		var $body = $( '#au-wms-import-mapping-body' );
		$body.empty();

		Object.keys( wizard.campos ).forEach( function ( campo ) {
			var esObligatorio = 'correo' === campo;
			var sugerido = wizard.mapeoSugerido[ campo ];

			var $select = $( '<select class="au-wms-select au-wms-import-mapping-select" data-campo="' + campo + '"></select>' );

			if ( ! esObligatorio ) {
				$select.append( '<option value="">' + AU_WMS.i18n.selectColumnPlaceholder + '</option>' );
			}

			wizard.headers.forEach( function ( header, indice ) {
				var seleccionado = ( null !== sugerido && parseInt( sugerido, 10 ) === indice ) ? ' selected' : '';
				$select.append( '<option value="' + indice + '"' + seleccionado + '>' + $( '<div>' ).text( header ).html() + '</option>' );
			} );

			var etiqueta = wizard.campos[ campo ] + ( esObligatorio ? ' *' : '' );

			var $row = $( '<tr></tr>' );
			$row.append( '<td>' + $( '<div>' ).text( etiqueta ).html() + '</td>' );
			var $td = $( '<td></td>' );
			$td.append( $select );
			$row.append( $td );

			$body.append( $row );
		} );
	}

	/**
	 * Lee el mapeo campo => índice de columna configurado en la tabla.
	 *
	 * @return {Object}
	 */
	function leerMapeoActual() {
		var mapping = {};

		$( '.au-wms-import-mapping-select' ).each( function () {
			var campo = $( this ).data( 'campo' );
			mapping[ campo ] = $( this ).val();
		} );

		return mapping;
	}

	/**
	 * Ejecuta la validación previa (sin escribir en base de datos) y
	 * renderiza la previsualización del paso 4.
	 *
	 * @param {Object} mapping Mapeo campo => índice de columna.
	 */
	function validarImportacion( mapping ) {
		mostrarCargandoSwal( AU_WMS.i18n.importValidating );

		$.post( AU_WMS.ajaxUrl, {
			action: 'au_wms_import_validar',
			nonce: AU_WMS.nonce,
			import_id: wizard.importId,
			empresa_id: wizard.empresaId,
			paquete_id: wizard.paqueteId,
			mapping: mapping,
		} )
			.done( function ( response ) {
				Swal.close();

				if ( ! response || ! response.success ) {
					mostrarErrorSwal( response && response.data ? response.data.message : AU_WMS.i18n.genericError );
					return;
				}

				wizard.preview = response.data;
				renderPrevisualizacion( response.data );
				irAPaso( 4 );
			} )
			.fail( function () {
				Swal.close();
				mostrarErrorSwal( AU_WMS.i18n.genericError );
			} );
	}

	/**
	 * Renderiza los 3 (+1) bloques de la previsualización, el resumen
	 * numérico y la advertencia de cupos si aplica.
	 *
	 * @param {Object} data Respuesta de au_wms_import_validar.
	 */
	function renderPrevisualizacion( data ) {
		renderListaImport( '#au-wms-list-nuevos', data.nuevos, null );
		renderListaImport( '#au-wms-list-actualizar', data.actualizar, null );
		renderListaImport( '#au-wms-list-agregar-area', data.agregar_area, 'motivo' );
		renderListaImport( '#au-wms-list-omitidos', data.omitidos, 'motivo' );
		renderListaImport( '#au-wms-list-duplicados', data.duplicados, 'motivo' );

		$( '#au-wms-count-nuevos' ).text( data.resumen.nuevos );
		$( '#au-wms-count-actualizar' ).text( data.resumen.actualizar );
		$( '#au-wms-count-agregar-area' ).text( data.resumen.agregar_area );
		$( '#au-wms-count-omitidos' ).text( data.resumen.omitidos );
		$( '#au-wms-count-duplicados' ).text( data.resumen.duplicados );

		$( '#au-wms-import-group-duplicados' ).toggle( data.resumen.duplicados > 0 );

		$( '#au-wms-import-summary' ).html(
			'<strong>' + data.resumen.total + '</strong> ' +
			( AU_WMS.i18n.importSummaryTotal || 'registros procesados' )
		);

		var $warning = $( '#au-wms-import-cupos-warning' );
		var $continuar = $( '#au-wms-import-btn-continuar' );

		if ( data.bloqueado || data.parcial ) {
			var combinados = data.nuevos.concat( data.actualizar ).concat( data.agregar_area );
			var alcanzan = combinados.filter( function ( item ) {
				return false !== item.cabe_en_cupos;
			} ).length;
			var fuera = combinados.length - alcanzan;

			var mensaje = AU_WMS.i18n.importCuposExceeded + ' ' + data.faltan_cupos + ' ' + AU_WMS.i18n.importCupos + '.' +
				'<br>' + alcanzan + ' ' + AU_WMS.i18n.importAlcanzanImportar + ', ' +
				fuera + ' ' + AU_WMS.i18n.importQuedanFuera;

			if ( data.parcial ) {
				mensaje += '<br><strong>' + AU_WMS.i18n.importSoloDisponibles + '</strong>';
			}

			$warning.show().html( mensaje );
			$continuar.prop( 'disabled', data.bloqueado );
		} else {
			$warning.hide();
			$continuar.prop( 'disabled', false );
		}
	}

	/**
	 * Renderiza una lista de correos (con motivo opcional) dentro de un
	 * bloque de la previsualización.
	 *
	 * @param {string}      selector    Selector del <ul> destino.
	 * @param {Array}       items       Lista de filas (con al menos "correo").
	 * @param {string|null} campoMotivo Nombre del campo de motivo a mostrar, si aplica.
	 */
	function renderListaImport( selector, items, campoMotivo ) {
		var $ul = $( selector );
		$ul.empty();

		if ( ! items || ! items.length ) {
			$ul.append( '<li class="au-wms-import-list-empty">' + AU_WMS.i18n.importNoResults + '</li>' );
			return;
		}

		items.forEach( function ( item ) {
			var texto = item.correo;
			if ( campoMotivo && item[ campoMotivo ] ) {
				texto += ' — ' + item[ campoMotivo ];
			}

			var $li = $( '<li></li>' ).text( texto );

			if ( false === item.cabe_en_cupos ) {
				$li.addClass( 'au-wms-import-sin-cupo' ).append(
					' <span class="au-wms-import-sin-cupo-tag">' + AU_WMS.i18n.importSinCupo + '</span>'
				);
			}

			$ul.append( $li );
		} );
	}

	// Procesamiento uno por uno: cada llamada AJAX crea/actualiza un único
	// registro en vez de un lote, para evitar timeouts/errores parciales en
	// archivos grandes y dar feedback más granular por usuario.
	var BATCH_SIZE_MAX = 1;
	var lotesState = { batchSize: BATCH_SIZE_MAX, total: 0 };

	/**
	 * Inicia el procesamiento por lotes (paso 5) y actualiza la barra de
	 * progreso hasta completar la importación.
	 */
	function iniciarProcesamiento() {
		wizard.procesando = true;
		wizard.resultadosAcumulados = [];

		$( '#au-wms-import-btn-cancelar, #au-wms-import-btn-atras, #au-wms-import-btn-continuar' ).hide();
		$( '#au-wms-import-btn-finalizar' ).hide();
		$( '#au-wms-import-final-summary' ).hide().empty();

		// El total ya se conoce desde la previsualización (paso 4); no hay
		// que esperar a la primera respuesta AJAX para mostrarlo.
		var totalConocido = ( wizard.preview.resumen.nuevos || 0 ) + ( wizard.preview.resumen.actualizar || 0 ) + ( wizard.preview.resumen.agregar_area || 0 );
		lotesState.total = totalConocido;

		// Tamaño de lote fijo en 1: cada petición procesa un único registro.
		lotesState.batchSize = BATCH_SIZE_MAX;

		$( '#au-wms-import-progress-fill' ).css( 'width', '0%' );
		$( '#au-wms-import-progress-text' ).text( '0 / ' + totalConocido );

		procesarLote( 0 );
	}

	/**
	 * Procesa un lote y se llama a sí misma hasta que el backend
	 * reporte `done: true`.
	 *
	 * @param {number} offset Posición inicial del siguiente lote.
	 */
	function procesarLote( offset ) {
		$.post( AU_WMS.ajaxUrl, {
			action: 'au_wms_import_procesar_lote',
			nonce: AU_WMS.nonce,
			import_id: wizard.importId,
			offset: offset,
			batch_size: lotesState.batchSize,
		} )
			.done( function ( response ) {
				if ( ! response || ! response.success ) {
					mostrarErrorSwal( response && response.data ? response.data.message : AU_WMS.i18n.genericError );
					finalizarProcesamiento();
					return;
				}

				wizard.resultadosAcumulados = wizard.resultadosAcumulados.concat( response.data.results );

				var porcentaje = response.data.total > 0 ? Math.round( ( response.data.offset / response.data.total ) * 100 ) : 100;
				$( '#au-wms-import-progress-fill' ).css( 'width', porcentaje + '%' );
				$( '#au-wms-import-progress-text' ).text( response.data.offset + ' / ' + response.data.total );

				if ( response.data.done ) {
					finalizarProcesamiento();
					return;
				}

				procesarLote( response.data.offset );
			} )
			.fail( function () {
				mostrarErrorSwal( AU_WMS.i18n.genericError );
				finalizarProcesamiento();
			} );
	}

	/**
	 * Muestra el resumen final (creados, actualizados, errores) al
	 * terminar el procesamiento por lotes.
	 */
	function finalizarProcesamiento() {
		var creados = 0;
		var actualizados = 0;
		var areasAgregadas = 0;
		var sinCupo = 0;
		var errores = 0;

		wizard.resultadosAcumulados.forEach( function ( item ) {
			if ( 'creado' === item.status ) {
				creados++;
			} else if ( 'actualizado' === item.status ) {
				actualizados++;
			} else if ( 'area_agregada' === item.status ) {
				areasAgregadas++;
			} else if ( 'sin_cupo' === item.status ) {
				sinCupo++;
			} else {
				errores++;
			}
		} );

		var html = '<h3>' + AU_WMS.i18n.importDoneTitle + '</h3>';
		html += '<ul class="au-wms-import-final-list">';
		html += '<li class="au-wms-import-final-ok">' + creados + ' ' + ( AU_WMS.i18n.importCreados || 'creados correctamente' ) + '</li>';
		html += '<li class="au-wms-import-final-ok">' + actualizados + ' ' + ( AU_WMS.i18n.importActualizados || 'actualizados correctamente' ) + '</li>';
		if ( areasAgregadas > 0 ) {
			html += '<li class="au-wms-import-final-ok">' + areasAgregadas + ' ' + ( AU_WMS.i18n.importAreasAgregadas || 'agregados a esta área' ) + '</li>';
		}
		if ( sinCupo > 0 ) {
			html += '<li class="au-wms-import-final-warning">' + sinCupo + ' ' + AU_WMS.i18n.importSinCupoFinal + '</li>';
		}
		if ( errores > 0 ) {
			html += '<li class="au-wms-import-final-error">' + errores + ' ' + ( AU_WMS.i18n.importErrores || 'con errores' ) + '</li>';
		}
		html += '</ul>';

		$( '#au-wms-import-final-summary' ).html( html ).show();
		$( '#au-wms-import-btn-finalizar' ).show();

		renderCredencialesCreados( obtenerUsuariosCreadosConPassword() );
	}

	/**
	 * Extrae, de los resultados acumulados de ESTA importación, solo los
	 * usuarios que se crearon exitosamente (status "creado") y que
	 * traen la contraseña que el sistema les asignó — nunca se
	 * regenera aquí, es exactamente la que devolvió el backend al
	 * crear la cuenta.
	 *
	 * @return {Array<{email:string,password:string}>}
	 */
	function obtenerUsuariosCreadosConPassword() {
		return wizard.resultadosAcumulados
			.filter( function ( item ) {
				return 'creado' === item.status && item.password;
			} )
			.map( function ( item ) {
				return { email: item.email, password: item.password };
			} );
	}

	/**
	 * Renderiza (o esconde, si no hay usuarios creados) el bloque de
	 * credenciales del paso 5: la tabla Correo/Contraseña y los botones
	 * "Copiar al portapapeles" / "Descargar Excel".
	 *
	 * @param {Array<{email:string,password:string}>} creados Usuarios creados en esta importación.
	 */
	function renderCredencialesCreados( creados ) {
		wizard.usuariosCreados = creados;

		var $bloque = $( '#au-wms-import-credenciales' );
		var $body = $( '#au-wms-import-credenciales-body' );
		$body.empty();

		if ( ! creados.length ) {
			$bloque.hide();
			return;
		}

		creados.forEach( function ( item ) {
			var $row = $( '<tr></tr>' );
			$row.append( $( '<td></td>' ).text( item.email ) );
			$row.append(
				$( '<td class="au-wms-import-credenciales-password"></td>' ).text( item.password )
			);
			$body.append( $row );
		} );

		$bloque.show();
	}

	/**
	 * Cablea los botones "Copiar al portapapeles" y "Descargar Excel"
	 * del bloque de credenciales (paso 5).
	 */
	function initCredencialesActions() {
		$( '#au-wms-import-btn-copiar' ).on( 'click', copiarCredencialesAlPortapapeles );
		$( '#au-wms-import-btn-excel' ).on( 'click', descargarExcelCredenciales );
	}

	/**
	 * Copia la lista de correos/contraseñas de los usuarios creados en
	 * esta importación al portapapeles, en un formato de texto plano
	 * fácil de pegar (una entrada por cada correo + contraseña).
	 */
	function copiarCredencialesAlPortapapeles() {
		var creados = wizard.usuariosCreados || [];

		if ( ! creados.length ) {
			return;
		}

		var correoLabel = AU_WMS.i18n.importCredencialesCorreoLabel || 'Correo';
		var passwordLabel = AU_WMS.i18n.importCredencialesPasswordLabel || 'Contraseña';

		var texto = creados
			.map( function ( item ) {
				return correoLabel + ': ' + item.email + '\n' + passwordLabel + ': ' + item.password;
			} )
			.join( '\n\n' );

		copiarTexto( texto )
			.then( function () {
				Swal.fire( {
					icon: 'success',
					title: AU_WMS.i18n.importCredencialesCopiadoOk,
					timer: 2200,
					showConfirmButton: false,
				} );
			} )
			.catch( function () {
				mostrarErrorSwal( AU_WMS.i18n.importCredencialesCopiadoError );
			} );
	}

	/**
	 * Copia un texto al portapapeles, usando la Clipboard API cuando
	 * está disponible (contexto seguro/HTTPS) y una alternativa con
	 * `document.execCommand('copy')` como respaldo para navegadores o
	 * contextos donde no lo esté.
	 *
	 * @param {string} texto Texto a copiar.
	 * @return {Promise}
	 */
	function copiarTexto( texto ) {
		if ( navigator.clipboard && navigator.clipboard.writeText ) {
			return navigator.clipboard.writeText( texto );
		}

		return new Promise( function ( resolve, reject ) {
			var $textarea = $( '<textarea readonly></textarea>' )
				.css( { position: 'fixed', top: '-1000px', left: '-1000px' } )
				.val( texto );

			$( 'body' ).append( $textarea );
			$textarea.get( 0 ).select();

			var exito = false;
			try {
				exito = document.execCommand( 'copy' );
			} catch ( error ) {
				exito = false;
			}

			$textarea.remove();

			if ( exito ) {
				resolve();
			} else {
				reject();
			}
		} );
	}

	/**
	 * Genera y descarga un archivo .xlsx real (OOXML, vía SheetJS) con
	 * los usuarios creados en esta importación. El nombre del archivo
	 * se arma dinámicamente a partir de la Empresa y el Área/Paquete
	 * seleccionados en el paso 1, sanitizado para ser válido en
	 * Windows y otros sistemas operativos.
	 */
	function descargarExcelCredenciales() {
		var creados = wizard.usuariosCreados || [];

		if ( ! creados.length || 'undefined' === typeof XLSX ) {
			return;
		}

		var correoCol = AU_WMS.i18n.importCredencialesColCorreo;
		var passwordCol = AU_WMS.i18n.importCredencialesColPassword;
		var areaCol = AU_WMS.i18n.importCredencialesColArea;
		var areaNombre = ( wizard.areaInfo && wizard.areaInfo.nombre ) || '';

		var filas = creados.map( function ( item ) {
			var fila = {};
			fila[ correoCol ] = item.email;
			fila[ passwordCol ] = item.password;
			fila[ areaCol ] = areaNombre;
			return fila;
		} );

		var hoja = XLSX.utils.json_to_sheet( filas );
		hoja[ '!cols' ] = [ { wch: 34 }, { wch: 16 }, { wch: 24 } ];

		var libro = XLSX.utils.book_new();
		XLSX.utils.book_append_sheet( libro, hoja, 'Usuarios' );

		XLSX.writeFile( libro, construirNombreArchivoExcel() );
	}

	/**
	 * Arma el nombre del archivo Excel a partir de la Empresa y el
	 * Área/Paquete seleccionados ("Empresa_{empresa}_Area_{area}.xlsx"),
	 * sanitizando ambos nombres.
	 *
	 * @return {string}
	 */
	function construirNombreArchivoExcel() {
		var empresa = sanitizarNombreArchivo(
			wizard.empresaNombre || AU_WMS.i18n.importCredencialesEmpresaFallback
		);
		var area = sanitizarNombreArchivo(
			( wizard.areaInfo && wizard.areaInfo.nombre ) || ''
		);

		var partes = [ 'Empresa_' + empresa ];
		if ( area ) {
			partes.push( 'Area_' + area );
		}

		return partes.join( '_' ) + '.xlsx';
	}

	/**
	 * Sanitiza un fragmento para usarlo en un nombre de archivo:
	 * elimina caracteres inválidos en Windows (\ / : * ? " < > |) y
	 * otros no imprimibles, y reemplaza espacios por guiones bajos.
	 *
	 * @param {string} texto Texto original.
	 * @return {string}
	 */
	function sanitizarNombreArchivo( texto ) {
		return String( texto || '' )
			.replace( /[\\/:*?"<>|]/g, '' )
			.replace( /\s+/g, '_' )
			.replace( /_{2,}/g, '_' )
			.replace( /^_+|_+$/g, '' );
	}

	/**
	 * Navega a un paso específico del asistente (1-5), mostrando el
	 * panel correspondiente y ajustando los botones del pie.
	 *
	 * @param {number} paso Número de paso destino.
	 */
	function irAPaso( paso ) {
		wizard.step = paso;

		$( '.au-wms-import-panel' ).removeClass( 'is-active' );
		$( '.au-wms-import-panel[data-step-panel="' + paso + '"]' ).addClass( 'is-active' );

		$( '.au-wms-import-step-dot' ).removeClass( 'is-active is-done' );
		$( '.au-wms-import-step-dot' ).each( function () {
			var dotStep = parseInt( $( this ).data( 'step' ), 10 );
			if ( dotStep < paso ) {
				$( this ).addClass( 'is-done' );
			} else if ( dotStep === paso ) {
				$( this ).addClass( 'is-active' );
			}
		} );

		var $atras = $( '#au-wms-import-btn-atras' );
		var $siguiente = $( '#au-wms-import-btn-siguiente' );
		var $continuar = $( '#au-wms-import-btn-continuar' );
		var $finalizar = $( '#au-wms-import-btn-finalizar' );
		var $cancelar = $( '#au-wms-import-btn-cancelar' );

		$atras.toggle( paso > 1 && paso < 5 );
		$cancelar.toggle( paso < 5 );
		$siguiente.toggle( paso <= 3 );
		$continuar.toggle( 4 === paso );
		$finalizar.toggle( false );
	}

	/**
	 * Muestra un SweetAlert de "cargando" con overlay bloqueante.
	 *
	 * @param {string} titulo Texto a mostrar.
	 */
	function mostrarCargandoSwal( titulo ) {
		Swal.fire( {
			title: titulo,
			allowOutsideClick: false,
			didOpen: function () {
				Swal.showLoading();
			},
		} );
	}

	/**
	 * Muestra un error mediante SweetAlert2.
	 *
	 * @param {string} mensaje Mensaje a mostrar.
	 */
	function mostrarErrorSwal( mensaje ) {
		Swal.fire( {
			icon: 'error',
			title: mensaje || AU_WMS.i18n.genericError,
		} );
	}
} )( jQuery );
