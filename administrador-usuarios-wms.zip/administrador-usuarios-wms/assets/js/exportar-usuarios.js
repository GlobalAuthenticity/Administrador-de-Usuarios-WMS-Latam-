/**
 * Modal "Exportar usuarios" (Tab Empresas): wizard de 2 pasos —
 * 1) Seleccionar áreas  2) Previsualización y exportación a Excel.
 *
 * El Excel se genera 100% en el navegador vía SheetJS, con los datos
 * ya devueltos ordenados por área (alfabético) por el propio backend
 * (`AU_Repository_Usuarios::buscar_para_exportar()`), así que no hace
 * falta reordenar nada en el cliente.
 *
 * @package Administrador_Usuarios_WMS
 */

( function ( $ ) {
	'use strict';

	var wizard = {
		empresaId: '',
		empresaNombre: '',
		step: 1,
		areas: [],
		usuarios: [],
		cargandoListado: false,
	};

	$( document ).ready( function () {
		initTriggers();
		initToolbar();
		initFooterNavigation();

		window.AU_WMS_abrirModalExportarUsuarios = abrirModal;
	} );

	/**
	 * Cierre del modal (botón X, "Cancelar" y clic fuera del contenido).
	 * A diferencia de "Resetear contraseñas", esta acción es de solo
	 * lectura, así que se cierra directo sin pedir confirmación.
	 */
	function initTriggers() {
		$( '#au-wms-export-users-close, #au-wms-export-users-btn-cancelar' ).on( 'click', function () {
			cerrarModal();
		} );

		$( '#au-wms-export-users-overlay' ).on( 'click', function ( event ) {
			if ( event.target === this ) {
				cerrarModal();
			}
		} );
	}

	function cerrarModal() {
		$( '#au-wms-export-users-overlay' ).removeClass( 'is-open' );
	}

	/**
	 * Abre el modal para una empresa concreta y arranca la carga del
	 * Paso 1 (listado de áreas).
	 *
	 * @param {number} empresaId     ID de la empresa (usuario `company`).
	 * @param {string} empresaNombre Nombre a mostrar en el encabezado.
	 */
	function abrirModal( empresaId, empresaNombre ) {
		wizard = {
			empresaId: empresaId,
			empresaNombre: empresaNombre || '',
			step: 1,
			areas: [],
			usuarios: [],
			cargandoListado: false,
		};

		$( '#au-wms-export-users-empresa-nombre' ).text( wizard.empresaNombre );
		$( '#au-wms-export-users-preview-body' ).empty();
		$( '#au-wms-export-users-resumen' ).empty();
		$( '#au-wms-export-users-check-all' ).prop( { checked: false, indeterminate: false } );

		irAPaso( 1 );
		actualizarContadorYBoton();

		$( '#au-wms-export-users-overlay' ).addClass( 'is-open' );

		cargarAreas();
	}

	/**
	 * Cambia de panel visible dentro del modal y actualiza los puntos
	 * de progreso y los botones del footer.
	 *
	 * @param {number} paso Paso destino (1-2).
	 */
	function irAPaso( paso ) {
		wizard.step = paso;

		$( '.au-wms-import-panel' ).removeClass( 'is-active' );
		$( '.au-wms-import-panel[data-step-panel="' + paso + '"]' ).addClass( 'is-active' );

		$( '.au-wms-import-step-dot' ).each( function () {
			var dotStep = parseInt( $( this ).data( 'step' ), 10 );
			$( this ).toggleClass( 'is-active', dotStep === paso );
			$( this ).toggleClass( 'is-done', dotStep < paso );
		} );

		var $atras = $( '#au-wms-export-users-btn-atras' );
		var $cancelar = $( '#au-wms-export-users-btn-cancelar' );
		var $siguiente = $( '#au-wms-export-users-btn-siguiente' );
		var $exportar = $( '#au-wms-export-users-btn-exportar' );

		$atras.hide();
		$cancelar.hide();
		$siguiente.hide();
		$exportar.hide();

		if ( 1 === paso ) {
			$cancelar.show();
			$siguiente.show();
		} else if ( 2 === paso ) {
			$atras.show();
			$cancelar.show();
			$exportar.show();
		}
	}

	/**
	 * Carga las áreas/paquetes de la empresa y arma la tabla de
	 * checkboxes del Paso 1 (todas preseleccionadas).
	 */
	function cargarAreas() {
		var $body = $( '#au-wms-export-users-areas-body' );
		$body.html(
			'<tr class="au-wms-row-loading"><td colspan="2"><div class="au-wms-spinner"></div>' +
			AU_WMS.i18n.loading + '</td></tr>'
		);

		$.post( AU_WMS.ajaxUrl, {
			action: 'au_wms_exportar_usuarios_areas',
			nonce: AU_WMS.nonce,
			empresa_id: wizard.empresaId,
		} )
			.done( function ( response ) {
				if ( ! response || ! response.success ) {
					$body.html(
						'<tr class="au-wms-row-empty"><td colspan="2">' +
						( response && response.data ? response.data.message : AU_WMS.i18n.genericError ) +
						'</td></tr>'
					);
					return;
				}

				wizard.areas = response.data.areas || [];
				renderTablaAreas();
			} )
			.fail( function () {
				$body.html( '<tr class="au-wms-row-empty"><td colspan="2">' + AU_WMS.i18n.genericError + '</td></tr>' );
			} );
	}

	/**
	 * Renderiza la tabla de áreas del Paso 1, con cada checkbox
	 * marcado por defecto.
	 */
	function renderTablaAreas() {
		var $body = $( '#au-wms-export-users-areas-body' );
		$body.empty();

		if ( ! wizard.areas.length ) {
			var emptyTemplate = document.getElementById( 'au-wms-export-users-areas-empty-template' );
			$body.append( document.importNode( emptyTemplate.content, true ) );
			actualizarEstadoCheckAll();
			actualizarContadorYBoton();
			return;
		}

		var template = document.getElementById( 'au-wms-export-users-area-row-template' );

		wizard.areas.forEach( function ( area ) {
			var $row = $( document.importNode( template.content, true ) );
			var $tr = $row.filter( 'tr' ).length ? $row.filter( 'tr' ) : $row.find( 'tr' );

			$tr.attr( 'data-area-id', area.id );
			$tr.find( '.au-wms-export-users-area-nombre' ).text( area.nombre );

			var $checkbox = $tr.find( '.au-wms-export-users-area-checkbox' );
			$checkbox.prop( 'checked', true );

			$checkbox.on( 'change', function () {
				actualizarEstadoCheckAll();
				actualizarContadorYBoton();
			} );

			$body.append( $tr );
		} );

		actualizarEstadoCheckAll();
		actualizarContadorYBoton();
	}

	/**
	 * Wiring del checkbox "Seleccionar todos / Deseleccionar todos"
	 * del Paso 1.
	 */
	function initToolbar() {
		$( '#au-wms-export-users-check-all' ).on( 'change', function () {
			var marcar = $( this ).is( ':checked' );

			$( '.au-wms-export-users-area-checkbox' ).prop( 'checked', marcar );

			actualizarEstadoCheckAll();
			actualizarContadorYBoton();
		} );
	}

	/**
	 * Refleja en el checkbox "Seleccionar todos" si todas, ninguna o
	 * solo algunas de las áreas están marcadas.
	 */
	function actualizarEstadoCheckAll() {
		var $checkAll = $( '#au-wms-export-users-check-all' );
		var $checkboxes = $( '.au-wms-export-users-area-checkbox' );

		if ( ! $checkboxes.length ) {
			$checkAll.prop( { checked: false, indeterminate: false, disabled: true } );
			$( '#au-wms-export-users-check-all-label' ).text( AU_WMS.i18n.resetPwdSeleccionarTodos );
			return;
		}

		$checkAll.prop( 'disabled', false );

		var total = $checkboxes.length;
		var marcados = $checkboxes.filter( ':checked' ).length;

		$checkAll.prop( {
			checked: marcados === total,
			indeterminate: marcados > 0 && marcados < total,
		} );

		$( '#au-wms-export-users-check-all-label' ).text(
			marcados === total ? AU_WMS.i18n.resetPwdDeseleccionarTodos : AU_WMS.i18n.resetPwdSeleccionarTodos
		);
	}

	/**
	 * Actualiza el contador "N áreas seleccionadas" y habilita/
	 * deshabilita "Siguiente".
	 */
	function actualizarContadorYBoton() {
		var total = leerAreaIdsSeleccionadas().length;

		$( '#au-wms-export-users-contador' ).text( total + ' ' + AU_WMS.i18n.exportUsersAreasSeleccionadas );
		$( '#au-wms-export-users-btn-siguiente' ).prop( 'disabled', 0 === total );
	}

	/**
	 * Lee directamente del DOM los IDs de las áreas actualmente
	 * marcadas en el Paso 1.
	 *
	 * @return {Array<number>}
	 */
	function leerAreaIdsSeleccionadas() {
		return $( '.au-wms-export-users-area-checkbox:checked' )
			.map( function () {
				return parseInt( $( this ).closest( 'tr' ).data( 'area-id' ), 10 );
			} )
			.get();
	}

	/**
	 * Wiring de la navegación del footer (Siguiente / Atrás / Exportar).
	 */
	function initFooterNavigation() {
		$( '#au-wms-export-users-btn-siguiente' ).on( 'click', function () {
			var areaIds = leerAreaIdsSeleccionadas();

			if ( ! areaIds.length || wizard.cargandoListado ) {
				return;
			}

			cargarUsuariosYPrevisualizar( areaIds );
		} );

		$( '#au-wms-export-users-btn-atras' ).on( 'click', function () {
			irAPaso( 1 );
		} );

		$( '#au-wms-export-users-btn-exportar' ).on( 'click', exportarExcel );
	}

	/**
	 * Pide al backend el listado de usuarios de las áreas
	 * seleccionadas (ya ordenado por área) y, con la respuesta,
	 * arma la previsualización del Paso 2.
	 *
	 * @param {Array<number>} areaIds IDs de área marcados en el Paso 1.
	 */
	function cargarUsuariosYPrevisualizar( areaIds ) {
		wizard.cargandoListado = true;

		var $siguiente = $( '#au-wms-export-users-btn-siguiente' );
		var textoOriginal = $siguiente.data( 'texto-original' ) || $siguiente.text();
		$siguiente.data( 'texto-original', textoOriginal );
		$siguiente.prop( 'disabled', true ).text( AU_WMS.i18n.loading );

		$.post( AU_WMS.ajaxUrl, {
			action: 'au_wms_exportar_usuarios_listar',
			nonce: AU_WMS.nonce,
			empresa_id: wizard.empresaId,
			paquete_ids: areaIds,
		} )
			.done( function ( response ) {
				if ( ! response || ! response.success ) {
					mostrarErrorSwal(
						( response && response.data && response.data.message ) || AU_WMS.i18n.genericError
					);
					return;
				}

				wizard.usuarios = response.data.usuarios || [];
				renderPaso2();
				irAPaso( 2 );
			} )
			.fail( function () {
				mostrarErrorSwal( AU_WMS.i18n.genericError );
			} )
			.always( function () {
				wizard.cargandoListado = false;
				$siguiente.prop( 'disabled', false ).text( textoOriginal );
			} );
	}

	/**
	 * Arma la previsualización del Paso 2: una fila por área
	 * seleccionada con el número de usuarios que se exportarán, más
	 * el resumen y el total general.
	 */
	function renderPaso2() {
		var $body = $( '#au-wms-export-users-preview-body' );
		$body.empty();

		var conteoPorArea = {};
		var ordenAreas = [];

		wizard.usuarios.forEach( function ( usuario ) {
			var nombreArea = usuario.area_nombre || AU_WMS.i18n.exportUsersAreaSinNombre;

			if ( ! conteoPorArea.hasOwnProperty( nombreArea ) ) {
				conteoPorArea[ nombreArea ] = 0;
				ordenAreas.push( nombreArea );
			}

			conteoPorArea[ nombreArea ]++;
		} );

		var template = document.getElementById( 'au-wms-export-users-preview-row-template' );

		// `ordenAreas` conserva el orden en que aparecen por primera
		// vez en `wizard.usuarios`, que ya viene alfabético por área
		// desde el backend (ver buscar_para_exportar()).
		ordenAreas.forEach( function ( nombreArea ) {
			var $row = $( document.importNode( template.content, true ) );
			var $tr = $row.filter( 'tr' ).length ? $row.filter( 'tr' ) : $row.find( 'tr' );

			$tr.find( '.au-wms-export-users-preview-area' ).text( nombreArea );
			$tr.find( '.au-wms-export-users-preview-total' ).text( conteoPorArea[ nombreArea ] );

			$body.append( $tr );
		} );

		if ( ! ordenAreas.length ) {
			$body.html(
				'<tr class="au-wms-row-empty"><td colspan="2">' +
				AU_WMS.i18n.exportUsersSinUsuarios +
				'</td></tr>'
			);
		}

		var resumen = AU_WMS.i18n.exportUsersResumen
			.replace( '{N}', wizard.usuarios.length )
			.replace( '{AREAS}', ordenAreas.length );

		$( '#au-wms-export-users-resumen' ).text( resumen );
	}

	/**
	 * Colores de marca WMS Latam (mismos tokens que `assets/css/admin.css`)
	 * reutilizados aquí para que el Excel exportado se sienta parte del
	 * mismo sistema de diseño que el resto del panel.
	 */
	var EXCEL_COLOR_NAVY = '131A1E';
	var EXCEL_COLOR_YELLOW = 'F7F05E';
	var EXCEL_COLOR_ON_YELLOW = '0B0F0E';
	var EXCEL_COLOR_WHITE = 'FFFFFF';
	var EXCEL_COLOR_BANDA_A = 'FFFFFF';
	var EXCEL_COLOR_BANDA_B = 'F8FAFC';
	var EXCEL_COLOR_BORDE = 'E2E8F0';
	var EXCEL_COLOR_TEST_OK_BG = 'DCFCE7';
	var EXCEL_COLOR_TEST_OK_TEXT = '16A34A';
	var EXCEL_COLOR_TEST_SIN_BG = 'F8FAFC';
	var EXCEL_COLOR_TEST_SIN_TEXT = '64748B';
	var EXCEL_COLOR_PERFIL_OK_BG = 'DCFCE7';
	var EXCEL_COLOR_PERFIL_OK_TEXT = '16A34A';
	var EXCEL_COLOR_PERFIL_INCOMPLETO_BG = 'FEE2E2';
	var EXCEL_COLOR_PERFIL_INCOMPLETO_TEXT = 'DC2626';

	/**
	 * Genera y descarga el .xlsx (vía SheetJS + estilos) con el listado
	 * completo de `wizard.usuarios`: correo, nombre, área, estado del
	 * perfil y estado del test. El orden de filas es el mismo que
	 * devolvió el backend (por área, alfabético), sin reordenar nada
	 * en el cliente.
	 *
	 * Formato: fila de título (fusionada, en amarillo de marca) + fila
	 * de encabezado (navy/blanco) + filas de datos con una banda de
	 * color alterna cada vez que cambia el área (para que el
	 * agrupamiento por área salte a la vista), la celda "Perfil"
	 * coloreada en verde/rojo y la celda "Test" en verde/gris según
	 * corresponda (mismos colores que usan sus respectivos badges en
	 * el Tab Integrantes / "Resetear contraseñas").
	 */
	function exportarExcel() {
		if ( ! wizard.usuarios.length || 'undefined' === typeof XLSX ) {
			return;
		}

		var correoCol = AU_WMS.i18n.exportUsersColCorreo;
		var nombreCol = AU_WMS.i18n.exportUsersColNombre;
		var areaCol = AU_WMS.i18n.exportUsersColArea;
		var perfilCol = AU_WMS.i18n.exportUsersColPerfil;
		var testCol = AU_WMS.i18n.exportUsersColTest;

		var totalAreas = contarAreasUnicas( wizard.usuarios );
		var titulo = AU_WMS.i18n.exportUsersExcelTitulo
			.replace( '{EMPRESA}', wizard.empresaNombre || AU_WMS.i18n.importCredencialesEmpresaFallback )
			.replace( '{AREAS}', totalAreas )
			.replace( '{N}', wizard.usuarios.length );

		var aoa = [
			[ titulo, '', '', '', '' ],
			[ correoCol, nombreCol, areaCol, perfilCol, testCol ],
		];

		wizard.usuarios.forEach( function ( usuario ) {
			aoa.push( [
				usuario.correo,
				usuario.nombre,
				usuario.area_nombre || '',
				usuario.perfil_completo ? AU_WMS.i18n.resetPwdPerfilCompleto : AU_WMS.i18n.incompleteProfile,
				usuario.tiene_test ? AU_WMS.i18n.testOk : AU_WMS.i18n.sinTest,
			] );
		} );

		var hoja = XLSX.utils.aoa_to_sheet( aoa );
		hoja[ '!cols' ] = [ { wch: 34 }, { wch: 28 }, { wch: 22 }, { wch: 16 }, { wch: 14 } ];
		hoja[ '!rows' ] = [ { hpt: 24 }, { hpt: 20 } ];
		hoja[ '!merges' ] = [ { s: { r: 0, c: 0 }, e: { r: 0, c: 4 } } ];

		// Filtro (autofiltro) en las columnas "Área" (C), "Perfil" (D)
		// y "Test" (E): al ser un único rango de autofiltro por hoja,
		// no es posible saltarse una columna intermedia (Perfil quedó
		// entre Área y Test), así que se incluyen las tres — el
		// usuario puede desplegar la flecha de cada una y filtrar sin
		// tocar Correo/Nombre. El rango cubre desde el encabezado
		// (fila 2) hasta la última fila de datos.
		var ultimaFila = wizard.usuarios.length + 2;
		hoja[ '!autofilter' ] = { ref: 'C2:E' + ultimaFila };

		hoja[ '!pageSetup' ] = { orientation: 'landscape', fitToWidth: 1, fitToHeight: 0 };
		hoja[ '!margins' ] = { left: 0.2, right: 0.2, top: 0.3, bottom: 0.3, header: 0, footer: 0 };

		var bordeFino = { style: 'thin', color: { rgb: EXCEL_COLOR_BORDE } };
		var bordeCompleto = { top: bordeFino, bottom: bordeFino, left: bordeFino, right: bordeFino };

		// Fila 1: título (las 5 celdas se estilan, aunque solo A1 tenga
		// texto, para que el borde/relleno cubra toda la fusión).
		[ 'A1', 'B1', 'C1', 'D1', 'E1' ].forEach( function ( addr ) {
			if ( ! hoja[ addr ] ) {
				hoja[ addr ] = { t: 's', v: '' };
			}
			hoja[ addr ].s = {
				font: { bold: true, sz: 13, color: { rgb: EXCEL_COLOR_ON_YELLOW } },
				fill: { patternType: 'solid', fgColor: { rgb: EXCEL_COLOR_YELLOW } },
				alignment: { horizontal: 'left', vertical: 'center' },
			};
		} );

		// Fila 2: encabezado de columnas.
		[ 'A2', 'B2', 'C2', 'D2', 'E2' ].forEach( function ( addr ) {
			hoja[ addr ].s = {
				font: { bold: true, color: { rgb: EXCEL_COLOR_WHITE } },
				fill: { patternType: 'solid', fgColor: { rgb: EXCEL_COLOR_NAVY } },
				alignment: { horizontal: 'center', vertical: 'center' },
				border: bordeCompleto,
			};
		} );

		// Filas de datos: banda alterna cada vez que cambia el área
		// (refuerza visualmente el orden alfabético por área), celda
		// "Perfil" coloreada en verde/rojo y celda "Test" coloreada en
		// verde/gris según corresponda.
		var banda = 0;
		var areaAnterior = null;

		wizard.usuarios.forEach( function ( usuario, indice ) {
			var fila = indice + 3;
			var nombreArea = usuario.area_nombre || '';

			if ( nombreArea !== areaAnterior ) {
				banda = 1 - banda;
				areaAnterior = nombreArea;
			}

			var colorBanda = banda ? EXCEL_COLOR_BANDA_B : EXCEL_COLOR_BANDA_A;

			[ 'A', 'B', 'C' ].forEach( function ( columna ) {
				var addr = columna + fila;
				if ( ! hoja[ addr ] ) {
					hoja[ addr ] = { t: 's', v: '' };
				}
				hoja[ addr ].s = {
					fill: { patternType: 'solid', fgColor: { rgb: colorBanda } },
					border: bordeCompleto,
					alignment: { vertical: 'center' },
				};
			} );

			var perfilOk = !! usuario.perfil_completo;
			hoja[ 'D' + fila ].s = {
				font: { bold: true, color: { rgb: perfilOk ? EXCEL_COLOR_PERFIL_OK_TEXT : EXCEL_COLOR_PERFIL_INCOMPLETO_TEXT } },
				fill: { patternType: 'solid', fgColor: { rgb: perfilOk ? EXCEL_COLOR_PERFIL_OK_BG : EXCEL_COLOR_PERFIL_INCOMPLETO_BG } },
				alignment: { horizontal: 'center', vertical: 'center' },
				border: bordeCompleto,
			};

			var testOk = !! usuario.tiene_test;
			hoja[ 'E' + fila ].s = {
				font: { bold: true, color: { rgb: testOk ? EXCEL_COLOR_TEST_OK_TEXT : EXCEL_COLOR_TEST_SIN_TEXT } },
				fill: { patternType: 'solid', fgColor: { rgb: testOk ? EXCEL_COLOR_TEST_OK_BG : EXCEL_COLOR_TEST_SIN_BG } },
				alignment: { horizontal: 'center', vertical: 'center' },
				border: bordeCompleto,
			};
		} );

		var libro = XLSX.utils.book_new();
		XLSX.utils.book_append_sheet( libro, hoja, 'Usuarios' );

		XLSX.writeFile( libro, construirNombreArchivoExcel() );
	}

	/**
	 * Cuenta cuántas áreas distintas (por nombre) aparecen en la lista
	 * de usuarios, para el resumen del título del Excel.
	 *
	 * @param {Array} usuarios Lista de usuarios devuelta por el backend.
	 * @return {number}
	 */
	function contarAreasUnicas( usuarios ) {
		var vistas = {};
		var total = 0;

		usuarios.forEach( function ( usuario ) {
			var nombreArea = usuario.area_nombre || '';
			if ( ! vistas[ nombreArea ] ) {
				vistas[ nombreArea ] = true;
				total++;
			}
		} );

		return total;
	}

	/**
	 * Arma "Empresa_{empresa}_Usuarios_{YYYY-MM-DD}.xlsx", sanitizando
	 * el nombre de la empresa.
	 *
	 * @return {string}
	 */
	function construirNombreArchivoExcel() {
		var empresa = sanitizarNombreArchivo(
			wizard.empresaNombre || AU_WMS.i18n.importCredencialesEmpresaFallback
		);

		return 'Empresa_' + empresa + '_Usuarios_' + formatearFechaISO( new Date() ) + '.xlsx';
	}

	/**
	 * Sanitiza un fragmento para usarlo en un nombre de archivo:
	 * elimina caracteres inválidos en Windows (\ / : * ? " < > |) y
	 * otros no imprimibles, y reemplaza espacios por guiones bajos.
	 *
	 * @param {string} texto Texto original.
	 * @return {string}
	 */
	function sanitizarNombreArchivo( texto ) {
		return String( texto || '' )
			.replace( /[\\/:*?"<>|]/g, '' )
			.replace( /\s+/g, '_' )
			.replace( /_{2,}/g, '_' )
			.replace( /^_+|_+$/g, '' );
	}

	/**
	 * Formatea una fecha como YYYY-MM-DD (hora local del navegador).
	 *
	 * @param {Date} fecha Fecha a formatear.
	 * @return {string}
	 */
	function formatearFechaISO( fecha ) {
		var pad = function ( n ) {
			return ( n < 10 ? '0' : '' ) + n;
		};

		return fecha.getFullYear() + '-' + pad( fecha.getMonth() + 1 ) + '-' + pad( fecha.getDate() );
	}

	/**
	 * Muestra un error genérico vía SweetAlert2.
	 *
	 * @param {string} mensaje Mensaje a mostrar.
	 */
	function mostrarErrorSwal( mensaje ) {
		Swal.fire( {
			icon: 'error',
			title: mensaje || AU_WMS.i18n.genericError,
		} );
	}
} )( jQuery );
