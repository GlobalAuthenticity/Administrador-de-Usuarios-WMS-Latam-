/**
 * Modal "Resetear contraseñas" (Tab Empresas): wizard de 4 pasos —
 * 1) Seleccionar usuarios  2) Confirmar  3) Procesar  4) Resultados.
 *
 * @package Administrador_Usuarios_WMS
 */

( function ( $ ) {
	'use strict';

	var wizard = {
		empresaId: '',
		empresaNombre: '',
		step: 1,
		areas: [],
		areasSeleccionadas: [],
		perfilFiltro: '',
		usuarios: [],
		seleccionDatos: {},
		procesando: false,
		requestId: '',
		resultado: null,
		usuariosRequestSeq: 0,
	};

	$( document ).ready( function () {
		initTriggers();
		initFiltros();
		initToolbar();
		initFooterNavigation();

		window.AU_WMS_abrirModalResetPassword = abrirModal;
	} );

	/**
	 * Cierre del modal (botón X, "Cancelar" y clic fuera del contenido).
	 */
	function initTriggers() {
		$( '#au-wms-reset-pwd-close, #au-wms-reset-pwd-btn-cancelar' ).on( 'click', function () {
			solicitarCierre();
		} );

		$( '#au-wms-reset-pwd-overlay' ).on( 'click', function ( event ) {
			if ( event.target === this ) {
				solicitarCierre();
			}
		} );

		// Dropdown de checkboxes del filtro "Área": los cambios de
		// checkboxes NO disparan la consulta al servidor uno por uno
		// (eso es lo que abría la puerta a que dos peticiones en vuelo
		// se cruzaran). En su lugar, se lee el estado final de los
		// checkboxes y se aplica el filtro UNA sola vez, al cerrar el
		// dropdown -- ya sea con el botón o haciendo clic fuera.
		$( '#au-wms-reset-pwd-area-btn' ).on( 'click', function ( event ) {
			event.stopPropagation();

			var estabaAbierto = $( '#au-wms-reset-pwd-area-dropdown' ).hasClass( 'is-open' );
			$( '#au-wms-reset-pwd-area-dropdown' ).toggleClass( 'is-open' );

			if ( estabaAbierto ) {
				aplicarFiltroAreas();
			}
		} );

		$( document ).on( 'click', function () {
			var $dropdown = $( '#au-wms-reset-pwd-area-dropdown' );
			if ( $dropdown.hasClass( 'is-open' ) ) {
				$dropdown.removeClass( 'is-open' );
				aplicarFiltroAreas();
			}
		} );

		$( '#au-wms-reset-pwd-area-menu' ).on( 'click', function ( event ) {
			event.stopPropagation();
		} );
	}

	/**
	 * Pide confirmación antes de cerrar si ya hay una selección hecha o
	 * el proceso ya terminó (a partir del paso 2), igual que el resto
	 * de wizards del plugin.
	 */
	function solicitarCierre() {
		if ( wizard.step <= 1 ) {
			cerrarModal();
			return;
		}

		Swal.fire( {
			title: AU_WMS.i18n.importConfirmCancelTitle,
			text: AU_WMS.i18n.importConfirmCancelText,
			icon: 'warning',
			showCancelButton: true,
			confirmButtonText: AU_WMS.i18n.confirmDeleteButton,
			cancelButtonText: AU_WMS.i18n.cancelButton,
			customClass: { confirmButton: 'au-wms-swal-danger' },
			reverseButtons: true,
		} ).then( function ( result ) {
			if ( result.isConfirmed ) {
				cerrarModal();
			}
		} );
	}

	function cerrarModal() {
		$( '#au-wms-reset-pwd-overlay' ).removeClass( 'is-open' );
	}

	/**
	 * Abre el modal para una empresa concreta y arranca la carga del
	 * Paso 1 (áreas para el filtro + listado inicial de usuarios).
	 *
	 * @param {number} empresaId      ID de la empresa (usuario `company`).
	 * @param {string} empresaNombre  Nombre a mostrar en el encabezado.
	 */
	function abrirModal( empresaId, empresaNombre ) {
		wizard = {
			empresaId: empresaId,
			empresaNombre: empresaNombre || '',
			step: 1,
			areas: [],
			areasSeleccionadas: [],
			perfilFiltro: '',
			usuarios: [],
			seleccionDatos: {},
			procesando: false,
			requestId: '',
			resultado: null,
			usuariosRequestSeq: 0,
		};

		$( '#au-wms-reset-pwd-empresa-nombre' ).text( wizard.empresaNombre );
		$( '#au-wms-reset-pwd-perfil' ).val( '' );
		$( '#au-wms-reset-pwd-check-all' ).prop( { checked: false, indeterminate: false } );
		$( '#au-wms-reset-pwd-area-label' ).text( AU_WMS.i18n.resetPwdFiltroAreaTodas );
		$( '#au-wms-reset-pwd-area-menu' ).empty();
		$( '#au-wms-reset-pwd-confirm-body' ).empty();
		$( '#au-wms-reset-pwd-credenciales-body' ).empty();
		$( '#au-wms-reset-pwd-final-summary' ).empty();

		irAPaso( 1 );
		actualizarContadorYBoton();

		$( '#au-wms-reset-pwd-overlay' ).addClass( 'is-open' );

		cargarAreas();
		cargarUsuarios();
	}

	/**
	 * Cambia de panel visible dentro del modal y actualiza los puntos
	 * de progreso y los botones del footer.
	 *
	 * @param {number} paso Paso destino (1-4).
	 */
	function irAPaso( paso ) {
		wizard.step = paso;

		$( '.au-wms-import-panel' ).removeClass( 'is-active' );
		$( '.au-wms-import-panel[data-step-panel="' + paso + '"]' ).addClass( 'is-active' );

		$( '.au-wms-import-step-dot' ).each( function () {
			var dotStep = parseInt( $( this ).data( 'step' ), 10 );
			$( this ).toggleClass( 'is-active', dotStep === paso );
			$( this ).toggleClass( 'is-done', dotStep < paso );
		} );

		var $atras = $( '#au-wms-reset-pwd-btn-atras' );
		var $cancelar = $( '#au-wms-reset-pwd-btn-cancelar' );
		var $siguiente = $( '#au-wms-reset-pwd-btn-siguiente' );
		var $ejecutar = $( '#au-wms-reset-pwd-btn-ejecutar' );
		var $finalizar = $( '#au-wms-reset-pwd-btn-finalizar' );

		$atras.hide();
		$cancelar.hide();
		$siguiente.hide();
		$ejecutar.hide();
		$finalizar.hide();

		if ( 1 === paso ) {
			$cancelar.show();
			$siguiente.show();
		} else if ( 2 === paso ) {
			$atras.show();
			$cancelar.show();
			$ejecutar.show();
		} else if ( 4 === paso ) {
			$finalizar.show();
		}
		// Paso 3 (procesando): sin botones visibles.
	}

	/**
	 * Wiring de los filtros del Paso 1 (Área, Estado del perfil): cada
	 * cambio recarga el listado de usuarios desde el servidor.
	 */
	function initFiltros() {
		$( '#au-wms-reset-pwd-perfil' ).on( 'change', function () {
			wizard.perfilFiltro = $( this ).val();
			cargarUsuarios();
		} );
	}

	/**
	 * Carga las áreas/paquetes de la empresa y arma el dropdown de
	 * checkboxes del filtro "Área".
	 */
	function cargarAreas() {
		$.post( AU_WMS.ajaxUrl, {
			action: 'au_wms_reset_password_areas',
			nonce: AU_WMS.nonce,
			empresa_id: wizard.empresaId,
		} )
			.done( function ( response ) {
				if ( ! response || ! response.success ) {
					return;
				}

				wizard.areas = response.data.areas || [];
				renderMenuAreas();
			} );
	}

	/**
	 * Renderiza los checkboxes del dropdown "Área" a partir de
	 * `wizard.areas`.
	 */
	function renderMenuAreas() {
		var $menu = $( '#au-wms-reset-pwd-area-menu' );
		$menu.empty();

		wizard.areas.forEach( function ( area ) {
			var itemId = 'au-wms-reset-pwd-area-' + area.id;

			var $item = $( '<label class="au-wms-checkbox-dropdown-item"></label>' ).attr( 'for', itemId );
			var $checkbox = $( '<input type="checkbox" />' )
				.attr( 'id', itemId )
				.val( area.id );

			$checkbox.on( 'change', function () {
				// Solo refleja el estado en el texto del botón mientras
				// el dropdown sigue abierto. La consulta al servidor se
				// dispara una única vez, al cerrar el dropdown (ver
				// aplicarFiltroAreas()) -- así nunca hay dos peticiones
				// en vuelo compitiendo entre sí.
				actualizarLabelAreas();
			} );

			$item.append( $checkbox ).append( $( '<span></span>' ).text( area.nombre ) );
			$menu.append( $item );
		} );
	}

	/**
	 * Lee directamente del DOM qué checkboxes del dropdown "Área" están
	 * marcados en este momento. Es la única fuente de verdad: no se
	 * mantiene un arreglo acumulado a punta de push()/filter() en cada
	 * clic, para eliminar de raíz cualquier forma de que un evento se
	 * pierda o se procese fuera de orden.
	 *
	 * @return {Array<number>}
	 */
	function leerAreasSeleccionadasDesdeDOM() {
		return $( '#au-wms-reset-pwd-area-menu input[type="checkbox"]:checked' )
			.map( function () {
				return parseInt( $( this ).val(), 10 );
			} )
			.get();
	}

	/**
	 * Aplica el filtro de área: relee el estado real de los checkboxes,
	 * y si cambió respecto al último filtro aplicado, actualiza
	 * `wizard.areasSeleccionadas` y recarga el listado (una sola
	 * petición, con el estado final y completo).
	 */
	function aplicarFiltroAreas() {
		var nuevasAreas = leerAreasSeleccionadasDesdeDOM();
		var sinCambios =
			nuevasAreas.length === wizard.areasSeleccionadas.length &&
			nuevasAreas.every( function ( id ) {
				return -1 !== wizard.areasSeleccionadas.indexOf( id );
			} );

		if ( sinCambios ) {
			return;
		}

		wizard.areasSeleccionadas = nuevasAreas;
		cargarUsuarios();
	}

	/**
	 * Actualiza el texto del botón del filtro "Área" según cuántos
	 * checkboxes estén marcados EN ESTE MOMENTO en el DOM (mientras el
	 * dropdown sigue abierto, antes de aplicar el filtro).
	 */
	function actualizarLabelAreas() {
		var total = leerAreasSeleccionadasDesdeDOM().length;
		var texto = 0 === total
			? AU_WMS.i18n.resetPwdFiltroAreaTodas
			: total + ' ' + AU_WMS.i18n.resetPwdFiltroAreasSeleccionadas;

		$( '#au-wms-reset-pwd-area-label' ).text( texto );
	}

	/**
	 * Pide al backend el listado de usuarios de la empresa según los
	 * filtros activos (área(s) + estado de perfil) y vuelve a
	 * renderizar la tabla del Paso 1.
	 */
	function cargarUsuarios() {
		var $body = $( '#au-wms-reset-pwd-body' );
		$body.html(
			'<tr class="au-wms-row-loading"><td colspan="3"><div class="au-wms-spinner"></div>' +
			AU_WMS.i18n.loading + '</td></tr>'
		);

		// Cada cambio de filtro dispara una nueva petición; si el
		// usuario marca dos áreas rápido, pueden quedar dos peticiones
		// en vuelo a la vez y responder en cualquier orden. Se marca
		// cada petición con un número de secuencia y, al volver, solo
		// se pinta si sigue siendo la más reciente — así una respuesta
		// vieja (de un estado de filtros ya superado) nunca sobrescribe
		// a una más nueva.
		var miSecuencia = ++wizard.usuariosRequestSeq;

		$.post( AU_WMS.ajaxUrl, {
			action: 'au_wms_reset_password_listar',
			nonce: AU_WMS.nonce,
			empresa_id: wizard.empresaId,
			paquete_ids: wizard.areasSeleccionadas,
			perfil_filtro: wizard.perfilFiltro,
		} )
			.done( function ( response ) {
				if ( miSecuencia !== wizard.usuariosRequestSeq ) {
					return;
				}

				if ( ! response || ! response.success ) {
					$body.html(
						'<tr class="au-wms-row-empty"><td colspan="3">' +
						( response && response.data ? response.data.message : AU_WMS.i18n.genericError ) +
						'</td></tr>'
					);
					return;
				}

				wizard.usuarios = response.data.usuarios || [];
				renderTablaUsuarios();
			} )
			.fail( function () {
				if ( miSecuencia !== wizard.usuariosRequestSeq ) {
					return;
				}

				$body.html( '<tr class="au-wms-row-empty"><td colspan="3">' + AU_WMS.i18n.genericError + '</td></tr>' );
			} );
	}

	/**
	 * Renderiza la tabla de usuarios del Paso 1 a partir de
	 * `wizard.usuarios`, marcando como seleccionados los que ya
	 * estuvieran en `wizard.seleccionDatos` (persistencia entre
	 * cambios de filtro).
	 */
	function renderTablaUsuarios() {
		var $body = $( '#au-wms-reset-pwd-body' );
		$body.empty();

		if ( ! wizard.usuarios.length ) {
			var emptyTemplate = document.getElementById( 'au-wms-reset-pwd-empty-template' );
			$body.append( document.importNode( emptyTemplate.content, true ) );
			actualizarEstadoCheckAll();
			return;
		}

		var template = document.getElementById( 'au-wms-reset-pwd-row-template' );

		wizard.usuarios.forEach( function ( usuario ) {
			var $row = $( document.importNode( template.content, true ) );
			var $tr = $row.filter( 'tr' ).length ? $row.filter( 'tr' ) : $row.find( 'tr' );

			$tr.attr( 'data-user-id', usuario.id );
			$tr.find( '.au-wms-reset-pwd-nombre' ).text( usuario.nombre );
			$tr.find( '.au-wms-reset-pwd-correo' ).text( usuario.correo );
			$tr.find( '.au-wms-reset-pwd-area' ).text( usuario.area_nombre || '—' );

			var $badge = $tr.find( '.au-wms-reset-pwd-perfil-badge' );
			if ( usuario.perfil_completo ) {
				$badge.addClass( 'au-wms-badge--test-ok' ).text( AU_WMS.i18n.resetPwdPerfilCompleto );
			} else {
				$badge.addClass( 'au-wms-badge--warning' ).text( AU_WMS.i18n.incompleteProfile );
			}

			var $checkbox = $tr.find( '.au-wms-reset-pwd-checkbox' );
			$checkbox.prop( 'checked', !! wizard.seleccionDatos[ usuario.id ] );

			$checkbox.on( 'change', function () {
				if ( $( this ).is( ':checked' ) ) {
					wizard.seleccionDatos[ usuario.id ] = usuario;
				} else {
					delete wizard.seleccionDatos[ usuario.id ];
				}

				actualizarContadorYBoton();
				actualizarEstadoCheckAll();
			} );

			$body.append( $tr );
		} );

		actualizarEstadoCheckAll();
	}

	/**
	 * Wiring del checkbox "Seleccionar todos / Deseleccionar todos":
	 * opera únicamente sobre los usuarios actualmente visibles (los
	 * que cumplen los filtros activos), respetando selecciones hechas
	 * bajo otros filtros.
	 */
	function initToolbar() {
		$( '#au-wms-reset-pwd-check-all' ).on( 'change', function () {
			var marcar = $( this ).is( ':checked' );

			wizard.usuarios.forEach( function ( usuario ) {
				if ( marcar ) {
					wizard.seleccionDatos[ usuario.id ] = usuario;
				} else {
					delete wizard.seleccionDatos[ usuario.id ];
				}
			} );

			renderTablaUsuarios();
			actualizarContadorYBoton();
		} );
	}

	/**
	 * Refleja en el checkbox "Seleccionar todos" si todos, ninguno o
	 * solo algunos de los usuarios VISIBLES están seleccionados.
	 */
	function actualizarEstadoCheckAll() {
		var $checkAll = $( '#au-wms-reset-pwd-check-all' );

		if ( ! wizard.usuarios.length ) {
			$checkAll.prop( { checked: false, indeterminate: false, disabled: true } );
			$( '#au-wms-reset-pwd-check-all-label' ).text( AU_WMS.i18n.resetPwdSeleccionarTodos );
			return;
		}

		$checkAll.prop( 'disabled', false );

		var total = wizard.usuarios.length;
		var seleccionados = wizard.usuarios.filter( function ( usuario ) {
			return !! wizard.seleccionDatos[ usuario.id ];
		} ).length;

		$checkAll.prop( {
			checked: seleccionados === total,
			indeterminate: seleccionados > 0 && seleccionados < total,
		} );

		$( '#au-wms-reset-pwd-check-all-label' ).text(
			seleccionados === total ? AU_WMS.i18n.resetPwdDeseleccionarTodos : AU_WMS.i18n.resetPwdSeleccionarTodos
		);
	}

	/**
	 * Actualiza el contador "N seleccionados" (total global, a través
	 * de todos los filtros) y habilita/deshabilita "Siguiente".
	 */
	function actualizarContadorYBoton() {
		var total = Object.keys( wizard.seleccionDatos ).length;

		$( '#au-wms-reset-pwd-contador' ).text( total + ' ' + AU_WMS.i18n.resetPwdSeleccionados );
		$( '#au-wms-reset-pwd-btn-siguiente' ).prop( 'disabled', 0 === total );
	}

	/**
	 * Wiring de la navegación del footer (Siguiente / Atrás / Resetear
	 * contraseñas / Finalizar).
	 */
	function initFooterNavigation() {
		$( '#au-wms-reset-pwd-btn-siguiente' ).on( 'click', function () {
			if ( ! Object.keys( wizard.seleccionDatos ).length ) {
				return;
			}

			renderPaso2();
			irAPaso( 2 );
		} );

		$( '#au-wms-reset-pwd-btn-atras' ).on( 'click', function () {
			irAPaso( 1 );
		} );

		$( '#au-wms-reset-pwd-btn-ejecutar' ).on( 'click', function () {
			confirmarYEjecutar();
		} );

		$( '#au-wms-reset-pwd-btn-finalizar' ).on( 'click', function () {
			cerrarModal();
		} );

		$( '#au-wms-reset-pwd-btn-copiar' ).on( 'click', copiarLista );
		$( '#au-wms-reset-pwd-btn-excel' ).on( 'click', descargarExcel );
		$( '#au-wms-reset-pwd-btn-enviar-correos' ).on( 'click', enviarCorreos );
	}

	/**
	 * Renderiza la tabla de confirmación del Paso 2 con los usuarios
	 * elegidos hasta el momento (Correo / Nombre / Área).
	 */
	function renderPaso2() {
		var seleccionados = Object.values( wizard.seleccionDatos );

		$( '#au-wms-reset-pwd-resumen-confirmacion' ).text(
			AU_WMS.i18n.resetPwdPaso2Resumen.replace( '{N}', seleccionados.length )
		);

		var $body = $( '#au-wms-reset-pwd-confirm-body' );
		$body.empty();

		seleccionados.forEach( function ( usuario ) {
			var $row = $( '<tr></tr>' );
			$row.append( $( '<td></td>' ).text( usuario.correo ) );
			$row.append( $( '<td></td>' ).text( usuario.nombre ) );
			$row.append( $( '<td></td>' ).text( usuario.area_nombre || '—' ) );
			$body.append( $row );
		} );
	}

	/**
	 * Pide confirmación explícita antes de ejecutar el reseteo (la
	 * acción es irreversible: la contraseña anterior deja de
	 * funcionar de inmediato).
	 */
	function confirmarYEjecutar() {
		var total = Object.keys( wizard.seleccionDatos ).length;

		Swal.fire( {
			title: AU_WMS.i18n.resetPwdConfirmTitle.replace( '{N}', total ),
			text: AU_WMS.i18n.resetPwdConfirmText,
			icon: 'warning',
			showCancelButton: true,
			confirmButtonText: AU_WMS.i18n.resetPwdBtnEjecutar,
			cancelButtonText: AU_WMS.i18n.cancelButton,
			customClass: { confirmButton: 'au-wms-swal-danger' },
			reverseButtons: true,
		} ).then( function ( result ) {
			if ( result.isConfirmed ) {
				ejecutarReset();
			}
		} );
	}

	/**
	 * Ejecuta el reseteo masivo. Genera una `request_id` nueva por
	 * intento: junto con el candado del backend, evita que un doble
	 * clic o una recarga accidental disparen el cambio dos veces.
	 */
	function ejecutarReset() {
		if ( wizard.procesando ) {
			return;
		}
		wizard.procesando = true;
		wizard.requestId = generarRequestId();

		irAPaso( 3 );

		var userIds = Object.keys( wizard.seleccionDatos ).map( function ( id ) {
			return parseInt( id, 10 );
		} );

		$.post( AU_WMS.ajaxUrl, {
			action: 'au_wms_reset_password_ejecutar',
			nonce: AU_WMS.nonce,
			empresa_id: wizard.empresaId,
			user_ids: userIds,
			request_id: wizard.requestId,
		} )
			.done( function ( response ) {
				wizard.procesando = false;

				if ( ! response || ! response.success ) {
					mostrarErrorSwal( response && response.data ? response.data.message : AU_WMS.i18n.genericError );
					irAPaso( 2 );
					return;
				}

				wizard.resultado = response.data;
				renderPaso4();
				irAPaso( 4 );
			} )
			.fail( function () {
				wizard.procesando = false;
				mostrarErrorSwal( AU_WMS.i18n.genericError );
				irAPaso( 2 );
			} );
	}

	/**
	 * Genera un identificador aleatorio de un solo uso para esta
	 * ejecución, usando `crypto.randomUUID()` cuando está disponible.
	 *
	 * @return {string}
	 */
	function generarRequestId() {
		if ( window.crypto && 'function' === typeof window.crypto.randomUUID ) {
			return window.crypto.randomUUID();
		}

		return 'rp-' + Date.now() + '-' + Math.random().toString( 36 ).slice( 2 );
	}

	/**
	 * Renderiza el Paso 4: resumen ("Proceso finalizado" + conteos) y
	 * la tabla de resultados (todas las filas procesadas, incluidas
	 * las que fallaron, identificadas como "Error").
	 */
	function renderPaso4() {
		var resultado = wizard.resultado || { seleccionados: 0, actualizados: 0, errores: 0, resultados: [] };

		var html = '<h3>' + AU_WMS.i18n.resetPwdFinalizado + '</h3>';
		html += '<ul class="au-wms-import-final-list">';
		html += '<li class="au-wms-import-final-ok">' + AU_WMS.i18n.resetPwdResumenSeleccionados + ': ' + resultado.seleccionados + '</li>';
		html += '<li class="au-wms-import-final-ok">' + AU_WMS.i18n.resetPwdResumenActualizados + ': ' + resultado.actualizados + '</li>';
		if ( resultado.errores > 0 ) {
			html += '<li class="au-wms-import-final-error">' + AU_WMS.i18n.resetPwdResumenErrores + ': ' + resultado.errores + '</li>';
		}
		html += '</ul>';

		$( '#au-wms-reset-pwd-final-summary' ).html( html ).show();

		var $body = $( '#au-wms-reset-pwd-credenciales-body' );
		$body.empty();

		resultado.resultados.forEach( function ( item ) {
			var datosSeleccion = wizard.seleccionDatos[ item.id ] || {};
			var areaNombre = datosSeleccion.area_nombre || '—';

			var $row = $( '<tr></tr>' );
			$row.append( $( '<td></td>' ).text( item.email ) );

			if ( 'ok' === item.status ) {
				$row.append( $( '<td class="au-wms-import-credenciales-password"></td>' ).text( item.password ) );
			} else {
				$row.append(
					$( '<td></td>' ).append(
						$( '<span class="au-wms-badge au-wms-badge--warning"></span>' ).text(
							AU_WMS.i18n.resetPwdEstadoError + ( item.motivo ? ': ' + item.motivo : '' )
						)
					)
				);
			}

			$row.append( $( '<td></td>' ).text( areaNombre ) );
			$body.append( $row );
		} );
	}

	/**
	 * Copia al portapapeles, en formato tabulado (compatible con pegar
	 * en Excel), únicamente las filas cuya contraseña se generó
	 * correctamente.
	 */
	function copiarLista() {
		var exitosos = obtenerResultadosExitosos();

		if ( ! exitosos.length ) {
			return;
		}

		var encabezado = [
			AU_WMS.i18n.resetPwdColCorreo,
			AU_WMS.i18n.resetPwdColPassword,
			AU_WMS.i18n.resetPwdColArea,
		].join( '\t' );

		var filas = exitosos.map( function ( item ) {
			var areaNombre = ( wizard.seleccionDatos[ item.id ] && wizard.seleccionDatos[ item.id ].area_nombre ) || '';
			return [ item.email, item.password, areaNombre ].join( '\t' );
		} );

		var texto = encabezado + '\n' + filas.join( '\n' );

		copiarTexto( texto )
			.then( function () {
				Swal.fire( {
					icon: 'success',
					title: AU_WMS.i18n.resetPwdCopiadoOk,
					timer: 2200,
					showConfirmButton: false,
				} );
			} )
			.catch( function () {
				mostrarErrorSwal( AU_WMS.i18n.resetPwdCopiadoError );
			} );
	}

	/**
	 * Copia un texto al portapapeles (Clipboard API, con respaldo
	 * `execCommand('copy')` para contextos sin acceso a ella).
	 *
	 * @param {string} texto Texto a copiar.
	 * @return {Promise}
	 */
	function copiarTexto( texto ) {
		if ( navigator.clipboard && navigator.clipboard.writeText ) {
			return navigator.clipboard.writeText( texto );
		}

		return new Promise( function ( resolve, reject ) {
			var $textarea = $( '<textarea readonly></textarea>' )
				.css( { position: 'fixed', top: '-1000px', left: '-1000px' } )
				.val( texto );

			$( 'body' ).append( $textarea );
			$textarea.get( 0 ).select();

			var exito = false;
			try {
				exito = document.execCommand( 'copy' );
			} catch ( error ) {
				exito = false;
			}

			$textarea.remove();

			if ( exito ) {
				resolve();
			} else {
				reject();
			}
		} );
	}

	/**
	 * Genera y descarga el .xlsx (vía SheetJS) con únicamente las
	 * contraseñas generadas correctamente.
	 */
	function descargarExcel() {
		var exitosos = obtenerResultadosExitosos();

		if ( ! exitosos.length || 'undefined' === typeof XLSX ) {
			return;
		}

		var correoCol = AU_WMS.i18n.resetPwdColCorreo;
		var passwordCol = AU_WMS.i18n.resetPwdColPassword;
		var areaCol = AU_WMS.i18n.resetPwdColArea;

		var filas = exitosos.map( function ( item ) {
			var areaNombre = ( wizard.seleccionDatos[ item.id ] && wizard.seleccionDatos[ item.id ].area_nombre ) || '';
			var fila = {};
			fila[ correoCol ] = item.email;
			fila[ passwordCol ] = item.password;
			fila[ areaCol ] = areaNombre;
			return fila;
		} );

		var hoja = XLSX.utils.json_to_sheet( filas );
		hoja[ '!cols' ] = [ { wch: 34 }, { wch: 16 }, { wch: 24 } ];

		var libro = XLSX.utils.book_new();
		XLSX.utils.book_append_sheet( libro, hoja, 'Contrase\u00f1as' );

		XLSX.writeFile( libro, construirNombreArchivoExcel() );
	}

	/**
	 * Envía al webhook configurado (Configuración → "Resetear
	 * contraseñas") el correo, la nueva contraseña y el área de cada
	 * usuario cuya contraseña se generó correctamente, para que un
	 * sistema externo se encargue de notificarlos por correo.
	 */
	function enviarCorreos() {
		var exitosos = obtenerResultadosExitosos();

		if ( ! exitosos.length ) {
			mostrarErrorSwal( AU_WMS.i18n.resetPwdSinResultadosParaEnviar );
			return;
		}

		var usuarios = exitosos.map( function ( item ) {
			var areaNombre = ( wizard.seleccionDatos[ item.id ] && wizard.seleccionDatos[ item.id ].area_nombre ) || '';
			return { email: item.email, password: item.password, area: areaNombre };
		} );

		var $boton = $( '#au-wms-reset-pwd-btn-enviar-correos' );
		var textoOriginal = $boton.data( 'texto-original' ) || $boton.text();
		$boton.data( 'texto-original', textoOriginal );
		$boton.prop( 'disabled', true ).text( AU_WMS.i18n.resetPwdEnviandoCorreos );

		$.post( AU_WMS.ajaxUrl, {
			action: 'au_wms_reset_password_enviar_correos',
			nonce: AU_WMS.nonce,
			usuarios: usuarios,
		} )
			.done( function ( response ) {
				if ( ! response || ! response.success ) {
					mostrarErrorSwal(
						( response && response.data && response.data.message ) || AU_WMS.i18n.resetPwdCorreosEnviadosError
					);
					return;
				}

				Swal.fire( {
					icon: 'success',
					title: AU_WMS.i18n.resetPwdCorreosEnviados,
					text: AU_WMS.i18n.resetPwdCorreosEnviadosOk,
					timer: 2500,
					showConfirmButton: false,
				} );
			} )
			.fail( function () {
				mostrarErrorSwal( AU_WMS.i18n.resetPwdCorreosEnviadosError );
			} )
			.always( function () {
				$boton.prop( 'disabled', false ).text( textoOriginal );
			} );
	}

	/**
	 * Solo los resultados con `status === 'ok'` (excluye los que
	 * quedaron marcados como "Error").
	 *
	 * @return {Array}
	 */
	function obtenerResultadosExitosos() {
		var resultado = wizard.resultado || { resultados: [] };
		return resultado.resultados.filter( function ( item ) {
			return 'ok' === item.status && item.password;
		} );
	}

	/**
	 * Arma "Empresa_{empresa}_Reset_Contraseñas_{YYYY-MM-DD}.xlsx",
	 * sanitizando el nombre de la empresa.
	 *
	 * @return {string}
	 */
	function construirNombreArchivoExcel() {
		var empresa = sanitizarNombreArchivo(
			wizard.empresaNombre || AU_WMS.i18n.importCredencialesEmpresaFallback
		);

		return 'Empresa_' + empresa + '_Reset_Contrasenas_' + formatearFechaISO( new Date() ) + '.xlsx';
	}

	/**
	 * Sanitiza un fragmento para usarlo en un nombre de archivo:
	 * elimina caracteres inválidos en Windows (\ / : * ? " < > |) y
	 * otros no imprimibles, y reemplaza espacios por guiones bajos.
	 *
	 * @param {string} texto Texto original.
	 * @return {string}
	 */
	function sanitizarNombreArchivo( texto ) {
		return String( texto || '' )
			.replace( /[\\/:*?"<>|]/g, '' )
			.replace( /\s+/g, '_' )
			.replace( /_{2,}/g, '_' )
			.replace( /^_+|_+$/g, '' );
	}

	/**
	 * Formatea una fecha como YYYY-MM-DD (hora local del navegador).
	 *
	 * @param {Date} fecha Fecha a formatear.
	 * @return {string}
	 */
	function formatearFechaISO( fecha ) {
		var pad = function ( n ) {
			return ( n < 10 ? '0' : '' ) + n;
		};

		return fecha.getFullYear() + '-' + pad( fecha.getMonth() + 1 ) + '-' + pad( fecha.getDate() );
	}

	/**
	 * Muestra un error genérico vía SweetAlert2.
	 *
	 * @param {string} mensaje Mensaje a mostrar.
	 */
	function mostrarErrorSwal( mensaje ) {
		Swal.fire( {
			icon: 'error',
			title: mensaje || AU_WMS.i18n.genericError,
		} );
	}
} )( jQuery );
