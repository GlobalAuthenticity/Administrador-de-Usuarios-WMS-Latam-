/**
 * Administrador de Usuarios (WMS Latam) — Modal "Áreas del usuario"
 * (Tab Integrantes).
 *
 * Depende de jQuery (ya cargado por admin.js) y del objeto global
 * `AU_WMS` (ajaxUrl, nonce, i18n) localizado desde PHP.
 */
( function ( $ ) {
	'use strict';

	var state = {
		userId: 0,
		nombreUsuario: '',
		search: '',
		page: 1,
		perPage: 10,
		totalPages: 1,
		totalAreas: 0,
	};

	var searchDebounceTimer = null;

	$( document ).ready( function () {
		if ( ! $( '#au-wms-areas-usuario-overlay' ).length ) {
			return;
		}

		initCierre();
		initBusquedaYPaginacion();
		initEventosTabla();
		initVincularArea();
	} );

	/**
	 * Punto de entrada expuesto globalmente: admin.js lo llama al hacer
	 * clic en "Áreas del usuario" dentro del dropdown de acciones de
	 * una fila del Tab Integrantes.
	 *
	 * @param {number} userId ID del usuario seleccionado.
	 * @param {string} nombre Nombre a mostrar en el título del modal.
	 */
	window.AU_WMS_abrirAreasUsuario = function ( userId, nombre ) {
		state.userId = userId;
		state.nombreUsuario = nombre || '';
		state.search = '';
		state.page = 1;

		$( '#au-wms-areas-usuario-search' ).val( '' );
		$( '#au-wms-areas-usuario-title' ).text(
			( AU_WMS.i18n.areasUsuarioTitulo || 'Áreas del usuario' ) + ' — ' + state.nombreUsuario
		);

		$( '#au-wms-areas-usuario-overlay' ).addClass( 'is-open' );

		cargarAreasUsuario();
	};

	function initCierre() {
		$( '#au-wms-areas-usuario-close' ).on( 'click', cerrarModal );

		$( '#au-wms-areas-usuario-overlay' ).on( 'click', function ( event ) {
			if ( event.target === this ) {
				cerrarModal();
			}
		} );
	}

	function cerrarModal() {
		$( '#au-wms-areas-usuario-overlay' ).removeClass( 'is-open' );
	}

	/**
	 * Buscador con debounce, selector de registros por página y
	 * controles de paginación.
	 */
	function initBusquedaYPaginacion() {
		$( '#au-wms-areas-usuario-search' ).on( 'input', function () {
			var value = $( this ).val();

			clearTimeout( searchDebounceTimer );
			searchDebounceTimer = setTimeout( function () {
				state.search = value;
				state.page = 1;
				cargarAreasUsuario();
			}, 350 );
		} );

		$( '#au-wms-areas-usuario-per-page' ).on( 'change', function () {
			state.perPage = parseInt( $( this ).val(), 10 ) || 10;
			state.page = 1;
			cargarAreasUsuario();
		} );

		$( '#au-wms-areas-usuario-pagination' ).on( 'click', '.au-wms-page-btn', function () {
			var target = $( this ).data( 'page' );

			if ( 'first' === target ) {
				state.page = 1;
			} else if ( 'prev' === target ) {
				state.page = Math.max( 1, state.page - 1 );
			} else if ( 'next' === target ) {
				state.page = Math.min( state.totalPages, state.page + 1 );
			} else if ( 'last' === target ) {
				state.page = state.totalPages;
			}

			cargarAreasUsuario();
		} );

		$( '#au-wms-btn-refresh-areas-usuario' ).on( 'click', function () {
			cargarAreasUsuario();
		} );
	}

	/**
	 * Delegación de eventos sobre la tabla: abrir/cerrar el dropdown
	 * de Acciones y disparar el flujo de "Desvincular área".
	 */
	function initEventosTabla() {
		var $tbody = $( '#au-wms-areas-usuario-body' );

		$tbody.on( 'click', '.au-wms-actions-btn', function ( event ) {
			event.stopPropagation();

			var $dropdown = $( this ).closest( '.au-wms-actions-dropdown' );
			var wasOpen = $dropdown.hasClass( 'is-open' );

			$( '.au-wms-actions-dropdown' ).removeClass( 'is-open' );

			if ( ! wasOpen ) {
				$dropdown.addClass( 'is-open' );
			}
		} );

		$tbody.on( 'click', '.au-wms-areas-usuario-action-desvincular', function () {
			if ( $( this ).prop( 'disabled' ) ) {
				return;
			}

			var $row = $( this ).closest( 'tr' );
			var paqueteId = $row.data( 'paquete-id' );
			var areaNombre = $row.find( '.au-wms-area-row-nombre' ).text();

			confirmarDesvincularArea( paqueteId, areaNombre );
		} );
	}

	/**
	 * Pide confirmación antes de desvincular al usuario del área.
	 *
	 * @param {number} paqueteId  ID del área/paquete.
	 * @param {string} areaNombre Nombre del área (para el mensaje).
	 */
	function confirmarDesvincularArea( paqueteId, areaNombre ) {
		var mensaje = ( AU_WMS.i18n.desvincularAreaTexto || 'El usuario {usuario} dejará de ser parte del área {area}.' )
			.replace( '{usuario}', state.nombreUsuario )
			.replace( '{area}', areaNombre );

		Swal.fire( {
			title: AU_WMS.i18n.desvincularAreaTitulo || '¿Desvincular al usuario de esta área?',
			text: mensaje,
			icon: 'warning',
			showCancelButton: true,
			confirmButtonText: AU_WMS.i18n.desvincularAreaBoton || 'Desvincular usuario',
			cancelButtonText: AU_WMS.i18n.cancelButton,
			customClass: { confirmButton: 'au-wms-swal-danger' },
			reverseButtons: true,
		} ).then( function ( result ) {
			if ( ! result.isConfirmed ) {
				return;
			}

			ejecutarDesvincularArea( paqueteId );
		} );
	}

	/**
	 * Ejecuta la desvinculación vía AJAX y, si tiene éxito, muestra la
	 * confirmación y refresca el listado.
	 *
	 * @param {number} paqueteId ID del área/paquete.
	 */
	function ejecutarDesvincularArea( paqueteId ) {
		$.post( AU_WMS.ajaxUrl, {
			action: 'au_wms_usuario_area_desvincular',
			nonce: AU_WMS.nonce,
			user_id: state.userId,
			paquete_id: paqueteId,
		} )
			.done( function ( response ) {
				if ( ! response || ! response.success ) {
					mostrarErrorSwal( response && response.data ? response.data.message : AU_WMS.i18n.genericError );
					return;
				}

				var mensaje = ( AU_WMS.i18n.areaDesvinculadaTexto || 'El usuario {usuario} se ha desvinculado del área {area}.' )
					.replace( '{usuario}', response.data.nombre_usuario )
					.replace( '{area}', response.data.area_nombre );

				Swal.fire( {
					icon: 'success',
					title: AU_WMS.i18n.areaDesvinculadaTitulo || 'Área desvinculada',
					text: mensaje,
				} );

				cargarAreasUsuario();
			} )
			.fail( function () {
				mostrarErrorSwal( AU_WMS.i18n.genericError );
			} );
	}

	/**
	 * Carga (o recarga) el listado paginado de áreas del usuario actual.
	 */
	function cargarAreasUsuario() {
		$( '#au-wms-areas-usuario-body' ).html(
			'<tr class="au-wms-row-loading"><td colspan="4"><div class="au-wms-spinner"></div>' +
			AU_WMS.i18n.loading +
			'</td></tr>'
		);

		$.post( AU_WMS.ajaxUrl, {
			action: 'au_wms_usuario_areas_listar',
			nonce: AU_WMS.nonce,
			user_id: state.userId,
			search: state.search,
			page: state.page,
			per_page: state.perPage,
		} )
			.done( function ( response ) {
				if ( ! response || ! response.success ) {
					mostrarErrorSwal( response && response.data ? response.data.message : AU_WMS.i18n.genericError );
					return;
				}

				// Se necesita ANTES de pintar las filas: "Desvincular
				// área" solo debe estar habilitado si el usuario tiene
				// dos o más áreas en total (no solo en la página
				// actual, ya que puede estar filtrando/paginando).
				state.totalAreas = response.data.total;

				renderTablaAreasUsuario( response.data.items );
				renderPaginacionAreasUsuario( response.data );
			} )
			.fail( function () {
				mostrarErrorSwal( AU_WMS.i18n.genericError );
			} );
	}

	/**
	 * Renderiza las filas de la tabla de áreas del usuario.
	 *
	 * @param {Array} items Lista de áreas.
	 */
	function renderTablaAreasUsuario( items ) {
		var $tbody = $( '#au-wms-areas-usuario-body' );
		$tbody.empty();

		if ( ! items || ! items.length ) {
			var emptyTemplate = document.getElementById( 'au-wms-areas-usuario-empty-template' );
			$tbody.append( document.importNode( emptyTemplate.content, true ) );
			return;
		}

		var template = document.getElementById( 'au-wms-areas-usuario-row-template' );

		items.forEach( function ( item ) {
			var $row = $( document.importNode( template.content, true ) );
			var $tr = $row.filter( 'tr' ).length ? $row.filter( 'tr' ) : $row.find( 'tr' );

			$tr.attr( 'data-paquete-id', item.id );
			$tr.find( '.au-wms-user-id' ).text( 'ID: ' + item.id );
			$tr.find( '.au-wms-area-row-nombre' ).text( item.nombre );
			$tr.find( '.au-wms-areas-usuario-codigo' ).text( item.codigo );
			$tr.find( '.au-wms-areas-uso-badge' )
				.addClass( 'au-wms-badge au-wms-badge--empresa' )
				.text( item.usados + ' / ' + item.cupo );

			// "Desvincular área" solo aplica si el usuario pertenece a
			// dos o más áreas en total: no puede quedar sin ninguna.
			if ( state.totalAreas <= 1 ) {
				$tr.find( '.au-wms-areas-usuario-action-desvincular' )
					.prop( 'disabled', true )
					.addClass( 'is-disabled' )
					.attr( 'title', AU_WMS.i18n.desvincularAreaUnicaTitulo || 'El usuario debe pertenecer al menos a un área.' );
			}

			$tbody.append( $tr );
		} );
	}

	/**
	 * Actualiza los controles de paginación del modal.
	 *
	 * @param {Object} data Respuesta de au_wms_usuario_areas_listar.
	 */
	function renderPaginacionAreasUsuario( data ) {
		state.page = data.page;
		state.totalPages = data.total_pages;

		$( '#au-wms-areas-usuario-total' ).text( data.total );
		$( '#au-wms-areas-usuario-current-page' ).text( data.page );
		$( '#au-wms-areas-usuario-total-pages' ).text( data.total_pages );

		$( '#au-wms-areas-usuario-pagination .au-wms-page-btn[data-page="first"]' ).prop( 'disabled', data.page <= 1 );
		$( '#au-wms-areas-usuario-pagination .au-wms-page-btn[data-page="prev"]' ).prop( 'disabled', data.page <= 1 );
		$( '#au-wms-areas-usuario-pagination .au-wms-page-btn[data-page="next"]' ).prop( 'disabled', data.page >= data.total_pages );
		$( '#au-wms-areas-usuario-pagination .au-wms-page-btn[data-page="last"]' ).prop( 'disabled', data.page >= data.total_pages );
	}

	/* ==========================================================================
	   Modal "Agregar área"
	   ========================================================================== */

	var vincularState = {
		areasDisponibles: [],
	};

	/**
	 * Cablea el botón "Agregar área" del header y los controles del
	 * modal secundario (cierre, cambio de selección, botón "Vincular
	 * área").
	 */
	function initVincularArea() {
		$( '#au-wms-areas-usuario-btn-agregar' ).on( 'click', function () {
			abrirModalVincularArea();
		} );

		$( '#au-wms-vincular-area-close, #au-wms-vincular-area-btn-cancelar' ).on( 'click', function () {
			cerrarModalVincularArea();
		} );

		$( '#au-wms-vincular-area-overlay' ).on( 'click', function ( event ) {
			if ( event.target === this ) {
				cerrarModalVincularArea();
			}
		} );

		$( '#au-wms-vincular-area-select' ).on( 'change', function () {
			var paqueteId = $( this ).val();
			var area = actualizarInfoAreaSeleccionada( paqueteId );

			var sinCupo = area && area.disponibles <= 0;
			$( '#au-wms-vincular-area-btn-vincular' ).prop( 'disabled', ! paqueteId || sinCupo );
		} );

		$( '#au-wms-vincular-area-btn-vincular' ).on( 'click', vincularAreaSeleccionada );
	}

	/**
	 * Abre el modal "Agregar área" para el usuario actualmente abierto
	 * en "Áreas del usuario", y carga sus áreas disponibles.
	 */
	function abrirModalVincularArea() {
		vincularState.areasDisponibles = [];

		$( '#au-wms-vincular-area-title' ).text(
			( AU_WMS.i18n.agregarAreaTitulo || 'Agregar área' ) + ' — ' + state.nombreUsuario
		);
		$( '#au-wms-vincular-area-info' ).hide();
		$( '#au-wms-vincular-area-sin-cupo' ).hide();
		$( '#au-wms-vincular-area-sin-opciones' ).hide();
		$( '#au-wms-vincular-area-btn-vincular' ).prop( 'disabled', true );

		cargarAreasDisponibles();

		$( '#au-wms-vincular-area-overlay' ).addClass( 'is-open' );
	}

	function cerrarModalVincularArea() {
		$( '#au-wms-vincular-area-overlay' ).removeClass( 'is-open' );
	}

	/**
	 * Carga vía AJAX las áreas de la empresa del usuario que todavía
	 * no tiene vinculadas, y puebla el select.
	 */
	function cargarAreasDisponibles() {
		var $select = $( '#au-wms-vincular-area-select' );

		$select.prop( 'disabled', true ).empty().append(
			'<option value="">' + AU_WMS.i18n.loading + '</option>'
		);

		$.post( AU_WMS.ajaxUrl, {
			action: 'au_wms_usuario_areas_disponibles',
			nonce: AU_WMS.nonce,
			user_id: state.userId,
		} )
			.done( function ( response ) {
				if ( ! response || ! response.success ) {
					mostrarErrorSwal( response && response.data ? response.data.message : AU_WMS.i18n.genericError );
					return;
				}

				vincularState.areasDisponibles = response.data.areas || [];

				$select.empty().append(
					'<option value="">' + ( AU_WMS.i18n.selectAreaPlaceholder || 'Selecciona un área' ) + '</option>'
				);

				vincularState.areasDisponibles.forEach( function ( area ) {
					$select.append(
						'<option value="' + area.id + '">' + $( '<div>' ).text( area.nombre ).html() + '</option>'
					);
				} );

				var hayOpciones = vincularState.areasDisponibles.length > 0;
				$select.prop( 'disabled', ! hayOpciones );
				$( '#au-wms-vincular-area-sin-opciones' ).toggle( ! hayOpciones );
			} )
			.fail( function () {
				mostrarErrorSwal( AU_WMS.i18n.genericError );
			} );
	}

	/**
	 * Muestra el resumen de cupos ("X / Y cupos utilizados") del área
	 * seleccionada en el select, usando los datos ya cargados en
	 * memoria (sin una petición AJAX adicional). Si el área ya no
	 * tiene cupos disponibles, lo marca visualmente como advertencia.
	 *
	 * @param {string|number} paqueteId ID del área seleccionada.
	 * @return {Object|null} El área encontrada (o null si no hay selección).
	 */
	function actualizarInfoAreaSeleccionada( paqueteId ) {
		var area = null;

		vincularState.areasDisponibles.forEach( function ( item ) {
			if ( parseInt( item.id, 10 ) === parseInt( paqueteId, 10 ) ) {
				area = item;
			}
		} );

		var $info = $( '#au-wms-vincular-area-info' );
		var $sinCupoAviso = $( '#au-wms-vincular-area-sin-cupo' );

		if ( ! area ) {
			$info.hide();
			$sinCupoAviso.hide();
			return null;
		}

		var sinCupo = area.disponibles <= 0;

		$( '#au-wms-vincular-area-info-nombre' ).text( area.nombre );
		$( '#au-wms-vincular-area-info-cupos' ).text(
			' — ' + area.utilizados + ' / ' + area.cupo + ' ' + ( AU_WMS.i18n.importCuposUsados || 'cupos utilizados' )
		);
		$info.toggleClass( 'au-wms-import-cupos-warning--inline', sinCupo );
		$info.show();

		$sinCupoAviso.toggle( sinCupo );

		return area;
	}

	/**
	 * Vincula al usuario actual con el área seleccionada y, si tiene
	 * éxito, muestra la confirmación y refresca el listado principal
	 * de "Áreas del usuario".
	 */
	function vincularAreaSeleccionada() {
		var paqueteId = $( '#au-wms-vincular-area-select' ).val();

		if ( ! paqueteId ) {
			return;
		}

		var $boton = $( '#au-wms-vincular-area-btn-vincular' );
		$boton.prop( 'disabled', true );

		$.post( AU_WMS.ajaxUrl, {
			action: 'au_wms_usuario_area_vincular',
			nonce: AU_WMS.nonce,
			user_id: state.userId,
			paquete_id: paqueteId,
		} )
			.done( function ( response ) {
				if ( ! response || ! response.success ) {
					mostrarErrorSwal( response && response.data ? response.data.message : AU_WMS.i18n.genericError );
					$boton.prop( 'disabled', false );
					return;
				}

				cerrarModalVincularArea();

				var mensaje = ( AU_WMS.i18n.areaVinculadaTexto || 'El usuario {usuario} ha sido agregado al área {area}.' )
					.replace( '{usuario}', response.data.nombre_usuario )
					.replace( '{area}', response.data.area_nombre );

				Swal.fire( {
					icon: 'success',
					title: AU_WMS.i18n.areaVinculadaTitulo || 'Área agregada',
					text: mensaje,
				} );

				// Refresca el listado del modal principal para que la
				// nueva área aparezca de inmediato.
				cargarAreasUsuario();
			} )
			.fail( function () {
				mostrarErrorSwal( AU_WMS.i18n.genericError );
			} )
			.always( function () {
				$boton.prop( 'disabled', false );
			} );
	}

	function mostrarErrorSwal( mensaje ) {
		Swal.fire( {
			icon: 'error',
			title: mensaje || AU_WMS.i18n.genericError,
		} );
	}
} )( jQuery );
