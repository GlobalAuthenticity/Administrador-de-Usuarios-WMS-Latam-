/**
 * Administrador de Usuarios (WMS Latam) — Acciones sobre una cuenta.
 *
 * Flujos que se lanzan desde el menú "Acciones" de una fila y que
 * otras pestañas reutilizan vía `window.AU_WMS_*`: descargar resultado
 * del test, borrar / dejar de ser usuario WMS (con su escenario de
 * programas), habilitar o deshabilitar acceso, cambiar contraseña,
 * cambiar correo e iniciar sesión como el usuario.
 *
 * Módulos (en orden de carga): admin-core.js → acciones-usuario.js →
 * borrado-masivo.js → admin.js (Integrantes). Cada módulo publica sus
 * funciones en `window.AU_WMS_APP` y llama a las de los demás a través
 * de pequeños delegados, resueltos en el momento de la llamada (no al
 * cargar), así que el orden solo importa para los `$( document ).ready`.
 *
 * Depende de jQuery y SweetAlert2. Usa el objeto global `AU_WMS`
 * (ajaxUrl, nonce, i18n) localizado desde PHP.
 */
( function ( $ ) {
	'use strict';

	var App = window.AU_WMS_APP = window.AU_WMS_APP || {};

	// Funciones de otros módulos (delegados resueltos al llamarse).
	function cargarUsuarios() {
		return App.cargarUsuarios.apply( null, arguments );
	}
	function mostrarError() {
		return App.mostrarError.apply( null, arguments );
	}
	function refrescarListaTrasAccion() {
		return App.refrescarListaTrasAccion.apply( null, arguments );
	}

	/**
	 * Descarga el PDF del test de un integrante sin salir del listado.
	 * El backend genera el mismo informe que el botón "Descargar
	 * resultado" de /resultado-test-trabajador/ y lo devuelve como archivo.
	 *
	 * @param {jQuery} $btn Botón pulsado dentro de la fila.
	 */
	function descargarResultadoTest( $btn ) {
		if ( $btn.prop( 'disabled' ) ) {
			return;
		}

		var userId = $btn.closest( 'tr' ).data( 'user-id' );
		var $texto = $btn.find( '.au-wms-descargar-resultado-texto' );
		var $icono = $btn.find( '.dashicons' );

		$btn.prop( 'disabled', true ).addClass( 'is-loading' );
		$icono.removeClass( 'dashicons-download' ).addClass( 'dashicons-update' );
		$texto.text( AU_WMS.i18n.descargandoResultado );

		var body = new FormData();
		body.append( 'action', 'au_wms_descargar_resultado_test' );
		body.append( 'nonce', AU_WMS.nonce );
		body.append( 'user_id', userId );

		fetch( AU_WMS.ajaxUrl, { method: 'POST', body: body, credentials: 'same-origin' } )
			.then( function ( res ) {
				var tipo = res.headers.get( 'Content-Type' ) || '';

				if ( ! res.ok || tipo.indexOf( 'application/pdf' ) === -1 ) {
					return res.json().then( function ( json ) {
						throw new Error( json && json.data && json.data.message ? json.data.message : AU_WMS.i18n.genericError );
					}, function () {
						throw new Error( AU_WMS.i18n.genericError );
					} );
				}

				var nombreArchivo = 'informe.pdf';
				var match = /filename\*=UTF-8''([^;]+)/i.exec( res.headers.get( 'Content-Disposition' ) || '' );
				if ( match ) {
					nombreArchivo = decodeURIComponent( match[1] );
				}

				return res.blob().then( function ( blob ) {
					var blobUrl = window.URL.createObjectURL( blob );
					var link = document.createElement( 'a' );
					link.href = blobUrl;
					link.download = nombreArchivo;
					document.body.appendChild( link );
					link.click();
					link.remove();
					window.URL.revokeObjectURL( blobUrl );
				} );
			} )
			.catch( function ( error ) {
				mostrarError( error.message );
			} )
			.finally( function () {
				$btn.prop( 'disabled', false ).removeClass( 'is-loading' );
				$icono.removeClass( 'dashicons-update' ).addClass( 'dashicons-download' );
				$texto.text( AU_WMS.i18n.descargarResultado );
			} );
	}

	/**
	 * Paso 1 del nuevo flujo de "Borrar usuario": sin confirmación
	 * previa, refresca automáticamente los programas (Inspira/Octágono)
	 * de este usuario y, al terminar, determina qué modal mostrar según
	 * los programas que tenga asignados.
	 *
	 * @param {number} userId ID del usuario.
	 */
	function iniciarFlujoBorrarUsuario( userId ) {
		Swal.fire( {
			title: AU_WMS.i18n.refrescandoProgramasUsuario,
			allowOutsideClick: false,
			allowEscapeKey: false,
			showConfirmButton: false,
			didOpen: function () {
				Swal.showLoading();
			},
		} );

		refrescarProgramasSilencioso( userId, function () {
			obtenerEscenarioYMostrarModal( userId, mostrarModalEscenarioBorrado );
		} );
	}

	/**
	 * Refresca los programas (Inspira/Octágono) de un único usuario sin
	 * mostrar ningún resumen (a diferencia del flujo normal de
	 * "Refrescar programas"), y llama a `onComplete` al terminar.
	 * Expuesta globalmente para reutilizarse desde otros tabs (ej.
	 * Usuarios Externos) sin duplicar esta lógica.
	 *
	 * @param {number}   userId     ID del usuario.
	 * @param {Function} onComplete Callback a ejecutar cuando termine.
	 */
	function refrescarProgramasSilencioso( userId, onComplete ) {
		$.post( AU_WMS.ajaxUrl, {
			action: 'au_wms_sync_programas_iniciar_usuario',
			nonce: AU_WMS.nonce,
			user_id: userId,
		} )
			.done( function ( response ) {
				if ( ! response || ! response.success ) {
					mostrarError( response && response.data ? response.data.message : AU_WMS.i18n.genericError );
					return;
				}

				if ( 0 === response.data.total ) {
					onComplete();
					return;
				}

				procesarLoteSilencioso( response.data.sync_id, 0, onComplete );
			} )
			.fail( function () {
				mostrarError( AU_WMS.i18n.genericError );
			} );
	}

	window.AU_WMS_refrescarProgramasSilencioso = refrescarProgramasSilencioso;

	/**
	 * Procesa un lote (de a 1 usuario) del refresco silencioso, hasta
	 * completar, y entonces llama a `onComplete`.
	 *
	 * @param {string}   syncId     ID de sincronización.
	 * @param {number}   offset     Posición inicial del siguiente lote.
	 * @param {Function} onComplete Callback a ejecutar al terminar.
	 */
	function procesarLoteSilencioso( syncId, offset, onComplete ) {
		$.post( AU_WMS.ajaxUrl, {
			action: 'au_wms_sync_programas_procesar_lote',
			nonce: AU_WMS.nonce,
			sync_id: syncId,
			offset: offset,
			batch_size: 1,
		} )
			.done( function ( response ) {
				if ( ! response || ! response.success ) {
					mostrarError( response && response.data ? response.data.message : AU_WMS.i18n.genericError );
					return;
				}

				if ( response.data.done ) {
					onComplete();
					return;
				}

				procesarLoteSilencioso( syncId, response.data.offset, onComplete );
			} )
			.fail( function () {
				mostrarError( AU_WMS.i18n.genericError );
			} );
	}

	/**
	 * Consulta qué programas (Inspira/Octágono) tiene asignados un
	 * usuario y llama a `alManosSaberlo` con el resultado. Expuesta
	 * globalmente para reutilizarse desde otros tabs.
	 *
	 * @param {number}   userId         ID del usuario.
	 * @param {Function} alConocerlo    Callback( userId, {email, tiene_inspira, tiene_octagono} ).
	 */
	function obtenerEscenarioYMostrarModal( userId, alConocerlo ) {
		$.post( AU_WMS.ajaxUrl, {
			action: 'au_wms_usuario_obtener_escenario',
			nonce: AU_WMS.nonce,
			user_id: userId,
		} )
			.done( function ( response ) {
				if ( ! response || ! response.success ) {
					mostrarError( response && response.data ? response.data.message : AU_WMS.i18n.genericError );
					return;
				}

				alConocerlo( userId, response.data );
			} )
			.fail( function () {
				mostrarError( AU_WMS.i18n.genericError );
			} );
	}

	window.AU_WMS_obtenerEscenarioProgramas = obtenerEscenarioYMostrarModal;

	/**
	 * Muestra el modal correspondiente al escenario del usuario
	 * (Octágono / Inspira / ambos / ninguno), con los botones
	 * correspondientes a cada caso.
	 *
	 * @param {number} userId    ID del usuario.
	 * @param {Object} escenario {email, tiene_inspira, tiene_octagono}.
	 */
	function mostrarModalEscenarioBorrado( userId, escenario ) {
		var tieneInspira = !! escenario.tiene_inspira;
		var tieneOctagono = !! escenario.tiene_octagono;

		var titulo;
		var texto;
		var mostrarBorrarDefinitivo = false;

		if ( tieneInspira && tieneOctagono ) {
			titulo = AU_WMS.i18n.escenarioAmbosTitulo;
			texto = AU_WMS.i18n.escenarioAmbosTexto;
		} else if ( tieneOctagono ) {
			titulo = AU_WMS.i18n.escenarioOctagonoTitulo;
			texto = AU_WMS.i18n.escenarioOctagonoTexto;
		} else if ( tieneInspira ) {
			titulo = AU_WMS.i18n.escenarioInspiraTitulo;
			texto = AU_WMS.i18n.escenarioInspiraTexto;
		} else {
			titulo = AU_WMS.i18n.escenarioSoloWmsTitulo;
			texto = AU_WMS.i18n.escenarioSoloWmsTexto;
			mostrarBorrarDefinitivo = true;
		}

		Swal.fire( {
			title: titulo,
			text: texto,
			icon: 'warning',
			showCancelButton: true,
			showDenyButton: mostrarBorrarDefinitivo,
			confirmButtonText: AU_WMS.i18n.btnDejarWms,
			denyButtonText: AU_WMS.i18n.btnBorrarDefinitivo,
			cancelButtonText: AU_WMS.i18n.cancelButton,
			confirmButtonColor: '#131A1E',
			denyButtonColor: '#dc2626',
			reverseButtons: true,
		} ).then( function ( result ) {
			if ( result.isConfirmed ) {
				ejecutarDejarDeSerUsuarioWms( userId );
			} else if ( result.isDenied ) {
				ejecutarBorrarDefinitivo( userId );
			}
		} );
	}

	/**
	 * Ejecuta el flujo "Dejar de ser usuario WMS".
	 *
	 * @param {number} userId ID del usuario.
	 */
	function ejecutarDejarDeSerUsuarioWms( userId ) {
		Swal.fire( {
			title: AU_WMS.i18n.loading,
			allowOutsideClick: false,
			allowEscapeKey: false,
			showConfirmButton: false,
			didOpen: function () {
				Swal.showLoading();
			},
		} );

		$.post( AU_WMS.ajaxUrl, {
			action: 'au_wms_usuario_dejar_wms',
			nonce: AU_WMS.nonce,
			user_id: userId,
		} )
			.done( function ( response ) {
				if ( ! response || ! response.success ) {
					mostrarError( response && response.data ? response.data.message : AU_WMS.i18n.genericError );
					return;
				}

				var mensaje;
				if ( response.data.tiene_inspira && response.data.tiene_octagono ) {
					mensaje = AU_WMS.i18n.exitoAmbos;
				} else if ( response.data.tiene_octagono ) {
					mensaje = AU_WMS.i18n.exitoOctagono;
				} else if ( response.data.tiene_inspira ) {
					mensaje = AU_WMS.i18n.exitoInspira;
				} else {
					mensaje = AU_WMS.i18n.exitoSoloWms;
				}
				mensaje = mensaje.replace( '{EMAIL}', response.data.email );

				Swal.fire( {
					icon: 'success',
					title: mensaje,
				} );

				refrescarListaTrasAccion();
			} )
			.fail( function () {
				mostrarError( AU_WMS.i18n.genericError );
			} );
	}

	/**
	 * Ejecuta el flujo "Borrar definitivamente" (solo disponible cuando
	 * el usuario no tiene Inspira ni Octágono).
	 *
	 * @param {number} userId ID del usuario.
	 */
	function ejecutarBorrarDefinitivo( userId ) {
		Swal.fire( {
			title: AU_WMS.i18n.loading,
			allowOutsideClick: false,
			allowEscapeKey: false,
			showConfirmButton: false,
			didOpen: function () {
				Swal.showLoading();
			},
		} );

		$.post( AU_WMS.ajaxUrl, {
			action: 'au_wms_eliminar_usuario',
			nonce: AU_WMS.nonce,
			user_id: userId,
		} )
			.done( function ( response ) {
				if ( ! response || ! response.success ) {
					mostrarError( response && response.data ? response.data.message : AU_WMS.i18n.genericError );
					return;
				}

				Swal.fire( {
					icon: 'success',
					title: response.data.message,
				} );

				refrescarListaTrasAccion();
			} )
			.fail( function () {
				mostrarError( AU_WMS.i18n.genericError );
			} );
	}

	/**
	 * Solicita confirmación (SweetAlert2) e inicia sesión como el usuario
	 * seleccionado.
	 *
	 * @param {number} userId ID del usuario a impersonar.
	 */
	/**
	 * Pide confirmación y habilita/deshabilita el acceso de inicio de
	 * sesión de un usuario.
	 *
	 * @param {number}  userId               ID del usuario.
	 * @param {boolean} deshabilitadoActualmente Si actualmente tiene el acceso deshabilitado.
	 */
	function confirmarToggleAccesoLogin( userId, deshabilitadoActualmente ) {
		var titulo = deshabilitadoActualmente ? AU_WMS.i18n.habilitarAccesoConfirmTitle : AU_WMS.i18n.deshabilitarAccesoConfirmTitle;
		var texto = deshabilitadoActualmente ? AU_WMS.i18n.habilitarAccesoConfirmText : AU_WMS.i18n.deshabilitarAccesoConfirmText;

		Swal.fire( {
			title: titulo,
			text: texto,
			icon: 'warning',
			showCancelButton: true,
			confirmButtonText: AU_WMS.i18n.aceptar,
			cancelButtonText: AU_WMS.i18n.cancelButton,
			customClass: deshabilitadoActualmente ? {} : { confirmButton: 'au-wms-swal-danger' },
			reverseButtons: true,
		} ).then( function ( result ) {
			if ( ! result.isConfirmed ) {
				return;
			}

			$.post( AU_WMS.ajaxUrl, {
				action: 'au_wms_alternar_acceso_login',
				nonce: AU_WMS.nonce,
				user_id: userId,
			} )
				.done( function ( response ) {
					if ( ! response || ! response.success ) {
						mostrarError( response && response.data ? response.data.message : AU_WMS.i18n.genericError );
						return;
					}

					var mensaje = response.data.deshabilitado ? AU_WMS.i18n.accesoDeshabilitadoExito : AU_WMS.i18n.accesoHabilitadoExito;

					Swal.fire( { icon: 'success', title: mensaje, timer: 1800, showConfirmButton: false } );
					cargarUsuarios();
				} )
				.fail( function () {
					mostrarError( AU_WMS.i18n.genericError );
				} );
		} );
	}

	/**
	 * Pide el nuevo correo (SweetAlert2 con input) y lo actualiza en
	 * wp_users + wp_correos_configurados.
	 *
	 * @param {number} userId       ID del usuario.
	 * @param {string} correoActual Correo actual (se precarga en el input).
	 */
	/**
	 * Genera una contraseña aleatoria de 8 caracteres, garantizando al
	 * menos una mayúscula, una minúscula, un número y un símbolo. Evita
	 * caracteres ambiguos (0/O, 1/l/I) para que sea más fácil de leer y
	 * transcribir a mano.
	 *
	 * @return string
	 */
	function generarPasswordAleatoria() {
		var mayus = 'ABCDEFGHJKLMNPQRSTUVWXYZ';
		var minus = 'abcdefghijkmnpqrstuvwxyz';
		var numeros = '23456789';
		var simbolos = '!@#$%&*+-=?';
		var todos = mayus + minus + numeros + simbolos;

		var partes = [
			mayus.charAt( Math.floor( Math.random() * mayus.length ) ),
			minus.charAt( Math.floor( Math.random() * minus.length ) ),
			numeros.charAt( Math.floor( Math.random() * numeros.length ) ),
			simbolos.charAt( Math.floor( Math.random() * simbolos.length ) ),
		];

		while ( partes.length < 8 ) {
			partes.push( todos.charAt( Math.floor( Math.random() * todos.length ) ) );
		}

		// Barajar (Fisher-Yates) para que las 4 categorías garantizadas
		// no queden siempre al principio.
		for ( var i = partes.length - 1; i > 0; i-- ) {
			var j = Math.floor( Math.random() * ( i + 1 ) );
			var tmp = partes[ i ];
			partes[ i ] = partes[ j ];
			partes[ j ] = tmp;
		}

		return partes.join( '' );
	}

	/**
	 * Abre el modal "Cambiar Contraseña": input de texto + botón de
	 * generar aleatoria + Cancelar/Cambiar Contraseña. Expuesta
	 * globalmente para reutilizarse desde Empresas y Usuarios Externos
	 * sin duplicar esta lógica.
	 *
	 * @param {number} userId       ID del usuario.
	 * @param {string} correoActual Correo del usuario (para el mensaje final).
	 */
	function abrirModalCambiarPassword( userId, correoActual ) {
		Swal.fire( {
			title: AU_WMS.i18n.cambiarPasswordTitulo,
			html:
				'<div class="au-wms-password-field">' +
					'<input type="text" id="au-wms-swal-password-input" class="au-wms-input" placeholder="' + AU_WMS.i18n.cambiarPasswordPlaceholder + '" autocomplete="off" />' +
					'<button type="button" id="au-wms-swal-dice-btn" class="au-wms-refresh-btn" title="' + AU_WMS.i18n.cambiarPasswordGenerar + '">' +
						'<span class="dashicons dashicons-randomize"></span>' +
					'</button>' +
				'</div>',
			showCancelButton: true,
			confirmButtonText: AU_WMS.i18n.cambiarPasswordConfirmar,
			cancelButtonText: AU_WMS.i18n.cancelButton,
			reverseButtons: true,
			didOpen: function () {
				document.getElementById( 'au-wms-swal-dice-btn' ).addEventListener( 'click', function () {
					document.getElementById( 'au-wms-swal-password-input' ).value = generarPasswordAleatoria();
				} );
			},
			preConfirm: function () {
				var valor = document.getElementById( 'au-wms-swal-password-input' ).value;
				if ( ! valor ) {
					Swal.showValidationMessage( AU_WMS.i18n.cambiarPasswordObligatoria );
					return false;
				}
				return valor;
			},
		} ).then( function ( result ) {
			if ( ! result.isConfirmed || ! result.value ) {
				return;
			}

			ejecutarCambiarPassword( userId, result.value );
		} );
	}

	window.AU_WMS_abrirModalCambiarPassword = abrirModalCambiarPassword;

	/**
	 * Ejecuta el cambio de contraseña vía AJAX y muestra el mensaje de
	 * éxito con el correo y la nueva contraseña.
	 *
	 * @param {number} userId        ID del usuario.
	 * @param {string} nuevaPassword Nueva contraseña.
	 */
	function ejecutarCambiarPassword( userId, nuevaPassword ) {
		Swal.fire( {
			title: AU_WMS.i18n.loading,
			allowOutsideClick: false,
			allowEscapeKey: false,
			showConfirmButton: false,
			didOpen: function () {
				Swal.showLoading();
			},
		} );

		$.post( AU_WMS.ajaxUrl, {
			action: 'au_wms_cambiar_password',
			nonce: AU_WMS.nonce,
			user_id: userId,
			nueva_password: nuevaPassword,
		} )
			.done( function ( response ) {
				if ( ! response || ! response.success ) {
					mostrarError( response && response.data ? response.data.message : AU_WMS.i18n.genericError );
					return;
				}

				var mensaje = AU_WMS.i18n.cambiarPasswordExito
					.replace( '{EMAIL}', response.data.email )
					.replace( '{PASSWORD}', response.data.password )
					.replace( '{EMAIL2}', response.data.email );

				Swal.fire( { icon: 'success', title: mensaje } );
			} )
			.fail( function () {
				mostrarError( AU_WMS.i18n.genericError );
			} );
	}

	function confirmarCambiarCorreo( userId, correoActual ) {
		Swal.fire( {
			title: AU_WMS.i18n.cambiarCorreoTitulo,
			input: 'email',
			inputValue: correoActual,
			inputLabel: AU_WMS.i18n.cambiarCorreoLabel,
			showCancelButton: true,
			confirmButtonText: AU_WMS.i18n.cambiarCorreoConfirmar,
			cancelButtonText: AU_WMS.i18n.cancelButton,
			reverseButtons: true,
			inputValidator: function ( value ) {
				if ( ! value ) {
					return AU_WMS.i18n.cambiarCorreoObligatorio;
				}
			},
		} ).then( function ( result ) {
			if ( ! result.isConfirmed || ! result.value ) {
				return;
			}

			var nuevoCorreo = result.value;

			$.post( AU_WMS.ajaxUrl, {
				action: 'au_wms_cambiar_correo',
				nonce: AU_WMS.nonce,
				user_id: userId,
				nuevo_correo: nuevoCorreo,
			} )
				.done( function ( response ) {
					if ( ! response || ! response.success ) {
						mostrarError( response && response.data ? response.data.message : AU_WMS.i18n.genericError );
						return;
					}

					Swal.fire( {
						icon: 'success',
						title: AU_WMS.i18n.cambiarCorreoExito,
						timer: 1800,
						showConfirmButton: false,
					} );
					cargarUsuarios();
				} )
				.fail( function () {
					mostrarError( AU_WMS.i18n.genericError );
				} );
		} );
	}

	function confirmarLoginComoUsuario( userId ) {
		Swal.fire( {
			title: AU_WMS.i18n.confirmLoginTitle,
			text: AU_WMS.i18n.confirmLoginText,
			icon: 'question',
			showCancelButton: true,
			confirmButtonText: AU_WMS.i18n.confirmLoginButton,
			cancelButtonText: AU_WMS.i18n.cancelButton,
			confirmButtonColor: '#131A1E',
			reverseButtons: true,
		} ).then( function ( result ) {
			if ( ! result.isConfirmed ) {
				return;
			}

			Swal.fire( {
				title: AU_WMS.i18n.loading,
				allowOutsideClick: false,
				didOpen: function () {
					Swal.showLoading();
				},
			} );

			$.post( AU_WMS.ajaxUrl, {
				action: 'au_wms_login_como_usuario',
				nonce: AU_WMS.nonce,
				user_id: userId,
			} )
				.done( function ( response ) {
					if ( response && response.success ) {
						Swal.fire( {
							icon: 'success',
							title: response.data.message,
							timer: 1500,
							showConfirmButton: false,
						} ).then( function () {
							window.location.href = response.data.redirect;
						} );
					} else {
						mostrarError( response && response.data ? response.data.message : AU_WMS.i18n.genericError );
					}
				} )
				.fail( function () {
					mostrarError( AU_WMS.i18n.genericError );
				} );
		} );
	}

	// Punto de integración con empresas.js: reutiliza la misma
	// confirmación + flujo de "iniciar sesión como usuario" del Tab
	// Integrantes, en vez de duplicar la lógica.
	window.AU_WMS_confirmarLoginComoUsuario = confirmarLoginComoUsuario;

	// Publicación en el espacio de nombres compartido.
	App.descargarResultadoTest = descargarResultadoTest;
	App.iniciarFlujoBorrarUsuario = iniciarFlujoBorrarUsuario;
	App.refrescarProgramasSilencioso = refrescarProgramasSilencioso;
	App.procesarLoteSilencioso = procesarLoteSilencioso;
	App.obtenerEscenarioYMostrarModal = obtenerEscenarioYMostrarModal;
	App.mostrarModalEscenarioBorrado = mostrarModalEscenarioBorrado;
	App.ejecutarDejarDeSerUsuarioWms = ejecutarDejarDeSerUsuarioWms;
	App.ejecutarBorrarDefinitivo = ejecutarBorrarDefinitivo;
	App.confirmarToggleAccesoLogin = confirmarToggleAccesoLogin;
	App.generarPasswordAleatoria = generarPasswordAleatoria;
	App.abrirModalCambiarPassword = abrirModalCambiarPassword;
	App.ejecutarCambiarPassword = ejecutarCambiarPassword;
	App.confirmarCambiarCorreo = confirmarCambiarCorreo;
	App.confirmarLoginComoUsuario = confirmarLoginComoUsuario;
} )( jQuery );
