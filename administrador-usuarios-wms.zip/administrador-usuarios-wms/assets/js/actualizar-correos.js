/**
 * Administrador de Usuarios (WMS Latam) — Asistente de actualización
 * masiva de correos ("Actualizar correos").
 *
 * Depende de jQuery y SweetAlert2 (ya cargados por admin.js), y del
 * objeto global `AU_WMS` localizado desde PHP.
 */
( function ( $ ) {
	'use strict';

	var wizard = {
		step: 1,
		file: null,
		updateId: '',
		headers: [],
		colActual: '',
		colNuevo: '',
		preview: null,
		procesando: false,
		resultadosAcumulados: [],
	};

	$( document ).ready( function () {
		if ( ! $( '#au-wms-mailupdate-overlay' ).length ) {
			return;
		}

		initModalTriggers();
		initDropzone();
		initColumnSelects();
		initFooterNavigation();
	} );

	/**
	 * Abre/cierra el modal y cablea el botón principal "Actualizar correos".
	 */
	function initModalTriggers() {
		$( '#au-wms-btn-mailupdate' ).on( 'click', function () {
			resetWizard();
			$( '#au-wms-mailupdate-overlay' ).addClass( 'is-open' );
		} );

		$( '#au-wms-mailupdate-close, #au-wms-mailupdate-btn-cancelar' ).on( 'click', function () {
			solicitarCierre();
		} );

		$( '#au-wms-mailupdate-overlay' ).on( 'click', function ( event ) {
			if ( event.target === this ) {
				solicitarCierre();
			}
		} );
	}

	/**
	 * Pide confirmación antes de cerrar si ya hay progreso en el
	 * asistente (a partir del paso 2).
	 */
	function solicitarCierre() {
		if ( wizard.step <= 1 ) {
			cerrarModal();
			return;
		}

		Swal.fire( {
			title: AU_WMS.i18n.importConfirmCancelTitle,
			text: AU_WMS.i18n.importConfirmCancelText,
			icon: 'warning',
			showCancelButton: true,
			confirmButtonText: AU_WMS.i18n.confirmDeleteButton,
			cancelButtonText: AU_WMS.i18n.cancelButton,
			customClass: { confirmButton: 'au-wms-swal-danger' },
			reverseButtons: true,
		} ).then( function ( result ) {
			if ( result.isConfirmed ) {
				cerrarModal();
			}
		} );
	}

	function cerrarModal() {
		$( '#au-wms-mailupdate-overlay' ).removeClass( 'is-open' );
		if ( wizard.procesando && 'function' === typeof window.AU_WMS_refrescarTabla ) {
			window.AU_WMS_refrescarTabla();
		}
	}

	/**
	 * Reinicia todo el estado del asistente y vuelve al paso 1.
	 */
	function resetWizard() {
		wizard = {
			step: 1,
			file: null,
			updateId: '',
			headers: [],
			colActual: '',
			colNuevo: '',
			preview: null,
			procesando: false,
			resultadosAcumulados: [],
		};

		$( '#au-wms-mailupdate-file-selected' ).hide();
		$( '#au-wms-mailupdate-dropzone' ).show();
		$( '#au-wms-mailupdate-file-input' ).val( '' );
		$( '#au-wms-mailupdate-columnas' ).hide();
		$( '#au-wms-mailupdate-col-actual' ).empty().append(
			'<option value="">' + AU_WMS.i18n.selectColumnPlaceholder + '</option>'
		);
		$( '#au-wms-mailupdate-col-nuevo' ).empty().append(
			'<option value="">' + AU_WMS.i18n.selectColumnPlaceholder + '</option>'
		);
		$( '#au-wms-mailupdate-generar-password' ).prop( 'checked', false );
		$( '#au-wms-mailupdate-preview-body' ).empty();
		$( '#au-wms-mailupdate-summary' ).empty();
		$( '#au-wms-mailupdate-progress-fill' ).css( 'width', '0%' );
		$( '#au-wms-mailupdate-progress-text' ).text( '0 / 0' );
		$( '#au-wms-mailupdate-final-summary' ).hide().empty();
		$( '#au-wms-mailupdate-final-table-wrapper' ).hide();
		$( '#au-wms-mailupdate-final-table-body' ).empty();
		$( '#au-wms-mailupdate-btn-siguiente' ).prop( 'disabled', true );
		$( '#au-wms-mailupdate-btn-actualizar' ).prop( 'disabled', true );

		irAPaso( 1 );
	}

	/**
	 * Dropzone de subida de archivo (click y drag & drop). En cuanto
	 * se selecciona un archivo válido, se sube y analiza automáticamente.
	 */
	function initDropzone() {
		var $dropzone = $( '#au-wms-mailupdate-dropzone' );
		var $fileInput = $( '#au-wms-mailupdate-file-input' );

		$dropzone.on( 'click', function () {
			$fileInput.get( 0 ).click();
		} );

		$dropzone.on( 'dragover', function ( event ) {
			event.preventDefault();
			$dropzone.addClass( 'is-dragover' );
		} );

		$dropzone.on( 'dragleave', function () {
			$dropzone.removeClass( 'is-dragover' );
		} );

		$dropzone.on( 'drop', function ( event ) {
			event.preventDefault();
			$dropzone.removeClass( 'is-dragover' );

			var files = event.originalEvent.dataTransfer.files;
			if ( files && files.length ) {
				seleccionarArchivo( files[ 0 ] );
			}
		} );

		$fileInput.on( 'change', function () {
			if ( this.files && this.files.length ) {
				seleccionarArchivo( this.files[ 0 ] );
			}
		} );

		$( '#au-wms-mailupdate-file-remove' ).on( 'click', function ( event ) {
			event.stopPropagation();
			wizard.file = null;
			wizard.updateId = '';
			$( '#au-wms-mailupdate-file-selected' ).hide();
			$( '#au-wms-mailupdate-dropzone' ).show();
			$( '#au-wms-mailupdate-columnas' ).hide();
			$( '#au-wms-mailupdate-btn-siguiente' ).prop( 'disabled', true );
			$fileInput.val( '' );
		} );
	}

	/**
	 * Guarda el archivo seleccionado, actualiza la vista y lo sube de
	 * inmediato para detectar sus columnas.
	 *
	 * @param {File} file Archivo seleccionado.
	 */
	function seleccionarArchivo( file ) {
		var extension = file.name.split( '.' ).pop().toLowerCase();

		if ( [ 'xls', 'xlsx' ].indexOf( extension ) === -1 ) {
			mostrarErrorSwal( AU_WMS.i18n.mailupdateInvalidFile );
			return;
		}

		wizard.file = file;
		$( '#au-wms-mailupdate-file-name' ).text( file.name );
		$( '#au-wms-mailupdate-dropzone' ).hide();
		$( '#au-wms-mailupdate-file-selected' ).show();

		subirArchivo();
	}

	/**
	 * Sube el archivo vía AJAX (multipart/form-data) y, si el análisis
	 * es exitoso, puebla los dos selects de columnas.
	 */
	function subirArchivo() {
		mostrarCargandoSwal( AU_WMS.i18n.importUploading );

		var formData = new FormData();
		formData.append( 'action', 'au_wms_mailupdate_upload' );
		formData.append( 'nonce', AU_WMS.nonce );
		formData.append( 'archivo', wizard.file );

		$.ajax( {
			url: AU_WMS.ajaxUrl,
			type: 'POST',
			data: formData,
			processData: false,
			contentType: false,
		} )
			.done( function ( response ) {
				Swal.close();

				if ( ! response || ! response.success ) {
					mostrarErrorSwal( response && response.data ? response.data.message : AU_WMS.i18n.genericError );
					return;
				}

				wizard.updateId = response.data.update_id;
				wizard.headers = response.data.headers;

				construirSelectsColumnas();
				$( '#au-wms-mailupdate-columnas' ).show();
				actualizarEstadoSiguiente();
			} )
			.fail( function () {
				Swal.close();
				mostrarErrorSwal( AU_WMS.i18n.genericError );
			} );
	}

	/**
	 * Puebla los dos <select> de columnas con los encabezados
	 * detectados en el archivo.
	 */
	function construirSelectsColumnas() {
		[ '#au-wms-mailupdate-col-actual', '#au-wms-mailupdate-col-nuevo' ].forEach( function ( selector ) {
			var $select = $( selector );
			$select.empty().append( '<option value="">' + AU_WMS.i18n.selectColumnPlaceholder + '</option>' );

			wizard.headers.forEach( function ( header, indice ) {
				$select.append( '<option value="' + indice + '">' + $( '<div>' ).text( header ).html() + '</option>' );
			} );
		} );
	}

	/**
	 * Cablea los cambios de los selects de columnas.
	 */
	function initColumnSelects() {
		$( '#au-wms-mailupdate-col-actual' ).on( 'change', function () {
			wizard.colActual = $( this ).val();
			actualizarEstadoSiguiente();
		} );

		$( '#au-wms-mailupdate-col-nuevo' ).on( 'change', function () {
			wizard.colNuevo = $( this ).val();
			actualizarEstadoSiguiente();
		} );
	}

	/**
	 * Habilita el botón "Siguiente" solo cuando ambas columnas fueron
	 * seleccionadas.
	 */
	function actualizarEstadoSiguiente() {
		var listo = '' !== wizard.colActual && '' !== wizard.colNuevo;
		$( '#au-wms-mailupdate-btn-siguiente' ).prop( 'disabled', ! listo );
	}

	/**
	 * Cablea los botones del pie del modal.
	 */
	function initFooterNavigation() {
		$( '#au-wms-mailupdate-btn-atras' ).on( 'click', function () {
			irAPaso( wizard.step - 1 );
		} );

		$( '#au-wms-mailupdate-btn-siguiente' ).on( 'click', function () {
			validarActualizacion();
		} );

		$( '#au-wms-mailupdate-btn-actualizar' ).on( 'click', function () {
			confirmarYProcesar();
		} );

		$( '#au-wms-mailupdate-btn-finalizar' ).on( 'click', function () {
			cerrarModal();
		} );
	}

	/**
	 * Ejecuta la validación previa (sin escribir en base de datos) y
	 * renderiza la tabla de previsualización del paso 2.
	 */
	function validarActualizacion() {
		mostrarCargandoSwal( AU_WMS.i18n.importValidating );

		$.post( AU_WMS.ajaxUrl, {
			action: 'au_wms_mailupdate_validar',
			nonce: AU_WMS.nonce,
			update_id: wizard.updateId,
			col_actual: wizard.colActual,
			col_nuevo: wizard.colNuevo,
		} )
			.done( function ( response ) {
				Swal.close();

				if ( ! response || ! response.success ) {
					mostrarErrorSwal( response && response.data ? response.data.message : AU_WMS.i18n.genericError );
					return;
				}

				wizard.preview = response.data;
				renderPrevisualizacion( response.data );
				irAPaso( 2 );
			} )
			.fail( function () {
				Swal.close();
				mostrarErrorSwal( AU_WMS.i18n.genericError );
			} );
	}

	/**
	 * Renderiza la tabla de previsualización y el resumen numérico.
	 *
	 * @param {Object} data Respuesta de au_wms_mailupdate_validar.
	 */
	function renderPrevisualizacion( data ) {
		var $body = $( '#au-wms-mailupdate-preview-body' );
		$body.empty();

		data.filas.forEach( function ( fila ) {
			var $tr = $( '<tr></tr>' );
			$tr.append( $( '<td></td>' ).text( fila.correo_actual ) );
			$tr.append( $( '<td></td>' ).text( fila.correo_nuevo ) );

			var $tdEstado = $( '<td></td>' );
			$tdEstado.append( construirBadgeEstado( fila.estado ) );
			$tr.append( $tdEstado );

			$tr.append( $( '<td></td>' ).text( fila.observacion ) );

			$body.append( $tr );
		} );

		$( '#au-wms-mailupdate-summary' ).html(
			'<strong>' + data.resumen.total + '</strong> ' + AU_WMS.i18n.mailupdateResumenTotal + ' — ' +
			'<span class="au-wms-import-final-ok">' + data.resumen.listos + ' ' + AU_WMS.i18n.mailupdateResumenListos + '</span> · ' +
			'<span class="au-wms-import-final-error">' + data.resumen.errores + ' ' + AU_WMS.i18n.mailupdateResumenErrores + '</span> · ' +
			data.resumen.omitidos + ' ' + AU_WMS.i18n.mailupdateResumenOmitidos
		);

		$( '#au-wms-mailupdate-btn-actualizar' ).prop( 'disabled', data.resumen.listos <= 0 );
	}

	/**
	 * Construye el badge visual (✅/❌/⚠️) para el estado de una fila.
	 *
	 * @param {string} estado 'listo' | 'error' | 'omitido'.
	 * @return {jQuery}
	 */
	function construirBadgeEstado( estado ) {
		if ( 'listo' === estado ) {
			return $( '<span class="au-wms-badge au-wms-badge--test-ok"></span>' ).text( '✅ ' + AU_WMS.i18n.mailupdateEstadoListo );
		}

		if ( 'omitido' === estado ) {
			return $( '<span class="au-wms-badge au-wms-badge--test-sin"></span>' ).text( '⚠️ ' + AU_WMS.i18n.mailupdateEstadoOmitido );
		}

		return $( '<span class="au-wms-badge au-wms-badge--warning"></span>' ).text( '❌ ' + AU_WMS.i18n.mailupdateEstadoError );
	}

	/**
	 * Muestra el SweetAlert de confirmación (Paso 3 del requerimiento)
	 * antes de ejecutar cualquier escritura en la base de datos.
	 */
	function confirmarYProcesar() {
		var total = wizard.preview.resumen.listos;

		Swal.fire( {
			title: AU_WMS.i18n.mailupdateConfirmTitle.replace( '{N}', total ),
			text: AU_WMS.i18n.mailupdateConfirmText,
			icon: 'warning',
			showCancelButton: true,
			confirmButtonText: AU_WMS.i18n.mailupdateConfirmButton,
			cancelButtonText: AU_WMS.i18n.cancelButton,
			reverseButtons: true,
		} ).then( function ( result ) {
			if ( result.isConfirmed ) {
				irAPaso( 3 );
				iniciarProcesamiento();
			}
		} );
	}

	// Lote fijo de 1: cada correo se procesa en su propia petición AJAX,
	// para que la barra de progreso avance correo por correo en tiempo
	// real (a costa de más idas y vueltas al servidor que con lotes
	// grandes).
	var BATCH_SIZE_MAX = 1;
	var lotesState = { batchSize: BATCH_SIZE_MAX, total: 0, listosEmails: [] };

	/**
	 * Inicia el procesamiento por lotes (paso 3) y actualiza la barra
	 * de progreso hasta completar la actualización.
	 */
	function iniciarProcesamiento() {
		wizard.procesando = true;
		wizard.resultadosAcumulados = [];

		$( '#au-wms-mailupdate-btn-cancelar, #au-wms-mailupdate-btn-atras, #au-wms-mailupdate-btn-actualizar' ).hide();
		$( '#au-wms-mailupdate-btn-finalizar' ).hide();
		$( '#au-wms-mailupdate-final-summary' ).hide().empty();
		$( '#au-wms-mailupdate-final-table-wrapper' ).hide();
		$( '#au-wms-mailupdate-final-table-body' ).empty();

		// Mismo orden en que el backend construye `$listos` en
		// AU_Mail_Update_Validator::validar() (push secuencial por
		// cada fila con estado 'listo'), así el correo que se muestra
		// aquí siempre coincide con el que realmente se está
		// procesando en ese offset.
		lotesState.listosEmails = ( wizard.preview.filas || [] ).filter( function ( fila ) {
			return 'listo' === fila.estado;
		} );

		var totalConocido = wizard.preview.resumen.listos || 0;
		lotesState.total = totalConocido;
		lotesState.batchSize = BATCH_SIZE_MAX;

		$( '#au-wms-mailupdate-progress-fill' ).css( 'width', '0%' );
		$( '#au-wms-mailupdate-progress-text' ).text( '0 / ' + totalConocido );
		mostrarCorreoActual( 0 );

		procesarLote( 0 );
	}

	/**
	 * Muestra en pantalla el correo que corresponde al offset dado
	 * (el que está a punto de procesarse), antes de disparar la
	 * petición AJAX.
	 *
	 * @param {number} offset Índice dentro de `lotesState.listosEmails`.
	 */
	function mostrarCorreoActual( offset ) {
		var fila = lotesState.listosEmails[ offset ];
		var $texto = $( '#au-wms-mailupdate-progress-current' );

		if ( ! fila ) {
			$texto.text( '' );
			return;
		}

		$texto.text( fila.correo_actual + ' → ' + fila.correo_nuevo );
	}

	/**
	 * Procesa un lote y se llama a sí misma hasta que el backend
	 * reporte `done: true`.
	 *
	 * @param {number} offset Posición inicial del siguiente lote.
	 */
	function procesarLote( offset ) {
		var generarPassword = $( '#au-wms-mailupdate-generar-password' ).is( ':checked' );

		$.post( AU_WMS.ajaxUrl, {
			action: 'au_wms_mailupdate_procesar_lote',
			nonce: AU_WMS.nonce,
			update_id: wizard.updateId,
			offset: offset,
			batch_size: lotesState.batchSize,
			generar_password: generarPassword ? 'true' : 'false',
		} )
			.done( function ( response ) {
				if ( ! response || ! response.success ) {
					mostrarErrorSwal( response && response.data ? response.data.message : AU_WMS.i18n.genericError );
					finalizarProcesamiento();
					return;
				}

				wizard.resultadosAcumulados = wizard.resultadosAcumulados.concat( response.data.results );

				var porcentaje = response.data.total > 0 ? Math.round( ( response.data.offset / response.data.total ) * 100 ) : 100;
				$( '#au-wms-mailupdate-progress-fill' ).css( 'width', porcentaje + '%' );
				$( '#au-wms-mailupdate-progress-text' ).text( response.data.offset + ' / ' + response.data.total );

				if ( response.data.done ) {
					$( '#au-wms-mailupdate-progress-current' ).text( '' );
					finalizarProcesamiento();
					return;
				}

				mostrarCorreoActual( response.data.offset );
				procesarLote( response.data.offset );
			} )
			.fail( function () {
				mostrarErrorSwal( AU_WMS.i18n.genericError );
				finalizarProcesamiento();
			} );
	}

	/**
	 * Muestra el resumen final (actualizados/errores) y la tabla de
	 * resultados detallada al terminar el procesamiento por lotes.
	 */
	function finalizarProcesamiento() {
		var actualizados = 0;
		var errores = 0;

		var $body = $( '#au-wms-mailupdate-final-table-body' );
		$body.empty();

		wizard.resultadosAcumulados.forEach( function ( item ) {
			if ( 'actualizado' === item.resultado ) {
				actualizados++;
			} else {
				errores++;
			}

			var $tr = $( '<tr></tr>' );
			$tr.append( $( '<td></td>' ).text( item.correo_anterior ) );
			$tr.append( $( '<td></td>' ).text( item.correo_nuevo ) );

			var $tdResultado = $( '<td></td>' );
			if ( 'actualizado' === item.resultado ) {
				$tdResultado.append( $( '<span class="au-wms-import-final-ok"></span>' ).text( '✅ ' + AU_WMS.i18n.mailupdateResultadoActualizado ) );
			} else {
				var texto = '❌ ' + AU_WMS.i18n.mailupdateResultadoError;
				if ( item.mensaje ) {
					texto += ' — ' + item.mensaje;
				}
				$tdResultado.append( $( '<span class="au-wms-import-final-error"></span>' ).text( texto ) );
			}
			$tr.append( $tdResultado );

			$body.append( $tr );
		} );

		var html = '<h3>' + AU_WMS.i18n.mailupdateDoneTitle + '</h3>';
		html += '<p>' + AU_WMS.i18n.mailupdateProcesados.replace( '{N}', wizard.resultadosAcumulados.length ) + '</p>';
		html += '<ul class="au-wms-import-final-list">';
		html += '<li class="au-wms-import-final-ok">' + actualizados + ' ' + AU_WMS.i18n.mailupdateActualizadosOk + '</li>';
		if ( errores > 0 ) {
			html += '<li class="au-wms-import-final-error">' + errores + ' ' + AU_WMS.i18n.mailupdateConErrores + '</li>';
		}
		html += '</ul>';

		$( '#au-wms-mailupdate-final-summary' ).html( html ).show();
		$( '#au-wms-mailupdate-final-table-wrapper' ).show();
		$( '#au-wms-mailupdate-btn-finalizar' ).show();
	}

	/**
	 * Navega a un paso específico del asistente (1-3).
	 *
	 * @param {number} paso Número de paso destino.
	 */
	function irAPaso( paso ) {
		wizard.step = paso;

		$( '#au-wms-mailupdate-overlay .au-wms-import-panel' ).removeClass( 'is-active' );
		$( '#au-wms-mailupdate-overlay .au-wms-import-panel[data-step-panel="' + paso + '"]' ).addClass( 'is-active' );

		$( '#au-wms-mailupdate-overlay .au-wms-import-step-dot' ).removeClass( 'is-active is-done' );
		$( '#au-wms-mailupdate-overlay .au-wms-import-step-dot' ).each( function () {
			var dotStep = parseInt( $( this ).data( 'step' ), 10 );
			if ( dotStep < paso ) {
				$( this ).addClass( 'is-done' );
			} else if ( dotStep === paso ) {
				$( this ).addClass( 'is-active' );
			}
		} );

		var $atras = $( '#au-wms-mailupdate-btn-atras' );
		var $siguiente = $( '#au-wms-mailupdate-btn-siguiente' );
		var $actualizar = $( '#au-wms-mailupdate-btn-actualizar' );
		var $finalizar = $( '#au-wms-mailupdate-btn-finalizar' );
		var $cancelar = $( '#au-wms-mailupdate-btn-cancelar' );

		$atras.toggle( 2 === paso );
		$cancelar.toggle( paso < 3 );
		$siguiente.toggle( 1 === paso );
		$actualizar.toggle( 2 === paso );
		$finalizar.toggle( false );
	}

	/**
	 * Muestra un SweetAlert de "cargando" con overlay bloqueante.
	 *
	 * @param {string} titulo Texto a mostrar.
	 */
	function mostrarCargandoSwal( titulo ) {
		Swal.fire( {
			title: titulo,
			allowOutsideClick: false,
			didOpen: function () {
				Swal.showLoading();
			},
		} );
	}

	/**
	 * Muestra un error mediante SweetAlert2.
	 *
	 * @param {string} mensaje Mensaje a mostrar.
	 */
	function mostrarErrorSwal( mensaje ) {
		Swal.fire( {
			icon: 'error',
			title: mensaje || AU_WMS.i18n.genericError,
		} );
	}
} )( jQuery );
