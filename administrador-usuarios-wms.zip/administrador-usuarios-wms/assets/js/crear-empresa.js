/**
 * Administrador de Usuarios (WMS Latam) — asistente "Crear Empresa"
 * (Tab Empresas → Acciones → Crear Empresa).
 *
 * Los pasos de áreas dependen de los programas elegidos en el paso 1;
 * `pasosActivos()` arma la secuencia y todo lo demás trabaja sobre ella,
 * así "Anterior"/"Siguiente" nunca caen en un paso que no aplica. Los
 * datos viven en el DOM de cada panel, que nunca se vacía al navegar:
 * volver atrás conserva lo escrito.
 *
 * Depende de jQuery y SweetAlert2. Usa `AU_WMS` (ajaxUrl, nonce, i18n) y
 * `AU_WMS_CREAR_EMPRESA` (valores por defecto y tokens faltantes).
 */
( function ( $ ) {
	'use strict';

	var PASOS_FIJOS_INICIO = [ 'programas', 'empresa' ];
	var PASOS_FIJOS_FINAL = [ 'resumen', 'resultado' ];

	var PROGRAMAS = {
		wms: 'Liderazgo (WMS)',
		inspira: 'Inspira',
		octagono: 'Octágono del sentido',
	};

	// Qué paso de áreas aporta cada programa (WMS crea áreas solo con
	// Liderazgo; los externos, uno por programa).
	var PASO_AREAS = {
		wms: 'areas_wms',
		inspira: 'areas_inspira',
		octagono: 'areas_octagono',
	};

	var pasoActual = 'programas';
	var ultimoResultado = null;
	var creando = false;

	$( document ).ready( function () {
		if ( ! $( '#au-wms-crear-empresa-overlay' ).length ) {
			return;
		}

		initEventos();
	} );

	function cfg() {
		return ( window.AU_WMS_CREAR_EMPRESA || {} );
	}

	function initEventos() {
		// Mismo patrón que "Licencias" en licencias.js: cierra el
		// dropdown "Acciones" de la toolbar y abre el modal.
		$( '#au-wms-btn-abrir-crear-empresa' ).on( 'click', function ( event ) {
			event.stopPropagation();
			$( '#au-wms-empresas-acciones-dropdown' ).removeClass( 'is-open' );
			abrirModal();
		} );
		$( '#au-wms-crear-empresa-close, #au-wms-ce-btn-cancelar, #au-wms-ce-btn-finalizar' ).on( 'click', cerrarModal );

		$( '#au-wms-crear-empresa-overlay' ).on( 'click', function ( event ) {
			if ( event.target === this ) {
				cerrarModal();
			}
		} );

		$( '#au-wms-ce-btn-siguiente' ).on( 'click', siguientePaso );
		$( '#au-wms-ce-btn-anterior' ).on( 'click', anteriorPaso );
		$( '#au-wms-ce-btn-crear' ).on( 'click', crearEmpresa );

		$( '.au-wms-ce-programa-input' ).on( 'change', function () {
			// El tipo de licencia es de Liderazgo: sin ese programa no se
			// muestra ni se envía.
			$( '#au-wms-ce-licencia-wrap' ).toggleClass( 'au-wms-hidden', ! programaElegido( 'wms' ) );
			pintarSeleccionProgramas();
			pintarPasos();
		} );

		$( '.au-wms-ce-add-row' ).on( 'click', function () {
			var destino = $( this ).data( 'ce-add' );
			agregarFila( destino, filaPorDefecto( destino ) );
		} );

		$( '#au-wms-crear-empresa-overlay' ).on( 'click', '.au-wms-ce-fila-remove', function () {
			$( this ).closest( '.au-wms-ce-fila' ).remove();
		} );

		// Reintento de un programa externo o del webhook, desde el panel
		// de resultado.
		$( '#au-wms-ce-resultado' ).on( 'click', '.au-wms-ce-reintentar', function () {
			reintentar( $( this ).data( 'objetivo' ) );
		} );

		// Copiar un campo suelto (correo o contraseña) o todo el resumen,
		// desde la propia tarjeta de credenciales.
		$( '#au-wms-ce-resultado' ).on( 'click', '.au-wms-ce-credencial-copiar', function () {
			copiarAlPortapapeles( String( $( this ).attr( 'data-valor' ) || '' ) );
		} );

		$( '#au-wms-ce-resultado' ).on( 'click', '.au-wms-ce-copiar-todo', copiarInformacion );
	}

	// ------------------------------------------------------------------
	// Apertura / cierre
	// ------------------------------------------------------------------

	function abrirModal() {
		pasoActual = 'programas';
		ultimoResultado = null;
		creando = false;

		$( '#au-wms-ce-nombre-empresa, #au-wms-ce-nit, #au-wms-ce-nombre-encargado, #au-wms-ce-apellidos, #au-wms-ce-contacto, #au-wms-ce-ocupacion, #au-wms-ce-email' ).val( '' );
		// La licencia de la EMPRESA arranca vacía ("Sin licencia"): la
		// configurada por defecto es la de las áreas, no la de la empresa.
		$( '#au-wms-ce-licencia' ).val( '' );
		$( '.au-wms-ce-programa-input' ).prop( 'checked', function () {
			return 'wms' === $( this ).val();
		} );
		$( '#au-wms-ce-licencia-wrap' ).removeClass( 'au-wms-hidden' );
		$( '#au-wms-ce-resumen, #au-wms-ce-resultado' ).empty();

		// Cada paso de áreas arranca con su fila por defecto, tomada de
		// la configuración del plugin.
		Object.keys( PASO_AREAS ).forEach( function ( programa ) {
			var destino = PASO_AREAS[ programa ];
			$( '[data-ce-filas="' + destino + '"]' ).empty();
			agregarFila( destino, filaPorDefecto( destino ) );
		} );

		limpiarError();
		pintarTokensFaltantes();
		pintarSeleccionProgramas();
		mostrarPaso( 'programas' );

		$( '#au-wms-crear-empresa-overlay' ).addClass( 'is-open' );
	}

	function cerrarModal() {
		if ( creando ) {
			return;
		}

		$( '#au-wms-crear-empresa-overlay' ).removeClass( 'is-open' );

		// Si hubo creación, el listado puede haber cambiado.
		if ( ultimoResultado && 'function' === typeof window.AU_WMS_recargarEmpresas ) {
			window.AU_WMS_recargarEmpresas();
		}
	}

	// ------------------------------------------------------------------
	// Pasos
	// ------------------------------------------------------------------

	function programasElegidos() {
		return $( '.au-wms-ce-programa-input:checked' ).map( function () {
			return $( this ).val();
		} ).get();
	}

	function programaElegido( clave ) {
		return programasElegidos().indexOf( clave ) !== -1;
	}

	/**
	 * Secuencia de pasos según los programas elegidos.
	 *
	 * @return {string[]}
	 */
	function pasosActivos() {
		var pasos = PASOS_FIJOS_INICIO.slice();

		[ 'wms', 'inspira', 'octagono' ].forEach( function ( programa ) {
			if ( programaElegido( programa ) ) {
				pasos.push( PASO_AREAS[ programa ] );
			}
		} );

		return pasos.concat( PASOS_FIJOS_FINAL );
	}

	/**
	 * Nombre legible de cada paso, para el rótulo "Paso 3 de 6 · …".
	 *
	 * @param {string} paso Clave del paso.
	 * @return {string}
	 */
	function etiquetaPaso( paso ) {
		var etiquetas = {
			programas: AU_WMS.i18n.cePasoProgramas || 'Programas',
			empresa: AU_WMS.i18n.cePasoEmpresa || 'Datos de la empresa',
			areas_wms: ( AU_WMS.i18n.ceAreasDe || 'Áreas de' ) + ' ' + PROGRAMAS.wms,
			areas_inspira: ( AU_WMS.i18n.ceAreasDe || 'Áreas de' ) + ' ' + PROGRAMAS.inspira,
			areas_octagono: ( AU_WMS.i18n.ceAreasDe || 'Áreas de' ) + ' ' + PROGRAMAS.octagono,
			resumen: AU_WMS.i18n.cePasoResumen || 'Resumen',
			resultado: AU_WMS.i18n.cePasoResultado || 'Resultado',
		};

		return etiquetas[ paso ] || paso;
	}

	/**
	 * Pinta los círculos de paso y el rótulo con el nombre del actual.
	 * Los ya recorridos quedan en verde (`is-done`), para distinguirlos
	 * de los que faltan.
	 */
	function pintarPasos() {
		var pasos = pasosActivos();
		var actual = pasos.indexOf( pasoActual );
		var $steps = $( '#au-wms-crear-empresa-steps' ).empty();

		pasos.forEach( function ( paso, index ) {
			$( '<span>' )
				.addClass( 'au-wms-import-step-dot' )
				.toggleClass( 'is-active', index === actual )
				.toggleClass( 'is-done', index < actual )
				.attr( 'data-step', paso )
				.attr( 'title', etiquetaPaso( paso ) )
				.text( index + 1 )
				.appendTo( $steps );
		} );

		$( '#au-wms-ce-paso-actual' ).text(
			( AU_WMS.i18n.cePaso || 'Paso' ) + ' ' + ( actual + 1 ) +
				' ' + ( AU_WMS.i18n.ceDe || 'de' ) + ' ' + pasos.length +
				' · ' + etiquetaPaso( pasoActual )
		);
	}

	function mostrarPaso( paso ) {
		pasoActual = paso;

		$( '[data-ce-panel]' ).removeClass( 'is-active' );
		$( '[data-ce-panel="' + paso + '"]' ).addClass( 'is-active' );

		var pasos = pasosActivos();
		var esPrimero = pasos.indexOf( paso ) === 0;
		var esResumen = 'resumen' === paso;
		var esResultado = 'resultado' === paso;

		$( '#au-wms-ce-btn-anterior' ).toggleClass( 'au-wms-hidden', esPrimero || esResultado );
		$( '#au-wms-ce-btn-cancelar' ).toggleClass( 'au-wms-hidden', esResultado );
		$( '#au-wms-ce-btn-siguiente' ).toggleClass( 'au-wms-hidden', esResumen || esResultado );
		$( '#au-wms-ce-btn-crear' ).toggleClass( 'au-wms-hidden', ! esResumen );
		// "Copiar información" vive dentro de la tarjeta de credenciales,
		// junto a lo que copia; el footer del último paso solo cierra.
		$( '#au-wms-ce-btn-finalizar' ).toggleClass( 'au-wms-hidden', ! esResultado );

		pintarPasos();
	}

	function siguientePaso() {
		var error = validarPaso( pasoActual );

		if ( error ) {
			mostrarError( error );
			return;
		}

		limpiarError();

		var pasos = pasosActivos();
		var siguiente = pasos[ pasos.indexOf( pasoActual ) + 1 ];

		if ( 'resumen' === siguiente ) {
			// El correo y el NIT definitivos los calcula el servidor (dependen
			// de lo que ya exista en la base de datos), así que el resumen se
			// pide antes de pintarlo. No crea nada.
			previsualizar();
			return;
		}

		mostrarPaso( siguiente );
	}

	function anteriorPaso() {
		limpiarError();

		var pasos = pasosActivos();
		var anterior = pasos[ pasos.indexOf( pasoActual ) - 1 ];

		if ( anterior ) {
			mostrarPaso( anterior );
		}
	}

	function validarPaso( paso ) {
		if ( 'programas' === paso && ! programasElegidos().length ) {
			return AU_WMS.i18n.ceSinProgramas || 'Debes seleccionar al menos un programa.';
		}

		if ( 'empresa' === paso && ! $.trim( $( '#au-wms-ce-nombre-empresa' ).val() ) ) {
			return AU_WMS.i18n.ceNombreObligatorio || 'El nombre de la empresa es obligatorio.';
		}

		if ( paso.indexOf( 'areas_' ) === 0 && ! leerFilas( paso ).length ) {
			return AU_WMS.i18n.ceSinAreas || 'Debes dejar al menos un área con nombre.';
		}

		return '';
	}

	// ------------------------------------------------------------------
	// Filas de áreas
	// ------------------------------------------------------------------

	function filaPorDefecto( destino ) {
		var c = cfg();

		if ( 'areas_wms' === destino ) {
			return {
				nombre: c.areaNombre || 'Área demo',
				cupos: c.areaCuposWms || 1,
				licencia_id: c.areaLicenciaId || '',
			};
		}

		return {
			nombre: c.areaNombre || 'Área demo',
			cupos: ( 'areas_inspira' === destino ? c.areaCuposInspira : c.areaCuposOctagono ) || 1,
			fecha_expiracion: c.fechaExpiracionPorDefecto || '',
		};
	}

	function agregarFila( destino, valores ) {
		var esWms = 'areas_wms' === destino;
		var template = document.getElementById( esWms ? 'au-wms-ce-fila-wms-template' : 'au-wms-ce-fila-externo-template' );
		var $fila = $( document.importNode( template.content, true ) ).find( '.au-wms-ce-fila' );

		$fila.find( '.au-wms-ce-fila-nombre' ).val( valores.nombre || '' );
		$fila.find( '.au-wms-ce-fila-cupos' ).val( valores.cupos || '' );

		if ( esWms ) {
			$fila.find( '.au-wms-ce-fila-licencia' ).val( String( valores.licencia_id || '' ) );
		} else {
			$fila.find( '.au-wms-ce-fila-fecha' ).val( valores.fecha_expiracion || '' );
		}

		$( '[data-ce-filas="' + destino + '"]' ).append( $fila );
	}

	/**
	 * Filas con nombre de un paso de áreas (las vacías se descartan).
	 *
	 * @param {string} destino Clave del paso (areas_wms, areas_inspira…).
	 * @return {Array}
	 */
	function leerFilas( destino ) {
		var esWms = 'areas_wms' === destino;
		var filas = [];

		$( '[data-ce-filas="' + destino + '"]' ).find( '.au-wms-ce-fila' ).each( function () {
			var $fila = $( this );
			var nombre = $.trim( $fila.find( '.au-wms-ce-fila-nombre' ).val() );

			if ( ! nombre ) {
				return;
			}

			var fila = {
				nombre: nombre,
				cupos: parseInt( $fila.find( '.au-wms-ce-fila-cupos' ).val(), 10 ) || 1,
			};

			if ( esWms ) {
				fila.licencia_id = parseInt( $fila.find( '.au-wms-ce-fila-licencia' ).val(), 10 ) || 0;
			} else {
				fila.fecha_expiracion = $fila.find( '.au-wms-ce-fila-fecha' ).val() || cfg().fechaExpiracionPorDefecto || '';
			}

			filas.push( fila );
		} );

		return filas;
	}

	// ------------------------------------------------------------------
	// Datos y envío
	// ------------------------------------------------------------------

	function datosEmpresa() {
		return {
			nombre_empresa: $.trim( $( '#au-wms-ce-nombre-empresa' ).val() ),
			nit_empresa: $.trim( $( '#au-wms-ce-nit' ).val() ),
			nombre_encargado: $.trim( $( '#au-wms-ce-nombre-encargado' ).val() ),
			apellidos_encargado: $.trim( $( '#au-wms-ce-apellidos' ).val() ),
			contacto: $.trim( $( '#au-wms-ce-contacto' ).val() ),
			ocupacion: $.trim( $( '#au-wms-ce-ocupacion' ).val() ),
			email: $.trim( $( '#au-wms-ce-email' ).val() ),
		};
	}

	function payloadBase() {
		return $.extend( datosEmpresa(), {
			nonce: AU_WMS.nonce,
			programas: programasElegidos(),
			licencia_id: programaElegido( 'wms' ) ? ( $( '#au-wms-ce-licencia' ).val() || 0 ) : 0,
			areas_wms: JSON.stringify( leerFilas( 'areas_wms' ) ),
			areas_inspira: JSON.stringify( leerFilas( 'areas_inspira' ) ),
			areas_octagono: JSON.stringify( leerFilas( 'areas_octagono' ) ),
		} );
	}

	function previsualizar() {
		var $boton = $( '#au-wms-ce-btn-siguiente' ).prop( 'disabled', true );

		$.post( AU_WMS.ajaxUrl, $.extend( payloadBase(), { action: 'au_wms_crear_empresa_previsualizar' } ) )
			.done( function ( response ) {
				if ( ! response || ! response.success ) {
					mostrarError( response && response.data ? response.data.message : AU_WMS.i18n.genericError );
					return;
				}

				pintarResumen( response.data.empresa );
				mostrarPaso( 'resumen' );
			} )
			.fail( function () {
				mostrarError( AU_WMS.i18n.genericError );
			} )
			.always( function () {
				$boton.prop( 'disabled', false );
			} );
	}

	function crearEmpresa() {
		if ( creando ) {
			return;
		}

		creando = true;
		limpiarError();

		// Se pasa al panel de resultado con la lista de operaciones en
		// curso: con tres plataformas la petición puede tardar bastante
		// (dos llamadas HTTP externas más el webhook) y el botón en
		// "Creando…" no alcanzaba a explicar la espera.
		pintarProgreso();
		mostrarPaso( 'resultado' );

		var $boton = $( '#au-wms-ce-btn-crear' )
			.prop( 'disabled', true )
			.text( AU_WMS.i18n.ceCreando || 'Creando…' );

		$.post( AU_WMS.ajaxUrl, $.extend( payloadBase(), { action: 'au_wms_crear_empresa' } ) )
			.done( function ( response ) {
				if ( ! response || ! response.success ) {
					// Falló WMS: no se creó nada. Se vuelve al resumen,
					// que conserva todo lo escrito para corregirlo.
					volverDesdeProgreso( response && response.data ? response.data.message : AU_WMS.i18n.genericError );
					return;
				}

				ultimoResultado = response.data;
				pintarResultado( ultimoResultado );
			} )
			.fail( function () {
				volverDesdeProgreso( AU_WMS.i18n.genericError );
			} )
			.always( function () {
				creando = false;
				$( '#au-wms-ce-btn-finalizar' ).prop( 'disabled', false );
				$boton.prop( 'disabled', false ).text( AU_WMS.i18n.ceCrear || 'Crear la empresa' );
			} );
	}

	function reintentar( objetivo ) {
		if ( ! ultimoResultado || ! ultimoResultado.op_id ) {
			return;
		}

		var $boton = $( '.au-wms-ce-reintentar[data-objetivo="' + objetivo + '"]' )
			.prop( 'disabled', true )
			.text( AU_WMS.i18n.ceReintentando || 'Reintentando…' );

		$.post( AU_WMS.ajaxUrl, {
			action: 'au_wms_crear_empresa_reintentar',
			nonce: AU_WMS.nonce,
			op_id: ultimoResultado.op_id,
			objetivo: objetivo,
		} )
			.done( function ( response ) {
				if ( ! response || ! response.success ) {
					Swal.fire( {
						icon: 'error',
						title: response && response.data ? response.data.message : AU_WMS.i18n.genericError,
					} );
					return;
				}

				ultimoResultado = response.data;
				pintarResultado( ultimoResultado );
			} )
			.fail( function () {
				Swal.fire( { icon: 'error', title: AU_WMS.i18n.genericError } );
			} )
			.always( function () {
				$boton.prop( 'disabled', false );
			} );
	}

	// ------------------------------------------------------------------
	// Resumen y resultado
	// ------------------------------------------------------------------

	function pintarResumen( empresa ) {
		var programas = programasElegidos();
		var $wrap = $( '#au-wms-ce-resumen' ).empty();

		var filas = [
			[ AU_WMS.i18n.ceEmpresa || 'Empresa', empresa.nombre_empresa ],
			[ 'NIT', empresa.nit_empresa ],
			[ AU_WMS.i18n.ceEncargado || 'Encargado', empresa.nombre_encargado + ' ' + empresa.apellidos_encargado ],
			[ AU_WMS.i18n.ceContacto || 'Contacto', empresa.contacto ],
			[ AU_WMS.i18n.ceOcupacion || 'Ocupación', empresa.ocupacion ],
			[ AU_WMS.i18n.ceCorreo || 'Correo que se usará', empresa.email ],
			[ AU_WMS.i18n.ceProgramas || 'Programas', programas.map( function ( p ) { return PROGRAMAS[ p ]; } ).join( ', ' ) ],
			[ AU_WMS.i18n.ceRolWms || 'Rol en WMS', programaElegido( 'wms' ) ? 'Company' : 'External User' ],
		];

		if ( programaElegido( 'wms' ) ) {
			filas.push( [ AU_WMS.i18n.ceLicencia || 'Licencia de la empresa', nombreLicencia( $( '#au-wms-ce-licencia' ).val() ) ] );
		}

		$wrap.append( listaDatos( filas ) );

		// Los valores que se completaron solos van como nota al pie, no
		// como un dato más: son metainformación de cómo se rellenó el
		// formulario, no parte de la empresa.
		if ( empresa.defaults_aplicados && empresa.defaults_aplicados.length ) {
			$wrap.append(
				$( '<p>' )
					.addClass( 'au-wms-ce-nota' )
					.text(
						( AU_WMS.i18n.ceDefaults || 'Valores predeterminados aplicados' ) + ': ' +
							empresa.defaults_aplicados.map( etiquetaCampo ).join( ', ' ) + '.'
					)
			);
		}

		[ 'wms', 'inspira', 'octagono' ].forEach( function ( programa ) {
			if ( ! programaElegido( programa ) ) {
				return;
			}

			var areas = leerFilas( PASO_AREAS[ programa ] );

			if ( ! areas.length ) {
				return;
			}

			$wrap.append( $( '<h4>' ).addClass( 'au-wms-ce-subtitulo' ).text( ( AU_WMS.i18n.ceAreasDe || 'Áreas de' ) + ' ' + PROGRAMAS[ programa ] ) );
			$wrap.append( listaAreasResumen( programa, areas ) );
		} );

		$wrap.append(
			$( '<p>' )
				.addClass( 'au-wms-settings-hint' )
				.text( AU_WMS.i18n.ceAvisoWebhook || 'Al crear, las credenciales se enviarán al webhook configurado.' )
		);
	}

	/**
	 * Panel que se muestra mientras corre la creación: la secuencia real
	 * de operaciones que el servidor va a ejecutar, en orden.
	 *
	 * El avance no es en vivo (todo ocurre en una sola petición, así que
	 * el navegador no sabe en cuál va): lo que aporta es decir qué está
	 * pasando y cuánto falta, en vez de un botón congelado.
	 */
	function pintarProgreso() {
		var $wrap = $( '#au-wms-ce-resultado' ).empty();

		$( '#au-wms-ce-btn-finalizar' ).prop( 'disabled', true );

		$wrap.append(
			$( '<div>' )
				.addClass( 'au-wms-ce-aviso au-wms-ce-aviso--progreso' )
				.append( $( '<span>' ).addClass( 'au-wms-ce-spinner' ) )
				.append( document.createTextNode( AU_WMS.i18n.ceCreandoAviso || 'Creando la empresa… no cierres esta ventana.' ) )
		);

		var operaciones = [];

		programasElegidos().forEach( function ( programa ) {
			operaciones.push( PROGRAMAS[ programa ] );
		} );

		if ( operaciones.indexOf( PROGRAMAS.wms ) === -1 ) {
			// Sin Liderazgo igual se crea el usuario en WMS.
			operaciones.unshift( PROGRAMAS.wms );
		}

		operaciones.push( AU_WMS.i18n.ceWebhook || 'Envío de credenciales' );

		operaciones.forEach( function ( nombre ) {
			$wrap.append(
				$( '<div>' )
					.addClass( 'au-wms-ce-estado is-pendiente' )
					.append( $( '<span>' ).addClass( 'dashicons dashicons-clock' ) )
					.append(
						$( '<div>' )
							.addClass( 'au-wms-ce-estado-texto' )
							.append( $( '<strong>' ).text( nombre ) )
							.append( $( '<span>' ).text( AU_WMS.i18n.ceEnEspera || 'En proceso…' ) )
					)
			);
		} );
	}

	/**
	 * Vuelve del panel de progreso al resumen cuando la creación no
	 * llegó a hacerse, mostrando el motivo.
	 *
	 * @param {string} mensaje Error a mostrar.
	 */
	function volverDesdeProgreso( mensaje ) {
		$( '#au-wms-ce-resultado' ).empty();
		mostrarPaso( 'resumen' );
		mostrarError( mensaje );
	}

	function pintarResultado( data ) {
		var $wrap = $( '#au-wms-ce-resultado' ).empty();
		var wms = data.wms || {};

		var pendientes = [];

		// Título real del resultado (antes usaba la clase de subtítulo y
		// el nombre de la empresa se leía como un rótulo secundario).
		$wrap.append(
			$( '<h3>' ).addClass( 'au-wms-ce-titulo' ).text( wms.nombre_empresa || '' )
		);

		// Las credenciales van primero y destacadas: es el único momento
		// en que esa contraseña se puede ver, y si se cierra el modal sin
		// copiarla ya no hay forma de recuperarla.
		$wrap.append( tarjetaCredenciales( data ) );

		// --- WMS ---
		$wrap.append( bloqueEstado( 'WMS', true, ( AU_WMS.i18n.ceRolAsignado || 'Rol asignado' ) + ': ' + ( wms.rol_etiqueta || wms.rol || '' ) ) );

		if ( wms.areas && wms.areas.length ) {
			$wrap.append( listaAreasCreadas( wms.areas ) );
		}

		// --- Programas externos ---
		( data.programas_seleccionados || [] ).forEach( function ( programa ) {
			if ( 'wms' === programa ) {
				return;
			}

			var resultado = ( data.programas || {} )[ programa ] || {};
			var ok = !! resultado.success;

			if ( ! ok ) {
				pendientes.push( PROGRAMAS[ programa ] );
			}

			$wrap.append( bloqueEstado( PROGRAMAS[ programa ], ok, resultado.message || '', ok ? '' : programa ) );

			if ( ok && resultado.areas && resultado.areas.length ) {
				$wrap.append( listaAreasCreadas( resultado.areas ) );
			}
		} );

		// --- Webhook ---
		var webhook = data.webhook || {};
		var webhookOk = !! webhook.success;

		if ( ! webhookOk ) {
			pendientes.push( AU_WMS.i18n.ceWebhook || 'Envío de credenciales' );
		}

		$wrap.append(
			bloqueEstado(
				AU_WMS.i18n.ceWebhook || 'Envío de credenciales',
				webhookOk,
				webhook.message || '',
				webhookOk ? '' : 'webhook'
			)
		);

		if ( pendientes.length ) {
			$wrap.prepend(
				$( '<div>' )
					.addClass( 'au-wms-ce-aviso au-wms-ce-aviso--pendiente' )
					.text( ( AU_WMS.i18n.cePendientes || 'La empresa se creó en WMS, pero quedaron operaciones pendientes:' ) + ' ' + pendientes.join( ', ' ) )
			);
		} else {
			$wrap.prepend(
				$( '<div>' )
					.addClass( 'au-wms-ce-aviso au-wms-ce-aviso--ok' )
					.text( AU_WMS.i18n.ceTodoOk || 'Todo se creó correctamente y las credenciales se enviaron.' )
			);
		}
	}

	/**
	 * Credenciales de acceso: solo las de WMS.
	 *
	 * Aunque la empresa se cree también en Inspira u Octágono (y cada una
	 * genere allá su propia contraseña), el inicio de sesión siempre pasa
	 * por WMS, así que esas otras contraseñas no le sirven a nadie y solo
	 * confundían al mostrarlas.
	 *
	 * @param {Object} data Resultado completo.
	 * @return {jQuery}
	 */
	function tarjetaCredenciales( data ) {
		var wms = data.wms || {};

		var $tarjeta = $( '<div>' ).addClass( 'au-wms-ce-credenciales' );

		$( '<div>' )
			.addClass( 'au-wms-ce-credenciales-head' )
			.append( $( '<span>' ).addClass( 'dashicons dashicons-admin-network' ) )
			.append( $( '<strong>' ).text( AU_WMS.i18n.ceCredenciales || 'Credenciales de acceso (WMS)' ) )
			.appendTo( $tarjeta );

		$tarjeta.append( campoCredencial( AU_WMS.i18n.ceCorreoCol || 'Correo', wms.email || '', false ) );
		$tarjeta.append( campoCredencial( AU_WMS.i18n.cePassword || 'Contraseña', wms.password || '', true ) );

		$( '<p>' )
			.addClass( 'au-wms-ce-credenciales-aviso' )
			.text( AU_WMS.i18n.cePasswordUnicaVez || 'Esta contraseña no se vuelve a mostrar: cópiala antes de cerrar.' )
			.appendTo( $tarjeta );

		$( '<button>' )
			.attr( 'type', 'button' )
			.addClass( 'au-wms-btn au-wms-btn--secondary au-wms-ce-copiar-todo' )
			.append( $( '<span>' ).addClass( 'dashicons dashicons-clipboard' ) )
			.append( document.createTextNode( ' ' + ( AU_WMS.i18n.ceCopiarTodo || 'Copiar información' ) ) )
			.appendTo( $tarjeta );

		return $tarjeta;
	}

	/**
	 * Una línea de la tarjeta de credenciales: etiqueta, valor en
	 * monoespaciada y su propio botón de copiar.
	 *
	 * @param {string}  etiqueta Nombre del campo.
	 * @param {string}  valor    Valor a mostrar y copiar.
	 * @param {boolean} destacar true para la contraseña (texto más grande).
	 * @return {jQuery}
	 */
	function campoCredencial( etiqueta, valor, destacar ) {
		var $campo = $( '<div>' ).addClass( 'au-wms-ce-credencial' );

		$( '<span>' ).addClass( 'au-wms-ce-credencial-label' ).text( etiqueta ).appendTo( $campo );

		$( '<code>' )
			.addClass( 'au-wms-ce-credencial-valor' )
			.toggleClass( 'is-destacado', !! destacar )
			.text( valor )
			.appendTo( $campo );

		$( '<button>' )
			.attr( 'type', 'button' )
			.addClass( 'au-wms-ce-credencial-copiar' )
			.attr( 'title', AU_WMS.i18n.ceCopiarCampo || 'Copiar' )
			.attr( 'aria-label', ( AU_WMS.i18n.ceCopiarCampo || 'Copiar' ) + ' ' + etiqueta )
			.attr( 'data-valor', valor )
			.append( $( '<span>' ).addClass( 'dashicons dashicons-clipboard' ) )
			.appendTo( $campo );

		return $campo;
	}

	function bloqueEstado( titulo, ok, detalle, objetivoReintento ) {
		var $bloque = $( '<div>' )
			.addClass( 'au-wms-ce-estado' )
			.addClass( ok ? 'is-ok' : 'is-ko' );

		$( '<span>' ).addClass( 'dashicons' ).addClass( ok ? 'dashicons-yes-alt' : 'dashicons-warning' ).appendTo( $bloque );

		var $texto = $( '<div>' ).addClass( 'au-wms-ce-estado-texto' ).appendTo( $bloque );
		$( '<strong>' ).text( titulo ).appendTo( $texto );

		if ( detalle ) {
			$( '<span>' ).text( detalle ).appendTo( $texto );
		}

		if ( objetivoReintento ) {
			$( '<button>' )
				.attr( 'type', 'button' )
				.addClass( 'au-wms-btn au-wms-btn--secondary au-wms-ce-reintentar' )
				.attr( 'data-objetivo', objetivoReintento )
				.text( AU_WMS.i18n.ceReintentar || 'Reintentar' )
				.appendTo( $bloque );
		}

		return $bloque;
	}

	function listaAreasCreadas( areas ) {
		var $lista = $( '<ul>' ).addClass( 'au-wms-ce-areas-creadas' );

		areas.forEach( function ( area ) {
			var partes = [ area.nombre ];

			if ( area.cupos ) {
				partes.push(
					area.cupos + ' ' + ( 1 === Number( area.cupos )
						? ( AU_WMS.i18n.ceCupo || 'cupo' )
						: ( AU_WMS.i18n.ceCupos || 'cupos' ) )
				);
			}
			if ( area.codigo ) {
				partes.push( ( AU_WMS.i18n.ceCodigo || 'Código' ) + ': ' + area.codigo );
			}
			if ( area.fecha_expiracion ) {
				partes.push( area.fecha_expiracion );
			}
			if ( false === area.success ) {
				partes.push( area.message || '' );
			}

			$( '<li>' ).text( partes.join( ' · ' ) ).appendTo( $lista );
		} );

		return $lista;
	}

	/**
	 * Resumen en lista de definición en vez de tabla: son pares
	 * etiqueta/valor, no datos tabulares, y la tabla con sus bordes y
	 * cabeceras pesaba mucho para lo que dice.
	 *
	 * @param {Array} filas Pares [etiqueta, valor].
	 * @return {jQuery}
	 */
	function listaDatos( filas ) {
		var $lista = $( '<dl>' ).addClass( 'au-wms-ce-datos' );

		filas.forEach( function ( fila ) {
			if ( ! fila[ 1 ] ) {
				return;
			}

			$( '<dt>' ).text( fila[ 0 ] ).appendTo( $lista );
			$( '<dd>' ).text( fila[ 1 ] ).appendTo( $lista );
		} );

		return $lista;
	}

	/**
	 * Etiqueta legible de un campo de la empresa, para la nota de
	 * valores predeterminados (antes salían los nombres internos:
	 * "nombre_encargado, apellidos_encargado, …").
	 *
	 * @param {string} campo Clave del campo.
	 * @return {string}
	 */
	function etiquetaCampo( campo ) {
		var etiquetas = {
			nit_empresa: 'NIT',
			nombre_encargado: AU_WMS.i18n.ceNombreEncargado || 'nombre del encargado',
			apellidos_encargado: AU_WMS.i18n.ceApellidos || 'apellidos',
			contacto: ( AU_WMS.i18n.ceContacto || 'Contacto' ).toLowerCase(),
			ocupacion: ( AU_WMS.i18n.ceOcupacion || 'Ocupación' ).toLowerCase(),
			email: ( AU_WMS.i18n.ceCorreoCol || 'Correo' ).toLowerCase(),
		};

		return etiquetas[ campo ] || campo;
	}

	/**
	 * Áreas del resumen, una línea por área: nombre a la izquierda y sus
	 * datos a la derecha en texto atenuado. Misma idea que `listaDatos`:
	 * son dos o tres áreas, no hace falta una tabla con cabeceras.
	 *
	 * @param {string} programa Clave del programa.
	 * @param {Array}  areas    Áreas leídas del formulario.
	 * @return {jQuery}
	 */
	function listaAreasResumen( programa, areas ) {
		var esWms = 'wms' === programa;
		var $lista = $( '<ul>' ).addClass( 'au-wms-ce-areas-resumen' );

		areas.forEach( function ( area ) {
			var detalle = [
				area.cupos + ' ' + ( 1 === Number( area.cupos )
					? ( AU_WMS.i18n.ceCupo || 'cupo' )
					: ( AU_WMS.i18n.ceCupos || 'cupos' ) ),
			];

			if ( esWms ) {
				detalle.push( nombreLicencia( area.licencia_id ) );
			} else {
				detalle.push( ( AU_WMS.i18n.ceExpira || 'Expira' ).toLowerCase() + ' ' + area.fecha_expiracion );
			}

			$( '<li>' )
				.append( $( '<span>' ).addClass( 'au-wms-ce-area-nombre' ).text( area.nombre ) )
				.append( $( '<span>' ).addClass( 'au-wms-ce-area-detalle' ).text( detalle.join( ' · ' ) ) )
				.appendTo( $lista );
		} );

		return $lista;
	}

	function nombreLicencia( licenciaId ) {
		var id = parseInt( licenciaId, 10 ) || 0;

		if ( ! id ) {
			return AU_WMS.i18n.sinLicencia || 'Sin licencia';
		}

		return $( '#au-wms-ce-licencia option[value="' + id + '"]' ).text() || String( id );
	}

	// ------------------------------------------------------------------
	// Copiar información
	// ------------------------------------------------------------------

	function copiarInformacion() {
		if ( ! ultimoResultado ) {
			return;
		}

		var data = ultimoResultado;
		var wms = data.wms || {};
		var lineas = [ ( AU_WMS.i18n.ceEmpresa || 'Empresa' ) + ': ' + ( wms.nombre_empresa || '' ) ];

		lineas.push( ( AU_WMS.i18n.ceProgramas || 'Programas' ) + ':' );

		( data.programas_seleccionados || [] ).forEach( function ( programa ) {
			if ( 'wms' === programa ) {
				lineas.push( '- ' + PROGRAMAS.wms + ' (' + ( wms.rol_etiqueta || wms.rol || '' ) + ')' );
				return;
			}

			var resultado = ( data.programas || {} )[ programa ] || {};
			lineas.push( '- ' + PROGRAMAS[ programa ] + ': ' + ( resultado.success ? 'OK' : ( resultado.message || 'pendiente' ) ) );
		} );

		// Solo las credenciales de WMS: el acceso a todos los programas se
		// hace iniciando sesión en WMS (ver tarjetaCredenciales()).
		lineas.push( '' );
		lineas.push( ( AU_WMS.i18n.ceCredenciales || 'Credenciales de acceso' ) + ':' );
		lineas.push( ( AU_WMS.i18n.ceCorreoCol || 'Correo' ) + ': ' + ( wms.email || '' ) );
		lineas.push( ( AU_WMS.i18n.cePassword || 'Contraseña' ) + ': ' + ( wms.password || '' ) );

		copiarAlPortapapeles( lineas.join( '\n' ) );
	}

	function copiarAlPortapapeles( texto ) {
		var $temp = $( '<textarea>' ).val( texto ).css( { position: 'fixed', top: '-1000px' } ).appendTo( 'body' );

		$temp[ 0 ].select();

		try {
			document.execCommand( 'copy' );
			Swal.fire( {
				icon: 'success',
				title: AU_WMS.i18n.ceCopiado || 'Información copiada',
				timer: 1500,
				showConfirmButton: false,
			} );
		} catch ( e ) {
			Swal.fire( { icon: 'error', title: AU_WMS.i18n.genericError } );
		}

		$temp.remove();
	}

	// ------------------------------------------------------------------
	// Avisos
	// ------------------------------------------------------------------

	/**
	 * Avisa si un programa externo no tiene token configurado. El aviso
	 * va dentro de la tarjeta del programa afectado — antes era un
	 * párrafo suelto al final del paso y no se sabía a cuál señalaba.
	 */
	function pintarTokensFaltantes() {
		var faltantes = cfg().tokensFaltantes || {};

		$( '.au-wms-ce-programa' ).each( function () {
			var $tarjeta = $( this );
			var programa = $tarjeta.data( 'programa' );
			var falta = Object.prototype.hasOwnProperty.call( faltantes, programa );

			$tarjeta.toggleClass( 'is-sin-token', falta );
			$tarjeta.find( '.au-wms-ce-programa-aviso' )
				.toggleClass( 'au-wms-hidden', ! falta )
				.text(
					( AU_WMS.i18n.ceTokensFaltantes || 'Falta el token de esta API.' ) + ' ' +
						( AU_WMS.i18n.ceTokensDonde || 'Cárgalo en Usuarios WMS → Configuración antes de crear.' )
				);
		} );
	}

	/**
	 * Refleja en la tarjeta si su programa está elegido (borde y fondo),
	 * para que la selección se lea sin mirar la casilla.
	 */
	function pintarSeleccionProgramas() {
		$( '.au-wms-ce-programa' ).each( function () {
			var $tarjeta = $( this );
			$tarjeta.toggleClass( 'is-selected', $tarjeta.find( '.au-wms-ce-programa-input' ).is( ':checked' ) );
		} );
	}

	function mostrarError( mensaje ) {
		$( '#au-wms-ce-error' ).removeClass( 'au-wms-hidden' ).text( mensaje );
	}

	function limpiarError() {
		$( '#au-wms-ce-error' ).addClass( 'au-wms-hidden' ).text( '' );
	}
} )( jQuery );
