/**
 * Modales "Licencias" (Tab Empresas → dropdown "Acciones" → "Licencias").
 *
 * Tres modales independientes — listado, "Crear Licencia" y "Editar
 * Licencia" — mismo patrón que "Ver Áreas" / "Crear Área/s" / "Editar
 * Área" (ver empresas.js): "Crear"/"Editar" se abren por encima del
 * listado, que se refresca al cerrarlos. Mismos campos y validaciones
 * que `astra-child/includes/companies/licenses.php` y `licenses-add.php`.
 *
 * @package Administrador_Usuarios_WMS
 */

( function ( $ ) {
	'use strict';

	// Mismo orden que AU_Repository_Licencias::CAMPOS_ACCESO (PHP).
	var CAMPOS_ACCESO = [
		'incluir_resultado_individual',
		'incluir_resultado_grupal',
		'incluir_resultado_global',
		'incluir_cursos_individuales',
		'incluir_cursos_grupales',
		'incluir_test_alineacion',
		'incluir_conferencia_induccion',
		'incluir_acceso_adpropositum',
		'incluir_cruces',
	];

	// Mismas etiquetas que la columna "Accesos" del listado — ver
	// AU_Repository_Licencias::CAMPOS_ACCESO (PHP) — para que la matriz
	// use el mismo nombre de atributo que ya se ve en pantalla.
	var ETIQUETAS_ACCESO = {
		incluir_resultado_individual: 'Evaluación perfil personal',
		incluir_resultado_grupal: 'Evaluación áreas empresariales',
		incluir_resultado_global: 'Evaluación perfil empresarial',
		incluir_cursos_individuales: 'Programa de fortalecimiento personal',
		incluir_cursos_grupales: 'Programa cultural para líderes',
		incluir_test_alineacion: 'Evaluación ajuste inter-áreas',
		incluir_conferencia_induccion: 'Conferencia de inducción',
		incluir_acceso_adpropositum: 'Acceso a AdPropositum',
		incluir_cruces: 'Evaluación ajuste perfiles personales/empresa/área',
	};

	var searchDebounceTimer = null;

	// ID de la licencia que se está editando en el modal "Editar Licencia".
	var editarLicenciaId = null;

	// Estado de paginación del listado.
	var listaState = {
		page: 1,
		perPage: 10,
		totalPages: 1,
	};

	$( document ).ready( function () {
		if ( ! $( '#au-wms-licencias-overlay' ).length ) {
			return;
		}

		initAccionesDropdown();
		initAccionesLicenciasDropdown();
		initModalLista();
		initModalCrear();
		initModalEditar();
		initExportarMatriz();
	} );

	/**
	 * Dropdown "Acciones" de la toolbar del Tab Empresas. Su primera (y
	 * por ahora única) opción abre el modal "Licencias".
	 */
	function initAccionesDropdown() {
		var $dropdown = $( '#au-wms-empresas-acciones-dropdown' );

		if ( ! $dropdown.length ) {
			return;
		}

		$( '#au-wms-btn-empresas-acciones' ).on( 'click', function ( event ) {
			event.stopPropagation();
			$dropdown.toggleClass( 'is-open' );
		} );

		// Cerrar al hacer click fuera o al elegir una opción.
		$( document ).on( 'click', function () {
			$dropdown.removeClass( 'is-open' );
		} );

		$( '#au-wms-btn-abrir-licencias' ).on( 'click', function ( event ) {
			event.stopPropagation();
			$dropdown.removeClass( 'is-open' );
			abrirModalLista();
		} );
	}

	/**
	 * Dropdown "Acciones" del encabezado del modal "Licencias" ("Crear
	 * Licencia" y "Descargar matriz comparativa"), mismo patrón que el
	 * dropdown "Acciones" de la toolbar del Tab Empresas.
	 */
	function initAccionesLicenciasDropdown() {
		var $dropdown = $( '#au-wms-licencias-acciones-dropdown' );

		if ( ! $dropdown.length ) {
			return;
		}

		$( '#au-wms-btn-licencias-acciones' ).on( 'click', function ( event ) {
			event.stopPropagation();
			$dropdown.toggleClass( 'is-open' );
		} );

		$( document ).on( 'click', function () {
			$dropdown.removeClass( 'is-open' );
		} );
	}

	/* ==========================================================================
	   Modal "Licencias" (listado)
	   ========================================================================== */

	function initModalLista() {
		$( '#au-wms-licencias-close, #au-wms-licencias-btn-cerrar-lista' ).on( 'click', function () {
			cerrarModalLista();
		} );

		$( '#au-wms-licencias-overlay' ).on( 'click', function ( event ) {
			if ( event.target === this ) {
				cerrarModalLista();
			}
		} );

		$( '#au-wms-btn-refresh-licencias' ).on( 'click', function () {
			cargarLicencias();
		} );

		$( '#au-wms-licencias-btn-crear' ).on( 'click', function ( event ) {
			event.stopPropagation();
			$( '#au-wms-licencias-acciones-dropdown' ).removeClass( 'is-open' );
			abrirModalCrear();
		} );

		// Delegado: las filas del listado se generan dinámicamente.
		$( '#au-wms-licencias-body' ).on( 'click', '.au-wms-licencia-row-editar', function () {
			var licenciaId = $( this ).data( 'licencia-id' );
			abrirModalEditar( licenciaId );
		} );

		$( '#au-wms-licencias-search' ).on( 'input', function () {
			clearTimeout( searchDebounceTimer );
			searchDebounceTimer = setTimeout( function () {
				listaState.page = 1;
				cargarLicencias();
			}, 300 );
		} );

		$( '#au-wms-licencias-per-page' ).on( 'change', function () {
			listaState.perPage = parseInt( $( this ).val(), 10 ) || 10;
			listaState.page = 1;
			cargarLicencias();
		} );

		$( '#au-wms-licencias-pagination' ).on( 'click', '.au-wms-page-btn', function () {
			var target = $( this ).data( 'page' );

			if ( 'first' === target ) {
				listaState.page = 1;
			} else if ( 'prev' === target ) {
				listaState.page = Math.max( 1, listaState.page - 1 );
			} else if ( 'next' === target ) {
				listaState.page = Math.min( listaState.totalPages, listaState.page + 1 );
			} else if ( 'last' === target ) {
				listaState.page = listaState.totalPages;
			}

			cargarLicencias();
		} );
	}

	function abrirModalLista() {
		listaState.page = 1;
		$( '#au-wms-licencias-search' ).val( '' );
		$( '#au-wms-licencias-per-page' ).val( listaState.perPage );
		cargarLicencias();
		$( '#au-wms-licencias-overlay' ).addClass( 'is-open' );
	}

	function cerrarModalLista() {
		$( '#au-wms-licencias-overlay' ).removeClass( 'is-open' );
	}

	function cargarLicencias() {
		var $body = $( '#au-wms-licencias-body' );

		$body.html(
			'<tr class="au-wms-row-loading"><td colspan="5"><div class="au-wms-spinner"></div>' + AU_WMS.i18n.loading + '</td></tr>'
		);

		$.post( AU_WMS.ajaxUrl, {
			action: 'au_wms_licencias_listar',
			nonce: AU_WMS.nonce,
			search: $( '#au-wms-licencias-search' ).val(),
			page: listaState.page,
			per_page: listaState.perPage,
		} )
			.done( function ( response ) {
				if ( ! response || ! response.success ) {
					renderLicencias( [] );
					mostrarErrorSwal( ( response && response.data && response.data.message ) || AU_WMS.i18n.genericError );
					return;
				}

				renderLicencias( response.data.items || [], response.data.total || 0 );
				renderPaginacionLicencias( response.data );
			} )
			.fail( function () {
				renderLicencias( [] );
				mostrarErrorSwal( AU_WMS.i18n.genericError );
			} );
	}

	function renderLicencias( items, total ) {
		var $body = $( '#au-wms-licencias-body' );
		var template = document.getElementById( 'au-wms-licencias-row-template' );
		var emptyTemplate = document.getElementById( 'au-wms-licencias-empty-template' );

		$body.empty();

		total = 'undefined' === typeof total ? items.length : total;

		$( '#au-wms-licencias-total-badge' ).text(
			total + ' ' + ( 1 === total ? AU_WMS.i18n.licenciaSingular : AU_WMS.i18n.licenciasPlural )
		);

		if ( ! items.length ) {
			$body.append( document.importNode( emptyTemplate.content, true ) );
			return;
		}

		items.forEach( function ( item ) {
			var $row = $( document.importNode( template.content, true ) );
			var $tr = $row.filter( 'tr' ).length ? $row.filter( 'tr' ) : $row.find( 'tr' );

			$tr.attr( 'data-licencia-id', item.id );
			$tr.find( '.au-wms-licencia-row-id' ).text( item.id );
			$tr.find( '.au-wms-licencia-row-nombre' ).text( item.nombre );
			$tr.find( '.au-wms-licencia-row-duracion' ).text( item.duracion );

			var $accesos = $tr.find( '.au-wms-licencia-row-accesos' );

			if ( item.accesos && item.accesos.length ) {
				item.accesos.forEach( function ( etiqueta ) {
					$( '<li></li>' ).text( etiqueta ).appendTo( $accesos );
				} );
			} else {
				$( '<li></li>' ).text( '—' ).appendTo( $accesos );
			}

			$tr.find( '.au-wms-licencia-row-editar' ).data( 'licencia-id', item.id );

			$body.append( $tr );
		} );
	}

	/**
	 * Actualiza los controles de paginación del listado.
	 *
	 * @param {Object} data Respuesta de au_wms_licencias_listar.
	 */
	function renderPaginacionLicencias( data ) {
		listaState.page = data.page;
		listaState.totalPages = data.total_pages;

		$( '#au-wms-licencias-total' ).text( data.total );
		$( '#au-wms-licencias-current-page' ).text( data.page );
		$( '#au-wms-licencias-total-pages' ).text( data.total_pages );

		$( '#au-wms-licencias-pagination .au-wms-page-btn[data-page="first"]' ).prop( 'disabled', data.page <= 1 );
		$( '#au-wms-licencias-pagination .au-wms-page-btn[data-page="prev"]' ).prop( 'disabled', data.page <= 1 );
		$( '#au-wms-licencias-pagination .au-wms-page-btn[data-page="next"]' ).prop( 'disabled', data.page >= data.total_pages );
		$( '#au-wms-licencias-pagination .au-wms-page-btn[data-page="last"]' ).prop( 'disabled', data.page >= data.total_pages );
	}

	/* ==========================================================================
	   Modal "Crear Licencia"
	   ========================================================================== */

	function initModalCrear() {
		$( '#au-wms-crear-licencia-close, #au-wms-crear-licencia-btn-cancelar' ).on( 'click', function () {
			cerrarModalCrear();
		} );

		$( '#au-wms-crear-licencia-overlay' ).on( 'click', function ( event ) {
			if ( event.target === this ) {
				cerrarModalCrear();
			}
		} );

		$( '#au-wms-crear-licencia-btn-guardar' ).on( 'click', function () {
			guardarLicenciaNueva();
		} );
	}

	function abrirModalCrear() {
		$( '#au-wms-crear-licencia-nombre' ).val( '' );
		$( '#au-wms-crear-licencia-duracion' ).val( '' );
		$( '.au-wms-crear-licencia-acceso-input' ).prop( 'checked', false );
		$( '#au-wms-crear-licencia-error' ).addClass( 'au-wms-hidden' ).text( '' );

		$( '#au-wms-crear-licencia-overlay' ).addClass( 'is-open' );
		$( '#au-wms-crear-licencia-nombre' ).trigger( 'focus' );
	}

	function cerrarModalCrear() {
		$( '#au-wms-crear-licencia-overlay' ).removeClass( 'is-open' );
	}

	/**
	 * Envía el formulario "Crear Licencia". Mismas validaciones que el
	 * original: nombre y duración son obligatorios, el resto de campos
	 * son interruptores opcionales.
	 */
	function guardarLicenciaNueva() {
		var nombre = $.trim( $( '#au-wms-crear-licencia-nombre' ).val() );
		var duracion = $.trim( $( '#au-wms-crear-licencia-duracion' ).val() );
		var $error = $( '#au-wms-crear-licencia-error' );

		if ( ! nombre || '' === duracion ) {
			$error.removeClass( 'au-wms-hidden' ).text( AU_WMS.i18n.licenciaCamposObligatorios );
			return;
		}

		$error.addClass( 'au-wms-hidden' ).text( '' );

		var $btn = $( '#au-wms-crear-licencia-btn-guardar' );
		var textoOriginal = $btn.text();
		$btn.prop( 'disabled', true ).text( AU_WMS.i18n.loading );

		var data = {
			action: 'au_wms_licencias_crear',
			nonce: AU_WMS.nonce,
			nombre: nombre,
			duracion: duracion,
		};

		CAMPOS_ACCESO.forEach( function ( campo ) {
			data[ campo ] = $( '.au-wms-crear-licencia-acceso-input[data-campo="' + campo + '"]' ).is( ':checked' ) ? 1 : 0;
		} );

		$.post( AU_WMS.ajaxUrl, data )
			.done( function ( response ) {
				if ( ! response || ! response.success ) {
					$error.removeClass( 'au-wms-hidden' ).text(
						( response && response.data && response.data.message ) || AU_WMS.i18n.genericError
					);
					return;
				}

				cerrarModalCrear();
				cargarLicencias();

				Swal.fire( {
					icon: 'success',
					title: AU_WMS.i18n.licenciaCreadaTitulo,
					text: ( response.data && response.data.message ) || '',
				} );
			} )
			.fail( function () {
				$error.removeClass( 'au-wms-hidden' ).text( AU_WMS.i18n.genericError );
			} )
			.always( function () {
				$btn.prop( 'disabled', false ).text( textoOriginal );
			} );
	}

	/* ==========================================================================
	   Modal "Editar Licencia"
	   ========================================================================== */

	function initModalEditar() {
		$( '#au-wms-editar-licencia-close, #au-wms-editar-licencia-btn-cancelar' ).on( 'click', function () {
			cerrarModalEditar();
		} );

		$( '#au-wms-editar-licencia-overlay' ).on( 'click', function ( event ) {
			if ( event.target === this ) {
				cerrarModalEditar();
			}
		} );

		$( '#au-wms-editar-licencia-btn-guardar' ).on( 'click', function () {
			guardarLicenciaEditada();
		} );
	}

	/**
	 * Abre el modal "Editar Licencia" de inmediato (formulario vacío) y
	 * pide en segundo plano los valores reales de la licencia para
	 * precargarlo, igual que "Editar Área".
	 *
	 * @param {number} licenciaId ID de la licencia a editar.
	 */
	function abrirModalEditar( licenciaId ) {
		editarLicenciaId = licenciaId;

		$( '#au-wms-editar-licencia-nombre' ).val( '' );
		$( '#au-wms-editar-licencia-duracion' ).val( '' );
		$( '.au-wms-editar-licencia-acceso-input' ).prop( 'checked', false );
		$( '#au-wms-editar-licencia-error' ).addClass( 'au-wms-hidden' ).text( '' );

		$( '#au-wms-editar-licencia-overlay' ).addClass( 'is-open' );

		$.post( AU_WMS.ajaxUrl, {
			action: 'au_wms_licencias_obtener',
			nonce: AU_WMS.nonce,
			licencia_id: licenciaId,
		} )
			.done( function ( response ) {
				if ( ! response || ! response.success ) {
					cerrarModalEditar();
					mostrarErrorSwal( ( response && response.data && response.data.message ) || AU_WMS.i18n.genericError );
					return;
				}

				$( '#au-wms-editar-licencia-nombre' ).val( response.data.nombre );
				$( '#au-wms-editar-licencia-duracion' ).val( response.data.duracion );

				CAMPOS_ACCESO.forEach( function ( campo ) {
					$( '.au-wms-editar-licencia-acceso-input[data-campo="' + campo + '"]' ).prop( 'checked', !! response.data[ campo ] );
				} );
			} )
			.fail( function () {
				cerrarModalEditar();
				mostrarErrorSwal( AU_WMS.i18n.genericError );
			} );
	}

	function cerrarModalEditar() {
		$( '#au-wms-editar-licencia-overlay' ).removeClass( 'is-open' );
		editarLicenciaId = null;
	}

	/**
	 * Envía el formulario "Editar Licencia". Mismas validaciones que
	 * "Crear Licencia".
	 */
	function guardarLicenciaEditada() {
		if ( ! editarLicenciaId ) {
			return;
		}

		var nombre = $.trim( $( '#au-wms-editar-licencia-nombre' ).val() );
		var duracion = $.trim( $( '#au-wms-editar-licencia-duracion' ).val() );
		var $error = $( '#au-wms-editar-licencia-error' );

		if ( ! nombre || '' === duracion ) {
			$error.removeClass( 'au-wms-hidden' ).text( AU_WMS.i18n.licenciaCamposObligatorios );
			return;
		}

		$error.addClass( 'au-wms-hidden' ).text( '' );

		var $btn = $( '#au-wms-editar-licencia-btn-guardar' );
		var textoOriginal = $btn.text();
		$btn.prop( 'disabled', true ).text( AU_WMS.i18n.loading );

		var data = {
			action: 'au_wms_licencias_editar',
			nonce: AU_WMS.nonce,
			licencia_id: editarLicenciaId,
			nombre: nombre,
			duracion: duracion,
		};

		CAMPOS_ACCESO.forEach( function ( campo ) {
			data[ campo ] = $( '.au-wms-editar-licencia-acceso-input[data-campo="' + campo + '"]' ).is( ':checked' ) ? 1 : 0;
		} );

		$.post( AU_WMS.ajaxUrl, data )
			.done( function ( response ) {
				if ( ! response || ! response.success ) {
					$error.removeClass( 'au-wms-hidden' ).text(
						( response && response.data && response.data.message ) || AU_WMS.i18n.genericError
					);
					return;
				}

				cerrarModalEditar();
				cargarLicencias();

				Swal.fire( {
					icon: 'success',
					title: AU_WMS.i18n.licenciaActualizadaTitulo,
					text: ( response.data && response.data.message ) || '',
				} );
			} )
			.fail( function () {
				$error.removeClass( 'au-wms-hidden' ).text( AU_WMS.i18n.genericError );
			} )
			.always( function () {
				$btn.prop( 'disabled', false ).text( textoOriginal );
			} );
	}

	/* ==========================================================================
	   "Descargar matriz comparativa" (dropdown "Acciones" del listado)
	   ========================================================================== */

	function initExportarMatriz() {
		$( '#au-wms-licencias-btn-exportar-matriz' ).on( 'click', function ( event ) {
			event.stopPropagation();
			$( '#au-wms-licencias-acciones-dropdown' ).removeClass( 'is-open' );
			exportarMatrizComparativa();
		} );
	}

	/**
	 * Pide TODAS las licencias (sin paginar ni filtrar) y arma el .xlsx
	 * con la matriz atributo × licencia.
	 */
	function exportarMatrizComparativa() {
		if ( 'undefined' === typeof XLSX ) {
			return;
		}

		var $btn = $( '#au-wms-licencias-btn-exportar-matriz' );
		var htmlOriginal = $btn.html();
		$btn.prop( 'disabled', true );

		$.post( AU_WMS.ajaxUrl, {
			action: 'au_wms_licencias_listar_todas',
			nonce: AU_WMS.nonce,
		} )
			.done( function ( response ) {
				if ( ! response || ! response.success ) {
					mostrarErrorSwal( ( response && response.data && response.data.message ) || AU_WMS.i18n.genericError );
					return;
				}

				var licencias = response.data.items || [];

				if ( ! licencias.length ) {
					mostrarErrorSwal( AU_WMS.i18n.licenciaMatrizSinDatos );
					return;
				}

				generarExcelMatriz( licencias );
			} )
			.fail( function () {
				mostrarErrorSwal( AU_WMS.i18n.genericError );
			} )
			.always( function () {
				$btn.prop( 'disabled', false ).html( htmlOriginal );
			} );
	}

	/**
	 * Construye y descarga "Matriz_comparativa_de_licencias.xlsx": filas
	 * = los 9 atributos "incluir_*" (mismas etiquetas que la columna
	 * "Accesos" del listado), columnas = cada licencia existente,
	 * celdas = "SI" (verde) / "NO" (rojo).
	 *
	 * @param {Array} licencias Licencias con el estado real de cada atributo.
	 */
	function generarExcelMatriz( licencias ) {
		var COLOR_TITULO = { bg: 'E9EBEC', color: '131A1E' };
		var COLOR_HEADER = { bg: '131A1E', color: 'FFFFFF' };
		var COLOR_SI = { bg: 'DCFCE7', color: '16A34A' };
		var COLOR_NO = { bg: 'FEE2E2', color: 'DC2626' };
		var COLOR_BORDE = { rgb: 'CBD5E1' };
		var BORDE_FINO = {
			top: { style: 'thin', color: COLOR_BORDE },
			bottom: { style: 'thin', color: COLOR_BORDE },
			left: { style: 'thin', color: COLOR_BORDE },
			right: { style: 'thin', color: COLOR_BORDE },
		};

		// Fila de encabezados: "Atributo" + una columna por licencia
		// (solo el nombre).
		var encabezados = [ AU_WMS.i18n.licenciaMatrizColAtributo ];
		licencias.forEach( function ( licencia ) {
			encabezados.push( licencia.nombre );
		} );

		var totalColumnas = encabezados.length;

		// Fila 1: título + leyenda de colores, fusionada en todo el ancho
		// de la tabla, para que se entienda el archivo sin más contexto.
		var filaTitulo = [ AU_WMS.i18n.licenciaMatrizTitulo ];
		for ( var relleno = 1; relleno < totalColumnas; relleno++ ) {
			filaTitulo.push( '' );
		}

		var aoa = [ filaTitulo, encabezados ];

		// Una fila por cada atributo disponible: se incluyen los 9 aunque
		// una licencia en particular no los tenga, para poder comparar
		// todas las licencias contra el mismo listado de atributos.
		CAMPOS_ACCESO.forEach( function ( campo ) {
			var filaValores = [ ETIQUETAS_ACCESO[ campo ] ];

			licencias.forEach( function ( licencia ) {
				filaValores.push( licencia[ campo ] ? 'SI' : 'NO' );
			} );

			aoa.push( filaValores );
		} );

		var hoja = XLSX.utils.aoa_to_sheet( aoa );

		// Fila 1: título fusionado en todas las columnas.
		hoja[ '!merges' ] = [ { s: { r: 0, c: 0 }, e: { r: 0, c: totalColumnas - 1 } } ];

		var celdaTitulo = XLSX.utils.encode_cell( { r: 0, c: 0 } );
		hoja[ celdaTitulo ].s = {
			font: { bold: true, sz: 12, color: { rgb: COLOR_TITULO.color } },
			fill: { patternType: 'solid', fgColor: { rgb: COLOR_TITULO.bg } },
			alignment: { horizontal: 'center', vertical: 'center' },
			border: BORDE_FINO,
		};

		// Fila 2: encabezado con los nombres de licencia — fondo navy,
		// texto blanco en negrita.
		for ( var col = 0; col < totalColumnas; col++ ) {
			var celdaEncabezado = XLSX.utils.encode_cell( { r: 1, c: col } );
			hoja[ celdaEncabezado ].s = {
				font: { bold: true, color: { rgb: COLOR_HEADER.color } },
				fill: { patternType: 'solid', fgColor: { rgb: COLOR_HEADER.bg } },
				alignment: { horizontal: 'center', vertical: 'center', wrapText: true },
				border: BORDE_FINO,
			};
		}

		// Cuerpo: primera columna (nombre del atributo) en negrita sobre
		// fondo gris claro; el resto, "SI"/"NO" con su color.
		for ( var rowIndex = 0; rowIndex < CAMPOS_ACCESO.length; rowIndex++ ) {
			var fila = rowIndex + 2;
			var celdaAtributo = XLSX.utils.encode_cell( { r: fila, c: 0 } );
			hoja[ celdaAtributo ].s = {
				font: { bold: true },
				fill: { patternType: 'solid', fgColor: { rgb: 'F8FAFC' } },
				alignment: { vertical: 'center', wrapText: true },
				border: BORDE_FINO,
			};

			for ( var colIndex = 1; colIndex < totalColumnas; colIndex++ ) {
				var celda = XLSX.utils.encode_cell( { r: fila, c: colIndex } );
				var color = 'SI' === hoja[ celda ].v ? COLOR_SI : COLOR_NO;

				hoja[ celda ].s = {
					font: { bold: true, color: { rgb: color.color } },
					fill: { patternType: 'solid', fgColor: { rgb: color.bg } },
					alignment: { horizontal: 'center', vertical: 'center' },
					border: BORDE_FINO,
				};
			}
		}

		// Ancho de columnas: cada columna se ajusta a su propio contenido
		// más largo (fila de encabezado incluida, no el título fusionado),
		// igual que "Autoajustar ancho de columna" en Excel.
		var anchos = encabezados.map( function ( _, colIdx ) {
			var maxLargo = aoa.slice( 1 ).reduce( function ( largo, filaDatos ) {
				var valor = filaDatos[ colIdx ] ? String( filaDatos[ colIdx ] ) : '';
				return Math.max( largo, valor.length );
			}, 0 );

			return { wch: maxLargo + 2 };
		} );
		hoja[ '!cols' ] = anchos;

		// Alto de fila: título y encabezado un poco más altos, y el
		// cuerpo con algo más de aire que el alto por defecto.
		var altosFilas = [ { hpt: 24 }, { hpt: 26 } ];
		CAMPOS_ACCESO.forEach( function () {
			altosFilas.push( { hpt: 20 } );
		} );
		hoja[ '!rows' ] = altosFilas;

		// Encabezados (fila del título + fila de licencias, y columna A
		// con los atributos) siempre visibles al desplazarse. Se fija con
		// dos formas del mismo dato porque, según la versión de SheetJS
		// que sirva el CDN en cada momento, una u otra es la que
		// efectivamente escribe el <pane> en el .xlsx; incluir ambas no
		// tiene costo si una de ellas termina ignorada.
		var freezePanes = { xSplit: 1, ySplit: 2, topLeftCell: 'B3', activePane: 'bottomRight', state: 'frozen' };
		hoja[ '!freeze' ] = freezePanes;
		hoja[ '!sheetViews' ] = [ { workbookViewId: 0, pane: freezePanes, state: 'frozen', xSplit: 1, ySplit: 2, topLeftCell: 'B3', activePane: 'bottomRight' } ];

		var libro = XLSX.utils.book_new();
		XLSX.utils.book_append_sheet( libro, hoja, 'Matriz comparativa' );

		XLSX.writeFile( libro, 'Matriz_comparativa_de_licencias.xlsx' );
	}

	/**
	 * Muestra un error genérico vía SweetAlert2.
	 *
	 * @param {string} mensaje Mensaje a mostrar.
	 */
	function mostrarErrorSwal( mensaje ) {
		Swal.fire( {
			icon: 'error',
			title: mensaje || AU_WMS.i18n.genericError,
		} );
	}
} )( jQuery );
