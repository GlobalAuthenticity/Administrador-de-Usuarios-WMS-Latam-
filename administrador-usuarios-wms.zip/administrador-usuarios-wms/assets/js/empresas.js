/**
 * Administrador de Usuarios (WMS Latam) — Tab "Empresas".
 *
 * Reutiliza el mismo patrón de búsqueda/paginación del Tab Integrantes,
 * y se apoya en los hooks globales expuestos por admin.js/usermeta.js
 * (window.AU_WMS_confirmarLoginComoUsuario, window.AU_WMS_abrirUsermeta)
 * para no duplicar esa lógica.
 */
( function ( $ ) {
	'use strict';

	var state = {
		search: '',
		licenciaId: '',
		programaFiltro: '',
		page: 1,
		perPage: 10,
		totalPages: 1,
	};

	var searchDebounceTimer = null;

	$( document ).ready( function () {
		if ( ! $( '#au-wms-tabla-empresas' ).length ) {
			return;
		}

		initFiltros();
		initPaginacion();
		initEventosTabla();
		initModalAreas();
		initModalAreaCursos();
		initModalCambiarLicencia();
		initModalEditarEmpresa();
		initBotonRefrescarEmpresas();
		cargarEmpresas();
	} );

	/**
	 * Buscador (nombre de empresa o encargado) con debounce, y selector
	 * de registros por página.
	 */
	function initFiltros() {
		$( '#au-wms-empresas-search' ).on( 'input', function () {
			var value = $( this ).val();

			clearTimeout( searchDebounceTimer );
			searchDebounceTimer = setTimeout( function () {
				state.search = value;
				state.page = 1;
				cargarEmpresas();
			}, 400 );
		} );

		$( '#au-wms-btn-refresh-empresas' ).on( 'click', function () {
			cargarEmpresas();
		} );

		$( '#au-wms-empresas-per-page' ).on( 'change', function () {
			state.perPage = parseInt( $( this ).val(), 10 ) || 10;
			state.page = 1;
			cargarEmpresas();
		} );

		$( '#au-wms-empresas-licencia' ).on( 'change', function () {
			state.licenciaId = $( this ).val();
			state.page = 1;
			cargarEmpresas();
		} );

		$( '#au-wms-empresas-programa' ).on( 'change', function () {
			state.programaFiltro = $( this ).val();
			state.page = 1;
			cargarEmpresas();
		} );
	}

	/**
	 * Controles de paginación (primera, anterior, siguiente, última).
	 */
	function initPaginacion() {
		$( '#au-wms-empresas-pagination' ).on( 'click', '.au-wms-page-btn', function () {
			var target = $( this ).data( 'page' );

			if ( 'first' === target ) {
				state.page = 1;
			} else if ( 'prev' === target ) {
				state.page = Math.max( 1, state.page - 1 );
			} else if ( 'next' === target ) {
				state.page = Math.min( state.totalPages, state.page + 1 );
			} else if ( 'last' === target ) {
				state.page = state.totalPages;
			}

			cargarEmpresas();
		} );
	}

	/**
	 * Cierra todos los dropdowns "Acciones" abiertos (Empresas y Áreas) y
	 * cualquier submenú flyout que hubiera quedado abierto dentro de
	 * ellos, para que la próxima vez que se abra un dropdown no aparezca
	 * ya con un submenú desplegado de una interacción anterior.
	 */
	function cerrarTodosLosDropdowns() {
		$( '.au-wms-actions-dropdown' ).removeClass( 'is-open' );
		$( '.au-wms-actions-submenu' ).removeClass( 'is-open au-wms-actions-submenu--flip' );
	}

	/**
	 * Delegación de eventos sobre la tabla: dropdown de acciones,
	 * iniciar sesión como usuario, ver WP_USERMETA.
	 */
	function initEventosTabla() {
		var $tbody = $( '#au-wms-empresas-body' );

		$tbody.on( 'click', '.au-wms-actions-btn', function ( event ) {
			event.stopPropagation();

			var $dropdown = $( this ).closest( '.au-wms-actions-dropdown' );
			var wasOpen = $dropdown.hasClass( 'is-open' );

			cerrarTodosLosDropdowns();

			if ( ! wasOpen ) {
				$dropdown.addClass( 'is-open' );
			}
		} );

		// Submenús del dropdown "Acciones" (Empresas): clic para
		// abrir/cerrar (no hover), y se voltean hacia la izquierda solos
		// si el flyout no cabría a la derecha del viewport.
		$tbody.on( 'click', '.au-wms-actions-submenu-trigger', function ( event ) {
			event.stopPropagation();

			var $submenu = $( this ).closest( '.au-wms-actions-submenu' );
			var wasOpen = $submenu.hasClass( 'is-open' );

			$submenu.siblings( '.au-wms-actions-submenu' ).removeClass( 'is-open au-wms-actions-submenu--flip' );

			if ( wasOpen ) {
				$submenu.removeClass( 'is-open au-wms-actions-submenu--flip' );
				return;
			}

			$submenu.addClass( 'is-open' );

			var $panel = $submenu.find( '.au-wms-actions-submenu-panel' ).first();
			if ( $panel.length && $panel[ 0 ].getBoundingClientRect().right > window.innerWidth ) {
				$submenu.addClass( 'au-wms-actions-submenu--flip' );
			}
		} );

		$( document ).on( 'click', cerrarTodosLosDropdowns );

		$tbody.on( 'click', '.au-wms-empresa-action-login', function () {
			var userId = $( this ).closest( 'tr' ).data( 'user-id' );

			if ( 'function' === typeof window.AU_WMS_confirmarLoginComoUsuario ) {
				window.AU_WMS_confirmarLoginComoUsuario( userId );
			}
		} );

		$tbody.on( 'click', '.au-wms-empresa-action-ver-areas', function () {
			var $row = $( this ).closest( 'tr' );
			var empresaId = $row.data( 'user-id' );
			var empresaNombre = $row.find( '.au-wms-empresa-nombre' ).text();

			// Mismo modal que abre el botón "Ver más" de la columna Áreas.
			abrirModalAreas( empresaId, empresaNombre );
		} );

		$tbody.on( 'click', '.au-wms-empresa-action-editar', function () {
			abrirModalEditarEmpresa( $( this ).closest( 'tr' ).data( 'user-id' ) );
		} );

		$tbody.on( 'click', '.au-wms-empresa-action-cambiar-licencia', function () {
			var $row = $( this ).closest( 'tr' );

			abrirModalCambiarLicencia(
				$row.data( 'user-id' ),
				$row.find( '.au-wms-empresa-nombre' ).text(),
				parseInt( $row.attr( 'data-licencia-id' ), 10 ) || 0
			);
		} );

		$tbody.on( 'click', '.au-wms-empresa-action-usermeta', function () {
			var $row = $( this ).closest( 'tr' );
			var userId = $row.data( 'user-id' );
			var nombre = $row.find( '.au-wms-empresa-nombre' ).text();

			if ( 'function' === typeof window.AU_WMS_abrirUsermeta ) {
				window.AU_WMS_abrirUsermeta( userId, nombre );
			}
		} );

		$tbody.on( 'click', '.au-wms-empresa-action-refrescar', function () {
			var $row = $( this ).closest( 'tr' );
			var empresaId = $row.data( 'user-id' );
			var empresaNombre = $row.find( '.au-wms-empresa-nombre' ).text();

			confirmarRefrescarProgramas( empresaId, empresaNombre );
		} );

		$tbody.on( 'click', '.au-wms-areas-vermas-btn', function () {
			var $row = $( this ).closest( 'tr' );
			var empresaId = $row.data( 'user-id' );
			var empresaNombre = $row.find( '.au-wms-empresa-nombre' ).text();

			abrirModalAreas( empresaId, empresaNombre );
		} );

		$tbody.on( 'click', '.au-wms-empresa-action-codigo-empresa', function () {
			var $row = $( this ).closest( 'tr' );
			var empresaId = $row.data( 'user-id' );

			confirmarActualizarCodigoEmpresa( empresaId );
		} );

		$tbody.on( 'click', '.au-wms-empresa-action-cambiar-correo', function () {
			var $row = $( this ).closest( 'tr' );
			var empresaId = $row.data( 'user-id' );
			var correoActual = $row.find( '.au-wms-user-email' ).text();

			confirmarCambiarCorreoEmpresa( empresaId, correoActual );
		} );

		$tbody.on( 'click', '.au-wms-empresa-action-password', function () {
			var $row = $( this ).closest( 'tr' );
			var empresaId = $row.data( 'user-id' );
			var correo = $row.find( '.au-wms-user-email' ).text();

			if ( 'function' === typeof window.AU_WMS_abrirModalCambiarPassword ) {
				window.AU_WMS_abrirModalCambiarPassword( empresaId, correo );
			}
		} );

		$tbody.on( 'click', '.au-wms-empresa-action-reset-password', function () {
			var $row = $( this ).closest( 'tr' );
			var empresaId = $row.data( 'user-id' );
			var empresaNombre = $row.find( '.au-wms-empresa-nombre' ).text();

			if ( 'function' === typeof window.AU_WMS_abrirModalResetPassword ) {
				window.AU_WMS_abrirModalResetPassword( empresaId, empresaNombre );
			}
		} );

		$tbody.on( 'click', '.au-wms-empresa-action-exportar-usuarios', function () {
			var $row = $( this ).closest( 'tr' );
			var empresaId = $row.data( 'user-id' );
			var empresaNombre = $row.find( '.au-wms-empresa-nombre' ).text();

			if ( 'function' === typeof window.AU_WMS_abrirModalExportarUsuarios ) {
				window.AU_WMS_abrirModalExportarUsuarios( empresaId, empresaNombre );
			}
		} );

		$tbody.on( 'click', '.au-wms-empresa-action-comparar-usuarios', function () {
			var $row = $( this ).closest( 'tr' );
			var empresaId = $row.data( 'user-id' );
			var empresaNombre = $row.find( '.au-wms-empresa-nombre' ).text();

			if ( 'function' === typeof window.AU_WMS_abrirModalCompararUsuarios ) {
				window.AU_WMS_abrirModalCompararUsuarios( empresaId, empresaNombre );
			}
		} );
	}

	/**
	 * Pide confirmación y ejecuta "Actualizar id empresa usuario": para
	 * cada usuario de la empresa, guarda su `codigo_area` más antiguo
	 * (en `wp_correos_configurados`) como `user_code_company` en
	 * `wp_usermeta`.
	 *
	 * @param {number} empresaId ID de la empresa.
	 */
	function confirmarActualizarCodigoEmpresa( empresaId ) {
		Swal.fire( {
			title: AU_WMS.i18n.codigoEmpresaConfirmTitle,
			text: AU_WMS.i18n.codigoEmpresaConfirmText,
			icon: 'question',
			showCancelButton: true,
			confirmButtonText: AU_WMS.i18n.refrescarConfirmButton,
			cancelButtonText: AU_WMS.i18n.cancelButton,
			confirmButtonColor: '#131A1E',
			reverseButtons: true,
		} ).then( function ( result ) {
			if ( ! result.isConfirmed ) {
				return;
			}

			Swal.fire( {
				title: AU_WMS.i18n.loading,
				allowOutsideClick: false,
				allowEscapeKey: false,
				showConfirmButton: false,
				didOpen: function () {
					Swal.showLoading();
				},
			} );

			$.post( AU_WMS.ajaxUrl, {
				action: 'au_wms_actualizar_codigo_empresa_usuarios',
				nonce: AU_WMS.nonce,
				empresa_id: empresaId,
			} )
				.done( function ( response ) {
					if ( ! response || ! response.success ) {
						mostrarError( response && response.data ? response.data.message : AU_WMS.i18n.genericError );
						return;
					}

					Swal.fire( {
						icon: 'success',
						title: AU_WMS.i18n.codigoEmpresaExito.replace( '{N}', response.data.actualizados ),
					} );
				} )
				.fail( function () {
					mostrarError( AU_WMS.i18n.genericError );
				} );
		} );
	}

	/**
	 * Pide confirmación y cambia el correo de la cuenta `company` de
	 * una empresa. Reutiliza el mismo endpoint AJAX genérico
	 * (`au_wms_cambiar_correo` / `AU_User_Service::cambiar_correo()`)
	 * que usa el Tab Integrantes: no distingue por rol, solo actualiza
	 * `wp_users` y `wp_correos_configurados` para ese `user_id`.
	 *
	 * @param {number} empresaId    ID del usuario `company`.
	 * @param {string} correoActual Correo actual, para prellenar el input.
	 */
	function confirmarCambiarCorreoEmpresa( empresaId, correoActual ) {
		Swal.fire( {
			title: AU_WMS.i18n.cambiarCorreoTitulo,
			input: 'email',
			inputValue: correoActual,
			inputLabel: AU_WMS.i18n.cambiarCorreoLabel,
			showCancelButton: true,
			confirmButtonText: AU_WMS.i18n.cambiarCorreoConfirmar,
			cancelButtonText: AU_WMS.i18n.cancelButton,
			confirmButtonColor: '#131A1E',
			reverseButtons: true,
			inputValidator: function ( value ) {
				if ( ! value ) {
					return AU_WMS.i18n.cambiarCorreoObligatorio;
				}
			},
		} ).then( function ( result ) {
			if ( ! result.isConfirmed || ! result.value ) {
				return;
			}

			var nuevoCorreo = result.value;

			$.post( AU_WMS.ajaxUrl, {
				action: 'au_wms_cambiar_correo',
				nonce: AU_WMS.nonce,
				user_id: empresaId,
				nuevo_correo: nuevoCorreo,
			} )
				.done( function ( response ) {
					if ( ! response || ! response.success ) {
						mostrarError( response && response.data ? response.data.message : AU_WMS.i18n.genericError );
						return;
					}

					Swal.fire( {
						icon: 'success',
						title: AU_WMS.i18n.cambiarCorreoExito,
						timer: 1800,
						showConfirmButton: false,
					} );
					cargarEmpresas();
				} )
				.fail( function () {
					mostrarError( AU_WMS.i18n.genericError );
				} );
		} );
	}

	/**
	 * Carga (o recarga) el listado de empresas vía AJAX.
	 */
	// Hook global: el asistente "Crear Empresa" (crear-empresa.js) refresca
	// el listado al cerrarse, para que la empresa nueva aparezca sin
	// recargar la página.
	window.AU_WMS_recargarEmpresas = function () {
		state.page = 1;
		cargarEmpresas();
	};

	function cargarEmpresas() {
		mostrarCargando();

		$.post( AU_WMS.ajaxUrl, {
			action: 'au_wms_buscar_empresas',
			nonce: AU_WMS.nonce,
			search: state.search,
			licencia_id: state.licenciaId,
			programa_filtro: state.programaFiltro,
			page: state.page,
			per_page: state.perPage,
		} )
			.done( function ( response ) {
				if ( ! response || ! response.success ) {
					mostrarError( response && response.data ? response.data.message : AU_WMS.i18n.genericError );
					return;
				}

				renderTabla( response.data.items );
				renderPaginacion( response.data );

				if ( window.AU_WMS_UI ) {
					window.AU_WMS_UI.actualizarContadorTab( 'empresas', response.data.total, ! state.search && ! state.licenciaId && ! state.programaFiltro );
				}
			} )
			.fail( function () {
				mostrarError( AU_WMS.i18n.genericError );
			} );
	}

	function mostrarCargando() {
		$( '#au-wms-empresas-body' ).html(
			'<tr class="au-wms-row-loading"><td colspan="5"><div class="au-wms-spinner"></div>' +
			AU_WMS.i18n.loading +
			'</td></tr>'
		);
	}

	/**
	 * Renderiza las filas de la tabla de empresas.
	 *
	 * @param {Array} items Lista de empresas.
	 */
	function renderTabla( items ) {
		var $tbody = $( '#au-wms-empresas-body' );
		$tbody.empty();

		if ( ! items || ! items.length ) {
			var emptyTemplate = document.getElementById( 'au-wms-empresas-empty-template' );
			$tbody.append( document.importNode( emptyTemplate.content, true ) );
			return;
		}

		var template = document.getElementById( 'au-wms-empresas-row-template' );

		items.forEach( function ( item ) {
			var $row = $( document.importNode( template.content, true ) );
			var $tr = $row.filter( 'tr' ).length ? $row.filter( 'tr' ) : $row.find( 'tr' );

			$tr.attr( 'data-user-id', item.id );
			// La licencia actual viaja en la fila para que el modal
			// "Cambiar Licencia" pueda preseleccionarla sin otra consulta.
			$tr.attr( 'data-licencia-id', item.licencia_id || 0 );
			$tr.find( '.au-wms-user-id' ).text( '#' + item.id );
			$tr.find( '.au-wms-empresa-nombre' ).text( item.empresa_nombre || ( '#' + item.id ) );
			$tr.find( '.au-wms-user-email' ).text( item.user_email );

			if ( item.encargado_nombre ) {
				$tr.find( '.au-wms-empresa-encargado' ).text( AU_WMS.i18n.encargadoLabel + ': ' + item.encargado_nombre );
			}

			if ( item.created_by_api ) {
				$tr.find( '.au-wms-user-badges' ).append(
					$( '<span>' )
						.addClass( 'au-wms-badge au-wms-badge--created-by-api' )
						.text( AU_WMS.i18n.creadoPorApiLabel || 'Creado por API' )
				);
			}

			$tr.find( '.au-wms-user-date' )
				.text( formatearFechaCorta( item.user_registered ) )
				.attr( 'title', formatearFechaLarga( item.user_registered ) );

			$tr.find( '.au-wms-areas-count' ).text( item.num_areas );

			if ( item.licencia_nombre ) {
				$tr.find( '.au-wms-licencia-badge' )
					.addClass( 'au-wms-badge au-wms-badge--licencia' )
					.text( item.licencia_nombre );
			} else {
				$tr.find( '.au-wms-licencia-badge' )
					.addClass( 'au-wms-badge au-wms-badge--role-default' )
					.text( AU_WMS.i18n.sinLicencia || 'Sin licencia' );
			}

			var $programasBadges = $tr.find( '.au-wms-programas-badges' );

			if ( item.inspira_valor ) {
				$programasBadges.append( window.AU_WMS_UI.badgePrograma( 'inspira', item.inspira_valor ) );
			}

			if ( item.octagono_valor ) {
				$programasBadges.append( window.AU_WMS_UI.badgePrograma( 'octagono', item.octagono_valor ) );
			}

			$tbody.append( $tr );
		} );
	}

	/**
	 * Actualiza los controles de paginación.
	 *
	 * @param {Object} data Respuesta de au_wms_buscar_empresas.
	 */
	function renderPaginacion( data ) {
		state.page = data.page;
		state.totalPages = data.total_pages;

		$( '#au-wms-empresas-total' ).text( data.total );
		$( '#au-wms-empresas-current-page' ).text( data.page );
		$( '#au-wms-empresas-total-pages' ).text( data.total_pages );

		$( '#au-wms-empresas-pagination .au-wms-page-btn[data-page="first"]' ).prop( 'disabled', data.page <= 1 );
		$( '#au-wms-empresas-pagination .au-wms-page-btn[data-page="prev"]' ).prop( 'disabled', data.page <= 1 );
		$( '#au-wms-empresas-pagination .au-wms-page-btn[data-page="next"]' ).prop( 'disabled', data.page >= data.total_pages );
		$( '#au-wms-empresas-pagination .au-wms-page-btn[data-page="last"]' ).prop( 'disabled', data.page >= data.total_pages );
	}

	function mostrarError( mensaje ) {
		Swal.fire( {
			icon: 'error',
			title: mensaje || AU_WMS.i18n.genericError,
		} );
	}

	var MESES_ES = [
		'enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio',
		'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre',
	];
	var MESES_ES_CORTO = [
		'ene', 'feb', 'mar', 'abr', 'may', 'jun',
		'jul', 'ago', 'sep', 'oct', 'nov', 'dic',
	];

	function partesFecha( value ) {
		if ( ! value ) {
			return null;
		}
		var parts = value.split( ' ' )[ 0 ].split( '-' );
		if ( parts.length !== 3 ) {
			return null;
		}
		var anio = parseInt( parts[ 0 ], 10 );
		var mesIndex = parseInt( parts[ 1 ], 10 ) - 1;
		var dia = parseInt( parts[ 2 ], 10 );
		if ( ! anio || mesIndex < 0 || mesIndex > 11 || ! dia ) {
			return null;
		}
		return { anio: anio, mesIndex: mesIndex, dia: dia };
	}

	function formatearFechaCorta( value ) {
		var p = partesFecha( value );
		return p ? ( p.dia + ' ' + MESES_ES_CORTO[ p.mesIndex ] + ' ' + p.anio ) : ( value || '' );
	}

	function formatearFechaLarga( value ) {
		var p = partesFecha( value );
		return p ? ( p.dia + ' de ' + MESES_ES[ p.mesIndex ] + ' de ' + p.anio ) : ( value || '' );
	}

	/**
	 * Pide confirmación antes de refrescar los programas de una empresa
	 * completa (administrador + todos sus integrantes).
	 *
	 * @param {number} empresaId     ID de la empresa.
	 * @param {string} empresaNombre Nombre a mostrar en el resumen final.
	 */
	function confirmarRefrescarProgramas( empresaId, empresaNombre ) {
		confirmarRefrescarGenerico(
			AU_WMS.i18n.refrescarConfirmTitle,
			AU_WMS.i18n.refrescarConfirmText,
			function () {
				ejecutarRefrescarProgramas( 'au_wms_sync_programas_iniciar', { empresa_id: empresaId }, empresaNombre );
			}
		);
	}

	/**
	 * Opción "Refrescar programas" del dropdown "Acciones" de la
	 * toolbar: sincroniza TODAS las cuentas con rol `company` (las filas
	 * de este tab), sin sus integrantes — para eso está la acción
	 * "Refrescar programas" de cada fila. Reutiliza el mismo flujo de
	 * confirmación/progreso/resumen que el resto de refrescos.
	 */
	function initBotonRefrescarEmpresas() {
		$( '#au-wms-btn-refrescar-empresas' ).on( 'click', function ( event ) {
			// El dropdown lo abre/cierra licencias.js: igual que las
			// demás opciones, esta se cierra a mano antes de abrir el
			// modal de confirmación.
			event.stopPropagation();
			$( '#au-wms-empresas-acciones-dropdown' ).removeClass( 'is-open' );

			confirmarRefrescarGenerico(
				AU_WMS.i18n.refrescarConfirmTitleEmpresas,
				AU_WMS.i18n.refrescarConfirmTextEmpresas,
				function () {
					ejecutarRefrescarProgramas(
						'au_wms_sync_programas_iniciar_empresas',
						{},
						AU_WMS.i18n.refrescarEmpresasLabel
					);
				}
			);
		} );
	}

	/**
	 * Pide confirmación y arranca la sincronización de un único usuario
	 * (acción "Refrescar programas" reutilizada en el Tab Integrantes).
	 * Expuesta globalmente para que admin.js la use sin duplicar lógica.
	 *
	 * @param {number} userId          ID del usuario.
	 * @param {string} nombreOCorreo   Nombre o correo a mostrar en el resumen final.
	 */
	window.AU_WMS_confirmarRefrescarProgramasUsuario = function ( userId, nombreOCorreo ) {
		confirmarRefrescarGenerico(
			AU_WMS.i18n.refrescarConfirmTitleUsuario,
			AU_WMS.i18n.refrescarConfirmTextUsuario,
			function () {
				ejecutarRefrescarProgramas( 'au_wms_sync_programas_iniciar_usuario', { user_id: userId }, nombreOCorreo );
			}
		);
	};

	/**
	 * Muestra el SweetAlert de confirmación genérico (mismo diseño,
	 * distinto título/texto según si aplica a una empresa o a un usuario).
	 *
	 * @param {string}   titulo    Título del SweetAlert.
	 * @param {string}   texto     Texto del SweetAlert.
	 * @param {Function} onConfirm Callback a ejecutar si el usuario confirma.
	 */
	function confirmarRefrescarGenerico( titulo, texto, onConfirm ) {
		Swal.fire( {
			title: titulo,
			text: texto,
			icon: 'question',
			showCancelButton: true,
			confirmButtonText: AU_WMS.i18n.refrescarConfirmButton,
			cancelButtonText: AU_WMS.i18n.cancelButton,
			confirmButtonColor: '#131A1E',
			reverseButtons: true,
		} ).then( function ( result ) {
			if ( result.isConfirmed ) {
				onConfirm();
			}
		} );
	}

	// Expuestas globalmente para que otros tabs (Usuarios Externos, etc.)
	// puedan disparar el mismo flujo de confirmación + sincronización sin
	// duplicar esta lógica. Las funciones están "hoisted" (declaradas más
	// abajo con `function ejecutarRefrescarProgramas(...)`), así que ya
	// están disponibles aquí.
	window.AU_WMS_confirmarRefrescarGenerico = confirmarRefrescarGenerico;
	window.AU_WMS_ejecutarRefrescarProgramas = ejecutarRefrescarProgramas;

	/**
	 * Inicia la sincronización contra el endpoint AJAX indicado (empresa
	 * completa o un único usuario) y arranca el procesamiento por lotes
	 * con un modal de progreso bloqueante.
	 *
	 * @param {string} accionIniciar     Acción AJAX de inicio a llamar.
	 * @param {Object} payload           Datos adicionales a enviar (empresa_id o user_id).
	 * @param {string} etiquetaFallback  Nombre a mostrar si el backend no devuelve uno.
	 */
	function ejecutarRefrescarProgramas( accionIniciar, payload, etiquetaFallback ) {
		Swal.fire( {
			title: AU_WMS.i18n.refrescarIniciando,
			allowOutsideClick: false,
			allowEscapeKey: false,
			showConfirmButton: false,
			didOpen: function () {
				Swal.showLoading();
			},
		} );

		var datos = $.extend( { action: accionIniciar, nonce: AU_WMS.nonce }, payload );

		$.post( AU_WMS.ajaxUrl, datos )
			.done( function ( response ) {
				if ( ! response || ! response.success ) {
					mostrarError( response && response.data ? response.data.message : AU_WMS.i18n.genericError );
					return;
				}

				var sync = {
					syncId: response.data.sync_id,
					total: response.data.total,
					empresaNombre: response.data.empresa_nombre || etiquetaFallback,
					emails: response.data.emails || [],
					resultados: [],
				};

				if ( 0 === sync.total ) {
					mostrarResumenRefrescar( sync );
					return;
				}

				procesarLoteRefrescar( sync, 0 );
			} )
			.fail( function () {
				mostrarError( AU_WMS.i18n.genericError );
			} );
	}

	/**
	 * Tamaño de lote: cuántos usuarios se procesan EN PARALELO por cada
	 * llamada AJAX (cada uno dispara 2 llamadas HTTP —Inspira y
	 * Octágono— simultáneas, así que un lote de 5 puede llegar a 10
	 * llamadas HTTP concurrentes en el servidor). Ajusta este número si
	 * las APIs de Inspira/Octágono responden con errores de límite de
	 * peticiones (rate limiting) al usar lotes grandes.
	 */
	var REFRESCAR_TAMANO_LOTE = 5;

	/**
	 * Actualiza el modal bloqueante con el progreso actual, mostrando el
	 * lote en curso y los correos que contiene.
	 *
	 * @param {number} procesados     Usuarios ya procesados.
	 * @param {number} total          Total de usuarios a procesar.
	 * @param {Array}  correosDelLote Correos incluidos en el lote actual.
	 */
	function mostrarProgresoRefrescar( procesados, total, correosDelLote ) {
		var porcentaje = total > 0 ? Math.round( ( procesados / total ) * 100 ) : 100;
		var loteActual = Math.floor( procesados / REFRESCAR_TAMANO_LOTE ) + 1;
		var totalLotes = Math.max( 1, Math.ceil( total / REFRESCAR_TAMANO_LOTE ) );

		var listaCorreos = '';
		if ( correosDelLote && correosDelLote.length ) {
			listaCorreos = '<ul class="au-wms-refrescar-lista au-wms-refrescar-lote-correos">';
			correosDelLote.forEach( function ( email ) {
				listaCorreos += '<li>' + escapeHtml( email ) + '</li>';
			} );
			listaCorreos += '</ul>';
		}

		Swal.update( {
			title: AU_WMS.i18n.refrescarProcesando,
			html:
				'<div class="au-wms-import-progress-bar"><div class="au-wms-import-progress-fill" style="width:' + porcentaje + '%"></div></div>' +
				'<p>' + procesados + ' / ' + total + '</p>' +
				'<p class="au-wms-refrescar-lote-titulo">' +
					AU_WMS.i18n.refrescarLote + ' ' + loteActual + ' ' + AU_WMS.i18n.refrescarLoteDe + ' ' + totalLotes +
					' (' + ( correosDelLote ? correosDelLote.length : 0 ) + ' ' + AU_WMS.i18n.refrescarCorreos + ')' +
				'</p>' +
				listaCorreos,
			showConfirmButton: false,
			allowOutsideClick: false,
			allowEscapeKey: false,
		} );
	}

	/**
	 * Procesa un lote de varios usuarios EN PARALELO (ver
	 * REFRESCAR_TAMANO_LOTE) y se llama a sí misma hasta completar todos
	 * los usuarios.
	 *
	 * @param {Object} sync   Estado de la sincronización en curso.
	 * @param {number} offset Posición inicial del siguiente lote.
	 */
	function procesarLoteRefrescar( sync, offset ) {
		var correosDelLote = sync.emails.slice( offset, offset + REFRESCAR_TAMANO_LOTE );
		mostrarProgresoRefrescar( offset, sync.total, correosDelLote );

		$.post( AU_WMS.ajaxUrl, {
			action: 'au_wms_sync_programas_procesar_lote',
			nonce: AU_WMS.nonce,
			sync_id: sync.syncId,
			offset: offset,
			batch_size: REFRESCAR_TAMANO_LOTE,
		} )
			.done( function ( response ) {
				if ( ! response || ! response.success ) {
					mostrarError( response && response.data ? response.data.message : AU_WMS.i18n.genericError );
					return;
				}

				sync.resultados = sync.resultados.concat( response.data.results );

				if ( response.data.done ) {
					mostrarResumenRefrescar( sync );
					return;
				}

				procesarLoteRefrescar( sync, response.data.offset );
			} )
			.fail( function () {
				mostrarError( AU_WMS.i18n.genericError );
			} );
	}

	/**
	 * Muestra el resumen final de la sincronización (actualizados,
	 * eliminados y errores por cada programa).
	 *
	 * @param {Object} sync Estado final de la sincronización.
	 */
	function mostrarResumenRefrescar( sync ) {
		var listas = {
			inspira: { actualizado: [], eliminado: [] },
			octagono: { actualizado: [], eliminado: [] },
		};
		var contadorErrores = { inspira: 0, octagono: 0 };
		var errores = [];

		sync.resultados.forEach( function ( fila ) {
			[ 'inspira', 'octagono' ].forEach( function ( programa ) {
				var estado = fila[ programa ] ? fila[ programa ].status : null;

				if ( 'actualizado' === estado || 'eliminado' === estado ) {
					listas[ programa ][ estado ].push( fila.email );
				} else if ( 'error' === estado ) {
					contadorErrores[ programa ]++;
					errores.push( {
						email: fila.email,
						programa: programa,
						mensaje: fila[ programa ].mensaje,
					} );
				}
			} );
		} );

		var html = '<div class="au-wms-refrescar-resumen">';
		html += '<p><strong>' + AU_WMS.i18n.refrescarEmpresaLabel + ':</strong> ' + escapeHtml( sync.empresaNombre ) + '</p>';
		html += '<p><strong>' + AU_WMS.i18n.refrescarUsuariosProcesados + ':</strong> ' + sync.total + '</p>';

		[ 'inspira', 'octagono' ].forEach( function ( programa ) {
			var etiqueta = 'inspira' === programa ? 'Inspira' : 'Octágono';
			html += '<p class="au-wms-refrescar-programa-titulo">' + etiqueta + '</p>';

			html += '<p class="au-wms-refrescar-subtitulo au-wms-import-final-ok">✔ ' + AU_WMS.i18n.refrescarActualizados + ' (' + listas[ programa ].actualizado.length + ')</p>';
			html += renderListaCorreos( listas[ programa ].actualizado );

			html += '<p class="au-wms-refrescar-subtitulo au-wms-import-final-warning">✖ ' + AU_WMS.i18n.refrescarEliminados + ' (' + listas[ programa ].eliminado.length + ')</p>';
			html += renderListaCorreos( listas[ programa ].eliminado );

			if ( contadorErrores[ programa ] > 0 ) {
				html += '<p class="au-wms-refrescar-subtitulo au-wms-import-final-error">' + AU_WMS.i18n.refrescarConErrores + ' (' + contadorErrores[ programa ] + ')</p>';
			}
		} );

		if ( errores.length > 0 ) {
			html += '<p class="au-wms-refrescar-programa-titulo">' + AU_WMS.i18n.refrescarDetalleErrores + '</p>';
			html += '<ul class="au-wms-refrescar-lista au-wms-refrescar-errores">';
			errores.forEach( function ( err ) {
				html += '<li>' + escapeHtml( err.email ) + ' (' + err.programa + ') — ' + escapeHtml( err.mensaje ) + '</li>';
			} );
			html += '</ul>';
		}

		html += '</div>';

		Swal.fire( {
			icon: 'success',
			title: AU_WMS.i18n.refrescarFinalizado,
			html: html,
			confirmButtonText: AU_WMS.i18n.refrescarCerrar,
			confirmButtonColor: '#131A1E',
			allowOutsideClick: true,
			allowEscapeKey: true,
			showConfirmButton: true,
			width: 560,
		} );
	}

	/**
	 * Renderiza una lista de correos (o un texto "ninguno") dentro del
	 * resumen final.
	 *
	 * @param {Array} emails Lista de correos.
	 * @return {string}
	 */
	function renderListaCorreos( emails ) {
		if ( ! emails.length ) {
			return '<p class="au-wms-refrescar-sin-registros">' + AU_WMS.i18n.refrescarNinguno + '</p>';
		}

		var html = '<ul class="au-wms-refrescar-lista au-wms-refrescar-lista-correos">';
		emails.forEach( function ( email ) {
			html += '<li>' + escapeHtml( email ) + '</li>';
		} );
		html += '</ul>';

		return html;
	}

	/**
	 * Escapa HTML básico para insertar texto dinámico de forma segura
	 * dentro de las plantillas HTML de SweetAlert2.
	 *
	 * @param {string} value Texto a escapar.
	 * @return {string}
	 */
	function escapeHtml( value ) {
		return $( '<div>' ).text( value || '' ).html();
	}

	/* ==========================================================================
	   Modal "Ver más" — Áreas de una empresa
	   ========================================================================== */

	var areasState = {
		empresaId: 0,
		empresaNombre: '',
		search: '',
		liderFiltro: '',
		licenciaFiltro: '',
		cursosFiltro: '',
		page: 1,
		perPage: 10,
		totalPages: 1,
	};

	var areasSearchDebounce = null;

	/**
	 * Cablea el modal de Áreas (cierre, buscador, paginación). Se llama
	 * una sola vez al iniciar el Tab Empresas.
	 */
	function initModalAreas() {
		$( '#au-wms-areas-close' ).on( 'click', cerrarModalAreas );

		$( '#au-wms-areas-overlay' ).on( 'click', function ( event ) {
			if ( event.target === this ) {
				cerrarModalAreas();
			}
		} );

		$( '#au-wms-areas-search' ).on( 'input', function () {
			var value = $( this ).val();

			clearTimeout( areasSearchDebounce );
			areasSearchDebounce = setTimeout( function () {
				areasState.search = value;
				areasState.page = 1;
				cargarAreas();
			}, 350 );
		} );

		$( '#au-wms-btn-refresh-areas' ).on( 'click', function () {
			cargarAreas();
		} );

		$( '#au-wms-areas-per-page' ).on( 'change', function () {
			areasState.perPage = parseInt( $( this ).val(), 10 ) || 10;
			areasState.page = 1;
			cargarAreas();
		} );

		$( '#au-wms-areas-lider-filtro' ).on( 'change', function () {
			areasState.liderFiltro = $( this ).val();
			areasState.page = 1;
			cargarAreas();
		} );

		$( '#au-wms-areas-licencia-filtro' ).on( 'change', function () {
			areasState.licenciaFiltro = $( this ).val();
			areasState.page = 1;
			cargarAreas();
		} );

		$( '#au-wms-areas-cursos-filtro' ).on( 'change', function () {
			areasState.cursosFiltro = $( this ).val();
			areasState.page = 1;
			cargarAreas();
		} );

		$( '#au-wms-areas-body' ).on( 'click', '.au-wms-area-row-cursos-btn', function () {
			var areaId = $( this ).closest( 'tr' ).data( 'area-id' );

			abrirModalAreaCursos( areaId );
		} );

		// Dropdown "Acciones" de cada fila del listado de Áreas (mismo
		// patrón de abrir/cerrar que el dropdown de la tabla de Empresas,
		// pero delegado aquí porque vive dentro de este modal).
		$( '#au-wms-areas-body' ).on( 'click', '.au-wms-actions-btn', function ( event ) {
			event.stopPropagation();

			var $dropdown = $( this ).closest( '.au-wms-actions-dropdown' );
			var wasOpen = $dropdown.hasClass( 'is-open' );

			cerrarTodosLosDropdowns();

			if ( ! wasOpen ) {
				$dropdown.addClass( 'is-open' );
			}
		} );

		$( '#au-wms-areas-body' ).on( 'click', '.au-wms-area-row-action-editar', function () {
			var areaId = $( this ).closest( 'tr' ).data( 'area-id' );

			abrirModalEditarArea( areaId );
		} );

		$( '#au-wms-editar-area-close' ).on( 'click', cerrarModalEditarArea );
		$( '#au-wms-editar-area-btn-cancelar' ).on( 'click', cerrarModalEditarArea );

		$( '#au-wms-editar-area-overlay' ).on( 'click', function ( event ) {
			if ( event.target === this ) {
				cerrarModalEditarArea();
			}
		} );

		$( '#au-wms-editar-area-btn-guardar' ).on( 'click', guardarEdicionArea );

		$( '#au-wms-areas-pagination' ).on( 'click', '.au-wms-page-btn', function () {
			var target = $( this ).data( 'page' );

			if ( 'first' === target ) {
				areasState.page = 1;
			} else if ( 'prev' === target ) {
				areasState.page = Math.max( 1, areasState.page - 1 );
			} else if ( 'next' === target ) {
				areasState.page = Math.min( areasState.totalPages, areasState.page + 1 );
			} else if ( 'last' === target ) {
				areasState.page = areasState.totalPages;
			}

			cargarAreas();
		} );

		$( '#au-wms-areas-btn-crear' ).on( 'click', abrirModalCrearArea );
		$( '#au-wms-crear-area-close' ).on( 'click', cerrarModalCrearArea );
		$( '#au-wms-crear-area-btn-cancelar' ).on( 'click', cerrarModalCrearArea );

		$( '#au-wms-crear-area-overlay' ).on( 'click', function ( event ) {
			if ( event.target === this ) {
				cerrarModalCrearArea();
			}
		} );

		$( '#au-wms-crear-area-add-row' ).on( 'click', function () {
			agregarFilaCrearArea();
		} );

		$( '#au-wms-crear-area-filas' ).on( 'click', '.au-wms-crear-area-fila-remove', function () {
			// Siempre debe quedar al menos una fila en el formulario.
			if ( $( '#au-wms-crear-area-filas .au-wms-crear-area-fila' ).length <= 1 ) {
				return;
			}

			$( this ).closest( '.au-wms-crear-area-fila' ).remove();
		} );

		$( '#au-wms-crear-area-btn-registrar' ).on( 'click', validarYMostrarResumenCrearArea );
		$( '#au-wms-crear-area-btn-volver' ).on( 'click', mostrarPanelFormCrearArea );
		$( '#au-wms-crear-area-btn-confirmar' ).on( 'click', confirmarCrearAreas );
	}

	/**
	 * Abre el modal secundario "Crear Área/s" para la empresa que
	 * actualmente tiene abierto el modal de Áreas (`areasState.empresaId`),
	 * con una sola fila vacía para empezar.
	 */
	function abrirModalCrearArea() {
		$( '#au-wms-crear-area-filas' ).empty();
		agregarFilaCrearArea();
		mostrarPanelFormCrearArea();

		$( '#au-wms-crear-area-overlay' ).addClass( 'is-open' );
	}

	function cerrarModalCrearArea() {
		$( '#au-wms-crear-area-overlay' ).removeClass( 'is-open' );
	}

	/**
	 * Añade una fila vacía (Nombre / Cupos / Licencia / Quitar) al
	 * formulario de "Crear Área/s".
	 */
	function agregarFilaCrearArea() {
		var template = document.getElementById( 'au-wms-crear-area-fila-template' );
		var $fila = $( document.importNode( template.content, true ) ).find( '.au-wms-crear-area-fila' );

		$( '#au-wms-crear-area-filas' ).append( $fila );
	}

	/**
	 * Muestra el panel 1 (formulario de filas) y oculta el panel 2
	 * (resumen/confirmación), incluidos sus respectivos footers.
	 */
	function mostrarPanelFormCrearArea() {
		$( '#au-wms-crear-area-panel-form' ).removeClass( 'au-wms-hidden' );
		$( '#au-wms-crear-area-panel-resumen' ).addClass( 'au-wms-hidden' );
		$( '#au-wms-crear-area-footer-form' ).removeClass( 'au-wms-hidden' );
		$( '#au-wms-crear-area-footer-resumen' ).addClass( 'au-wms-hidden' );
	}

	function mostrarPanelResumenCrearArea() {
		$( '#au-wms-crear-area-panel-form' ).addClass( 'au-wms-hidden' );
		$( '#au-wms-crear-area-panel-resumen' ).removeClass( 'au-wms-hidden' );
		$( '#au-wms-crear-area-footer-form' ).addClass( 'au-wms-hidden' );
		$( '#au-wms-crear-area-footer-resumen' ).removeClass( 'au-wms-hidden' );
	}

	/**
	 * Lote de áreas actualmente en el paso de resumen/confirmación. Cada
	 * elemento conserva una referencia a su fila del formulario (`$fila`)
	 * para poder quitarla del DOM en cuanto esa área quede creada (así no
	 * puede reenviarse dos veces), y así el formulario, al "Volver",
	 * siempre refleja exactamente lo que falta por crear.
	 */
	var crearAreaLote = [];
	var crearAreaEnviando = false;

	/**
	 * Valida las filas del formulario (nombre y cupos, obligatorios) y,
	 * si todas son válidas, arma el lote y muestra el panel de resumen
	 * para confirmar antes de crear nada.
	 */
	function validarYMostrarResumenCrearArea() {
		var $error = $( '#au-wms-crear-area-error' );
		$error.addClass( 'au-wms-hidden' ).text( '' );

		var lote = [];
		var huboError = false;

		$( '#au-wms-crear-area-filas .au-wms-crear-area-fila' ).each( function () {
			var $fila = $( this );
			var nombre = $.trim( $fila.find( '.au-wms-crear-area-fila-nombre' ).val() );
			var cuposTexto = $.trim( $fila.find( '.au-wms-crear-area-fila-cupos' ).val() );
			// "cupos" es opcional: si se deja vacío, se guarda 1 por
			// defecto. Si se escribe un valor, sí debe ser válido (>= 1).
			var cupos = '' === cuposTexto ? 1 : parseInt( cuposTexto, 10 );
			var licenciaId = $fila.find( '.au-wms-crear-area-fila-licencia' ).val();
			var licenciaLabel = $fila.find( '.au-wms-crear-area-fila-licencia option:selected' ).text();
			var esValida = !! nombre && cupos >= 1;

			$fila.toggleClass( 'au-wms-crear-area-fila--error', ! esValida );

			if ( ! esValida ) {
				huboError = true;
				return;
			}

			lote.push( {
				$fila: $fila,
				nombre: nombre,
				cupos: cupos,
				licenciaId: licenciaId,
				licenciaLabel: licenciaId ? licenciaLabel : ( AU_WMS.i18n.sinLicencia || 'Sin licencia' ),
				estado: 'pendiente',
				mensaje: '',
			} );
		} );

		if ( huboError ) {
			$error.removeClass( 'au-wms-hidden' ).text(
				AU_WMS.i18n.crearAreaFilasInvalidas || 'Revisa los campos marcados: el nombre del área es obligatorio, y si escribes un número de cupos debe ser mayor a 0.'
			);
			return;
		}

		crearAreaLote = lote;
		renderResumenCrearArea();
		mostrarPanelResumenCrearArea();
	}

	/**
	 * Redibuja la tabla de resumen a partir de `crearAreaLote`, con el
	 * estado actual de cada área (pendiente / creando / creada / error).
	 */
	function renderResumenCrearArea() {
		var $body = $( '#au-wms-crear-area-resumen-body' );
		$body.empty();

		crearAreaLote.forEach( function ( item ) {
			var estadoHtml = '<span class="au-wms-badge au-wms-badge--role-default">' +
				( AU_WMS.i18n.crearAreaEstadoPendiente || 'Por crear' ) + '</span>';

			if ( 'creando' === item.estado ) {
				estadoHtml = '<span class="au-wms-badge au-wms-badge--role-default">' +
					( AU_WMS.i18n.crearAreaEstadoCreando || 'Creando…' ) + '</span>';
			} else if ( 'creada' === item.estado ) {
				estadoHtml = '<span class="au-wms-badge au-wms-badge--role-subscriber">' +
					( AU_WMS.i18n.crearAreaEstadoCreada || 'Creada' ) + '</span>';
			} else if ( 'error' === item.estado ) {
				estadoHtml = '<span class="au-wms-badge au-wms-badge--danger-outline">' +
					( AU_WMS.i18n.crearAreaEstadoError || 'Error' ) + '</span>';
			}

			var $tr = $( '<tr>' );
			$tr.append( $( '<td>' ).text( item.nombre ) );
			$tr.append( $( '<td>' ).text( item.cupos ) );
			$tr.append( $( '<td>' ).text( item.licenciaLabel ) );
			$tr.append( $( '<td>' ).html( estadoHtml ) );
			$body.append( $tr );

			if ( 'error' === item.estado && item.mensaje ) {
				var $trMensaje = $( '<tr class="au-wms-crear-area-resumen-error-row">' );
				$trMensaje.append(
					$( '<td colspan="4">' )
						.addClass( 'au-wms-crear-area-resumen-error-msg' )
						.text( item.mensaje )
				);
				$body.append( $trMensaje );
			}
		} );
	}

	/**
	 * Crea (o reintenta) las áreas del lote actual en una sola petición
	 * por lote. Solo reenvía las áreas que todavía no quedaron creadas
	 * ('pendiente' o 'error'); las ya creadas se excluyen siempre, así
	 * que pulsar el botón varias veces —o reintentar tras un error
	 * parcial— nunca puede duplicar un área. Si TODAS terminan creadas,
	 * cierra el modal, muestra el resumen final y refresca el listado
	 * principal de Áreas.
	 */
	function confirmarCrearAreas() {
		if ( crearAreaEnviando ) {
			return;
		}

		var porEnviar = crearAreaLote.filter( function ( item ) {
			return 'creada' !== item.estado;
		} );

		if ( ! porEnviar.length ) {
			return;
		}

		crearAreaEnviando = true;
		$( '#au-wms-crear-area-btn-confirmar' ).prop( 'disabled', true );
		$( '#au-wms-crear-area-btn-volver' ).prop( 'disabled', true );

		porEnviar.forEach( function ( item ) {
			item.estado = 'creando';
			item.mensaje = '';
		} );
		renderResumenCrearArea();

		var payload = porEnviar.map( function ( item ) {
			return {
				nombre: item.nombre,
				cupos: item.cupos,
				licencia_id: item.licenciaId,
			};
		} );

		$.post( AU_WMS.ajaxUrl, {
			action: 'au_wms_crear_areas_empresa',
			nonce: AU_WMS.nonce,
			empresa_id: areasState.empresaId,
			areas: JSON.stringify( payload ),
		} )
			.done( function ( response ) {
				if ( ! response || ! response.success ) {
					var mensajeGeneral = response && response.data ? response.data.message : AU_WMS.i18n.genericError;
					porEnviar.forEach( function ( item ) {
						item.estado = 'error';
						item.mensaje = mensajeGeneral;
					} );
					renderResumenCrearArea();
					return;
				}

				var resultados = response.data.resultados || [];

				porEnviar.forEach( function ( item, indice ) {
					var resultado = resultados[ indice ];

					if ( resultado && resultado.success ) {
						item.estado = 'creada';
						item.codigo = resultado.codigo;
						// Ya se creó: se quita del formulario para que un
						// reintento posterior nunca pueda reenviarla.
						item.$fila.remove();
					} else {
						item.estado = 'error';
						item.mensaje = resultado && resultado.message ? resultado.message : AU_WMS.i18n.genericError;
					}
				} );

				renderResumenCrearArea();

				var todasCreadas = crearAreaLote.every( function ( item ) {
					return 'creada' === item.estado;
				} );

				if ( todasCreadas ) {
					var resumenTexto = crearAreaLote.map( function ( item ) {
						return item.nombre + ' (' + item.codigo + ')';
					} ).join( '\n' );

					cerrarModalCrearArea();

					Swal.fire( {
						icon: 'success',
						title: AU_WMS.i18n.crearAreaExitoTitulo || 'Áreas creadas',
						text: resumenTexto,
					} );

					crearAreaLote = [];

					// Refresca el listado del modal de Áreas para que las
					// nuevas áreas aparezcan de inmediato.
					cargarAreas();
				}
			} )
			.fail( function () {
				porEnviar.forEach( function ( item ) {
					item.estado = 'error';
					item.mensaje = AU_WMS.i18n.genericError;
				} );
				renderResumenCrearArea();
			} )
			.always( function () {
				crearAreaEnviando = false;
				$( '#au-wms-crear-area-btn-confirmar' ).prop( 'disabled', false );
				$( '#au-wms-crear-area-btn-volver' ).prop( 'disabled', false );
			} );
	}

	/**
	 * ID del área que se está editando actualmente en el modal "Editar
	 * Área" (evita tener que releer `data-area-id` de una fila que, para
	 * cuando llega la respuesta de guardado, puede ya no existir si la
	 * lista se refrescó entretanto).
	 */
	// ------------------------------------------------------------------
	// Modal "Editar empresa" (acción de cada fila de Empresas)
	// ------------------------------------------------------------------

	// Campos del modal: id del input => clave que espera el servidor.
	var EDITAR_EMPRESA_CAMPOS = {
		'au-wms-ee-nombre-empresa': 'nombre_empresa',
		'au-wms-ee-nit': 'nit_empresa',
		'au-wms-ee-nombre-encargado': 'nombre_encargado',
		'au-wms-ee-apellidos': 'last_name',
		'au-wms-ee-contacto': 'contacto',
		'au-wms-ee-ocupacion': 'ocupacion',
	};

	var editarEmpresaId = null;
	var editarEmpresaGuardando = false;

	function initModalEditarEmpresa() {
		$( '#au-wms-editar-empresa-close, #au-wms-editar-empresa-btn-cancelar' ).on( 'click', cerrarModalEditarEmpresa );

		$( '#au-wms-editar-empresa-overlay' ).on( 'click', function ( event ) {
			if ( event.target === this ) {
				cerrarModalEditarEmpresa();
			}
		} );

		$( '#au-wms-editar-empresa-btn-guardar' ).on( 'click', guardarEdicionEmpresa );
	}

	/**
	 * Abre el modal y precarga los datos reales de la empresa: el
	 * listado no trae NIT, contacto ni ocupación, así que se piden al
	 * servidor en vez de leerlos de la fila.
	 *
	 * @param {number} empresaId ID de la empresa.
	 */
	function abrirModalEditarEmpresa( empresaId ) {
		editarEmpresaId = empresaId;

		var $error = $( '#au-wms-editar-empresa-error' ).addClass( 'au-wms-hidden' ).text( '' );
		var $guardar = $( '#au-wms-editar-empresa-btn-guardar' ).prop( 'disabled', true );

		Object.keys( EDITAR_EMPRESA_CAMPOS ).forEach( function ( id ) {
			$( '#' + id ).val( '' ).prop( 'disabled', true );
		} );

		$( '#au-wms-editar-empresa-correo' ).text( AU_WMS.i18n.loading || 'Cargando...' );
		$( '#au-wms-editar-empresa-overlay' ).addClass( 'is-open' );

		$.post( AU_WMS.ajaxUrl, {
			action: 'au_wms_obtener_empresa',
			nonce: AU_WMS.nonce,
			empresa_id: empresaId,
		} )
			.done( function ( response ) {
				if ( ! response || ! response.success ) {
					cerrarModalEditarEmpresa();
					mostrarError( response && response.data ? response.data.message : AU_WMS.i18n.genericError );
					return;
				}

				var empresa = response.data;

				Object.keys( EDITAR_EMPRESA_CAMPOS ).forEach( function ( id ) {
					$( '#' + id ).val( empresa[ EDITAR_EMPRESA_CAMPOS[ id ] ] || '' ).prop( 'disabled', false );
				} );

				$( '#au-wms-editar-empresa-correo' ).text(
					( AU_WMS.i18n.eeCorreo || 'Correo de la cuenta' ) + ': ' + ( empresa.email || '' )
				);

				$guardar.prop( 'disabled', false );
				$( '#au-wms-ee-nombre-empresa' ).trigger( 'focus' );
			} )
			.fail( function () {
				cerrarModalEditarEmpresa();
				mostrarError( AU_WMS.i18n.genericError );
			} );

		$error.addClass( 'au-wms-hidden' );
	}

	function cerrarModalEditarEmpresa() {
		if ( editarEmpresaGuardando ) {
			return;
		}

		$( '#au-wms-editar-empresa-overlay' ).removeClass( 'is-open' );
		editarEmpresaId = null;
	}

	/**
	 * Guarda los cambios. Ante un error, el modal se queda abierto con
	 * lo escrito para poder corregirlo.
	 */
	function guardarEdicionEmpresa() {
		if ( ! editarEmpresaId || editarEmpresaGuardando ) {
			return;
		}

		var $error = $( '#au-wms-editar-empresa-error' ).addClass( 'au-wms-hidden' ).text( '' );
		var $boton = $( '#au-wms-editar-empresa-btn-guardar' );
		var textoOriginal = $boton.text();

		if ( ! $.trim( $( '#au-wms-ee-nombre-empresa' ).val() ) ) {
			$error.removeClass( 'au-wms-hidden' ).text(
				AU_WMS.i18n.eeNombreObligatorio || 'La razón social o nombre de la empresa es obligatorio.'
			);
			return;
		}

		var datos = {
			action: 'au_wms_editar_empresa',
			nonce: AU_WMS.nonce,
			empresa_id: editarEmpresaId,
		};

		Object.keys( EDITAR_EMPRESA_CAMPOS ).forEach( function ( id ) {
			datos[ EDITAR_EMPRESA_CAMPOS[ id ] ] = $.trim( $( '#' + id ).val() );
		} );

		editarEmpresaGuardando = true;
		$boton.prop( 'disabled', true ).text( AU_WMS.i18n.eeGuardando || 'Guardando…' );

		$.post( AU_WMS.ajaxUrl, datos )
			.done( function ( response ) {
				if ( ! response || ! response.success ) {
					$error.removeClass( 'au-wms-hidden' ).text(
						response && response.data ? response.data.message : AU_WMS.i18n.genericError
					);
					return;
				}

				editarEmpresaGuardando = false;
				cerrarModalEditarEmpresa();

				Swal.fire( {
					icon: 'success',
					title: AU_WMS.i18n.eeExito || 'Los datos de la empresa se actualizaron correctamente',
					timer: 2200,
					showConfirmButton: false,
				} );

				// Refresca el listado por AJAX (sin recargar la página)
				// para que la fila muestre el nombre y el encargado nuevos.
				cargarEmpresas();
			} )
			.fail( function () {
				$error.removeClass( 'au-wms-hidden' ).text( AU_WMS.i18n.genericError );
			} )
			.always( function () {
				editarEmpresaGuardando = false;
				$boton.prop( 'disabled', false ).text( textoOriginal );
			} );
	}

	// ------------------------------------------------------------------
	// Modal "Cambiar Licencia" (acción de cada fila de Empresas)
	// ------------------------------------------------------------------

	var cambiarLicenciaEmpresaId = null;

	function initModalCambiarLicencia() {
		$( '#au-wms-cambiar-licencia-close' ).on( 'click', cerrarModalCambiarLicencia );
		$( '#au-wms-cambiar-licencia-btn-cancelar' ).on( 'click', cerrarModalCambiarLicencia );

		$( '#au-wms-cambiar-licencia-overlay' ).on( 'click', function ( event ) {
			if ( event.target === this ) {
				cerrarModalCambiarLicencia();
			}
		} );

		$( '#au-wms-cambiar-licencia-btn-guardar' ).on( 'click', guardarCambioLicencia );

		$( '#au-wms-cambiar-licencia-select' ).on( 'change', function () {
			renderAccesosLicencia( $( this ).val() );
		} );
	}

	/**
	 * Pinta los accesos de la licencia elegida: marca cada uno de los 9
	 * atributos como incluido o no, con los datos ya localizados en
	 * AU_WMS_EMPRESAS.licenciasAccesos. Con "Sin licencia" (o si la
	 * licencia ya no existe) muestra en su lugar la nota de que la
	 * empresa se queda sin accesos.
	 *
	 * @param {string} licenciaId Valor del select ('' = sin licencia).
	 */
	function renderAccesosLicencia( licenciaId ) {
		var mapa = ( window.AU_WMS_EMPRESAS && AU_WMS_EMPRESAS.licenciasAccesos ) || {};
		var licencia = licenciaId ? mapa[ licenciaId ] : null;
		var $detalle = $( '#au-wms-cambiar-licencia-detalle' );

		$detalle.prop( 'hidden', ! licencia );
		$( '#au-wms-cambiar-licencia-detalle-vacio' ).prop( 'hidden', !! licencia );

		if ( ! licencia ) {
			return;
		}

		$( '#au-wms-cambiar-licencia-duracion' ).text(
			licencia.duracion
				? licencia.duracion + ' ' + ( AU_WMS.i18n.licenciaDuracionSufijo || 'días de vigencia' )
				: ''
		);

		$detalle.find( 'li' ).each( function () {
			var $item = $( this );
			var incluido = !! licencia[ $item.data( 'campo' ) ];

			$item.toggleClass( 'is-on', incluido ).toggleClass( 'is-off', ! incluido );
			$item.find( '.au-wms-licencia-detalle-icono' )
				.toggleClass( 'dashicons-yes-alt', incluido )
				.toggleClass( 'dashicons-minus', ! incluido );
		} );
	}

	/**
	 * Abre el modal con la licencia actual de la empresa ya
	 * seleccionada. Si la empresa no tiene licencia (o apunta a una que
	 * ya no existe) queda marcada la opción "Sin licencia".
	 *
	 * @param {number} empresaId     ID de la empresa.
	 * @param {string} empresaNombre Nombre a mostrar en el modal.
	 * @param {number} licenciaId    ID de la licencia actual, o 0.
	 */
	function abrirModalCambiarLicencia( empresaId, empresaNombre, licenciaId ) {
		cambiarLicenciaEmpresaId = empresaId;

		var $select = $( '#au-wms-cambiar-licencia-select' );

		$( '#au-wms-cambiar-licencia-error' ).addClass( 'au-wms-hidden' ).text( '' );
		$( '#au-wms-cambiar-licencia-empresa' ).text( empresaNombre || ( '#' + empresaId ) );

		$select.val( licenciaId ? String( licenciaId ) : '' );

		// val() devuelve null si ese id ya no está entre las opciones
		// (licencia borrada): en ese caso se queda en "Sin licencia".
		if ( null === $select.val() ) {
			$select.val( '' );
		}

		renderAccesosLicencia( $select.val() );

		$( '#au-wms-cambiar-licencia-overlay' ).addClass( 'is-open' );
	}

	function cerrarModalCambiarLicencia() {
		$( '#au-wms-cambiar-licencia-overlay' ).removeClass( 'is-open' );
		cambiarLicenciaEmpresaId = null;
	}

	/**
	 * Guarda la licencia elegida y refresca el listado, para que la
	 * columna "Licencia adquirida" muestre el valor nuevo.
	 */
	function guardarCambioLicencia() {
		if ( ! cambiarLicenciaEmpresaId ) {
			return;
		}

		var $error = $( '#au-wms-cambiar-licencia-error' );
		var $boton = $( '#au-wms-cambiar-licencia-btn-guardar' );

		$error.addClass( 'au-wms-hidden' ).text( '' );
		$boton.prop( 'disabled', true );

		$.post( AU_WMS.ajaxUrl, {
			action: 'au_wms_cambiar_licencia_empresa',
			nonce: AU_WMS.nonce,
			empresa_id: cambiarLicenciaEmpresaId,
			licencia_id: $( '#au-wms-cambiar-licencia-select' ).val() || 0,
		} )
			.done( function ( response ) {
				if ( ! response || ! response.success ) {
					$error.removeClass( 'au-wms-hidden' ).text(
						response && response.data ? response.data.message : AU_WMS.i18n.genericError
					);
					return;
				}

				cerrarModalCambiarLicencia();

				Swal.fire( {
					icon: 'success',
					title: AU_WMS.i18n.cambiarLicenciaExitoTitulo || 'Licencia actualizada',
					timer: 2000,
					showConfirmButton: false,
				} );

				cargarEmpresas();
			} )
			.fail( function () {
				$error.removeClass( 'au-wms-hidden' ).text( AU_WMS.i18n.genericError );
			} )
			.always( function () {
				$boton.prop( 'disabled', false );
			} );
	}

	var editarAreaId = null;

	/**
	 * Abre el modal "Editar Área": pide primero los datos reales del área
	 * (no los que se ven en la fila, que pueden reflejar una licencia
	 * heredada de la empresa en vez de la propia del área) y, cuando
	 * llegan, precarga el formulario.
	 *
	 * @param {number} areaId ID del área (wp_paquetes.id).
	 */
	function abrirModalEditarArea( areaId ) {
		editarAreaId = areaId;

		var $error = $( '#au-wms-editar-area-error' );
		$error.addClass( 'au-wms-hidden' ).text( '' );

		$( '#au-wms-editar-area-nombre' ).val( '' );
		$( '#au-wms-editar-area-cupos' ).val( '' );
		$( '#au-wms-editar-area-licencia' ).val( '' );

		$( '#au-wms-editar-area-overlay' ).addClass( 'is-open' );

		$.post( AU_WMS.ajaxUrl, {
			action: 'au_wms_obtener_area',
			nonce: AU_WMS.nonce,
			area_id: areaId,
		} )
			.done( function ( response ) {
				if ( ! response || ! response.success ) {
					cerrarModalEditarArea();
					mostrarError( response && response.data ? response.data.message : AU_WMS.i18n.genericError );
					return;
				}

				$( '#au-wms-editar-area-nombre' ).val( response.data.nombre );
				$( '#au-wms-editar-area-cupos' ).val( response.data.cupos );
				$( '#au-wms-editar-area-licencia' ).val( response.data.licencia_id || '' );
			} )
			.fail( function () {
				cerrarModalEditarArea();
				mostrarError( AU_WMS.i18n.genericError );
			} );
	}

	function cerrarModalEditarArea() {
		$( '#au-wms-editar-area-overlay' ).removeClass( 'is-open' );
		editarAreaId = null;
	}

	/**
	 * Guarda los cambios del modal "Editar Área": valida solo el nombre
	 * en el cliente (obligatorio); "cupos" vacío se guarda como 1, igual
	 * que en "Crear Área/s". Si tiene éxito, cierra el modal y refresca
	 * el listado principal de Áreas.
	 */
	function guardarEdicionArea() {
		if ( ! editarAreaId ) {
			return;
		}

		var nombre = $.trim( $( '#au-wms-editar-area-nombre' ).val() );
		var $error = $( '#au-wms-editar-area-error' );

		$error.addClass( 'au-wms-hidden' ).text( '' );

		if ( ! nombre ) {
			$error.removeClass( 'au-wms-hidden' ).text( AU_WMS.i18n.crearAreaNombreObligatorio || 'El nombre del área es obligatorio.' );
			return;
		}

		var $boton = $( '#au-wms-editar-area-btn-guardar' );
		$boton.prop( 'disabled', true );

		$.post( AU_WMS.ajaxUrl, {
			action: 'au_wms_editar_area',
			nonce: AU_WMS.nonce,
			area_id: editarAreaId,
			nombre: nombre,
			cupos: $.trim( $( '#au-wms-editar-area-cupos' ).val() ),
			licencia_id: $( '#au-wms-editar-area-licencia' ).val(),
		} )
			.done( function ( response ) {
				if ( ! response || ! response.success ) {
					$error.removeClass( 'au-wms-hidden' ).text(
						response && response.data ? response.data.message : AU_WMS.i18n.genericError
					);
					return;
				}

				cerrarModalEditarArea();

				Swal.fire( {
					icon: 'success',
					title: AU_WMS.i18n.editarAreaExitoTitulo || 'Área actualizada',
				} );

				cargarAreas();
			} )
			.fail( function () {
				$error.removeClass( 'au-wms-hidden' ).text( AU_WMS.i18n.genericError );
			} )
			.always( function () {
				$boton.prop( 'disabled', false );
			} );
	}

	/**
	 * Abre el modal de Áreas para una empresa específica.
	 *
	 * @param {number} empresaId     ID de la empresa.
	 * @param {string} empresaNombre Nombre a mostrar en el título.
	 */
	function abrirModalAreas( empresaId, empresaNombre ) {
		areasState.empresaId = empresaId;
		areasState.empresaNombre = empresaNombre || '';
		areasState.search = '';
		areasState.liderFiltro = '';
		areasState.licenciaFiltro = '';
		areasState.cursosFiltro = '';
		areasState.page = 1;

		$( '#au-wms-areas-search' ).val( '' );
		$( '#au-wms-areas-lider-filtro' ).val( '' );
		$( '#au-wms-areas-licencia-filtro' ).val( '' );
		$( '#au-wms-areas-cursos-filtro' ).val( '' );
		$( '#au-wms-areas-title' ).text( ( AU_WMS.i18n.areasTitulo || 'Áreas' ) + ' — ' + areasState.empresaNombre );

		$( '#au-wms-areas-overlay' ).addClass( 'is-open' );

		cargarAreas();
	}

	function cerrarModalAreas() {
		$( '#au-wms-areas-overlay' ).removeClass( 'is-open' );
	}

	/**
	 * Carga (o recarga) el listado paginado de áreas de la empresa actual.
	 */
	function cargarAreas() {
		$( '#au-wms-areas-body' ).html(
			'<tr class="au-wms-row-loading"><td colspan="3"><div class="au-wms-spinner"></div>' +
			AU_WMS.i18n.loading +
			'</td></tr>'
		);

		$.post( AU_WMS.ajaxUrl, {
			action: 'au_wms_buscar_areas_empresa',
			nonce: AU_WMS.nonce,
			empresa_id: areasState.empresaId,
			search: areasState.search,
			lider_filtro: areasState.liderFiltro,
			licencia_id: areasState.licenciaFiltro,
			cursos_filtro: areasState.cursosFiltro,
			page: areasState.page,
			per_page: areasState.perPage,
		} )
			.done( function ( response ) {
				if ( ! response || ! response.success ) {
					mostrarError( response && response.data ? response.data.message : AU_WMS.i18n.genericError );
					return;
				}

				renderTablaAreas( response.data.items );
				renderPaginacionAreas( response.data );
			} )
			.fail( function () {
				mostrarError( AU_WMS.i18n.genericError );
			} );
	}

	/**
	 * Renderiza las filas de la tabla de áreas.
	 *
	 * @param {Array} items Lista de áreas.
	 */
	function renderTablaAreas( items ) {
		var $tbody = $( '#au-wms-areas-body' );
		$tbody.empty();

		if ( ! items || ! items.length ) {
			var emptyTemplate = document.getElementById( 'au-wms-areas-empty-template' );
			$tbody.append( document.importNode( emptyTemplate.content, true ) );
			return;
		}

		var template = document.getElementById( 'au-wms-areas-row-template' );

		items.forEach( function ( item ) {
			var $row = $( document.importNode( template.content, true ) );
			var $tr = $row.filter( 'tr' ).length ? $row.filter( 'tr' ) : $row.find( 'tr' );

			$tr.attr( 'data-area-id', item.id );

			$tr.find( '.au-wms-user-id' ).text( 'ID: ' + item.id );
			$tr.find( '.au-wms-area-row-nombre' ).text( item.nombre );
			$tr.find( '.au-wms-area-row-licencia' ).text( item.licencia_nombre || '' );

			var numCursos = item.num_cursos || 0;
			$tr.find( '.au-wms-area-row-cursos-count' ).text( numCursos );
			$tr.find( '.au-wms-area-row-cursos-btn' ).toggleClass( 'au-wms-hidden', numCursos <= 0 );

			var $liderBadge  = $tr.find( '.au-wms-area-row-lider-badge' );
			var $liderNombre = $tr.find( '.au-wms-area-row-lider-nombre' );
			var $liderEmail  = $tr.find( '.au-wms-area-row-lider-email' );

			if ( item.lider && item.lider.asignado ) {
				$liderBadge.addClass( 'au-wms-hidden' );
				$liderNombre.text( item.lider.nombre );
				$liderEmail.text( item.lider.email || '' );
			} else {
				$liderNombre.text( '' );
				$liderEmail.text( '' );
				$liderBadge.text( ( item.lider && item.lider.nombre ) || '' ).removeClass( 'au-wms-hidden' );
			}

			var cupoModifier = 'au-wms-badge--empresa';

			if ( item.cupo > 0 ) {
				cupoModifier = item.usados >= item.cupo ? 'au-wms-badge--cupo-lleno' : 'au-wms-badge--cupo-disponible';
			}

			$tr.find( '.au-wms-areas-uso-badge' )
				.addClass( 'au-wms-badge ' + cupoModifier )
				.text( item.usados + ' / ' + item.cupo );

			$tbody.append( $tr );
		} );
	}

	/**
	 * Actualiza los controles de paginación del modal de Áreas.
	 *
	 * @param {Object} data Respuesta de au_wms_buscar_areas_empresa.
	 */
	function renderPaginacionAreas( data ) {
		areasState.page = data.page;
		areasState.totalPages = data.total_pages;

		$( '#au-wms-areas-total' ).text( data.total );
		$( '#au-wms-areas-total-badge' ).text(
			data.total + ' ' + ( 1 === data.total ? ( AU_WMS.i18n.areaSingular || 'área' ) : ( AU_WMS.i18n.areasPlural || 'áreas' ) )
		);
		$( '#au-wms-areas-current-page' ).text( data.page );
		$( '#au-wms-areas-total-pages' ).text( data.total_pages );

		$( '#au-wms-areas-pagination .au-wms-page-btn[data-page="first"]' ).prop( 'disabled', data.page <= 1 );
		$( '#au-wms-areas-pagination .au-wms-page-btn[data-page="prev"]' ).prop( 'disabled', data.page <= 1 );
		$( '#au-wms-areas-pagination .au-wms-page-btn[data-page="next"]' ).prop( 'disabled', data.page >= data.total_pages );
		$( '#au-wms-areas-pagination .au-wms-page-btn[data-page="last"]' ).prop( 'disabled', data.page >= data.total_pages );
	}

	/* ==========================================================================
	   Modal "Ver cursos" (columna "Cursos asignados" del modal Áreas)
	   ========================================================================== */

	var areaCursosState = {
		todos: [],
		search: '',
	};

	var areaCursosSearchDebounce = null;

	/**
	 * Cablea el modal "Ver cursos". Se llama una sola vez al iniciar el
	 * Tab Empresas.
	 */
	function initModalAreaCursos() {
		$( '#au-wms-area-cursos-close' ).on( 'click', cerrarModalAreaCursos );

		$( '#au-wms-area-cursos-overlay' ).on( 'click', function ( event ) {
			if ( event.target === this ) {
				cerrarModalAreaCursos();
			}
		} );

		$( '#au-wms-area-cursos-search' ).on( 'input', function () {
			var value = $( this ).val();

			clearTimeout( areaCursosSearchDebounce );
			areaCursosSearchDebounce = setTimeout( function () {
				areaCursosState.search = value;
				aplicarFiltroCursos();
			}, 200 );
		} );
	}

	/**
	 * Abre el modal "Ver cursos" para un área específica y carga su
	 * listado de cursos asignados.
	 *
	 * @param {number} areaId ID del área (`wp_paquetes.id`).
	 */
	function abrirModalAreaCursos( areaId ) {
		areaCursosState.todos = [];
		areaCursosState.search = '';

		$( '#au-wms-area-cursos-search' ).val( '' );
		$( '#au-wms-area-cursos-title' ).text( AU_WMS.i18n.cursosAsignadosTitulo || 'Cursos asignados' );
		$( '#au-wms-area-cursos-overlay' ).addClass( 'is-open' );

		cargarCursosArea( areaId );
	}

	function cerrarModalAreaCursos() {
		$( '#au-wms-area-cursos-overlay' ).removeClass( 'is-open' );
	}

	/**
	 * Pide al backend los cursos asignados a un área y renderiza el
	 * listado (o el estado vacío/error).
	 *
	 * @param {number} areaId ID del área.
	 */
	function cargarCursosArea( areaId ) {
		var $list = $( '#au-wms-area-cursos-list' );

		$list.html(
			'<li class="au-wms-row-loading"><div class="au-wms-spinner"></div>' +
			AU_WMS.i18n.loading +
			'</li>'
		);

		$.post( AU_WMS.ajaxUrl, {
			action: 'au_wms_buscar_cursos_area',
			nonce: AU_WMS.nonce,
			area_id: areaId,
		} )
			.done( function ( response ) {
				if ( ! response || ! response.success ) {
					$list.html(
						'<li class="au-wms-row-empty">' +
						( response && response.data ? response.data.message : AU_WMS.i18n.genericError ) +
						'</li>'
					);
					return;
				}

				if ( response.data.area_nombre ) {
					$( '#au-wms-area-cursos-title' ).text(
						( AU_WMS.i18n.cursosAsignadosTitulo || 'Cursos asignados' ) + ' — ' + response.data.area_nombre
					);
				}

				// Se numeran una sola vez, contra la lista completa (sin
				// filtrar), para que el número de cada curso no cambie
				// al escribir en el buscador.
				areaCursosState.todos = ( response.data.cursos || [] ).map( function ( curso, index ) {
					return $.extend( {}, curso, { numero: index + 1 } );
				} );

				aplicarFiltroCursos();
			} )
			.fail( function () {
				$list.html( '<li class="au-wms-row-empty">' + AU_WMS.i18n.genericError + '</li>' );
			} );
	}

	/**
	 * Filtra `areaCursosState.todos` por el texto de búsqueda actual y
	 * renderiza el resultado.
	 */
	function aplicarFiltroCursos() {
		var termino = areaCursosState.search.trim().toLowerCase();

		var filtrados = ! termino
			? areaCursosState.todos
			: areaCursosState.todos.filter( function ( curso ) {
				return curso.titulo.toLowerCase().indexOf( termino ) !== -1;
			} );

		renderListaCursos( filtrados );
	}

	/**
	 * Renderiza el listado de cursos del modal "Ver cursos".
	 *
	 * @param {Array} cursos Lista de {id, titulo, numero} ya filtrada.
	 */
	function renderListaCursos( cursos ) {
		var $list = $( '#au-wms-area-cursos-list' );
		$list.empty();

		if ( ! cursos || ! cursos.length ) {
			var templateId = areaCursosState.todos.length
				? 'au-wms-area-cursos-sin-resultados-template'
				: 'au-wms-area-cursos-empty-template';
			var emptyTemplate = document.getElementById( templateId );
			$list.append( document.importNode( emptyTemplate.content, true ) );
			return;
		}

		var template = document.getElementById( 'au-wms-area-cursos-item-template' );

		cursos.forEach( function ( curso ) {
			var $item = $( document.importNode( template.content, true ) );
			var $li = $item.filter( 'li' ).length ? $item.filter( 'li' ) : $item.find( 'li' );

			$li.find( '.au-wms-curso-item-numero' ).text( curso.numero );
			$li.find( '.au-wms-curso-item-titulo' ).text( curso.titulo );

			$list.append( $li );
		} );
	}
} )( jQuery );
