/**
 * Administrador de Usuarios (WMS Latam) — Tab "Usuarios Externos".
 *
 * Reutiliza el mismo patrón de paginación/filtro de Integrantes y
 * Empresas, y se apoya en los hooks globales expuestos por
 * admin.js/usermeta.js (window.AU_WMS_confirmarLoginComoUsuario,
 * window.AU_WMS_abrirUsermeta) para no duplicar esa lógica.
 */
( function ( $ ) {
	'use strict';

	var state = {
		search: '',
		programaFiltro: '',
		page: 1,
		perPage: 10,
		totalPages: 1,
	};

	var searchDebounceTimer = null;

	$( document ).ready( function () {
		if ( ! $( '#au-wms-tabla-externos' ).length ) {
			return;
		}

		initFiltros();
		initPaginacion();
		initEventosTabla();
		initBotonRefrescarTodos();
		cargarExternos();
	} );

	/**
	 * Botón superior "Refrescar programas": sincroniza TODOS los
	 * usuarios con rol `external_user`, reutilizando el mismo flujo de
	 * confirmación/progreso/resumen expuesto globalmente por empresas.js.
	 */
	function initBotonRefrescarTodos() {
		$( '#au-wms-btn-refrescar-externos' ).on( 'click', function () {
			if (
				'function' !== typeof window.AU_WMS_confirmarRefrescarGenerico ||
				'function' !== typeof window.AU_WMS_ejecutarRefrescarProgramas
			) {
				return;
			}

			window.AU_WMS_confirmarRefrescarGenerico(
				AU_WMS.i18n.refrescarConfirmTitleExternos,
				AU_WMS.i18n.refrescarConfirmTextExternos,
				function () {
					window.AU_WMS_ejecutarRefrescarProgramas(
						'au_wms_sync_programas_iniciar_externos',
						{},
						AU_WMS.i18n.refrescarUsuariosExternosLabel
					);
				}
			);
		} );
	}

	/**
	 * Filtro de Programa y selector de registros por página.
	 */
	function initFiltros() {
		$( '#au-wms-externos-search' ).on( 'input', function () {
			var value = $( this ).val();

			clearTimeout( searchDebounceTimer );
			searchDebounceTimer = setTimeout( function () {
				state.search = value;
				state.page = 1;
				cargarExternos();
			}, 400 );
		} );

		$( '#au-wms-btn-refresh-externos' ).on( 'click', function () {
			cargarExternos();
		} );

		$( '#au-wms-externos-programa' ).on( 'change', function () {
			state.programaFiltro = $( this ).val();
			state.page = 1;
			cargarExternos();
		} );

		$( '#au-wms-externos-per-page' ).on( 'change', function () {
			state.perPage = parseInt( $( this ).val(), 10 ) || 10;
			state.page = 1;
			cargarExternos();
		} );
	}

	/**
	 * Controles de paginación (primera, anterior, siguiente, última).
	 */
	function initPaginacion() {
		$( '#au-wms-externos-pagination' ).on( 'click', '.au-wms-page-btn', function () {
			var target = $( this ).data( 'page' );

			if ( 'first' === target ) {
				state.page = 1;
			} else if ( 'prev' === target ) {
				state.page = Math.max( 1, state.page - 1 );
			} else if ( 'next' === target ) {
				state.page = Math.min( state.totalPages, state.page + 1 );
			} else if ( 'last' === target ) {
				state.page = state.totalPages;
			}

			cargarExternos();
		} );
	}

	/**
	 * Delegación de eventos sobre la tabla: dropdown de acciones,
	 * iniciar sesión como usuario, ver WP_USERMETA.
	 */
	function initEventosTabla() {
		var $tbody = $( '#au-wms-externos-body' );

		$tbody.on( 'click', '.au-wms-actions-btn', function ( event ) {
			event.stopPropagation();

			var $dropdown = $( this ).closest( '.au-wms-actions-dropdown' );
			var wasOpen = $dropdown.hasClass( 'is-open' );

			$( '.au-wms-actions-dropdown' ).removeClass( 'is-open' );

			if ( ! wasOpen ) {
				$dropdown.addClass( 'is-open' );
			}
		} );

		$( document ).on( 'click', function () {
			$( '.au-wms-actions-dropdown' ).removeClass( 'is-open' );
		} );

		$tbody.on( 'click', '.au-wms-externo-action-login', function () {
			var userId = $( this ).closest( 'tr' ).data( 'user-id' );

			if ( 'function' === typeof window.AU_WMS_confirmarLoginComoUsuario ) {
				window.AU_WMS_confirmarLoginComoUsuario( userId );
			}
		} );

		$tbody.on( 'click', '.au-wms-externo-action-usermeta', function () {
			var $row = $( this ).closest( 'tr' );
			var userId = $row.data( 'user-id' );
			var nombre = $row.find( '.au-wms-user-name' ).text();

			if ( 'function' === typeof window.AU_WMS_abrirUsermeta ) {
				window.AU_WMS_abrirUsermeta( userId, nombre );
			}
		} );

		$tbody.on( 'click', '.au-wms-externo-action-refrescar', function () {
			var $row = $( this ).closest( 'tr' );
			var userId = $row.data( 'user-id' );
			var nombre = $row.find( '.au-wms-user-name' ).text();

			if ( 'function' === typeof window.AU_WMS_confirmarRefrescarProgramasUsuario ) {
				window.AU_WMS_confirmarRefrescarProgramasUsuario( userId, nombre );
			}
		} );

		$tbody.on( 'click', '.au-wms-externo-action-password', function () {
			var $row = $( this ).closest( 'tr' );
			var userId = $row.data( 'user-id' );
			var correo = $row.find( '.au-wms-user-email' ).text();

			if ( 'function' === typeof window.AU_WMS_abrirModalCambiarPassword ) {
				window.AU_WMS_abrirModalCambiarPassword( userId, correo );
			}
		} );

		$tbody.on( 'click', '.au-wms-externo-action-delete', function () {
			var $row = $( this ).closest( 'tr' );
			var userId = $row.data( 'user-id' );

			iniciarFlujoBorrarUsuarioExterno( userId );
		} );
	}

	/**
	 * Flujo "Borrar usuario" del Tab Usuarios Externos: sin confirmación
	 * inicial, refresca programas en silencio (reutilizando el mismo
	 * hook global de Integrantes) y, según lo que quede en `inspira`/
	 * `octagono`, informa que no se puede borrar o pide confirmación
	 * para eliminarlo definitivamente.
	 *
	 * @param {number} userId ID del usuario.
	 */
	function iniciarFlujoBorrarUsuarioExterno( userId ) {
		if (
			'function' !== typeof window.AU_WMS_refrescarProgramasSilencioso ||
			'function' !== typeof window.AU_WMS_obtenerEscenarioProgramas
		) {
			return;
		}

		Swal.fire( {
			title: AU_WMS.i18n.refrescandoProgramasUsuario,
			allowOutsideClick: false,
			allowEscapeKey: false,
			showConfirmButton: false,
			didOpen: function () {
				Swal.showLoading();
			},
		} );

		window.AU_WMS_refrescarProgramasSilencioso( userId, function () {
			window.AU_WMS_obtenerEscenarioProgramas( userId, mostrarResultadoEscenarioExterno );
		} );
	}

	/**
	 * Muestra el mensaje correspondiente según el escenario de
	 * programas del usuario: si tiene Inspira y/o Octágono, solo
	 * informa (no se puede borrar); si no tiene ninguno, pide
	 * confirmación para eliminarlo definitivamente.
	 *
	 * @param {number} userId    ID del usuario.
	 * @param {Object} escenario {email, tiene_inspira, tiene_octagono}.
	 */
	function mostrarResultadoEscenarioExterno( userId, escenario ) {
		var tieneInspira = !! escenario.tiene_inspira;
		var tieneOctagono = !! escenario.tiene_octagono;

		if ( tieneInspira && tieneOctagono ) {
			Swal.fire( { icon: 'info', title: AU_WMS.i18n.externoTieneAmbos, confirmButtonText: AU_WMS.i18n.aceptar } );
			return;
		}

		if ( tieneOctagono ) {
			Swal.fire( { icon: 'info', title: AU_WMS.i18n.externoTieneOctagono, confirmButtonText: AU_WMS.i18n.aceptar } );
			return;
		}

		if ( tieneInspira ) {
			Swal.fire( { icon: 'info', title: AU_WMS.i18n.externoTieneInspira, confirmButtonText: AU_WMS.i18n.aceptar } );
			return;
		}

		Swal.fire( {
			title: AU_WMS.i18n.externoConfirmarBorrado,
			icon: 'warning',
			showCancelButton: true,
			confirmButtonText: AU_WMS.i18n.aceptar,
			cancelButtonText: AU_WMS.i18n.cancelButton,
			customClass: { confirmButton: 'au-wms-swal-danger' },
			reverseButtons: true,
		} ).then( function ( result ) {
			if ( result.isConfirmed ) {
				ejecutarBorrarUsuarioExterno( userId );
			}
		} );
	}

	/**
	 * Elimina definitivamente al usuario externo (reutiliza el mismo
	 * endpoint `au_wms_eliminar_usuario` ya usado en Integrantes, que ya
	 * revalida en el servidor que no tenga Inspira/Octágono).
	 *
	 * @param {number} userId ID del usuario.
	 */
	function ejecutarBorrarUsuarioExterno( userId ) {
		Swal.fire( {
			title: AU_WMS.i18n.loading,
			allowOutsideClick: false,
			allowEscapeKey: false,
			showConfirmButton: false,
			didOpen: function () {
				Swal.showLoading();
			},
		} );

		$.post( AU_WMS.ajaxUrl, {
			action: 'au_wms_eliminar_usuario',
			nonce: AU_WMS.nonce,
			user_id: userId,
		} )
			.done( function ( response ) {
				if ( ! response || ! response.success ) {
					mostrarError( response && response.data ? response.data.message : AU_WMS.i18n.genericError );
					return;
				}

				Swal.fire( { icon: 'success', title: AU_WMS.i18n.externoEliminadoExito } );
				cargarExternos();
			} )
			.fail( function () {
				mostrarError( AU_WMS.i18n.genericError );
			} );
	}

	/**
	 * Carga (o recarga) el listado de usuarios externos vía AJAX.
	 */
	function cargarExternos() {
		mostrarCargando();

		$.post( AU_WMS.ajaxUrl, {
			action: 'au_wms_buscar_usuarios_externos',
			nonce: AU_WMS.nonce,
			search: state.search,
			programa_filtro: state.programaFiltro,
			page: state.page,
			per_page: state.perPage,
		} )
			.done( function ( response ) {
				if ( ! response || ! response.success ) {
					mostrarError( response && response.data ? response.data.message : AU_WMS.i18n.genericError );
					return;
				}

				renderTabla( response.data.items );
				renderPaginacion( response.data );

				if ( window.AU_WMS_UI ) {
					window.AU_WMS_UI.actualizarContadorTab( 'usuarios-externos', response.data.total, ! state.search && ! state.programaFiltro );
				}
			} )
			.fail( function () {
				mostrarError( AU_WMS.i18n.genericError );
			} );
	}

	function mostrarCargando() {
		$( '#au-wms-externos-body' ).html(
			'<tr class="au-wms-row-loading"><td colspan="3"><div class="au-wms-spinner"></div>' +
			AU_WMS.i18n.loading +
			'</td></tr>'
		);
	}

	/**
	 * Renderiza las filas de la tabla de usuarios externos.
	 *
	 * @param {Array} items Lista de usuarios.
	 */
	function renderTabla( items ) {
		var $tbody = $( '#au-wms-externos-body' );
		$tbody.empty();

		if ( ! items || ! items.length ) {
			var emptyTemplate = document.getElementById( 'au-wms-externos-empty-template' );
			$tbody.append( document.importNode( emptyTemplate.content, true ) );
			return;
		}

		var template = document.getElementById( 'au-wms-externos-row-template' );

		items.forEach( function ( item ) {
			var $row = $( document.importNode( template.content, true ) );
			var $tr = $row.filter( 'tr' ).length ? $row.filter( 'tr' ) : $row.find( 'tr' );

			$tr.attr( 'data-user-id', item.id );
			$tr.find( '.au-wms-user-id' ).text( '#' + item.id );
			$tr.find( '.au-wms-user-name' ).text( item.nombre );
			$tr.find( '.au-wms-user-email' ).text( item.user_email );

			var $programasBadges = $tr.find( '.au-wms-programas-badges' );

			if ( item.inspira_valor ) {
				$programasBadges.append( window.AU_WMS_UI.badgePrograma( 'inspira', item.inspira_valor ) );
			}

			if ( item.octagono_valor ) {
				$programasBadges.append( window.AU_WMS_UI.badgePrograma( 'octagono', item.octagono_valor ) );
			}

			$tbody.append( $tr );
		} );
	}

	/**
	 * Actualiza los controles de paginación.
	 *
	 * @param {Object} data Respuesta de au_wms_buscar_usuarios_externos.
	 */
	function renderPaginacion( data ) {
		state.page = data.page;
		state.totalPages = data.total_pages;

		$( '#au-wms-externos-total' ).text( data.total );
		$( '#au-wms-externos-current-page' ).text( data.page );
		$( '#au-wms-externos-total-pages' ).text( data.total_pages );

		$( '#au-wms-externos-pagination .au-wms-page-btn[data-page="first"]' ).prop( 'disabled', data.page <= 1 );
		$( '#au-wms-externos-pagination .au-wms-page-btn[data-page="prev"]' ).prop( 'disabled', data.page <= 1 );
		$( '#au-wms-externos-pagination .au-wms-page-btn[data-page="next"]' ).prop( 'disabled', data.page >= data.total_pages );
		$( '#au-wms-externos-pagination .au-wms-page-btn[data-page="last"]' ).prop( 'disabled', data.page >= data.total_pages );
	}

	function mostrarError( mensaje ) {
		Swal.fire( {
			icon: 'error',
			title: mensaje || AU_WMS.i18n.genericError,
		} );
	}
} )( jQuery );
