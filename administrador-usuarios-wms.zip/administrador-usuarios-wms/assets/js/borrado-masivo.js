/**
 * Administrador de Usuarios (WMS Latam) — Selección múltiple y borrado masivo.
 *
 * Casillas de la tabla de Integrantes, botón "Borrar seleccionados"
 * y el asistente de borrado masivo (previsualización, ejecución y
 * resumen). Es el único dueño del conjunto de usuarios seleccionados.
 *
 * Módulos (en orden de carga): admin-core.js → acciones-usuario.js →
 * borrado-masivo.js → admin.js (Integrantes). Cada módulo publica sus
 * funciones en `window.AU_WMS_APP` y llama a las de los demás a través
 * de pequeños delegados, resueltos en el momento de la llamada (no al
 * cargar), así que el orden solo importa para los `$( document ).ready`.
 *
 * Depende de jQuery y SweetAlert2. Usa el objeto global `AU_WMS`
 * (ajaxUrl, nonce, i18n) localizado desde PHP.
 */
( function ( $ ) {
	'use strict';

	var App = window.AU_WMS_APP = window.AU_WMS_APP || {};

	// Funciones de otros módulos (delegados resueltos al llamarse).
	function badgePrograma() {
		return App.badgePrograma.apply( null, arguments );
	}
	function escapeHtml() {
		return App.escapeHtml.apply( null, arguments );
	}
	function mostrarProgresoGenerico() {
		return App.mostrarProgresoGenerico.apply( null, arguments );
	}
	function obtenerEscenarioYMostrarModal() {
		return App.obtenerEscenarioYMostrarModal.apply( null, arguments );
	}
	function refrescarListaTrasAccion() {
		return App.refrescarListaTrasAccion.apply( null, arguments );
	}
	function refrescarProgramasSilencioso() {
		return App.refrescarProgramasSilencioso.apply( null, arguments );
	}

	$( document ).ready( function () {
		initSeleccion();
		initModalBorradoMasivo();
	} );

	// Selección de usuarios para "Borrar seleccionados" (se reinicia en
	// cada carga de la tabla, para no arrastrar selección de filas que
	// ya no están visibles tras cambiar de página/filtro).
	var seleccionados = {};

	// Usuarios (con su escenario ya resuelto) que se muestran en el
	// modal de previsualización del borrado masivo, y que se procesan
	// al presionar "Continuar" en ese modal.
	var usuariosParaBorradoMasivo = [];

	/**
	 * Casillas de selección de la tabla de Integrantes ("Seleccionar
	 * todos" y una por fila) y el botón "Borrar seleccionados".
	 */
	function initSeleccion() {
		var $tbody = $( '#au-wms-tabla-body' );

		// Selección de filas para "Borrar seleccionados".
		$tbody.on( 'change', '.au-wms-row-checkbox', function () {
			var userId = $( this ).closest( 'tr' ).data( 'user-id' );

			if ( this.checked ) {
				seleccionados[ userId ] = true;
			} else {
				delete seleccionados[ userId ];
			}

			actualizarBotonBorrarSeleccionados();
			actualizarCheckboxSeleccionarTodos();
		} );

		$( '#au-wms-select-all' ).on( 'change', function () {
			var marcar = this.checked;

			$( '.au-wms-row-checkbox' ).each( function () {
				$( this ).prop( 'checked', marcar );

				var userId = $( this ).closest( 'tr' ).data( 'user-id' );
				if ( marcar ) {
					seleccionados[ userId ] = true;
				} else {
					delete seleccionados[ userId ];
				}
			} );

			actualizarBotonBorrarSeleccionados();
		} );

		$( '#au-wms-btn-borrar-seleccionados' ).on( 'click', function () {
			var ids = Object.keys( seleccionados );

			if ( ! ids.length ) {
				return;
			}

			iniciarBorradoMasivo( ids );
		} );
	}

	/**
	 * Vacía la selección (se llama en cada recarga de la tabla, para no
	 * arrastrar filas que ya no están visibles).
	 */
	function limpiarSeleccion() {
		seleccionados = {};
	}

	/**
	 * Muestra/oculta el botón "Borrar seleccionados" según haya o no
	 * usuarios marcados, actualizando el contador.
	 */
	function actualizarBotonBorrarSeleccionados() {
		var total = Object.keys( seleccionados ).length;
		var $btn = $( '#au-wms-btn-borrar-seleccionados' );

		if ( total > 0 ) {
			$( '#au-wms-seleccionados-count' ).text( total );
			$btn.show();
		} else {
			$btn.hide();
		}
	}

	/**
	 * Refleja en el checkbox "seleccionar todos" si están todas, ninguna
	 * o solo algunas de las filas visibles marcadas (estado indeterminado).
	 */
	function actualizarCheckboxSeleccionarTodos() {
		var $checkboxes = $( '.au-wms-row-checkbox' );
		var total = $checkboxes.length;
		var marcados = $checkboxes.filter( ':checked' ).length;
		var $selectAll = $( '#au-wms-select-all' );

		$selectAll.prop( 'checked', total > 0 && marcados === total );

		if ( $selectAll.length ) {
			$selectAll[ 0 ].indeterminate = marcados > 0 && marcados < total;
		}
	}

	/**
	 * Cablea el modal de previsualización del borrado masivo (cerrar,
	 * cancelar, continuar). Se llama una sola vez al iniciar el Tab
	 * Integrantes.
	 */
	function initModalBorradoMasivo() {
		$( '#au-wms-borrado-masivo-close, #au-wms-borrado-masivo-cancelar' ).on( 'click', function () {
			$( '#au-wms-borrado-masivo-overlay' ).removeClass( 'is-open' );
		} );

		$( '#au-wms-borrado-masivo-overlay' ).on( 'click', function ( event ) {
			if ( event.target === this ) {
				$( this ).removeClass( 'is-open' );
			}
		} );

		$( '#au-wms-borrado-masivo-continuar' ).on( 'click', function () {
			$( '#au-wms-borrado-masivo-overlay' ).removeClass( 'is-open' );
			ejecutarAccionesBorradoMasivo( usuariosParaBorradoMasivo, 0, { desvinculados: 0, eliminados: 0, errores: [] } );
		} );
	}

	/**
	 * Inicia el borrado masivo: primero refresca los programas de todos
	 * los usuarios seleccionados (en silencio, uno por uno), y al
	 * terminar muestra la tabla de previsualización con la acción que
	 * se aplicará a cada uno.
	 *
	 * @param {Array} ids IDs de usuario seleccionados.
	 */
	function iniciarBorradoMasivo( ids ) {
		// Se captura la info visible de cada fila (nombre/correo) ANTES
		// de tocar nada, para poder mostrarla en la previsualización
		// incluso si la fila cambia o desaparece más adelante.
		var usuarios = ids.map( function ( id ) {
			var $tr = $( '#au-wms-tabla-body tr[data-user-id="' + id + '"]' );
			return {
				id: id,
				nombre: $tr.find( '.au-wms-user-name' ).text(),
				email: $tr.find( '.au-wms-user-email' ).text(),
			};
		} );

		mostrarProgresoGenerico( AU_WMS.i18n.borradoMasivoRefrescando, 0, usuarios.length );

		refrescarYObtenerEscenariosMasivo( usuarios, 0, function ( usuariosConEscenario ) {
			mostrarPrevisualizacionBorradoMasivo( usuariosConEscenario );
		} );
	}

	/**
	 * Refresca en silencio los programas de cada usuario, uno por uno,
	 * y recopila su escenario (Inspira/Octágono) antes de mostrar la
	 * previsualización.
	 *
	 * @param {Array}    usuarios   Lista {id, nombre, email} (se le agrega tiene_inspira/tiene_octagono/inspira_valor/octagono_valor).
	 * @param {number}   indice     Posición actual dentro de `usuarios`.
	 * @param {Function} onComplete Callback( usuariosConEscenario ).
	 */
	function refrescarYObtenerEscenariosMasivo( usuarios, indice, onComplete ) {
		if ( indice >= usuarios.length ) {
			onComplete( usuarios );
			return;
		}

		mostrarProgresoGenerico( AU_WMS.i18n.borradoMasivoRefrescando, indice, usuarios.length );

		var actual = usuarios[ indice ];

		refrescarProgramasSilencioso( actual.id, function () {
			obtenerEscenarioYMostrarModal( actual.id, function ( uid, escenario ) {
				actual.tiene_inspira = !! escenario.tiene_inspira;
				actual.tiene_octagono = !! escenario.tiene_octagono;
				actual.inspira_valor = escenario.inspira_valor || '';
				actual.octagono_valor = escenario.octagono_valor || '';

				refrescarYObtenerEscenariosMasivo( usuarios, indice + 1, onComplete );
			} );
		} );
	}

	/**
	 * Muestra la tabla de previsualización del borrado masivo: usuario,
	 * programas actuales y la acción que se le va a aplicar.
	 *
	 * @param {Array} usuarios Lista con escenario ya resuelto.
	 */
	function mostrarPrevisualizacionBorradoMasivo( usuarios ) {
		Swal.close();

		usuariosParaBorradoMasivo = usuarios;

		var $tbody = $( '#au-wms-borrado-masivo-body' );
		$tbody.empty();

		var template = document.getElementById( 'au-wms-borrado-masivo-row-template' );

		usuarios.forEach( function ( usuario ) {
			var $row = $( document.importNode( template.content, true ) );
			var $tr = $row.filter( 'tr' ).length ? $row.filter( 'tr' ) : $row.find( 'tr' );

			$tr.find( '.au-wms-user-id' ).text( '#' + usuario.id );
			$tr.find( '.au-wms-user-name' ).text( usuario.nombre );
			$tr.find( '.au-wms-user-email' ).text( usuario.email );

			var $badges = $tr.find( '.au-wms-programas-badges' );

			if ( usuario.inspira_valor ) {
				$badges.append(
					badgePrograma( 'inspira', usuario.inspira_valor )
				);
			}
			if ( usuario.octagono_valor ) {
				$badges.append(
					badgePrograma( 'octagono', usuario.octagono_valor )
				);
			}
			if ( ! usuario.inspira_valor && ! usuario.octagono_valor ) {
				$badges.text( '—' );
			}

			var $accion = $tr.find( '.au-wms-borrado-masivo-accion' );
			if ( usuario.tiene_inspira || usuario.tiene_octagono ) {
				$accion.addClass( 'au-wms-badge au-wms-badge--role-default' ).text( AU_WMS.i18n.btnDejarWms );
			} else {
				$accion.addClass( 'au-wms-badge au-wms-badge--danger-outline' ).text( AU_WMS.i18n.btnBorrarDefinitivo );
			}

			$tbody.append( $tr );
		} );

		$( '#au-wms-borrado-masivo-overlay' ).addClass( 'is-open' );
	}

	/**
	 * Ejecuta la acción correspondiente (Dejar de ser usuario WMS o
	 * Borrar definitivamente) para cada usuario ya evaluado, uno por
	 * uno. Un error en uno no detiene el proceso de los demás.
	 *
	 * @param {Array}  usuarios   Lista con escenario ya resuelto.
	 * @param {number} indice     Posición actual dentro de `usuarios`.
	 * @param {Object} resultados Acumulador {desvinculados, eliminados, errores}.
	 */
	function ejecutarAccionesBorradoMasivo( usuarios, indice, resultados ) {
		if ( indice >= usuarios.length ) {
			mostrarResumenBorradoMasivo( resultados );
			return;
		}

		mostrarProgresoGenerico( AU_WMS.i18n.borradoMasivoProcesando, indice, usuarios.length );

		var actual = usuarios[ indice ];
		var accion = ( actual.tiene_inspira || actual.tiene_octagono ) ? 'au_wms_usuario_dejar_wms' : 'au_wms_eliminar_usuario';

		$.post( AU_WMS.ajaxUrl, {
			action: accion,
			nonce: AU_WMS.nonce,
			user_id: actual.id,
		} )
			.done( function ( response ) {
				if ( response && response.success ) {
					if ( 'au_wms_usuario_dejar_wms' === accion ) {
						resultados.desvinculados++;
					} else {
						resultados.eliminados++;
					}
				} else {
					resultados.errores.push( {
						userId: actual.id,
						mensaje: response && response.data ? response.data.message : AU_WMS.i18n.genericError,
					} );
				}
				ejecutarAccionesBorradoMasivo( usuarios, indice + 1, resultados );
			} )
			.fail( function () {
				resultados.errores.push( { userId: actual.id, mensaje: AU_WMS.i18n.genericError } );
				ejecutarAccionesBorradoMasivo( usuarios, indice + 1, resultados );
			} );
	}

	/**
	 * Muestra el resumen final del borrado masivo y refresca la tabla.
	 *
	 * @param {Object} resultados {desvinculados, eliminados, errores}.
	 */
	function mostrarResumenBorradoMasivo( resultados ) {
		var html = '<div class="au-wms-refrescar-resumen">';
		html += '<p class="au-wms-import-final-ok">' + resultados.desvinculados + ' ' + AU_WMS.i18n.borradoMasivoDesvinculados + '</p>';
		html += '<p class="au-wms-import-final-ok">' + resultados.eliminados + ' ' + AU_WMS.i18n.borradoMasivoEliminados + '</p>';

		if ( resultados.errores.length ) {
			html += '<p class="au-wms-import-final-error">' + resultados.errores.length + ' ' + AU_WMS.i18n.borradoMasivoErrores + '</p>';
			html += '<ul class="au-wms-refrescar-lista au-wms-refrescar-errores">';
			resultados.errores.forEach( function ( error ) {
				html += '<li>#' + error.userId + ' — ' + escapeHtml( error.mensaje ) + '</li>';
			} );
			html += '</ul>';
		}

		html += '</div>';

		Swal.fire( {
			icon: resultados.errores.length ? 'warning' : 'success',
			title: AU_WMS.i18n.borradoMasivoFinalizado,
			html: html,
			width: 520,
		} );

		seleccionados = {};
		refrescarListaTrasAccion();
	}

	// Publicación en el espacio de nombres compartido.
	App.initSeleccion = initSeleccion;
	App.limpiarSeleccion = limpiarSeleccion;
	App.actualizarBotonBorrarSeleccionados = actualizarBotonBorrarSeleccionados;
	App.actualizarCheckboxSeleccionarTodos = actualizarCheckboxSeleccionarTodos;
	App.initModalBorradoMasivo = initModalBorradoMasivo;
	App.iniciarBorradoMasivo = iniciarBorradoMasivo;
	App.refrescarYObtenerEscenariosMasivo = refrescarYObtenerEscenariosMasivo;
	App.mostrarPrevisualizacionBorradoMasivo = mostrarPrevisualizacionBorradoMasivo;
	App.ejecutarAccionesBorradoMasivo = ejecutarAccionesBorradoMasivo;
	App.mostrarResumenBorradoMasivo = mostrarResumenBorradoMasivo;
} )( jQuery );
