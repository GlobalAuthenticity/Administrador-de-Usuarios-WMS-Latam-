/**
 * Administrador de Usuarios (WMS Latam) — Pestaña "Integrantes".
 *
 * Filtros (Empresa / Área con Tom Select, Test, Programa, búsqueda),
 * menú "Opciones", listado, paginación y eventos de la tabla.
 * Conserva el handle `au-wms-admin`, del que dependen los demás
 * scripts, y declara como dependencias los tres módulos anteriores.
 *
 * Módulos (en orden de carga): admin-core.js → acciones-usuario.js →
 * borrado-masivo.js → admin.js (Integrantes). Cada módulo publica sus
 * funciones en `window.AU_WMS_APP` y llama a las de los demás a través
 * de pequeños delegados, resueltos en el momento de la llamada (no al
 * cargar), así que el orden solo importa para los `$( document ).ready`.
 *
 * Depende de jQuery y SweetAlert2. Usa el objeto global `AU_WMS`
 * (ajaxUrl, nonce, i18n) localizado desde PHP.
 */
( function ( $ ) {
	'use strict';

	var App = window.AU_WMS_APP = window.AU_WMS_APP || {};

	// Funciones de otros módulos (delegados resueltos al llamarse).
	function abrirModalCambiarPassword() {
		return App.abrirModalCambiarPassword.apply( null, arguments );
	}
	function actualizarBotonBorrarSeleccionados() {
		return App.actualizarBotonBorrarSeleccionados.apply( null, arguments );
	}
	function actualizarContadorTab() {
		return App.actualizarContadorTab.apply( null, arguments );
	}
	function badgePrograma() {
		return App.badgePrograma.apply( null, arguments );
	}
	function confirmarCambiarCorreo() {
		return App.confirmarCambiarCorreo.apply( null, arguments );
	}
	function confirmarLoginComoUsuario() {
		return App.confirmarLoginComoUsuario.apply( null, arguments );
	}
	function confirmarToggleAccesoLogin() {
		return App.confirmarToggleAccesoLogin.apply( null, arguments );
	}
	function descargarResultadoTest() {
		return App.descargarResultadoTest.apply( null, arguments );
	}
	function etiquetaRol() {
		return App.etiquetaRol.apply( null, arguments );
	}
	function formatearFecha() {
		return App.formatearFecha.apply( null, arguments );
	}
	function formatearFechaCorta() {
		return App.formatearFechaCorta.apply( null, arguments );
	}
	function iniciarFlujoBorrarUsuario() {
		return App.iniciarFlujoBorrarUsuario.apply( null, arguments );
	}
	function limpiarSeleccion() {
		return App.limpiarSeleccion.apply( null, arguments );
	}
	function mostrarError() {
		return App.mostrarError.apply( null, arguments );
	}

	$( document ).ready( function () {
		initBuscadoresSelect();
		initFilters();
		initPaginationControls();
		initTableDelegatedEvents();
		initToolbarOpcionesDropdown();
		cargarUsuarios();
	} );

	var state = {
		search: '',
		empresaId: '',
		paqueteId: '',
		testFiltro: '',
		programaFiltro: '',
		page: 1,
		perPage: 10,
		totalPages: 1,
	};

	var empresaTS = null;

	var areaTS = null;

	var searchDebounceTimer = null;

	/**
	 * Abre/cierra el dropdown "Opciones" de la toolbar de Integrantes
	 * (agrupa "Importar usuarios" y "Actualizar correos"). Los botones
	 * internos conservan sus IDs originales, así que import.js y
	 * actualizar-correos.js siguen enganchándose a ellos sin cambios.
	 */
	function initToolbarOpcionesDropdown() {
		var $dropdown = $( '#au-wms-opciones-dropdown' );

		if ( ! $dropdown.length ) {
			return;
		}

		$( '#au-wms-btn-opciones' ).on( 'click', function ( event ) {
			event.stopPropagation();
			$dropdown.toggleClass( 'is-open' );
		} );

		// Cerrar al hacer click fuera o al elegir una opción.
		$( document ).on( 'click', function () {
			$dropdown.removeClass( 'is-open' );
		} );
	}

	/**
	 * Inicializa Tom Select en los filtros de Empresa y Área/Paquete para
	 * que ambos tengan buscador (misma librería usada en Administrador
	 * de Cupones y WMS Product Webhooks).
	 */
	function initBuscadoresSelect() {
		empresaTS = new TomSelect( '#au-wms-filter-empresa', {
			maxOptions: null,
			placeholder: AU_WMS.i18n.allCompanies,
			allowEmptyOption: true,
			sortField: {
				field: '$order',
				direction: 'asc',
			},
		} );

		areaTS = new TomSelect( '#au-wms-filter-area', {
			maxOptions: null,
			placeholder: AU_WMS.i18n.selectCompanyFirst,
			allowEmptyOption: true,
		} );

		// El select original ya parte "disabled"; Tom Select respeta ese
		// estado al inicializar, así que no requiere llamada extra.
	}

	/**
	 * Reemplaza las opciones del buscador de Área/Paquete a partir de la
	 * respuesta AJAX, usando la API de Tom Select (no innerHTML, ya que
	 * Tom Select mantiene su propio índice de opciones).
	 *
	 * @param {Array} paquetes Lista de paquetes devueltos por el backend.
	 */
	function poblarAreaTS( paquetes ) {
		areaTS.clear( true );
		areaTS.clearOptions();
		areaTS.addOption( { value: '', text: AU_WMS.i18n.allAreas } );

		paquetes.forEach( function ( paquete ) {
			areaTS.addOption( { value: String( paquete.id ), text: paquete.nombre } );
		} );

		areaTS.refreshOptions( false );
		areaTS.setValue( '', true );
		areaTS.enable();
	}

	/**
	 * Deja el buscador de Área/Paquete vacío y deshabilitado (cuando no
	 * hay empresa seleccionada).
	 */
	function limpiarAreaTS() {
		areaTS.clear( true );
		areaTS.clearOptions();
		areaTS.addOption( { value: '', text: AU_WMS.i18n.allAreas } );
		areaTS.refreshOptions( false );
		areaTS.disable();
	}

	function initFilters() {
		$( '#au-wms-search' ).on( 'input', function () {
			var value = $( this ).val();

			clearTimeout( searchDebounceTimer );
			searchDebounceTimer = setTimeout( function () {
				state.search = value;
				state.page = 1;
				cargarUsuarios();
			}, 400 );
		} );

		$( '#au-wms-btn-refresh-integrantes' ).on( 'click', function () {
			cargarUsuarios();
		} );

		empresaTS.on( 'change', function ( empresaId ) {
			state.empresaId = empresaId;
			state.paqueteId = '';
			state.page = 1;

			if ( ! empresaId ) {
				limpiarAreaTS();
				cargarUsuarios();
				return;
			}

			areaTS.disable();
			areaTS.clear( true );
			areaTS.clearOptions();
			areaTS.addOption( { value: '', text: AU_WMS.i18n.loading } );
			areaTS.refreshOptions( false );

			$.post( AU_WMS.ajaxUrl, {
				action: 'au_wms_get_paquetes',
				nonce: AU_WMS.nonce,
				empresa_id: empresaId,
			} )
				.done( function ( response ) {
					if ( ! response || ! response.success ) {
						mostrarError( response && response.data ? response.data.message : AU_WMS.i18n.genericError );
						limpiarAreaTS();
						return;
					}

					poblarAreaTS( response.data.paquetes );
				} )
				.fail( function () {
					mostrarError( AU_WMS.i18n.genericError );
					limpiarAreaTS();
				} )
				.always( function () {
					cargarUsuarios();
				} );
		} );

		areaTS.on( 'change', function ( paqueteId ) {
			state.paqueteId = paqueteId;
			state.page = 1;
			cargarUsuarios();
		} );

		$( '#au-wms-filter-test' ).on( 'change', function () {
			state.testFiltro = $( this ).val();
			state.page = 1;
			cargarUsuarios();
		} );

		$( '#au-wms-filter-programa' ).on( 'change', function () {
			state.programaFiltro = $( this ).val();
			state.page = 1;
			cargarUsuarios();
		} );

		$( '#au-wms-per-page' ).on( 'change', function () {
			state.perPage = parseInt( $( this ).val(), 10 ) || 10;
			state.page = 1;
			cargarUsuarios();
		} );
	}

	/**
	 * Inicializa los botones de paginación (primera, anterior, siguiente, última).
	 */
	function initPaginationControls() {
		$( '#au-wms-pagination' ).on( 'click', '.au-wms-page-btn', function () {
			var target = $( this ).data( 'page' );

			if ( 'first' === target ) {
				state.page = 1;
			} else if ( 'prev' === target ) {
				state.page = Math.max( 1, state.page - 1 );
			} else if ( 'next' === target ) {
				state.page = Math.min( state.totalPages, state.page + 1 );
			} else if ( 'last' === target ) {
				state.page = state.totalPages;
			}

			cargarUsuarios();
		} );
	}

	/**
	 * Delegación de eventos sobre la tabla: dropdown de acciones,
	 * eliminar usuario e iniciar sesión como usuario.
	 */
	function initTableDelegatedEvents() {
		var $tbody = $( '#au-wms-tabla-body' );

		// Abrir/cerrar el dropdown de acciones.
		$tbody.on( 'click', '.au-wms-actions-btn', function ( event ) {
			event.stopPropagation();

			var $dropdown = $( this ).closest( '.au-wms-actions-dropdown' );
			var wasOpen = $dropdown.hasClass( 'is-open' );

			$( '.au-wms-actions-dropdown' ).removeClass( 'is-open' );
			$( '.au-wms-actions-submenu' ).removeClass( 'is-open au-wms-actions-submenu--flip' );

			if ( ! wasOpen ) {
				$dropdown.addClass( 'is-open' );
			}
		} );

		// Submenús: clic para abrir/cerrar; se voltean a la izquierda si
		// el flyout no cabe a la derecha del viewport.
		$tbody.on( 'click', '.au-wms-actions-submenu-trigger', function ( event ) {
			event.stopPropagation();

			var $submenu = $( this ).closest( '.au-wms-actions-submenu' );
			var wasOpen = $submenu.hasClass( 'is-open' );

			$submenu.siblings( '.au-wms-actions-submenu' ).removeClass( 'is-open au-wms-actions-submenu--flip' );

			if ( wasOpen ) {
				$submenu.removeClass( 'is-open au-wms-actions-submenu--flip' );
				return;
			}

			$submenu.addClass( 'is-open' );

			var $panel = $submenu.find( '.au-wms-actions-submenu-panel' ).first();
			if ( $panel.length && $panel[ 0 ].getBoundingClientRect().right > window.innerWidth ) {
				$submenu.addClass( 'au-wms-actions-submenu--flip' );
			}
		} );

		// Cerrar cualquier dropdown abierto al hacer click fuera.
		$( document ).on( 'click', function () {
			$( '.au-wms-actions-dropdown' ).removeClass( 'is-open' );
			$( '.au-wms-actions-submenu' ).removeClass( 'is-open au-wms-actions-submenu--flip' );
		} );

		// Borrar usuario (nuevo flujo: refresca programas, determina
		// escenario y ofrece "Dejar de ser usuario WMS" / "Borrar definitivamente").
		$tbody.on( 'click', '.au-wms-action-delete', function () {
			var $row = $( this ).closest( 'tr' );
			var userId = $row.data( 'user-id' );

			iniciarFlujoBorrarUsuario( userId );
		} );

		// Iniciar sesión como usuario.
		$tbody.on( 'click', '.au-wms-action-login', function () {
			var $row = $( this ).closest( 'tr' );
			var userId = $row.data( 'user-id' );

			confirmarLoginComoUsuario( userId );
		} );

		// Ver WP_USERMETA.
		$tbody.on( 'click', '.au-wms-action-usermeta', function () {
			var $row = $( this ).closest( 'tr' );
			var userId = $row.data( 'user-id' );
			var nombre = $row.find( '.au-wms-user-name' ).text();

			if ( 'function' === typeof window.AU_WMS_abrirUsermeta ) {
				window.AU_WMS_abrirUsermeta( userId, nombre );
			}
		} );

		// Áreas del usuario.
		$tbody.on( 'click', '.au-wms-action-areas-usuario', function () {
			var $row = $( this ).closest( 'tr' );
			var userId = $row.data( 'user-id' );
			var nombre = $row.find( '.au-wms-user-name' ).text();

			if ( 'function' === typeof window.AU_WMS_abrirAreasUsuario ) {
				window.AU_WMS_abrirAreasUsuario( userId, nombre );
			}
		} );

		// Cambiar correo.
		$tbody.on( 'click', '.au-wms-action-cambiar-correo', function () {
			var $row = $( this ).closest( 'tr' );
			var userId = $row.data( 'user-id' );
			var correoActual = $row.find( '.au-wms-user-email' ).text();

			confirmarCambiarCorreo( userId, correoActual );
		} );

		// Cambiar contraseña.
		$tbody.on( 'click', '.au-wms-action-cambiar-password', function () {
			var $row = $( this ).closest( 'tr' );
			var userId = $row.data( 'user-id' );
			var correoActual = $row.find( '.au-wms-user-email' ).text();

			abrirModalCambiarPassword( userId, correoActual );
		} );

		// Habilitar/Deshabilitar acceso de inicio de sesión.
		$tbody.on( 'click', '.au-wms-action-toggle-acceso', function () {
			var $row = $( this ).closest( 'tr' );
			var userId = $row.data( 'user-id' );
			var deshabilitadoActualmente = '1' === $( this ).attr( 'data-deshabilitado' );

			confirmarToggleAccesoLogin( userId, deshabilitadoActualmente );
		} );

		// Refrescar programas (solo este usuario).
		$tbody.on( 'click', '.au-wms-action-refrescar-programas', function () {
			var $row = $( this ).closest( 'tr' );
			var userId = $row.data( 'user-id' );
			var nombre = $row.find( '.au-wms-user-name' ).text();

			if ( 'function' === typeof window.AU_WMS_confirmarRefrescarProgramasUsuario ) {
				window.AU_WMS_confirmarRefrescarProgramasUsuario( userId, nombre );
			}
		} );

		$tbody.on( 'click', '.au-wms-descargar-resultado', function () {
			descargarResultadoTest( $( this ) );
		} );
	}

	/**
	 * Refresca la tabla de Integrantes tras "Dejar de ser usuario WMS" o
	 * "Borrar definitivamente": mantiene búsqueda, filtros y registros
	 * por página (el `state` del módulo ya los conserva), y si la
	 * página actual queda vacía, retrocede automáticamente a la
	 * anterior disponible.
	 */
	function refrescarListaTrasAccion() {
		cargarUsuarios( {
			mensajeCarga: AU_WMS.i18n.actualizandoListaIntegrantes,
			ajustarPaginaSiVacio: true,
			onError: function () {
				Swal.fire( {
					icon: 'warning',
					title: AU_WMS.i18n.errorActualizarLista,
				} );
			},
		} );
	}

	/**
	 * Carga (o recarga) la tabla de usuarios vía AJAX según el estado
	 * actual de filtros y paginación.
	 *
	 * @param {Object} [opts] Opciones adicionales:
	 *   - mensajeCarga {string} Texto a mostrar en el indicador de carga.
	 *   - ajustarPaginaSiVacio {bool} Si la página actual queda vacía,
	 *     retrocede automáticamente a la anterior disponible.
	 *   - onError {Function} Callback si la petición falla (en vez del
	 *     error genérico por defecto).
	 */
	// Hook global: el modal "Editar perfil de usuario" (editar-perfil.js)
	// refresca el listado al guardar, para que la fila muestre el nombre
	// nuevo sin recargar la página.
	window.AU_WMS_recargarUsuarios = function () {
		cargarUsuarios();
	};

	function cargarUsuarios( opts ) {
		opts = opts || {};

		limpiarSeleccion();
		actualizarBotonBorrarSeleccionados();
		$( '#au-wms-select-all' ).prop( 'checked', false ).prop( 'indeterminate', false );

		mostrarCargando( opts.mensajeCarga );

		$.post( AU_WMS.ajaxUrl, {
			action: 'au_wms_buscar_usuarios',
			nonce: AU_WMS.nonce,
			search: state.search,
			empresa_id: state.empresaId,
			paquete_id: state.paqueteId,
			test_filtro: state.testFiltro,
			programa_filtro: state.programaFiltro,
			page: state.page,
			per_page: state.perPage,
		} )
			.done( function ( response ) {
				if ( ! response || ! response.success ) {
					if ( opts.onError ) {
						opts.onError();
					} else {
						mostrarError( response && response.data ? response.data.message : AU_WMS.i18n.genericError );
					}
					return;
				}

				var sinResultados = ! response.data.items || ! response.data.items.length;

				if ( opts.ajustarPaginaSiVacio && sinResultados && state.page > 1 ) {
					state.page--;
					cargarUsuarios( opts );
					return;
				}

				renderTabla( response.data.items );
				renderPaginacion( response.data );
				actualizarContadorTab(
					'integrantes',
					response.data.total,
					! state.search && ! state.empresaId && ! state.paqueteId && ! state.testFiltro && ! state.programaFiltro
				);
			} )
			.fail( function () {
				if ( opts.onError ) {
					opts.onError();
				} else {
					mostrarError( AU_WMS.i18n.genericError );
				}
			} );
	}

	// Punto de integración con import.js: permite refrescar la tabla
	// principal al terminar una importación masiva, sin exponer el
	// resto del estado interno de este módulo.
	window.AU_WMS_refrescarTabla = cargarUsuarios;

	/**
	 * Muestra el indicador de carga dentro de la tabla.
	 *
	 * @param {string} [mensaje] Texto a mostrar (por defecto, "Cargando...").
	 */
	function mostrarCargando( mensaje ) {
		var $tbody = $( '#au-wms-tabla-body' );
		$tbody.html(
			'<tr class="au-wms-row-loading"><td colspan="6"><div class="au-wms-spinner"></div>' +
			( mensaje || AU_WMS.i18n.loading ) +
			'</td></tr>'
		);
	}

	/**
	 * Renderiza las filas de la tabla a partir de los datos devueltos
	 * por el backend, usando el <template> definido en la vista.
	 *
	 * @param {Array} items Lista de usuarios.
	 */
	function renderTabla( items ) {
		var $tbody = $( '#au-wms-tabla-body' );
		$tbody.empty();

		if ( ! items || ! items.length ) {
			var emptyTemplate = document.getElementById( 'au-wms-empty-template' );
			$tbody.append( document.importNode( emptyTemplate.content, true ) );
			return;
		}

		var template = document.getElementById( 'au-wms-row-template' );

		items.forEach( function ( item ) {
			var $row = $( document.importNode( template.content, true ) );
			var $tr = $row.filter( 'tr' ).length ? $row.filter( 'tr' ) : $row.find( 'tr' );

			$tr.attr( 'data-user-id', item.id );
			$tr.find( '.au-wms-user-id' ).text( '#' + item.id );
			$tr.find( '.au-wms-user-name' ).text( item.nombre );
			$tr.find( '.au-wms-user-email' ).text( item.user_email );

			if ( item.empresa_nombre ) {
				$tr.find( '.au-wms-user-empresa-badge' ).addClass( 'au-wms-badge au-wms-badge--empresa' ).text( item.empresa_nombre );
			}

			if ( item.es_importado ) {
				$tr.find( '.au-wms-user-importado-badge' ).addClass( 'au-wms-badge au-wms-badge--importado' ).text( AU_WMS.i18n.importadoBadge || 'Importado' );
			}

			if ( item.acceso_deshabilitado ) {
				$tr.find( '.au-wms-user-acceso-badge' ).addClass( 'au-wms-badge au-wms-badge--danger-outline' ).text( AU_WMS.i18n.accesoDeshabilitadoBadge );
			}

			$tr.find( '.au-wms-action-toggle-acceso' ).attr( 'data-deshabilitado', item.acceso_deshabilitado ? '1' : '0' );
			$tr.find( '.au-wms-action-toggle-acceso-texto' ).text(
				item.acceso_deshabilitado ? AU_WMS.i18n.habilitarAcceso : AU_WMS.i18n.deshabilitarAcceso
			);

			if ( ! item.perfil_completo ) {
				$tr.find( '.au-wms-user-perfil-badge' ).addClass( 'au-wms-badge au-wms-badge--warning' ).text( AU_WMS.i18n.incompleteProfile );
			}

			$tr.find( '.au-wms-user-date' )
				.text( formatearFechaCorta( item.user_registered ) )
				.attr( 'title', formatearFecha( item.user_registered ) );

			// Un usuario puede pertenecer a varias áreas (varias filas
			// en wp_correos_configurados), así que se listan todas en
			// vez de mostrar solo una.
			var $areaLista = $tr.find( '.au-wms-area-lista' );
			$areaLista.empty();

			if ( item.areas && item.areas.length ) {
				item.areas.forEach( function ( areaNombre ) {
					$areaLista.append( $( '<div></div>' ).addClass( 'au-wms-area-item' ).text( areaNombre ) );
				} );
			}

			var roleClass = 'au-wms-badge--role-default';
			if ( item.rol && [ 'administrator', 'company', 'subscriber' ].indexOf( item.rol ) !== -1 ) {
				roleClass = 'au-wms-badge--role-' + item.rol;
			}

			$tr.find( '.au-wms-role-badge' )
				.addClass( roleClass )
				.addClass( 'au-wms-badge' )
				.attr( 'title', item.rol || '' )
				.text( etiquetaRol( item.rol ) );

			if ( item.tiene_test ) {
				// Con test, el botón de descarga ya indica el estado: no se
				// muestra el badge "Test OK" para mantener la celda limpia.
				$tr.find( '.au-wms-test-badge' ).hide();

				$tr.find( '.au-wms-descargar-resultado-texto' ).text( AU_WMS.i18n.descargarResultado );
				$tr.find( '.au-wms-descargar-resultado' ).css( 'display', '' );
			} else {
				$tr.find( '.au-wms-test-badge' )
					.addClass( 'au-wms-badge au-wms-badge--test-sin' )
					.text( AU_WMS.i18n.sinTest || 'Sin test' );

				$tr.find( '.au-wms-descargar-resultado' ).hide();
			}

			var $programasBadges = $tr.find( '.au-wms-programas-badges' );

			if ( item.inspira_valor ) {
				$programasBadges.append( badgePrograma( 'inspira', item.inspira_valor ) );
			}

			if ( item.octagono_valor ) {
				$programasBadges.append( badgePrograma( 'octagono', item.octagono_valor ) );
			}

			$tbody.append( $tr );
		} );
	}

	/**
	 * Actualiza los controles y textos de paginación.
	 *
	 * @param {Object} data Respuesta del backend (total, page, total_pages...).
	 */
	function renderPaginacion( data ) {
		state.page = data.page;
		state.totalPages = data.total_pages;

		$( '#au-wms-total-registros' ).text( data.total );
		$( '#au-wms-current-page' ).text( data.page );
		$( '#au-wms-total-pages' ).text( data.total_pages );

		$( '.au-wms-page-btn[data-page="first"]' ).prop( 'disabled', data.page <= 1 );
		$( '.au-wms-page-btn[data-page="prev"]' ).prop( 'disabled', data.page <= 1 );
		$( '.au-wms-page-btn[data-page="next"]' ).prop( 'disabled', data.page >= data.total_pages );
		$( '.au-wms-page-btn[data-page="last"]' ).prop( 'disabled', data.page >= data.total_pages );
	}

	// Publicación en el espacio de nombres compartido.
	App.initToolbarOpcionesDropdown = initToolbarOpcionesDropdown;
	App.initBuscadoresSelect = initBuscadoresSelect;
	App.poblarAreaTS = poblarAreaTS;
	App.limpiarAreaTS = limpiarAreaTS;
	App.initFilters = initFilters;
	App.initPaginationControls = initPaginationControls;
	App.initTableDelegatedEvents = initTableDelegatedEvents;
	App.refrescarListaTrasAccion = refrescarListaTrasAccion;
	App.cargarUsuarios = cargarUsuarios;
	App.mostrarCargando = mostrarCargando;
	App.renderTabla = renderTabla;
	App.renderPaginacion = renderPaginacion;
} )( jQuery );
