/**
 * Modal "Comparar usuarios" (Tab Empresas): wizard de 2 pasos —
 * 1) Pegar/escribir correos (se convierten en tags vía TomSelect)
 * 2) Resultado de la comparación contra `wp_correos_configurados` de
 * la empresa (verde = pertenece + área, rojo = no pertenece).
 *
 * @package Administrador_Usuarios_WMS
 */

( function ( $ ) {
	'use strict';

	var wizard = {
		empresaId: '',
		empresaNombre: '',
		step: 1,
		resultado: [],
	};

	var tagsTS = null;
	var REGEX_CORREO = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
	var REGEX_SEPARADORES = /[\s,;]+/;

	// Mismos colores por estado que se usan al pintar la tabla del
	// Paso 2 (ver renderResultados) — centralizados aquí para no
	// repetir los valores en la exportación a Excel.
	var COLORES_ESTADO = {
		no_existe: { bg: 'FEE2E2', color: 'DC2626' },
		otra_empresa: { bg: 'FDFBE0', color: 'B8860B' },
		esta_empresa: { bg: 'DCFCE7', color: '16A34A' },
	};

	$( document ).ready( function () {
		initTagsInput();
		initTriggers();
		initFooterNavigation();
		initExportDropdown();

		window.AU_WMS_abrirModalCompararUsuarios = abrirModal;
	} );

	/**
	 * Nombre traducido de un estado ('esta_empresa'|'otra_empresa'|'no_existe').
	 *
	 * @param {string} estado Estado a traducir.
	 * @return {string}
	 */
	function tituloDeEstado( estado ) {
		if ( 'no_existe' === estado ) {
			return AU_WMS.i18n.compareUsersNoExiste;
		}
		if ( 'otra_empresa' === estado ) {
			return AU_WMS.i18n.compareUsersOtraEmpresa;
		}
		return AU_WMS.i18n.compareUsersEstaEmpresa;
	}

	/**
	 * Inicializa el input de tags (TomSelect en modo "libre": sin
	 * opciones predefinidas, cualquier texto que el usuario escriba o
	 * pegue se convierte en una etiqueta).
	 */
	function initTagsInput() {
		tagsTS = new TomSelect( '#au-wms-compare-users-input', {
			plugins: [ 'remove_button' ],
			persist: false,
			create: true,
			createOnBlur: true,
			hideSelected: true,
			onItemAdd: function () {
				// Limpia el texto que quedó en el buscador tras
				// confirmar una etiqueta, para que no estorbe al
				// seguir pegando/escribiendo.
				this.setTextboxValue( '' );
			},
			onItemRemove: actualizarContadorYBoton,
		} );

		// TomSelect, por sí solo, trata un "paste" como texto normal
		// en el buscador. Si el texto pegado trae varios correos
		// separados por saltos de línea, comas, punto y coma o
		// espacios (el caso típico: copiar una columna de Excel o una
		// lista), se interceptan y se agregan como etiquetas
		// individuales.
		tagsTS.control_input.addEventListener( 'paste', function ( event ) {
			var portapapeles = event.clipboardData || window.clipboardData;

			if ( ! portapapeles ) {
				return;
			}

			var texto = portapapeles.getData( 'text' );

			if ( ! texto || ! REGEX_SEPARADORES.test( texto ) ) {
				// Un solo token sin separadores: se deja que
				// TomSelect lo maneje de forma normal (queda
				// editable hasta confirmar con Enter).
				return;
			}

			event.preventDefault();
			agregarCorreosDesdeTexto( texto );
		} );
	}

	/**
	 * Parte un bloque de texto pegado en correos individuales, valida
	 * cada uno con una expresión regular simple, descarta duplicados
	 * y los agrega como tags. Los que no parecen un correo se
	 * ignoran (se avisa cuántos, sin bloquear el resto).
	 *
	 * @param {string} texto Texto pegado desde el portapapeles.
	 */
	function agregarCorreosDesdeTexto( texto ) {
		var partes = texto.split( REGEX_SEPARADORES );
		var invalidos = 0;

		partes.forEach( function ( parte ) {
			var correo = parte.trim().toLowerCase();

			if ( ! correo ) {
				return;
			}

			if ( ! REGEX_CORREO.test( correo ) ) {
				invalidos++;
				return;
			}

			if ( ! tagsTS.options[ correo ] ) {
				tagsTS.addOption( { value: correo, text: correo } );
			}

			if ( -1 === tagsTS.items.indexOf( correo ) ) {
				tagsTS.addItem( correo, true );
			}
		} );

		tagsTS.refreshItems();
		actualizarContadorYBoton();

		if ( invalidos > 0 && window.Swal ) {
			Swal.fire( {
				icon: 'info',
				title: AU_WMS.i18n.compareUsersInvalido.replace( '{N}', invalidos ),
				timer: 3000,
				showConfirmButton: false,
			} );
		}
	}

	/**
	 * Cierre del modal (botón X, "Cancelar" y clic fuera del contenido).
	 */
	function initTriggers() {
		$( '#au-wms-compare-users-close, #au-wms-compare-users-btn-cancelar' ).on( 'click', function () {
			cerrarModal();
		} );

		$( '#au-wms-compare-users-overlay' ).on( 'click', function ( event ) {
			if ( event.target === this ) {
				cerrarModal();
			}
		} );
	}

	function cerrarModal() {
		$( '#au-wms-compare-users-overlay' ).removeClass( 'is-open' );
	}

	/**
	 * Abre el modal para una empresa concreta y deja el input de
	 * correos vacío y listo en el Paso 1.
	 *
	 * @param {number} empresaId     ID de la empresa (usuario `company`).
	 * @param {string} empresaNombre Nombre a mostrar en el encabezado.
	 */
	function abrirModal( empresaId, empresaNombre ) {
		wizard = {
			empresaId: empresaId,
			empresaNombre: empresaNombre || '',
			step: 1,
			resultado: [],
		};

		tagsTS.clear( true );
		tagsTS.clearOptions();

		$( '#au-wms-compare-users-empresa-nombre' ).text( wizard.empresaNombre );
		$( '#au-wms-compare-users-results-body' ).empty();
		$( '#au-wms-compare-users-resumen' ).empty();
		$( '#au-wms-compare-users-export-dropdown' ).removeClass( 'is-open' );

		irAPaso( 1 );
		actualizarContadorYBoton();

		$( '#au-wms-compare-users-overlay' ).addClass( 'is-open' );
		tagsTS.focus();
	}

	/**
	 * Cambia de panel visible dentro del modal y actualiza los puntos
	 * de progreso y los botones del footer.
	 *
	 * @param {number} paso Paso destino (1-2).
	 */
	function irAPaso( paso ) {
		wizard.step = paso;

		$( '#au-wms-compare-users-overlay .au-wms-import-panel' ).removeClass( 'is-active' );
		$( '#au-wms-compare-users-overlay .au-wms-import-panel[data-step-panel="' + paso + '"]' ).addClass( 'is-active' );

		$( '#au-wms-compare-users-overlay .au-wms-import-step-dot' ).each( function () {
			var dotStep = parseInt( $( this ).data( 'step' ), 10 );
			$( this ).toggleClass( 'is-active', dotStep === paso );
			$( this ).toggleClass( 'is-done', dotStep < paso );
		} );

		var $atras = $( '#au-wms-compare-users-btn-atras' );
		var $siguiente = $( '#au-wms-compare-users-btn-siguiente' );

		if ( 1 === paso ) {
			$atras.hide();
			$siguiente.show();
		} else if ( 2 === paso ) {
			$atras.show();
			$siguiente.hide();
		}
	}

	/**
	 * Actualiza el contador "N correos" y habilita/deshabilita
	 * "Siguiente" según si hay al menos una etiqueta cargada.
	 */
	function actualizarContadorYBoton() {
		var total = tagsTS ? tagsTS.items.length : 0;

		$( '#au-wms-compare-users-contador' ).text( total + ' ' + AU_WMS.i18n.compareUsersContador );
		$( '#au-wms-compare-users-btn-siguiente' ).prop( 'disabled', 0 === total );
	}

	/**
	 * Wiring de la navegación del footer (Siguiente / Atrás).
	 */
	function initFooterNavigation() {
		$( '#au-wms-compare-users-btn-siguiente' ).on( 'click', function () {
			var correos = tagsTS.items.slice();

			if ( ! correos.length ) {
				return;
			}

			verificarCorreos( correos );
		} );

		$( '#au-wms-compare-users-btn-atras' ).on( 'click', function () {
			irAPaso( 1 );
		} );
	}

	/**
	 * Envía los correos al backend para compararlos contra
	 * `wp_correos_configurados` de la empresa y arma el Paso 2 con el
	 * resultado.
	 *
	 * @param {Array<string>} correos Correos cargados en el Paso 1.
	 */
	function verificarCorreos( correos ) {
		var $siguiente = $( '#au-wms-compare-users-btn-siguiente' );
		var textoOriginal = $siguiente.data( 'texto-original' ) || $siguiente.text();
		$siguiente.data( 'texto-original', textoOriginal );
		$siguiente.prop( 'disabled', true ).text( AU_WMS.i18n.loading );

		$.post( AU_WMS.ajaxUrl, {
			action: 'au_wms_comparar_usuarios_verificar',
			nonce: AU_WMS.nonce,
			empresa_id: wizard.empresaId,
			correos: correos,
		} )
			.done( function ( response ) {
				if ( ! response || ! response.success ) {
					mostrarErrorSwal(
						( response && response.data && response.data.message ) || AU_WMS.i18n.genericError
					);
					return;
				}

				renderResultados( response.data.resultado || [] );
				irAPaso( 2 );
			} )
			.fail( function () {
				mostrarErrorSwal( AU_WMS.i18n.genericError );
			} )
			.always( function () {
				$siguiente.prop( 'disabled', false ).text( textoOriginal );
			} );
	}

	/**
	 * Renderiza la tabla de resultados del Paso 2: una fila por
	 * correo, con uno de tres estados según lo que devolvió el
	 * backend — verde si ya está en esta empresa (con sus áreas),
	 * ámbar si está registrado en otra empresa (con cuál y sus
	 * áreas), o rojo si no existe en absoluto.
	 *
	 * @param {Array} resultado Lista devuelta por el backend: {correo, estado, detalle}.
	 */
	/**
	 * Renderiza la tabla de resultados del Paso 2 agrupada en 3
	 * secciones, en este orden fijo: (1) no registrados, (2)
	 * registrados en otra empresa, (3) ya en esta empresa. Cada
	 * sección lleva una fila de encabezado con su color y el conteo,
	 * y se omite por completo si no tiene ningún correo.
	 *
	 * @param {Array} resultado Lista devuelta por el backend: {correo, estado, detalle}.
	 */
	/**
	 * Renderiza la tabla de resultados del Paso 2 agrupada en 3
	 * secciones, en este orden fijo: (1) no registrados, (2)
	 * registrados en otra empresa, (3) ya en esta empresa. Cada
	 * sección lleva una fila de encabezado con su color y el conteo,
	 * y se omite por completo si no tiene ningún correo.
	 *
	 * Dentro de la sección "ya está en esta empresa" además se ordena
	 * por estado del test: primero los que NO lo han hecho (para que
	 * salten a la vista primero), luego los que sí.
	 *
	 * @param {Array} resultado Lista devuelta por el backend: {correo, estado, detalle, tiene_test}.
	 */
	function renderResultados( resultado ) {
		wizard.resultado = resultado;

		var $body = $( '#au-wms-compare-users-results-body' );
		$body.empty();

		var grupos = { no_existe: [], otra_empresa: [], esta_empresa: [] };

		resultado.forEach( function ( item ) {
			( grupos[ item.estado ] || grupos.no_existe ).push( item );
		} );

		// Sin test primero, con test después. Array.prototype.sort es
		// estable en los navegadores modernos, así que dentro de cada
		// mitad se conserva el orden que ya traía (alfabético por
		// área, heredado del backend).
		grupos.esta_empresa.sort( function ( a, b ) {
			return ( a.tiene_test ? 1 : 0 ) - ( b.tiene_test ? 1 : 0 );
		} );

		// Orden fijo pedido: primero los que no existen, luego los de
		// otra empresa, y al final los que ya están en esta empresa.
		var SECCIONES = [
			{ estado: 'no_existe', titulo: tituloDeEstado( 'no_existe' ), bg: '#' + COLORES_ESTADO.no_existe.bg, color: '#' + COLORES_ESTADO.no_existe.color },
			{ estado: 'otra_empresa', titulo: tituloDeEstado( 'otra_empresa' ), bg: '#' + COLORES_ESTADO.otra_empresa.bg, color: '#' + COLORES_ESTADO.otra_empresa.color },
			{ estado: 'esta_empresa', titulo: tituloDeEstado( 'esta_empresa' ), bg: '#' + COLORES_ESTADO.esta_empresa.bg, color: '#' + COLORES_ESTADO.esta_empresa.color },
		];

		actualizarDropdownExportar( grupos );

		var template = document.getElementById( 'au-wms-compare-users-result-row-template' );

		SECCIONES.forEach( function ( seccion ) {
			var items = grupos[ seccion.estado ];

			if ( ! items.length ) {
				return;
			}

			var $header = $( '<tr class="au-wms-compare-users-group-header"></tr>' );
			$( '<td colspan="4"></td>' )
				.css( { background: seccion.bg, color: seccion.color, fontWeight: '700', padding: '8px 12px' } )
				.text( seccion.titulo + ' (' + items.length + ')' )
				.appendTo( $header );
			$body.append( $header );

			items.forEach( function ( item ) {
				var $row = $( document.importNode( template.content, true ) );
				var $tr = $row.filter( 'tr' ).length ? $row.filter( 'tr' ) : $row.find( 'tr' );

				$tr.find( '.au-wms-compare-users-result-correo' ).text( item.correo );

				$tr.find( '.au-wms-compare-users-result-badge' )
					.text( seccion.titulo )
					.css( { background: seccion.bg, color: seccion.color, padding: '3px 10px', borderRadius: '999px', fontWeight: '600', fontSize: '12px' } );

				$tr.find( '.au-wms-compare-users-result-detalle' ).text( item.detalle || '—' );

				var $test = $tr.find( '.au-wms-compare-users-result-test' );

				if ( 'esta_empresa' === item.estado ) {
					var tieneTest = !! item.tiene_test;
					var colorTest = tieneTest ? COLORES_ESTADO.esta_empresa : COLORES_ESTADO.no_existe;
					$test
						.text( tieneTest ? AU_WMS.i18n.testOk : AU_WMS.i18n.sinTest )
						.css( {
							background: '#' + colorTest.bg,
							color: '#' + colorTest.color,
							padding: '3px 10px',
							borderRadius: '999px',
							fontWeight: '600',
							fontSize: '12px',
						} );
				} else {
					$test.text( '—' );
				}

				$body.append( $tr );
			} );
		} );

		var resumen = AU_WMS.i18n.compareUsersResumen
			.replace( '{TOTAL}', resultado.length )
			.replace( '{ESTA}', grupos.esta_empresa.length )
			.replace( '{EMPRESA}', wizard.empresaNombre || '' )
			.replace( '{OTRA}', grupos.otra_empresa.length )
			.replace( '{NINGUNA}', grupos.no_existe.length );

		$( '#au-wms-compare-users-resumen' ).text( resumen );
	}

	/**
	 * Muestra u oculta cada opción del menú "Exportar Excel" según si
	 * su grupo tiene al menos un correo — pedido explícitamente: si no
	 * hay ningún correo "en otra empresa" (o "sin registrar", o "en
	 * esta empresa"), esa opción ni siquiera aparece en la lista. Si
	 * los tres grupos están vacíos, se oculta el botón completo.
	 *
	 * @param {Object} grupos {no_existe, otra_empresa, esta_empresa} → arrays.
	 */
	function actualizarDropdownExportar( grupos ) {
		var algunaVisible = false;

		$( '.au-wms-compare-users-export-option' ).each( function () {
			var estado = $( this ).data( 'estado' );
			var visible = !! ( grupos[ estado ] && grupos[ estado ].length );

			$( this ).toggle( visible );

			if ( visible ) {
				algunaVisible = true;
			}
		} );

		$( '#au-wms-compare-users-export-dropdown' ).toggle( algunaVisible );
	}

	/**
	 * Wiring del menú desplegable "Exportar Excel" del Paso 2: abrir/
	 * cerrar al hacer clic en el botón, cerrar al hacer clic fuera, y
	 * disparar la exportación al elegir una opción.
	 */
	function initExportDropdown() {
		$( '#au-wms-compare-users-export-btn' ).on( 'click', function ( event ) {
			event.stopPropagation();
			$( '#au-wms-compare-users-export-dropdown' ).toggleClass( 'is-open' );
		} );

		$( document ).on( 'click', function () {
			$( '#au-wms-compare-users-export-dropdown' ).removeClass( 'is-open' );
		} );

		$( '#au-wms-compare-users-export-dropdown' ).on( 'click', '.au-wms-compare-users-export-option', function ( event ) {
			event.stopPropagation();

			var estado = $( this ).data( 'estado' );

			exportarExcelPorEstado( estado );

			$( '#au-wms-compare-users-export-dropdown' ).removeClass( 'is-open' );
		} );
	}

	/**
	 * Genera y descarga el .xlsx (vía SheetJS + estilos) de un solo
	 * grupo de la comparación:
	 * - "esta_empresa": Correo, Estado, Detalle y Test — las mismas 4
	 *   columnas que se ven en la tabla del Paso 2.
	 * - "otra_empresa" / "no_existe": solo la columna Correo, tal
	 *   como se pidió explícitamente.
	 *
	 * @param {string} estado 'esta_empresa'|'otra_empresa'|'no_existe'.
	 */
	function exportarExcelPorEstado( estado ) {
		if ( 'undefined' === typeof XLSX ) {
			return;
		}

		var items = ( wizard.resultado || [] ).filter( function ( item ) {
			return item.estado === estado;
		} );

		if ( ! items.length ) {
			return;
		}

		var aoa;
		var esEstaEmpresa = 'esta_empresa' === estado;

		if ( esEstaEmpresa ) {
			aoa = [ [
				AU_WMS.i18n.compareUsersColCorreo,
				AU_WMS.i18n.compareUsersColEstado,
				AU_WMS.i18n.compareUsersColDetalle,
				AU_WMS.i18n.compareUsersColTest,
			] ];

			items.forEach( function ( item ) {
				aoa.push( [
					item.correo,
					tituloDeEstado( item.estado ),
					item.detalle || '',
					item.tiene_test ? AU_WMS.i18n.testOk : AU_WMS.i18n.sinTest,
				] );
			} );
		} else {
			aoa = [ [ AU_WMS.i18n.compareUsersColCorreo ] ];

			items.forEach( function ( item ) {
				aoa.push( [ item.correo ] );
			} );
		}

		var hoja = XLSX.utils.aoa_to_sheet( aoa );
		var columnas = aoa[ 0 ].length;
		var letras = [ 'A', 'B', 'C', 'D' ].slice( 0, columnas );

		// Encabezado navy/blanco, igual que el resto de exports del
		// plugin (ver exportar-usuarios.js).
		letras.forEach( function ( letra ) {
			hoja[ letra + '1' ].s = {
				font: { bold: true, color: { rgb: 'FFFFFF' } },
				fill: { patternType: 'solid', fgColor: { rgb: '131A1E' } },
				alignment: { horizontal: 'center', vertical: 'center' },
			};
		} );

		if ( esEstaEmpresa ) {
			hoja[ '!cols' ] = [ { wch: 34 }, { wch: 24 }, { wch: 22 }, { wch: 14 } ];

			items.forEach( function ( item, indice ) {
				var fila = indice + 2;
				var colorEstado = COLORES_ESTADO.esta_empresa;

				hoja[ 'B' + fila ].s = {
					fill: { patternType: 'solid', fgColor: { rgb: colorEstado.bg } },
					font: { bold: true, color: { rgb: colorEstado.color } },
					alignment: { horizontal: 'center', vertical: 'center' },
				};

				var tieneTest = !! item.tiene_test;
				var colorTest = tieneTest ? COLORES_ESTADO.esta_empresa : COLORES_ESTADO.no_existe;

				hoja[ 'D' + fila ].s = {
					fill: { patternType: 'solid', fgColor: { rgb: colorTest.bg } },
					font: { bold: true, color: { rgb: colorTest.color } },
					alignment: { horizontal: 'center', vertical: 'center' },
				};
			} );
		} else {
			hoja[ '!cols' ] = [ { wch: 34 } ];
		}

		var libro = XLSX.utils.book_new();
		XLSX.utils.book_append_sheet( libro, hoja, 'Correos' );

		XLSX.writeFile( libro, construirNombreArchivoComparacion( estado ) );
	}

	/**
	 * Arma "Comparar_{empresa}_{Estado}_{YYYY-MM-DD}.xlsx".
	 *
	 * @param {string} estado 'esta_empresa'|'otra_empresa'|'no_existe'.
	 * @return {string}
	 */
	function construirNombreArchivoComparacion( estado ) {
		var SLUGS_ESTADO = {
			esta_empresa: 'EnEstaEmpresa',
			otra_empresa: 'EnOtraEmpresa',
			no_existe: 'NoRegistrados',
		};

		var empresa = sanitizarNombreArchivo( wizard.empresaNombre || 'Empresa' );

		return 'Comparar_' + empresa + '_' + SLUGS_ESTADO[ estado ] + '_' + formatearFechaISO( new Date() ) + '.xlsx';
	}

	/**
	 * Sanitiza un fragmento para usarlo en un nombre de archivo:
	 * elimina caracteres inválidos en Windows (\ / : * ? " < > |) y
	 * reemplaza espacios por guiones bajos.
	 *
	 * @param {string} texto Texto original.
	 * @return {string}
	 */
	function sanitizarNombreArchivo( texto ) {
		return String( texto || '' )
			.replace( /[\\/:*?"<>|]/g, '' )
			.replace( /\s+/g, '_' )
			.replace( /_{2,}/g, '_' )
			.replace( /^_+|_+$/g, '' );
	}

	/**
	 * Formatea una fecha como YYYY-MM-DD (hora local del navegador).
	 *
	 * @param {Date} fecha Fecha a formatear.
	 * @return {string}
	 */
	function formatearFechaISO( fecha ) {
		var pad = function ( n ) {
			return ( n < 10 ? '0' : '' ) + n;
		};

		return fecha.getFullYear() + '-' + pad( fecha.getMonth() + 1 ) + '-' + pad( fecha.getDate() );
	}

	/**
	 * Muestra un error genérico vía SweetAlert2.
	 *
	 * @param {string} mensaje Mensaje a mostrar.
	 */
	function mostrarErrorSwal( mensaje ) {
		Swal.fire( {
			icon: 'error',
			title: mensaje || AU_WMS.i18n.genericError,
		} );
	}
} )( jQuery );
