/**
 * Administrador de Usuarios (WMS Latam) — modal "Editar perfil de
 * usuario" (Tab Integrantes → Acciones → Datos del usuario).
 *
 * Mismos campos que el formulario "Mi cuenta" del tema, sin el correo
 * ni la contraseña. Los valores se piden al servidor al abrir (el
 * listado no trae edad, género, país, teléfono ni cargo) y se guardan
 * por AJAX; al terminar se refresca la tabla con el hook global
 * `window.AU_WMS_recargarUsuarios` que expone admin.js.
 *
 * Depende de jQuery y SweetAlert2, y usa `AU_WMS` (ajaxUrl, nonce, i18n).
 */
( function ( $ ) {
	'use strict';

	// Campos del modal: id del input => clave que espera el servidor.
	var CAMPOS = {
		'au-wms-ep-first-name': 'first_name',
		'au-wms-ep-last-name': 'last_name',
		'au-wms-ep-age': 'user_age',
		'au-wms-ep-gender': 'user_gender',
		'au-wms-ep-country': 'country',
		'au-wms-ep-phone': 'phone_number',
		'au-wms-ep-position': 'user_position',
	};

	var usuarioId = null;
	var guardando = false;

	$( document ).ready( function () {
		if ( ! $( '#au-wms-editar-perfil-overlay' ).length ) {
			return;
		}

		$( '#au-wms-tabla-body' ).on( 'click', '.au-wms-action-editar-perfil', function () {
			abrir( $( this ).closest( 'tr' ).data( 'user-id' ) );
		} );

		$( '#au-wms-editar-perfil-close, #au-wms-editar-perfil-btn-cancelar' ).on( 'click', cerrar );

		$( '#au-wms-editar-perfil-overlay' ).on( 'click', function ( event ) {
			if ( event.target === this ) {
				cerrar();
			}
		} );

		$( '#au-wms-editar-perfil-btn-guardar' ).on( 'click', guardar );
	} );

	/**
	 * Abre el modal y precarga el perfil real del usuario.
	 *
	 * @param {number} userId ID del usuario.
	 */
	function abrir( userId ) {
		usuarioId = userId;

		var $guardar = $( '#au-wms-editar-perfil-btn-guardar' ).prop( 'disabled', true );

		limpiarError();
		camposHabilitados( false );
		Object.keys( CAMPOS ).forEach( function ( id ) {
			$( '#' + id ).val( '' );
		} );

		$( '#au-wms-editar-perfil-correo' ).text( AU_WMS.i18n.loading || 'Cargando...' );
		$( '#au-wms-editar-perfil-overlay' ).addClass( 'is-open' );

		$.post( AU_WMS.ajaxUrl, {
			action: 'au_wms_obtener_perfil',
			nonce: AU_WMS.nonce,
			user_id: userId,
		} )
			.done( function ( response ) {
				if ( ! response || ! response.success ) {
					cerrar();
					Swal.fire( {
						icon: 'error',
						title: response && response.data ? response.data.message : AU_WMS.i18n.genericError,
					} );
					return;
				}

				var perfil = response.data;

				Object.keys( CAMPOS ).forEach( function ( id ) {
					$( '#' + id ).val( perfil[ CAMPOS[ id ] ] || '' );
				} );

				$( '#au-wms-editar-perfil-correo' ).text(
					( AU_WMS.i18n.epCorreo || 'Correo de la cuenta' ) + ': ' + ( perfil.email || '' )
				);

				camposHabilitados( true );
				$guardar.prop( 'disabled', false );
				$( '#au-wms-ep-first-name' ).trigger( 'focus' );
			} )
			.fail( function () {
				cerrar();
				Swal.fire( { icon: 'error', title: AU_WMS.i18n.genericError } );
			} );
	}

	function cerrar() {
		if ( guardando ) {
			return;
		}

		$( '#au-wms-editar-perfil-overlay' ).removeClass( 'is-open' );
		usuarioId = null;
	}

	/**
	 * Guarda el perfil. Ante un error, el modal se queda abierto con lo
	 * escrito para poder corregirlo.
	 */
	function guardar() {
		if ( ! usuarioId || guardando ) {
			return;
		}

		limpiarError();

		// Mismas reglas que el formulario del tema: todos obligatorios.
		// El servidor las vuelve a aplicar; esto solo evita el viaje.
		var vacio = Object.keys( CAMPOS ).filter( function ( id ) {
			return ! $.trim( $( '#' + id ).val() );
		} );

		if ( vacio.length ) {
			mostrarError( AU_WMS.i18n.epCamposRequeridos || 'Todos los campos son obligatorios.' );
			$( '#' + vacio[ 0 ] ).trigger( 'focus' );
			return;
		}

		var datos = {
			action: 'au_wms_editar_perfil',
			nonce: AU_WMS.nonce,
			user_id: usuarioId,
		};

		Object.keys( CAMPOS ).forEach( function ( id ) {
			datos[ CAMPOS[ id ] ] = $.trim( $( '#' + id ).val() );
		} );

		var $boton = $( '#au-wms-editar-perfil-btn-guardar' );
		var textoOriginal = $boton.text();

		guardando = true;
		$boton.prop( 'disabled', true ).text( AU_WMS.i18n.epGuardando || 'Guardando…' );

		$.post( AU_WMS.ajaxUrl, datos )
			.done( function ( response ) {
				if ( ! response || ! response.success ) {
					mostrarError( response && response.data ? response.data.message : AU_WMS.i18n.genericError );
					return;
				}

				guardando = false;
				cerrar();

				Swal.fire( {
					icon: 'success',
					title: AU_WMS.i18n.epExito || 'El perfil del usuario se actualizó correctamente',
					timer: 2200,
					showConfirmButton: false,
				} );

				if ( 'function' === typeof window.AU_WMS_recargarUsuarios ) {
					window.AU_WMS_recargarUsuarios();
				}
			} )
			.fail( function () {
				mostrarError( AU_WMS.i18n.genericError );
			} )
			.always( function () {
				guardando = false;
				$boton.prop( 'disabled', false ).text( textoOriginal );
			} );
	}

	function camposHabilitados( habilitados ) {
		Object.keys( CAMPOS ).forEach( function ( id ) {
			$( '#' + id ).prop( 'disabled', ! habilitados );
		} );
	}

	function mostrarError( mensaje ) {
		$( '#au-wms-editar-perfil-error' ).removeClass( 'au-wms-hidden' ).text( mensaje );
	}

	function limpiarError() {
		$( '#au-wms-editar-perfil-error' ).addClass( 'au-wms-hidden' ).text( '' );
	}
} )( jQuery );
