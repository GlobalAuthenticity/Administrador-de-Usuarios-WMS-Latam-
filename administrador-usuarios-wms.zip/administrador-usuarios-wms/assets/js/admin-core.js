/**
 * Administrador de Usuarios (WMS Latam) — Núcleo compartido del panel.
 *
 * Pestañas, utilidades de presentación (nombres de rol, badges de
 * programas, contadores de pestaña, fechas, errores, progreso) y el
 * espacio de nombres `window.AU_WMS_APP` que comparten los módulos.
 * Se carga primero.
 *
 * Módulos (en orden de carga): admin-core.js → acciones-usuario.js →
 * borrado-masivo.js → admin.js (Integrantes). Cada módulo publica sus
 * funciones en `window.AU_WMS_APP` y llama a las de los demás a través
 * de pequeños delegados, resueltos en el momento de la llamada (no al
 * cargar), así que el orden solo importa para los `$( document ).ready`.
 *
 * Depende de jQuery y SweetAlert2. Usa el objeto global `AU_WMS`
 * (ajaxUrl, nonce, i18n) localizado desde PHP.
 */
( function ( $ ) {
	'use strict';

	var App = window.AU_WMS_APP = window.AU_WMS_APP || {};

	$( document ).ready( function () {
		initTabs();
	} );

	/**
	 * Presentación de roles: traduce el slug técnico (subscriber,
	 * group_leader, company…) a un nombre legible y deja el slug en el
	 * tooltip. Se expone en `window.AU_WMS_UI` para que empresas.js y
	 * usuarios-externos.js (que dependen de este script) usen lo mismo.
	 */
	function etiquetaRol( rol ) {
		var mapa = ( window.AU_WMS && AU_WMS.rolesEtiquetas ) || {};
		var valor = String( rol || '' ).trim();

		if ( ! valor ) {
			return '—';
		}
		if ( mapa[ valor ] ) {
			return mapa[ valor ];
		}
		valor = valor.replace( /_/g, ' ' );
		return valor.charAt( 0 ).toUpperCase() + valor.slice( 1 );
	}

	function badgePrograma( programa, valor ) {
		var esInspira = 'inspira' === programa;
		return $( '<span></span>' )
			.addClass( 'au-wms-badge ' + ( esInspira ? 'au-wms-badge--inspira' : 'au-wms-badge--octagono' ) )
			.attr( 'title', ( esInspira ? 'Inspira' : 'Octágono' ) + ': ' + valor )
			.text( ( esInspira ? 'Inspira' : 'Octágono' ) + ': ' + etiquetaRol( valor ) );
	}

	/**
	 * Contador junto al nombre de cada pestaña. Muestra el total SIN
	 * filtros: solo se actualiza cuando el listado se pidió sin búsqueda
	 * ni filtros, para que el número no cambie al filtrar.
	 */
	function actualizarContadorTab( tab, total, sinFiltros ) {
		if ( ! sinFiltros ) {
			return;
		}
		var n = parseInt( total, 10 ) || 0;
		$( '.au-wms-tab-count[data-count-for="' + tab + '"]' )
			.text( n.toLocaleString( 'es-CO' ) )
			.prop( 'hidden', false );
	}

	/**
	 * Maneja el cambio entre pestañas (Empresas / Integrantes / Usuarios Externos).
	 */
	function initTabs() {
		$( '.au-wms-tab' ).on( 'click', function () {
			var tab = $( this ).data( 'tab' );

			$( '.au-wms-tab' ).removeClass( 'is-active' ).attr( 'aria-selected', 'false' );
			$( this ).addClass( 'is-active' ).attr( 'aria-selected', 'true' );

			$( '.au-wms-panel' ).removeClass( 'is-active' );
			$( '#au-wms-tab-' + tab ).addClass( 'is-active' );
		} );
	}

	/**
	 * Escapa HTML básico para insertar texto dinámico (ej. mensajes de
	 * error del servidor) de forma segura dentro de un bloque HTML de
	 * SweetAlert2.
	 *
	 * @param {string} value Texto a escapar.
	 * @return {string}
	 */
	function escapeHtml( value ) {
		return $( '<div>' ).text( value || '' ).html();
	}

	/**
	 * Muestra un error mediante SweetAlert2.
	 *
	 * @param {string} message Mensaje a mostrar.
	 */
	function mostrarError( message ) {
		Swal.fire( {
			icon: 'error',
			title: message || AU_WMS.i18n.genericError,
		} );
	}

	/**
	 * Actualiza (o crea) el modal bloqueante de progreso, reutilizable
	 * para cualquier fase del borrado masivo (refresco o procesamiento).
	 *
	 * @param {string} titulo    Título a mostrar.
	 * @param {number} procesados Usuarios ya procesados.
	 * @param {number} total      Total de usuarios a procesar.
	 */
	function mostrarProgresoGenerico( titulo, procesados, total ) {
		var porcentaje = total > 0 ? Math.round( ( procesados / total ) * 100 ) : 100;

		var opciones = {
			title: titulo,
			html:
				'<div class="au-wms-import-progress-bar"><div class="au-wms-import-progress-fill" style="width:' + porcentaje + '%"></div></div>' +
				'<p>' + procesados + ' / ' + total + '</p>',
			showConfirmButton: false,
			allowOutsideClick: false,
			allowEscapeKey: false,
		};

		if ( 0 === procesados && ! Swal.isVisible() ) {
			Swal.fire( opciones );
		} else {
			Swal.update( opciones );
		}
	}

	/**
	 * Formatea una fecha proveniente del backend (formato MySQL) a un
	 * formato legible en español: "15 de julio de 2026".
	 *
	 * @param {string} value Fecha en formato "YYYY-MM-DD HH:MM:SS".
	 * @return {string}
	 */
	var MESES_ES = [
		'enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio',
		'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre',
	];

	function formatearFecha( value ) {
		if ( ! value ) {
			return '';
		}

		var parts = value.split( ' ' )[ 0 ].split( '-' );
		if ( parts.length !== 3 ) {
			return value;
		}

		var anio = parseInt( parts[ 0 ], 10 );
		var mesIndex = parseInt( parts[ 1 ], 10 ) - 1;
		var dia = parseInt( parts[ 2 ], 10 );

		if ( ! anio || mesIndex < 0 || mesIndex > 11 || ! dia ) {
			return value;
		}

		return dia + ' de ' + MESES_ES[ mesIndex ] + ' de ' + anio;
	}

	/**
	 * Formatea una fecha en versión corta para la línea superior de la
	 * columna Usuario (ej. "15 jul 2026"), priorizando la compacidad.
	 *
	 * @param {string} value Fecha en formato "YYYY-MM-DD HH:MM:SS".
	 * @return {string}
	 */
	var MESES_ES_CORTO = [
		'ene', 'feb', 'mar', 'abr', 'may', 'jun',
		'jul', 'ago', 'sep', 'oct', 'nov', 'dic',
	];

	function formatearFechaCorta( value ) {
		if ( ! value ) {
			return '';
		}

		var parts = value.split( ' ' )[ 0 ].split( '-' );
		if ( parts.length !== 3 ) {
			return value;
		}

		var anio = parseInt( parts[ 0 ], 10 );
		var mesIndex = parseInt( parts[ 1 ], 10 ) - 1;
		var dia = parseInt( parts[ 2 ], 10 );

		if ( ! anio || mesIndex < 0 || mesIndex > 11 || ! dia ) {
			return value;
		}

		return dia + ' ' + MESES_ES_CORTO[ mesIndex ] + ' ' + anio;
	}

	window.AU_WMS_UI = {
		etiquetaRol: etiquetaRol,
		badgePrograma: badgePrograma,
		actualizarContadorTab: actualizarContadorTab,
	};

	// Publicación en el espacio de nombres compartido.
	App.etiquetaRol = etiquetaRol;
	App.badgePrograma = badgePrograma;
	App.actualizarContadorTab = actualizarContadorTab;
	App.initTabs = initTabs;
	App.escapeHtml = escapeHtml;
	App.mostrarError = mostrarError;
	App.mostrarProgresoGenerico = mostrarProgresoGenerico;
	App.formatearFecha = formatearFecha;
	App.formatearFechaCorta = formatearFechaCorta;
} )( jQuery );
