/**
 * Administrador de Usuarios (WMS Latam) — Modal "Ver WP_USERMETA".
 *
 * Depende de jQuery y SweetAlert2 (ya cargados por admin.js) y del
 * objeto global `AU_WMS` (ajaxUrl, nonce) localizado desde PHP.
 */
( function ( $ ) {
	'use strict';

	var LONGITUD_TRUNCADA = 120;

	var state = {
		userId: 0,
		nombreUsuario: '',
		search: '',
		page: 1,
		perPage: 10,
		totalPages: 1,
		modo: 'crear', // 'crear' | 'editar'
		editandoUmetaId: null,
		itemsActuales: [],
	};

	var searchDebounceTimer = null;

	$( document ).ready( function () {
		if ( ! $( '#au-wms-usermeta-overlay' ).length ) {
			return;
		}

		initCierre();
		initBusquedaYPaginacion();
		initEventosTabla();
		initFormulario();
	} );

	/**
	 * Punto de entrada expuesto globalmente: admin.js lo llama al hacer
	 * clic en "Ver WP_USERMETA" dentro del dropdown de acciones de una fila.
	 *
	 * @param {number} userId ID del usuario seleccionado.
	 * @param {string} nombre Nombre a mostrar en el título del modal.
	 */
	window.AU_WMS_abrirUsermeta = function ( userId, nombre ) {
		state.userId = userId;
		state.nombreUsuario = nombre || '';
		state.search = '';
		state.page = 1;

		$( '#au-wms-usermeta-search' ).val( '' );
		$( '#au-wms-usermeta-title' ).text( 'WP_USERMETA — ' + state.nombreUsuario + ' (#' + userId + ')' );

		mostrarPanelListado();
		$( '#au-wms-usermeta-overlay' ).addClass( 'is-open' );

		cargarListado();
	};

	function initCierre() {
		$( '#au-wms-usermeta-close' ).on( 'click', cerrarModal );

		$( '#au-wms-usermeta-overlay' ).on( 'click', function ( event ) {
			if ( event.target === this ) {
				cerrarModal();
			}
		} );

		$( '#au-wms-usermeta-vermas-close' ).on( 'click', function () {
			$( '#au-wms-usermeta-vermas-overlay' ).removeClass( 'is-open' );
		} );

		$( '#au-wms-usermeta-vermas-overlay' ).on( 'click', function ( event ) {
			if ( event.target === this ) {
				$( this ).removeClass( 'is-open' );
			}
		} );
	}

	function cerrarModal() {
		$( '#au-wms-usermeta-overlay' ).removeClass( 'is-open' );
		$( '#au-wms-usermeta-vermas-overlay' ).removeClass( 'is-open' );
	}

	/**
	 * Buscador con debounce, selector de registros por página y
	 * controles de paginación.
	 */
	function initBusquedaYPaginacion() {
		$( '#au-wms-usermeta-search' ).on( 'input', function () {
			var value = $( this ).val();

			clearTimeout( searchDebounceTimer );
			searchDebounceTimer = setTimeout( function () {
				state.search = value;
				state.page = 1;
				cargarListado();
			}, 350 );
		} );

		$( '#au-wms-usermeta-per-page' ).on( 'change', function () {
			state.perPage = parseInt( $( this ).val(), 10 ) || 10;
			state.page = 1;
			cargarListado();
		} );

		$( '#au-wms-usermeta-pagination' ).on( 'click', '.au-wms-page-btn', function () {
			var target = $( this ).data( 'page' );

			if ( 'first' === target ) {
				state.page = 1;
			} else if ( 'prev' === target ) {
				state.page = Math.max( 1, state.page - 1 );
			} else if ( 'next' === target ) {
				state.page = Math.min( state.totalPages, state.page + 1 );
			} else if ( 'last' === target ) {
				state.page = state.totalPages;
			}

			cargarListado();
		} );
	}

	/**
	 * Delegación de eventos sobre la tabla: Ver más, Editar, Eliminar.
	 */
	function initEventosTabla() {
		var $body = $( '#au-wms-usermeta-body' );

		$body.on( 'click', '.au-wms-usermeta-vermas-btn', function () {
			var umetaId = $( this ).closest( 'tr' ).data( 'umeta-id' );
			var item = buscarItemPorId( umetaId );

			if ( item ) {
				$( '#au-wms-usermeta-vermas-content' ).text( item.meta_value );
				$( '#au-wms-usermeta-vermas-overlay' ).addClass( 'is-open' );
			}
		} );

		$body.on( 'click', '.au-wms-usermeta-editar', function () {
			if ( $( this ).prop( 'disabled' ) ) {
				return;
			}

			var umetaId = $( this ).closest( 'tr' ).data( 'umeta-id' );
			var item = buscarItemPorId( umetaId );

			if ( ! item ) {
				return;
			}

			state.modo = 'editar';
			state.editandoUmetaId = umetaId;

			$( '#au-wms-usermeta-form-title' ).text( AU_WMS.i18n.usermetaEditarTitulo || 'Editar atributo' );
			$( '#au-wms-usermeta-form-key' ).val( item.meta_key );
			$( '#au-wms-usermeta-form-value' ).val( item.meta_value );

			mostrarPanelFormulario();
		} );

		$body.on( 'click', '.au-wms-usermeta-eliminar', function () {
			if ( $( this ).prop( 'disabled' ) ) {
				return;
			}

			var umetaId = $( this ).closest( 'tr' ).data( 'umeta-id' );
			confirmarEliminar( umetaId );
		} );
	}

	/**
	 * Botón "Agregar atributo" y controles del formulario (Volver,
	 * Cancelar, Guardar).
	 */
	function initFormulario() {
		$( '#au-wms-usermeta-btn-agregar' ).on( 'click', function () {
			state.modo = 'crear';
			state.editandoUmetaId = null;

			$( '#au-wms-usermeta-form-title' ).text( AU_WMS.i18n.usermetaAgregarTitulo || 'Agregar atributo' );
			$( '#au-wms-usermeta-form-key' ).val( '' );
			$( '#au-wms-usermeta-form-value' ).val( '' );

			mostrarPanelFormulario();
		} );

		$( '#au-wms-usermeta-form-volver, #au-wms-usermeta-form-cancelar' ).on( 'click', function () {
			mostrarPanelListado();
		} );

		$( '#au-wms-usermeta-form-guardar' ).on( 'click', guardarFormulario );
	}

	function mostrarPanelListado() {
		$( '#au-wms-usermeta-panel-form' ).hide();
		$( '#au-wms-usermeta-panel-list' ).show();
	}

	function mostrarPanelFormulario() {
		$( '#au-wms-usermeta-panel-list' ).hide();
		$( '#au-wms-usermeta-panel-form' ).show();
	}

	/**
	 * Guarda el formulario (crear o editar, según `state.modo`).
	 */
	function guardarFormulario() {
		var metaKey = $( '#au-wms-usermeta-form-key' ).val().trim();
		var metaValue = $( '#au-wms-usermeta-form-value' ).val();

		if ( '' === metaKey ) {
			mostrarErrorSwal( AU_WMS.i18n.usermetaKeyObligatorio || 'El Meta Key es obligatorio.' );
			return;
		}

		var $boton = $( '#au-wms-usermeta-form-guardar' );
		$boton.prop( 'disabled', true );

		var accion = 'crear' === state.modo ? 'au_wms_usermeta_crear' : 'au_wms_usermeta_actualizar';
		var datos = {
			action: accion,
			nonce: AU_WMS.nonce,
			user_id: state.userId,
			meta_key: metaKey,
			meta_value: metaValue,
		};

		if ( 'editar' === state.modo ) {
			datos.umeta_id = state.editandoUmetaId;
		}

		$.post( AU_WMS.ajaxUrl, datos )
			.done( function ( response ) {
				if ( response && response.success ) {
					Swal.fire( {
						icon: 'success',
						title: response.data.message,
						timer: 1800,
						showConfirmButton: false,
					} );
					mostrarPanelListado();
					cargarListado();
				} else {
					mostrarErrorSwal( response && response.data ? response.data.message : AU_WMS.i18n.genericError );
				}
			} )
			.fail( function () {
				mostrarErrorSwal( AU_WMS.i18n.genericError );
			} )
			.always( function () {
				$boton.prop( 'disabled', false );
			} );
	}

	/**
	 * Pide confirmación y elimina un atributo.
	 *
	 * @param {number} umetaId ID del registro (`umeta_id`).
	 */
	function confirmarEliminar( umetaId ) {
		Swal.fire( {
			title: AU_WMS.i18n.usermetaConfirmDeleteTitle || '¿Está seguro de eliminar este atributo?',
			text: AU_WMS.i18n.usermetaConfirmDeleteText || 'Esta acción no se puede deshacer.',
			icon: 'warning',
			showCancelButton: true,
			confirmButtonText: AU_WMS.i18n.confirmDeleteButton,
			cancelButtonText: AU_WMS.i18n.cancelButton,
			customClass: { confirmButton: 'au-wms-swal-danger' },
			reverseButtons: true,
		} ).then( function ( result ) {
			if ( ! result.isConfirmed ) {
				return;
			}

			$.post( AU_WMS.ajaxUrl, {
				action: 'au_wms_usermeta_eliminar',
				nonce: AU_WMS.nonce,
				user_id: state.userId,
				umeta_id: umetaId,
			} )
				.done( function ( response ) {
					if ( response && response.success ) {
						Swal.fire( {
							icon: 'success',
							title: response.data.message,
							timer: 1800,
							showConfirmButton: false,
						} );
						cargarListado();
					} else {
						mostrarErrorSwal( response && response.data ? response.data.message : AU_WMS.i18n.genericError );
					}
				} )
				.fail( function () {
					mostrarErrorSwal( AU_WMS.i18n.genericError );
				} );
		} );
	}

	/**
	 * Carga (o recarga) el listado paginado de usermeta del usuario actual.
	 */
	function cargarListado() {
		mostrarCargando();

		$.post( AU_WMS.ajaxUrl, {
			action: 'au_wms_usermeta_listar',
			nonce: AU_WMS.nonce,
			user_id: state.userId,
			search: state.search,
			page: state.page,
			per_page: state.perPage,
		} )
			.done( function ( response ) {
				if ( ! response || ! response.success ) {
					mostrarErrorSwal( response && response.data ? response.data.message : AU_WMS.i18n.genericError );
					return;
				}

				state.itemsActuales = response.data.items;
				renderTabla( response.data.items );
				renderPaginacion( response.data );
			} )
			.fail( function () {
				mostrarErrorSwal( AU_WMS.i18n.genericError );
			} );
	}

	function mostrarCargando() {
		$( '#au-wms-usermeta-body' ).html(
			'<tr class="au-wms-row-loading"><td colspan="3"><div class="au-wms-spinner"></div>' +
			AU_WMS.i18n.loading +
			'</td></tr>'
		);
	}

	/**
	 * Renderiza las filas de la tabla de usermeta.
	 *
	 * @param {Array} items Lista de registros.
	 */
	function renderTabla( items ) {
		var $body = $( '#au-wms-usermeta-body' );
		$body.empty();

		if ( ! items || ! items.length ) {
			var emptyTemplate = document.getElementById( 'au-wms-usermeta-empty-template' );
			$body.append( document.importNode( emptyTemplate.content, true ) );
			return;
		}

		var template = document.getElementById( 'au-wms-usermeta-row-template' );

		items.forEach( function ( item ) {
			var $row = $( document.importNode( template.content, true ) );
			var $tr = $row.filter( 'tr' ).length ? $row.filter( 'tr' ) : $row.find( 'tr' );

			$tr.attr( 'data-umeta-id', item.umeta_id );
			$tr.find( '.au-wms-usermeta-key' ).text( item.meta_key );

			var valorCompleto = item.meta_value || '';
			var esLargo = valorCompleto.length > LONGITUD_TRUNCADA;
			var valorMostrado = esLargo ? valorCompleto.substring( 0, LONGITUD_TRUNCADA ) + '…' : valorCompleto;

			$tr.find( '.au-wms-usermeta-value-text' ).text( valorMostrado );
			$tr.find( '.au-wms-usermeta-vermas-btn' ).toggle( esLargo );

			if ( item.protegido ) {
				$tr.find( '.au-wms-usermeta-editar, .au-wms-usermeta-eliminar' )
					.prop( 'disabled', true )
					.attr( 'title', AU_WMS.i18n.usermetaProtegido || 'Campo reservado por WordPress' )
					.addClass( 'is-disabled' );
			}

			$body.append( $tr );
		} );
	}

	/**
	 * Actualiza los controles de paginación del modal.
	 *
	 * @param {Object} data Respuesta de au_wms_usermeta_listar.
	 */
	function renderPaginacion( data ) {
		state.page = data.page;
		state.totalPages = data.total_pages;

		$( '#au-wms-usermeta-total' ).text( data.total );
		$( '#au-wms-usermeta-current-page' ).text( data.page );
		$( '#au-wms-usermeta-total-pages' ).text( data.total_pages );

		$( '#au-wms-usermeta-pagination .au-wms-page-btn[data-page="first"]' ).prop( 'disabled', data.page <= 1 );
		$( '#au-wms-usermeta-pagination .au-wms-page-btn[data-page="prev"]' ).prop( 'disabled', data.page <= 1 );
		$( '#au-wms-usermeta-pagination .au-wms-page-btn[data-page="next"]' ).prop( 'disabled', data.page >= data.total_pages );
		$( '#au-wms-usermeta-pagination .au-wms-page-btn[data-page="last"]' ).prop( 'disabled', data.page >= data.total_pages );
	}

	/**
	 * Busca un item por `umeta_id` dentro de los ya cargados en memoria.
	 *
	 * @param {number} umetaId ID del registro.
	 * @return {Object|null}
	 */
	function buscarItemPorId( umetaId ) {
		var encontrado = null;

		state.itemsActuales.forEach( function ( item ) {
			if ( parseInt( item.umeta_id, 10 ) === parseInt( umetaId, 10 ) ) {
				encontrado = item;
			}
		} );

		return encontrado;
	}

	function mostrarErrorSwal( mensaje ) {
		Swal.fire( {
			icon: 'error',
			title: mensaje || AU_WMS.i18n.genericError,
		} );
	}
} )( jQuery );
