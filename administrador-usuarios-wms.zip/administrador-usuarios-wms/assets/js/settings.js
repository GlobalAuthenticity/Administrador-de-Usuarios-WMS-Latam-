/**
 * Administrador de Usuarios (WMS Latam) — Página de Configuración
 * (APIs / Webhooks).
 *
 * Depende de jQuery y SweetAlert2. Usa el objeto global
 * `AU_WMS_SETTINGS` (ajaxUrl, nonce, i18n) localizado desde PHP.
 */
( function ( $ ) {
	'use strict';

	$( document ).ready( function () {
		initTokenToggle();
		initFormSubmit();
	} );

	/**
	 * Muestra/oculta cualquier campo de token al hacer clic en su ícono
	 * (funciona para todos los campos con clase .au-wms-token-toggle,
	 * vinculados a su input vía data-target).
	 */
	function initTokenToggle() {
		$( '.au-wms-token-toggle' ).on( 'click', function () {
			var $input = $( '#' + $( this ).data( 'target' ) );
			var esPassword = 'password' === $input.attr( 'type' );

			$input.attr( 'type', esPassword ? 'text' : 'password' );
			$( this ).find( '.dashicons' )
				.toggleClass( 'dashicons-visibility', ! esPassword )
				.toggleClass( 'dashicons-hidden', esPassword );
		} );
	}

	/**
	 * Envía el formulario vía AJAX y muestra el resultado con SweetAlert2.
	 */
	function initFormSubmit() {
		$( '#au-wms-settings-form' ).on( 'submit', function ( event ) {
			event.preventDefault();

			var $boton = $( '#au-wms-settings-guardar' );
			var textoOriginal = $boton.data( 'texto-original' ) || $boton.text();
			$boton.data( 'texto-original', textoOriginal );
			$boton.prop( 'disabled', true ).text( AU_WMS_SETTINGS.i18n.saving );

			$.post( AU_WMS_SETTINGS.ajaxUrl, {
				action: 'au_wms_guardar_configuracion',
				nonce: AU_WMS_SETTINGS.nonce,
				webhook_nuevo_usuario_url: $( '#au-wms-cfg-webhook-nuevo' ).val(),
				webhook_usuario_actualizado_url: $( '#au-wms-cfg-webhook-update' ).val(),
				token_autorizacion: $( '#au-wms-cfg-token' ).val(),
				webhooks_activos: $( '#au-wms-cfg-activos' ).is( ':checked' ) ? 1 : 0,
				inspira_sync_url: $( '#au-wms-cfg-inspira-url' ).val(),
				inspira_sync_token: $( '#au-wms-cfg-inspira-token' ).val(),
				octagono_sync_url: $( '#au-wms-cfg-octagono-url' ).val(),
				octagono_sync_token: $( '#au-wms-cfg-octagono-token' ).val(),
				webhook_recovery_pass_url: $( '#au-wms-cfg-recovery-pass-url' ).val(),
				webhook_reset_password_masivo_url: $( '#au-wms-cfg-reset-password-masivo-url' ).val(),
				pdf_resultado_test_url: $( '#au-wms-cfg-pdf-resultado-test-url' ).val(),
				// Asistente "Crear Empresa".
				crear_empresa_webhook_url: $( '#au-wms-cfg-ce-webhook' ).val(),
				crear_empresa_inspira_url: $( '#au-wms-cfg-ce-inspira-url' ).val(),
				crear_empresa_inspira_token: $( '#au-wms-cfg-ce-inspira-token' ).val(),
				crear_empresa_octagono_url: $( '#au-wms-cfg-ce-octagono-url' ).val(),
				crear_empresa_octagono_token: $( '#au-wms-cfg-ce-octagono-token' ).val(),
				crear_empresa_nombre_encargado: $( '#au-wms-cfg-ce-encargado' ).val(),
				crear_empresa_apellidos_encargado: $( '#au-wms-cfg-ce-apellidos' ).val(),
				crear_empresa_contacto: $( '#au-wms-cfg-ce-contacto' ).val(),
				crear_empresa_ocupacion: $( '#au-wms-cfg-ce-ocupacion' ).val(),
				crear_empresa_email_plantilla: $( '#au-wms-cfg-ce-email-plantilla' ).val(),
				crear_empresa_area_nombre: $( '#au-wms-cfg-ce-area-nombre' ).val(),
				crear_empresa_area_licencia_id: $( '#au-wms-cfg-ce-area-licencia' ).val(),
				crear_empresa_area_cupos_wms: $( '#au-wms-cfg-ce-cupos-wms' ).val(),
				crear_empresa_area_cupos_inspira: $( '#au-wms-cfg-ce-cupos-inspira' ).val(),
				crear_empresa_area_cupos_octagono: $( '#au-wms-cfg-ce-cupos-octagono' ).val(),
				crear_empresa_area_meses_expiracion: $( '#au-wms-cfg-ce-meses' ).val(),
			} )
				.done( function ( response ) {
					if ( response && response.success ) {
						Swal.fire( {
							icon: 'success',
							title: response.data.message,
							timer: 2000,
							showConfirmButton: false,
						} );
					} else {
						Swal.fire( {
							icon: 'error',
							title: response && response.data ? response.data.message : AU_WMS_SETTINGS.i18n.genericError,
						} );
					}
				} )
				.fail( function () {
					Swal.fire( { icon: 'error', title: AU_WMS_SETTINGS.i18n.genericError } );
				} )
				.always( function () {
					$boton.prop( 'disabled', false ).text( textoOriginal );
				} );
		} );
	}
} )( jQuery );
