# Administrador de Usuarios (WMS Latam)

Plugin de WordPress para gestionar Empresas, Integrantes y Usuarios Externos
del ecosistema WMS Latam desde un único panel de administración.

## Cambios 1.41.1 (organización del código)

- `admin.css` (3.077 líneas) dividido en 7 archivos por área en
  `assets/css/admin/`, cargados en el mismo orden: la cascada es
  idéntica.
- `admin.js` (1.681 líneas) dividido en 4 módulos: núcleo compartido,
  acciones sobre una cuenta, borrado masivo e Integrantes.
- Sin cambios de comportamiento ni de apariencia: verificado comparando
  capturas píxel a píxel y las peticiones AJAX de cada pantalla y de
  cada acción de los menús, antes y después de la división.

## Cambios 1.41.0 (ajustes visuales)

- **Roles legibles**: en tablas y badges se muestra "Integrante", "Líder
  de grupo", "Empresa", "Usuario externo", etc. en lugar del slug
  (`subscriber`, `group_leader`…), que queda en el tooltip. Aplica
  también a los valores de Inspira/Octágono. Etiquetas definidas en
  `rolesEtiquetas` (localizado como `AU_WMS.rolesEtiquetas`); helper JS
  compartido en `window.AU_WMS_UI`.
- "Octágono" con tilde en badges y filtros.
- **Colores de estado**: "Perfil incompleto" pasa a ámbar (aviso); el
  rojo queda para estados bloqueados y acciones destructivas.
  "Importado" pasa a neutro (es procedencia, no estado).
- **Contadores en las pestañas** con el total sin filtros de cada
  listado; no cambian al buscar o filtrar.
- **Modales ajustados a su contenido**: sin altura mínima fija. Solo
  los asistentes por pasos conservan una altura mínima para no saltar
  entre pasos.

## Cambios 1.40.0 (rediseño visual)

- Interfaz alineada con wmslatam.com (ver "Sistema de diseño").
  Solo cambia la presentación: misma lógica, mismos endpoints y mismos
  flujos.
- Encabezado de la página principal con título y pestañas debajo.
- Página de Configuración en dos columnas (descripción / campos) y con
  los campos del plugin en lugar del estilo por defecto de WordPress.
- Vista móvil con tablas en tarjetas y modales a pantalla completa.

## Cambios 1.39.0 (endurecimiento de seguridad)

- **Tokens fuera del código**: los tokens Bearer de Inspira y Octágono ya
  no tienen valor de fábrica. Deben cargarse en *Usuarios WMS →
  Configuración*. Mientras falte alguno, "Refrescar programas" queda
  bloqueado y la página de Configuración muestra un aviso.
- **Sincronización a prueba de tokens inválidos**: las respuestas HTTP
  0, 401, 403, 429 y 5xx de las APIs se tratan como error y nunca borran
  los metadatos `inspira`/`octagono` del usuario. Antes, un 401 con
  cuerpo JSON se interpretaba como "el usuario ya no tiene el programa".
- **Transacciones reales en el borrado**: "Borrar definitivamente" y
  "Dejar de ser usuario WMS" verifican cada consulta (`$wpdb` no lanza
  excepciones) y hacen ROLLBACK ante cualquier fallo, invalidando la
  caché del usuario. Los cupones solo se recalculan si la operación se
  confirmó. "Borrar definitivamente" ahora ejecuta `wp_delete_user()`
  dentro de la transacción y antes de borrar los usermeta, para que los
  hooks de LearnDash/WooCommerce vean los datos del usuario.
- **Roles protegidos**: eliminar, impersonar, cambiar correo/contraseña,
  deshabilitar acceso, editar usermeta, vincular/desvincular áreas y la
  actualización masiva de correos solo operan sobre `subscriber`,
  `group_leader`, `external_user` y `company` (o usuarios sin rol), y
  nunca sobre usuarios con capacidades privilegiadas. Ampliable con los
  filtros `au_wms_roles_gestionables` y `au_wms_capacidades_privilegiadas`.
- Requisito: las tablas `wp_users`, `wp_usermeta` y
  `wp_correos_configurados` deben ser InnoDB para que el ROLLBACK tenga
  efecto (en MyISAM las transacciones se ignoran).

## Instalación

1. Sube la carpeta `administrador-usuarios-wms` a `wp-content/plugins/`.
2. Actívalo desde **Plugins** en el escritorio de WordPress.
3. Verás un nuevo menú **"Usuarios WMS"** en la barra lateral de administración.

## Requisitos

- WordPress 5.8+
- PHP 7.4+
- WooCommerce activo (solo si quieres que la sincronización de cupones al
  eliminar un usuario funcione; si no está activo, ese paso se omite de
  forma segura sin generar errores).

## Estructura del plugin

```
administrador-usuarios-wms/
├── administrador-usuarios-wms.php   # Bootstrap del plugin
├── includes/
│   ├── class-au-loader.php              # Autoload / arranque de componentes
│   ├── class-au-security.php            # Nonces, capacidades, sanitización
│   ├── class-au-repository-empresas.php # Acceso a datos: empresas y paquetes
│   ├── class-au-repository-usuarios.php # Acceso a datos: búsqueda/paginación de usuarios
│   ├── class-au-coupon-service.php      # Recalcula usage_count de cupones WooCommerce
│   ├── class-au-user-service.php        # Flujo de eliminación e impersonación
│   ├── class-au-admin.php               # Menú, assets, render de la vista
│   └── class-au-ajax.php                # Endpoints AJAX (wp_ajax_*)
├── views/
│   ├── admin-page.php                   # Estructura de tabs
│   ├── tab-empresas.php                 # Listado de empresas (rol company)
│   ├── tab-integrantes.php              # Módulo principal
│   └── tab-usuarios-externos.php        # Listado de usuarios externos
└── assets/
    ├── css/admin/                       # Se cargan en este orden (la cascada depende de él)
    │   ├── 01-base.css                  # Tokens de marca, encabezado, pestañas, panel, filtros, controles
    │   ├── 02-tablas.css                # Tablas, badges, menú "Acciones" por fila, paginación
    │   ├── 03-componentes.css           # Barras de herramientas, botones, modales, SweetAlert2, asistentes
    │   ├── 04-importacion.css           # Asistente "Importar usuarios"
    │   ├── 05-configuracion.css         # Página "Configuración"
    │   ├── 06-modales.css               # Licencias, WP_USERMETA, Áreas, Correos, Contraseñas, Cambiar licencia
    │   └── 07-responsive.css            # Foco, movimiento reducido y móvil (sobrescribe a los anteriores)
    └── js/
        ├── admin-core.js                # Pestañas, utilidades compartidas y espacio de nombres AU_WMS_APP
        ├── acciones-usuario.js          # Acciones sobre una cuenta (borrar, contraseña, correo, acceso, login como)
        ├── borrado-masivo.js            # Selección múltiple y borrado masivo de Integrantes
        ├── admin.js                     # Pestaña Integrantes (handle `au-wms-admin`)
        └── …                            # Un archivo por modal/pestaña (empresas.js, import.js, licencias.js…)
```

**Cómo se organizan los estilos y scripts del panel**

- Los estilos se encolan desde `AU_Admin::hojas_de_estilo()`, encadenados
  (cada archivo depende del anterior). `au-wms-admin` queda registrado
  como alias de todos. Para agregar un archivo nuevo, inclúyelo en esa
  lista en la posición que le corresponda en la cascada.
- Los módulos JS publican sus funciones en `window.AU_WMS_APP` y llaman a
  las de otros módulos mediante delegados que se resuelven en el momento
  de la llamada. `admin.js` declara los otros tres como dependencias, así
  que cualquier script que dependa de `au-wms-admin` los recibe. Las
  funciones globales usadas por las demás pestañas
  (`AU_WMS_confirmarLoginComoUsuario`, `AU_WMS_abrirModalCambiarPassword`,
  `AU_WMS_refrescarTabla`, `AU_WMS_UI`…) se mantienen con el mismo nombre.

## Notas de implementación importantes

- **Rol principal mostrado en la columna "Rol"**: se extrae del primer rol
  con valor `true` en el meta serializado `wp_capabilities`. Si un usuario
  tiene varios roles, se muestra el primero que aparece en el array
  serializado (orden de asignación).

- **Badge de empresa y nombre de área en el listado general** (sin filtro
  de empresa/área aplicado): un usuario puede tener varios registros en
  `wp_correos_configurados` (una fila por cada `codigo_area`/paquete al
  que pertenece). Para no duplicar filas en la tabla, el listado agrupa
  por usuario y muestra **una** empresa/área representativa (`MAX()` en
  SQL). Al aplicar el filtro de Área, la fila mostrada corresponde
  exactamente a esa relación. Si en el futuro se requiere mostrar todas
  las áreas de un usuario simultáneamente, se recomienda agregar una
  columna expandible o un modal de detalle en lugar de cambiar el join
  principal (para no sacrificar el rendimiento de la paginación).

- **Eliminación de usuario**: sigue exactamente los 7 pasos solicitados,
  en este orden: (1-2) leer `codigo_area` desde `wp_correos_configurados`
  por email, (3) borrar esos registros, (4) recalcular y sincronizar el
  `usage_count` de cada cupón de WooCommerce asociado (`wp_paquetes.cupon_id`)
  contando los registros que **siguen existiendo** en
  `wp_correos_configurados` para ese `codigo_area`, (5) limpiar
  `wp_usermeta`, (6) eliminar el usuario con `wp_delete_user()` (función
  nativa de WordPress), (7) responder éxito para refrescar la tabla.
  Un administrador no puede eliminarse a sí mismo desde este panel.

- **Impersonación**: usa `wp_set_current_user()` + `wp_set_auth_cookie()`
  tras cerrar la sesión actual (`wp_clear_auth_cookie()` +
  `wp_destroy_current_session()`), protegida por `current_user_can()`,
  nonce y verificación CSRF (`AU_Security::guard()`). Se dispara la acción
  `au_wms_user_impersonated` por si se desea registrar auditoría en el
  futuro (por ejemplo, quién impersonó a quién y cuándo).

- **Rendimiento**: la búsqueda, el filtrado y la paginación se resuelven
  en una sola consulta SQL con `LIMIT`/`OFFSET`, sin bucles ni N+1. El
  listado de empresas se cachea 5 minutos con `wp_cache_get/set`.

- **Seguridad**: todas las peticiones AJAX pasan por
  `AU_Security::guard()` (capacidad `manage_options` + nonce
  `au_wms_nonce`). Todas las consultas usan `$wpdb->prepare()`. Las
  salidas en las vistas usan `esc_html()`/`esc_attr()`; en JS se escapa
  el texto dinámico antes de insertarlo en el DOM.

- **Internacionalización**: todas las cadenas visibles usan el text
  domain `au-wms` y las funciones `__()`/`esc_html_e()`/`esc_attr_e()`,
  listas para traducirse con un archivo `.pot`.

## Extender el plugin

- **Tab "Empresas"**: implementado — ver más abajo.
- **Tab "Usuarios Externos"**: se sugiere crear
  `class-au-repository-usuarios-externos.php` siguiendo el mismo patrón
  de repositorio + servicio + endpoint AJAX ya usado en "Integrantes".

## Tab "Empresas"

Lista usuarios con rol `company`, reutilizando la experiencia del Tab
Integrantes (buscador con debounce, paginación 10/25/50/100, badges de
"Programas" con la misma lógica/clases CSS, y el dropdown de Acciones
reutilizado vía los hooks globales `window.AU_WMS_confirmarLoginComoUsuario`
y `window.AU_WMS_abrirUsermeta` — sin duplicar esa lógica).

**Nota de diseño**: el requerimiento original listaba columnas separadas
para ID Empresa / Empresa / Encargado / Correo / Fecha de creación. Para
mantener "la misma experiencia que Integrantes" (que combina esos datos
en una sola columna "Usuario" compacta), aquí se agruparon igual en una
columna "Empresa" (ID + nombre + correo + encargado + fecha), dejando
Rol, Áreas, Programas y Acciones como columnas independientes — 5
columnas en total, igual que Integrantes. Si prefieres las columnas
separadas tal cual se pidieron originalmente, es un ajuste puntual en
`views/tab-empresas.php` y `assets/js/empresas.js`.

Piezas nuevas: `AU_Repository_Empresas::buscar_listado()` (filtra por
`cap.meta_value LIKE 's:7:"company"'`, cuenta áreas con
`COUNT(DISTINCT wp_paquetes.id)` vía `LEFT JOIN` a `empresa_id`, y
reutiliza las claves `inspira_valor`/`octagono_valor` para que el JS de
"Programas" sea idéntico al de Integrantes) y `AU_Ajax_Empresas` con el
endpoint `au_wms_buscar_empresas`.

## Crear Empresa (Tab Empresas → Acciones)

Asistente por pasos que da de alta una empresa en **Liderazgo (WMS)**,
**Inspira** y **Octágono del sentido**, según lo que se marque en el
primer paso. Piezas: `views/modal-crear-empresa.php`,
`assets/js/crear-empresa.js`, `AU_Crear_Empresa_Service`,
`AU_Programas_Api_Client` y `AU_Ajax_Crear_Empresa`.

Los pasos de áreas se arman en caliente (`pasosActivos()` en el JS): solo
aparece el de los programas elegidos, y "Anterior/Siguiente" recorren esa
secuencia. Los paneles nunca se vacían al navegar, así que volver atrás
conserva lo escrito.

### Orden de creación

1. **WMS siempre.** Con Liderazgo el rol es `company` y se crean sus
   áreas con `AU_Area_Service::crear()`; sin Liderazgo el rol es
   `external_user`, sin áreas y sin licencia. Si WMS falla, no se llama a
   ninguna API externa ni se envía el webhook.
2. **Inspira** y **Octágono**, por su API REST, desde el servidor.
3. **Webhook de credenciales**, con el estado de creación por plataforma.

`AU_Crear_Empresa_Service` replica las reglas de `UDA_Company::create()`
(nombre de empresa y NIT únicos, ascenso de un `external_user` existente,
`GET_LOCK` por nombre, misma generación de contraseña y mismos metadatos)
en vez de delegar en ella: allí `licencia_id` es obligatorio y aquí la
licencia solo existe cuando se eligió Liderazgo.

### Las credenciales NO se comparten entre plataformas

Ninguna de las dos APIs externas acepta recibir una contraseña: cada
sitio genera la suya y la devuelve una sola vez en su respuesta. Lo único
que se reutiliza es el correo (`user_email`), para que sea la misma
identidad en los tres sitios. Por eso el resultado muestra **una
credencial por plataforma**, y el webhook recibe la de WMS en
`email`/`password` más las demás dentro de `programas`.

Los contratos tampoco son iguales: Inspira tiene `apellidos` como campo
propio y Octágono no (allá el encargado va completo en
`nombre_encargado`). `AU_Crear_Empresa_Service::crear_en_programa()` arma
un cuerpo distinto para cada uno.

### Resultado parcial y reintentos

El estado completo de cada creación queda en un transient por usuario
(`au_wms_crear_empresa_<user_id>_<hash>`, 1 hora). Si falla un programa
externo o el webhook, el panel de resultado lo marca como pendiente y
ofrece "Reintentar" solo para esa operación: el reintento lee ese estado
y nunca vuelve a crear la empresa, las áreas ni lo que ya salió bien
(un webhook con respuesta 2xx no se reenvía).

### Configuración

Todo lo editable vive en "Usuarios WMS → Configuración", bloque
*Asistente "Crear Empresa"*: webhook de credenciales, URL y token de cada
API externa, valores predeterminados de la empresa (encargado,
apellidos, contacto, ocupación, plantilla del correo) y de las áreas
(nombre, cupos por programa, licencia inicial de Liderazgo y plazo de
expiración en meses).

Esas 16 claves se declaran una sola vez en
`AU_Settings::CAMPOS_CREAR_EMPRESA` (clave => tipo + valor de fábrica) y
de ahí salen los defaults, el saneado y la validación — a diferencia del
resto de la configuración, que repite un `if ( isset() )` por campo en
tres sitios.

**Los dos tokens salen vacíos de fábrica**, igual que
`inspira_sync_token`/`octagono_sync_token` desde la 1.39.0: no viajan
dentro del ZIP. Mientras falte uno, el paso 1 del asistente lo avisa y
esa API no se llama. El NIT no es configurable: siempre se genera uno
aleatorio y único cuando se deja vacío.

## Cambiar Licencia (Tab Empresas)

Acción **"Cambiar Licencia"** en el submenú "Datos de la empresa" del
dropdown de cada fila. Abre `views/modal-cambiar-licencia.php` con un
select de todas las licencias (`wp_licencias`) más la opción "Sin
licencia", con la licencia actual de la empresa ya preseleccionada.

La licencia actual llega en el propio listado (`licencia_id`, del JOIN
con `wp_licencias`, no de la meta: si la meta apunta a una licencia
borrada llega 0 y el modal abre en "Sin licencia") y viaja en la fila
como `data-licencia-id`, así que abrir el modal no cuesta otra consulta.

Debajo del select se muestran los **accesos de la licencia elegida**:
los 9 atributos `incluir_*` de `AU_Repository_Licencias::CAMPOS_ACCESO`
(los incluidos con visto verde, los demás atenuados) más su duración.
Los 9 se pintan una sola vez en el modal y el JS solo cambia su estado,
con el mapa `AU_WMS_EMPRESAS.licenciasAccesos` (id => duración +
atributos) localizado en `au-wms-empresas`: cambiar de licencia no
dispara ninguna consulta.

Al guardar, `AU_Empresa_Actions_Service::cambiar_licencia()` escribe la
meta `licencia` del usuario — la misma que leen el listado, las áreas
que heredan licencia y el front-end del tema — o la borra si se eligió
"Sin licencia". Endpoint: `au_wms_cambiar_licencia_empresa`.

## Refrescar programas (Tab Empresas)

Existe en dos alcances distintos, con el mismo flujo de
confirmación → lotes → resumen:

| Dónde | Alcance | Acción AJAX de inicio |
|---|---|---|
| Dropdown de acciones **de cada fila** | Esa empresa: su administrador + todos sus integrantes | `au_wms_sync_programas_iniciar` (`empresa_id`) |
| Botón **"Acciones"** de la toolbar | TODAS las cuentas con rol `company`, sin sus integrantes | `au_wms_sync_programas_iniciar_empresas` |

La opción de la toolbar es el equivalente del botón "Refrescar
programas" del Tab Usuarios Externos (que sincroniza solo los
`external_user`): cubre las filas que muestra el tab. Para refrescar
también a los integrantes de una empresa concreta se usa la acción de su
fila. La lista sale de
`AU_Repository_Empresas::obtener_todas_las_empresas_para_sincronizar()`,
con el mismo criterio de rol que el listado del tab.

El resto de esta sección describe la acción por fila. Sincroniza
`inspira`/`octagono` en `wp_usermeta` para el administrador de la
empresa + todos sus integrantes (`subscriber`/`group_leader`), consultando las APIs de
Inspira y Octágono por cada usuario (2 llamadas HTTP independientes;
un error en una no bloquea la otra).

- **Confirmación** con el mensaje exacto pedido, antes de ejecutar nada.
- **Procesamiento por lotes** (5 usuarios por llamada AJAX) vía
  `AU_Sync_Programas_Service`, igual patrón que el asistente de
  importación masiva — necesario porque puede haber decenas de usuarios
  × 2 llamadas HTTP externas cada uno.
- **Modal de progreso bloqueante** (SweetAlert2 sin botón de cierre,
  `allowOutsideClick: false`) mientras corre, con barra de progreso y
  contador "X / Y".
- **Resumen final**: actualizados/eliminados/errores por cada programa,
  más el detalle de errores (correo + motivo) si los hubo.
- **Lógica**: `success == true` → `update_user_meta()` con el `role`
  devuelto; `success == false` → `delete_user_meta()` solo si el
  metadato ya existía; error de conexión → se registra con `error_log()`
  y se reporta en el resumen, sin tocar el metadato.

**Endpoints y tokens configurables** (no hardcodeados): nueva sección
"Sincronización de Programas (Inspira / Octágono)" en
"Usuarios WMS → Configuración", con las URLs y tokens de ambas APIs
como valor por defecto la primera vez. `AU_Sync_Programas_Service` los
lee desde `AU_Settings`, igual que ya hacía `AU_Webhook_Service`.

## Importación masiva de usuarios ("Importar usuarios")

Asistente de 5 pasos en el Tab Integrantes: (1) Empresa/Área + resumen
de cupos, (2) subir CSV/XLS/XLSX, (3) mapeo de columnas con sugerencia
automática, (4) previsualización sin escribir nada en la base de datos
(clasifica cada correo en nuevo / a actualizar / omitido, detecta
duplicados del archivo y bloquea si no hay cupos suficientes), (5)
procesamiento por lotes (20 registros por llamada AJAX) con barra de
progreso y resumen final.

Piezas nuevas:

- `AU_File_Parser` — parser nativo de CSV y XLSX (sin Composer/librerías
  externas; XLSX se lee como ZIP+XML con `ZipArchive`/`SimpleXML`).
- `AU_Column_Mapper` — sugiere el mapeo de columnas por sinónimos.
- `AU_Import_Validator` — clasifica cada fila y guarda el resultado en
  transients (30 min de vida) identificados por un `import_id`.
- `AU_Import_Service` — crea/actualiza usuarios por lotes, inserta en
  `wp_correos_configurados` y dispara los webhooks.
- `AU_Webhook_Service` — llama los 2 webhooks externos (fire-and-forget,
  con log de errores sin bloquear la importación).
- `AU_Ajax_Importacion` — los 4 endpoints AJAX del asistente.

**Limitación conocida**: el formato binario legado **.xls** (Excel
97-2003, pre-2007) no se parsea — escribir un lector binario OLE2
correcto a mano está fuera de alcance razonable sin una librería como
PhpSpreadsheet. Si se sube un `.xls`, el sistema responde pidiendo
convertirlo a `.xlsx` o `.csv` (ambos 100% soportados). Si en algún
momento se necesita soporte real de `.xls`, la opción más simple es
integrar PhpSpreadsheet vía Composer dentro del plugin.

**Nota de escala**: el dataset validado (grupos nuevos/actualizar) se
guarda en un transient de WordPress durante el paso de previsualización.
Para archivos de algunos miles de filas esto funciona bien; para
volúmenes muy grandes (decenas de miles de filas) convendría paginar
también la fase de validación en vez de mantener todo en un solo
transient.

## Configuración (APIs / Webhooks)

Nuevo submenú **"Usuarios WMS → Configuración"**. Permite editar sin
tocar código:

- URL del webhook de usuario nuevo creado.
- URL del webhook de usuario actualizado (external_user → subscriber).
- Token de autorización opcional (se envía como `Authorization: Bearer`
  si se define).
- Interruptor para activar/desactivar el envío de webhooks por completo
  (la importación sigue funcionando igual si se desactiva).
- URL del microservicio que genera el PDF del botón "Descargar
  resultado" (columna Test del Tab Integrantes). Si se deja vacía se
  usa `AU_Settings::DEFAULT_PDF_RESULTADO_TEST_URL`, así el botón nunca
  queda sin endpoint.

Todo se guarda en una sola opción de WordPress (`au_wms_settings`, ver
`AU_Settings`). `AU_Webhook_Service` ya no tiene las URLs fijas en el
código: las lee de aquí, con las mismas URLs originales como valor por
defecto la primera vez que se activa el plugin.

## Ver WP_USERMETA (Tab Integrantes)

Nueva opción **"Ver WP_USERMETA"** en el dropdown de Acciones de cada
fila. Abre un modal con listado paginado (10/25/50/100), buscador en
vivo (Meta Key o Meta Value) y CRUD completo sobre los registros de
`wp_usermeta` de ese usuario:

- **Agregar atributo**: formulario con Meta Key (obligatorio) y Meta
  Value, crea un nuevo registro asociado al `user_id`.
- **Editar / Eliminar**: por fila, con confirmación de SweetAlert2 antes
  de eliminar.
- **Meta Value largo**: se trunca a 120 caracteres en la tabla con un
  botón "Ver más" que abre un modal secundario con el valor completo.

Piezas nuevas: `AU_Repository_Usermeta` (todas las escrituras exigen
`umeta_id` + `user_id` en el WHERE, así un `umeta_id` manipulado de otro
usuario nunca afecta registros ajenos) y `AU_Ajax_Usermeta` con los 4
endpoints (listar/crear/actualizar/eliminar).

**Protección añadida (no pedida explícitamente, pero importante)**: una
lista de claves reservadas de WordPress (`wp_capabilities`,
`wp_user_level`, `session_tokens`, `wp_user-settings`,
`wp_user-settings-time`) no se puede editar ni eliminar desde este
panel — siguen siendo visibles para inspección, pero los botones
Editar/Eliminar quedan deshabilitados en esas filas. El motivo es que
editar/borrar esos campos a mano puede tumbar el acceso o los permisos
del usuario; si en algún momento necesitas editarlos de todas formas,
la lista está centralizada en `AU_Repository_Usermeta::claves_protegidas()`.

## "Comparar usuarios" (Tab Empresas)

Botón "Comparar usuarios" en el dropdown de Acciones de cada empresa.
Modal de 2 pasos:

1. **Pegar correos**: un input de tags (TomSelect, la misma librería
   ya usada para los selects de Empresa/Área) donde cada correo se
   convierte en una etiqueta. Al pegar un bloque con varios correos
   (separados por saltos de línea, comas, punto y coma o espacios —
   el caso típico de copiar una columna de Excel o una lista), se
   intercepta el evento `paste` y se reparten en etiquetas
   individuales en vez de dejarlos como un solo texto; los que no
   pasan una validación simple de formato (`algo@algo.algo`) se
   descartan con un aviso, sin bloquear el resto. Se deduplican y se
   normalizan a minúsculas antes de mostrarse.
2. **Resultado**: al pulsar "Siguiente" se envían los correos al
   backend (`AU_Repository_Usuarios::verificar_pertenencia_por_correo()`),
   que los compara contra `wp_correos_configurados` de TODAS las
   empresas (no solo la indicada) y clasifica cada correo en uno de
   tres estados:
   - 🟢 **Ya está en esta empresa** — con la(s) área(s) a las que
     pertenece dentro de ella (si son varias, separadas por coma).
   - 🟡 **Registrado en otra empresa** — con el nombre de esa otra
     empresa (o empresas, si está en más de una) y sus áreas.
   - 🔴 **No está registrado** — no aparece en absoluto.

   Si el mismo correo está tanto en la empresa indicada como en otra,
   se prioriza "esta empresa" (es la pregunta que importa primero) y
   el detalle solo lista las áreas propias, no las de terceros. El
   resumen final muestra el conteo de los tres estados: "De N correos:
   X en {empresa}, Y en otra empresa, Z sin registrar."

   Los resultados se muestran agrupados en 3 secciones, en este orden
   fijo: primero los que no existen, después los de otra empresa, y
   al final los que ya están en esta empresa — cada sección con su
   propia fila de encabezado (color + conteo) y se omite por completo
   si no tiene ningún correo. Dentro de "ya está en esta empresa" hay
   una cuarta columna, "Test", con el mismo criterio y colores que el
   resto del plugin (verde "Test OK" / rojo "Sin test", según
   `question_test_ids` en `wp_usermeta`) — y esa sección se ordena
   además para mostrar primero a los que NO han hecho el test. Para
   "otra empresa" y "no existe" esa columna no aplica y se muestra
   como "—".

Como en el resto de acciones "Tab Empresas", la comparación resuelve
los nombres de "otras empresas" en un solo lote (sin N llamadas
sueltas a `get_userdata()`), y el resultado es case-insensitive (todo
se normaliza a minúsculas antes de comparar).

**Exportar Excel por grupo**: en el Paso 2, un botón "Exportar Excel"
con un menú de 3 opciones — una por cada estado. Cada opción solo
aparece si ese grupo tiene al menos un correo (si nadie cayó en
"otra empresa", esa opción ni se muestra); si los tres grupos
estuvieran vacíos, se oculta el botón completo. El archivo generado
varía según el grupo:
- **"Ya está en esta empresa"**: 4 columnas — Correo, Estado,
  Detalle y Test — igual que se ve en la tabla, con las mismas
  celdas coloreadas (verde/rojo según el test).
- **"Registrados en otra empresa"** y **"No está registrado"**: solo
  la columna Correo, tal como se pidió explícitamente.

Misma librería y mismo patrón de estilos que "Exportar usuarios"
(`xlsx-js-style`, encabezado navy/blanco); el archivo se llama
`Comparar_{empresa}_{grupo}_{fecha}.xlsx`.

## "Volver al administrador" tras impersonar a un usuario

"Iniciar sesión como usuario" (Tab Empresas y Tab Integrantes — ambos
pasan por `AU_User_Service::iniciar_sesion_como()`) ahora deja una
forma de regresar a la cuenta del administrador sin tener que cerrar
sesión manualmente y volver a loguearse:

- Justo antes de cambiar de sesión se guarda una cookie propia
  (`au_wms_switchback`, httponly, nunca accesible desde JS) con el ID
  del administrador y el ID del usuario impersonado, firmada con
  `wp_hash()` — el mismo mecanismo que usan las cookies de auth del
  núcleo de WordPress — así que no se puede falsificar sin conocer las
  claves secretas de `wp-config.php`.
- Mientras esa cookie siga siendo válida (coincide con el usuario
  actualmente conectado), aparece un enlace **"⇦ Volver a
  {administrador}"** en la barra de administración de WordPress, y
  además una franja fija al pie de página como respaldo por si el
  tema oculta la admin bar o el usuario impersonado la tiene
  deshabilitada.
- El enlace no usa AJAX (para no depender de que el tema cargue
  jQuery en el front-end): es un enlace protegido con nonce que un
  hook en `init` (`AU_Impersonation_Service::manejar_peticion_volver()`)
  intercepta, valida y resuelve el regreso, redirigiendo de vuelta al
  panel de "Usuarios WMS".
- La cookie expira sola a las 12 horas si el administrador no vuelve
  por su cuenta. Al volver, se dispara `au_wms_volvio_a_administrador`
  (mismo criterio que `au_wms_user_impersonated`) por si se quiere
  registrar auditoría de ambos lados del cambio de sesión.

Todo el mecanismo vive en `AU_Impersonation_Service`
(`includes/class-au-impersonation-service.php`), separado de
`AU_User_Service` para no mezclar la lógica de impersonación con la
de "volver".

## Flujo de "Borrar usuario" (rediseñado)

Reemplaza por completo el flujo anterior (confirmación simple + borrado
directo). Ahora:

1. Al hacer clic, **sin confirmación previa**, se ejecuta automáticamente
   "Refrescar programas" para ese usuario (modal bloqueante
   "Refrescando programas del usuario...", reutilizando los mismos
   endpoints `au_wms_sync_programas_iniciar_usuario` /
   `au_wms_sync_programas_procesar_lote` ya existentes, sin mostrar su
   resumen habitual).
2. Con los metadatos `inspira`/`octagono` ya actualizados, se consulta
   el escenario (`AU_User_Service::determinar_escenario_programas()`) y
   se muestra uno de 4 modales:
   - Solo Octágono / Solo Inspira / Ambos → botones **Cancelar** /
     **Dejar de ser usuario WMS**.
   - Ninguno de los dos → botones **Cancelar** / **Borrar
     definitivamente** / **Dejar de ser usuario WMS**.
3. **"Dejar de ser usuario WMS"** (`AU_User_Service::dejar_de_ser_usuario_wms()`,
   dentro de una transacción SQL): elimina `wp_correos_configurados`
   del usuario, recalcula los cupones afectados, borra toda la
   información de LearnDash, borra `question_test_ids`, y deja al
   usuario únicamente con el rol `external_user` — sin tocar
   `inspira`/`octagono`, para que conserve el acceso a esos programas.
4. **"Borrar definitivamente"** (solo disponible sin Inspira/Octágono,
   revalidado también en el servidor por seguridad): mismo flujo de
   antes + limpieza de LearnDash, dentro de una transacción.
5. Ningún paso dispara correos ni notificaciones (`set_role()` y
   `wp_delete_user()` no tienen hooks de email en el núcleo de WP).
6. Tras cualquiera de los dos flujos, la tabla se refresca solo por
   AJAX manteniendo búsqueda/filtros/registros por página, retrocediendo
   de página automáticamente si la actual queda vacía, con el mensaje
   "Actualizando lista de integrantes..." y un aviso específico si el
   refresco de la tabla falla (sin afectar el éxito de la operación).

**Nota de transparencia sobre LearnDash**: no existe una única función
pública de LearnDash para "borrar todo el progreso de un usuario", así
que `AU_User_Service::eliminar_datos_learndash()` limpia por patrones de
`meta_key` en `wp_usermeta` (progreso de curso, quizzes, acceso a
cursos, grupos, certificados) más un par de patrones de respaldo
(`%sfwd%`, `%certificate%`). Si tu instalación de LearnDash guarda algo
con un `meta_key` que no calce con ninguno de esos patrones, no se
eliminará automáticamente — el array `$patrones` de ese método está
pensado para ampliarse fácilmente si detectas algún caso así.

## Exportar usuarios por área (Tab Empresas)

Botón "Exportar usuarios" en el dropdown de Acciones de cada empresa.
Abre un modal de 2 pasos:

1. **Seleccionar áreas**: lista todas las áreas/paquetes de la empresa
   (`AU_Repository_Empresas::get_paquetes_por_empresa()`), cada una con
   un checkbox marcado por defecto, más un toggle "Seleccionar todos".
2. **Previsualización**: al pulsar "Siguiente" se piden al backend los
   integrantes (subscriber/group_leader) de las áreas marcadas
   (`AU_Repository_Usuarios::buscar_para_exportar()`), agrupados por
   (usuario, área) — si un usuario pertenece a varias áreas
   seleccionadas aparece una vez por cada una — y ordenados por nombre
   de área (alfabético). Se muestra el número de usuarios por área y
   el total; el botón "Exportar usuarios" genera el `.xlsx` en el
   navegador (SheetJS, mismo mecanismo que "Resetear contraseñas")
   con las columnas Correo electrónico, Nombre, Área y Test (mismos
   valores "Test OK"/"Sin test" que la columna Test del Tab
   Integrantes, según `question_test_ids` en `wp_usermeta`), sin
   volver a tocar el servidor.

Como en el resto de acciones "Tab Empresas", los IDs de área se
revalidan en la propia consulta SQL (`p.empresa_id = %d`), así que
aunque lleguen manipulados desde el navegador nunca es posible leer
datos de una empresa distinta.

**El Excel generado tiene estilo** (fila de título en amarillo de
marca, encabezado navy/blanco, banda de color alterna cada vez que
cambia el área, celda "Perfil" en verde/rojo y celda "Test" en
verde/gris según corresponda — mismos tokens de color que
`assets/css/admin/`) y trae **filtro (autofiltro) en las columnas
"Área", "Perfil" y "Test"** (`ws['!autofilter'] = { ref: 'C2:E...'
}` — un único rango de autofiltro por hoja no permite saltarse
"Perfil" al quedar entre Área y Test, así que las tres quedan con
flecha de filtro; Correo/Nombre no la tienen). La columna "Perfil"
usa exactamente el mismo criterio que `esta_perfil_completo()` (los
7 campos: first_name, last_name, user_age, user_gender, country,
phone_number, user_position) — igual que la columna Usuario del Tab
Integrantes y el filtro de "Resetear contraseñas". Se probó que
`!freeze` (congelar encabezado) NO se escribe en esta versión base de
SheetJS (0.18.5) — se queda como no soportado, no se incluyó en el
archivo final. Para el estilo/colores, el
handle `au-wms-sheetjs` (compartido por `import.js`,
`reset-password.js` y `exportar-usuarios.js`) pasó de
`xlsx@0.18.5/dist/xlsx.full.min.js` a
`xlsx-js-style@1.2.0/dist/xlsx.min.js` — un fork de SheetJS Community
Edition sobre la misma versión base (0.18.5) que añade soporte de
`cell.s` (fuente/relleno/borde) al escribir, algo que SheetJS
Community "a secas" no permite (es función de pago en su versión
Pro). Como es la misma API y la misma versión base, `import.js` y
`reset-password.js` siguen funcionando sin cambios.

## Sistema de diseño (identidad WMS Latam)

Desde la 1.40.0 los tokens de `assets/css/admin/01-base.css` (`:root`) salen de
la página de inicio de wmslatam.com, medidos en el navegador (estilos
computados, no código copiado):

- **Tipografía**: Plus Jakarta Sans 600 en títulos (página, pestañas,
  modales, nombres en tablas) e Inter 400/500 en la interfaz. Ambas se
  encolan desde Google Fonts solo en las pantallas del plugin.
- **Tinta** `#131a1e`: pestaña activa, botones de confirmación,
  paginación activa. **Azul WMS** `#5571ae`: foco, enlaces y programas
  (Inspira sólido, Octágono suave). **Azul hondo** `#1b3577`: títulos de
  página. **Niebla** `#f1f3f7`: barra de filtros, encabezados de tabla y
  pies de modal.
- **Amarillo** `#f7f05e`: como en el sitio, solo la acción principal de
  cada pantalla, con esquinas rectas.
- **Forma**: tarjetas de 8px con borde y sin sombra; controles y botones
  de 4px a 40px de alto; menús flotantes con la sombra del sitio.
- **Texto en minúscula de oración**: sin etiquetas ni badges en
  mayúsculas.
- **Móvil (≤782px)**: las tablas de Empresas, Integrantes y Usuarios
  Externos se convierten en tarjetas con etiqueta por celda; los filtros
  pasan a dos columnas; los modales ocupan la pantalla; Configuración
  pasa a una columna.

Los colores semánticos (verde = éxito, rojo = peligro) se mantienen. Los
alias antiguos (`--au-navy`, `--au-primary`, `--au-bg`…) siguen
existiendo y apuntan a los valores nuevos.
