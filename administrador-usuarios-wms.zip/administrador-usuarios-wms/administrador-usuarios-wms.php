<?php
/**
 * Plugin Name:       Administrador de Usuarios (WMS Latam)
 * Plugin URI:        https://wmslatam.com
 * Description:       Panel de administración centralizado para gestionar Empresas, Integrantes y Usuarios Externos del ecosistema WMS Latam. Permite buscar, filtrar, eliminar e impersonar usuarios manteniendo la sincronización de cupones de WooCommerce.
 * Version:           1.49.0
 * Author:            WMS Latam
 * Text Domain:       au-wms
 * Domain Path:       /languages
 * Requires PHP:      7.4
 * Requires at least: 5.8
 *
 * @package Administrador_Usuarios_WMS
 */

// Evitar acceso directo al archivo.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Constantes principales del plugin.
 */
define( 'AU_WMS_VERSION', '1.49.0' );
define( 'AU_WMS_PLUGIN_FILE', __FILE__ );
define( 'AU_WMS_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'AU_WMS_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'AU_WMS_PLUGIN_BASENAME', plugin_basename( __FILE__ ) );

/**
 * Autoload / carga de clases del plugin.
 *
 * Se centraliza en AU_Loader siguiendo el mismo patrón utilizado en los
 * demás plugins del ecosistema WMS Latam (Áreas Asignadas, Editar Perfil
 * de Suscriptor, etc.).
 */
require_once AU_WMS_PLUGIN_DIR . 'includes/class-au-loader.php';

/**
 * Punto de entrada del plugin.
 *
 * Se registra en `plugins_loaded` para asegurar que WordPress, WooCommerce
 * y demás dependencias ya estén disponibles antes de inicializar el plugin.
 */
function au_wms_init() {
	AU_Loader::init();
}
add_action( 'plugins_loaded', 'au_wms_init' );

/**
 * Hook de activación: crea capacidades necesarias si aplica y limpia caché.
 */
function au_wms_activate() {
	// Reservado para futuras tareas de instalación (creación de tablas,
	// capacidades personalizadas, etc.). Por ahora no se requiere nada,
	// el plugin trabaja sobre tablas ya existentes del ecosistema WMS.
	flush_rewrite_rules();
}
register_activation_hook( __FILE__, 'au_wms_activate' );

/**
 * Hook de desactivación: limpia transients propios del plugin.
 */
function au_wms_deactivate() {
	global $wpdb;
	$wpdb->query(
		"DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_au_wms_%' OR option_name LIKE '_transient_timeout_au_wms_%'"
	);
	flush_rewrite_rules();
}
register_deactivation_hook( __FILE__, 'au_wms_deactivate' );
