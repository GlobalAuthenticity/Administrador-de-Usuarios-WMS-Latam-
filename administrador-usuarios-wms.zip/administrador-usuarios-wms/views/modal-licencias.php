<?php
/**
 * Modales "Licencias" — primera opción del dropdown "Acciones" del Tab
 * Empresas. Reutilizan los mismos datos, campos y validaciones que
 * `/wp-admin/admin.php?page=licenses` y `licenses-add` del tema
 * (astra-child), pero dentro de "Usuarios WMS" y sin recargar la página.
 *
 * Tres modales independientes, mismo patrón que "Ver Áreas" / "Crear
 * Área/s" / "Editar Área" (ver modal-areas-empresa.php): el listado abre
 * "Crear Licencia" o "Editar Licencia" en un modal aparte, por encima del
 * suyo, y este último se refresca al cerrarlos.
 *
 * Se renderizan a nivel superior (fuera de los paneles de tabs), igual
 * que el resto de modales globales del plugin.
 *
 * @package Administrador_Usuarios_WMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<!-- Modal "Licencias": listado -->
<div class="au-wms-modal-overlay" id="au-wms-licencias-overlay">
	<div class="au-wms-modal au-wms-modal--wide" role="dialog" aria-modal="true" aria-labelledby="au-wms-licencias-title">

		<div class="au-wms-modal-header">
			<div class="au-wms-modal-header-titlewrap">
				<h2 id="au-wms-licencias-title"><?php esc_html_e( 'Licencias', 'au-wms' ); ?></h2>
				<span class="au-wms-badge au-wms-badge--brand" id="au-wms-licencias-total-badge"></span>
			</div>
			<div class="au-wms-modal-header-actions">
				<div class="au-wms-toolbar-dropdown" id="au-wms-licencias-acciones-dropdown">
					<button type="button" class="au-wms-btn au-wms-btn--primary au-wms-toolbar-dropdown-btn" id="au-wms-btn-licencias-acciones">
						<span class="dashicons dashicons-admin-generic"></span>
						<?php esc_html_e( 'Acciones', 'au-wms' ); ?>
						<span class="dashicons dashicons-arrow-down-alt2"></span>
					</button>
					<div class="au-wms-toolbar-dropdown-menu">
						<button type="button" class="au-wms-toolbar-dropdown-item" id="au-wms-licencias-btn-crear">
							<span class="dashicons dashicons-plus-alt2"></span>
							<?php esc_html_e( 'Crear Licencia', 'au-wms' ); ?>
						</button>
						<button type="button" class="au-wms-toolbar-dropdown-item" id="au-wms-licencias-btn-exportar-matriz">
							<span class="dashicons dashicons-media-spreadsheet"></span>
							<?php esc_html_e( 'Descargar matriz comparativa', 'au-wms' ); ?>
						</button>
					</div>
				</div>
				<button type="button" class="au-wms-modal-close" id="au-wms-licencias-close" aria-label="<?php esc_attr_e( 'Cerrar', 'au-wms' ); ?>">
					&times;
				</button>
			</div>
		</div>

		<div class="au-wms-modal-body">

			<div class="au-wms-licencias-toolbar">
				<div class="au-wms-filter au-wms-licencias-toolbar-search">
					<label for="au-wms-licencias-search"><?php esc_html_e( 'Buscar', 'au-wms' ); ?></label>
					<div class="au-wms-search-row">
						<input
							type="text"
							id="au-wms-licencias-search"
							class="au-wms-input"
							placeholder="<?php esc_attr_e( 'Buscar licencia...', 'au-wms' ); ?>"
						/>
						<button type="button" class="au-wms-refresh-btn" id="au-wms-btn-refresh-licencias" title="<?php esc_attr_e( 'Actualizar lista', 'au-wms' ); ?>">
							<span class="dashicons dashicons-update"></span>
						</button>
					</div>
				</div>
				<div class="au-wms-filter au-wms-licencias-toolbar-perpage">
					<label for="au-wms-licencias-per-page"><?php esc_html_e( 'Registros', 'au-wms' ); ?></label>
					<select id="au-wms-licencias-per-page" class="au-wms-select">
						<option value="10">10</option>
						<option value="25">25</option>
						<option value="50">50</option>
						<option value="100">100</option>
					</select>
				</div>
			</div>

			<div class="au-wms-table-wrapper">
				<table class="au-wms-table" id="au-wms-licencias-table">
					<thead>
						<tr>
							<th><?php esc_html_e( 'ID', 'au-wms' ); ?></th>
							<th><?php esc_html_e( 'Nombre', 'au-wms' ); ?></th>
							<th><?php esc_html_e( 'Duración (días)', 'au-wms' ); ?></th>
							<th><?php esc_html_e( 'Accesos', 'au-wms' ); ?></th>
							<th><?php esc_html_e( 'Editar', 'au-wms' ); ?></th>
						</tr>
					</thead>
					<tbody id="au-wms-licencias-body">
						<tr class="au-wms-row-loading">
							<td colspan="5">
								<div class="au-wms-spinner"></div>
								<?php esc_html_e( 'Cargando...', 'au-wms' ); ?>
							</td>
						</tr>
					</tbody>
				</table>
			</div>

			<div class="au-wms-pagination" id="au-wms-licencias-pagination">
				<div class="au-wms-pagination-info">
					<span id="au-wms-licencias-total">0</span>
					<?php esc_html_e( 'registros', 'au-wms' ); ?>
				</div>
				<div class="au-wms-pagination-controls">
					<button type="button" class="au-wms-page-btn" data-page="first" title="<?php esc_attr_e( 'Primera página', 'au-wms' ); ?>">&laquo;</button>
					<button type="button" class="au-wms-page-btn" data-page="prev" title="<?php esc_attr_e( 'Anterior', 'au-wms' ); ?>">&lsaquo;</button>
					<span class="au-wms-pagination-current">
						<?php esc_html_e( 'Página', 'au-wms' ); ?>
						<span id="au-wms-licencias-current-page">1</span>
						<?php esc_html_e( 'de', 'au-wms' ); ?>
						<span id="au-wms-licencias-total-pages">1</span>
					</span>
					<button type="button" class="au-wms-page-btn" data-page="next" title="<?php esc_attr_e( 'Siguiente', 'au-wms' ); ?>">&rsaquo;</button>
					<button type="button" class="au-wms-page-btn" data-page="last" title="<?php esc_attr_e( 'Última página', 'au-wms' ); ?>">&raquo;</button>
				</div>
			</div>

		</div>

		<div class="au-wms-modal-footer">
			<button type="button" class="au-wms-btn au-wms-btn--secondary" id="au-wms-licencias-btn-cerrar-lista">
				<?php esc_html_e( 'Cerrar', 'au-wms' ); ?>
			</button>
		</div>

	</div>
</div>

<!-- Plantilla de fila -->
<template id="au-wms-licencias-row-template">
	<tr data-licencia-id="">
		<td class="au-wms-licencia-row-id"></td>
		<td class="au-wms-licencia-row-nombre"></td>
		<td class="au-wms-licencia-row-duracion"></td>
		<td>
			<ul class="au-wms-licencia-row-accesos" style="margin: 0; padding-left: 18px;"></ul>
		</td>
		<td>
			<button type="button" class="au-wms-btn au-wms-btn--secondary au-wms-licencia-row-editar" data-licencia-id="">
				<?php esc_html_e( 'Editar Licencia', 'au-wms' ); ?>
			</button>
		</td>
	</tr>
</template>

<!-- Plantilla de estado vacío -->
<template id="au-wms-licencias-empty-template">
	<tr class="au-wms-row-empty">
		<td colspan="5">
			<div class="au-wms-empty-state">
				<span class="dashicons dashicons-id-alt"></span>
				<p><?php esc_html_e( 'No se encontraron licencias con ese criterio.', 'au-wms' ); ?></p>
			</div>
		</td>
	</tr>
</template>

<!-- Modal secundario: "Crear Licencia" (mismos campos, orden y valores
     por defecto que astra-child/includes/companies/licenses-add.php) -->
<div class="au-wms-modal-overlay" id="au-wms-crear-licencia-overlay">
	<div class="au-wms-modal au-wms-modal--wide" role="dialog" aria-modal="true" aria-labelledby="au-wms-crear-licencia-title">

		<div class="au-wms-modal-header">
			<h2 id="au-wms-crear-licencia-title"><?php esc_html_e( 'Crear Licencia', 'au-wms' ); ?></h2>
			<button type="button" class="au-wms-modal-close" id="au-wms-crear-licencia-close" aria-label="<?php esc_attr_e( 'Cerrar', 'au-wms' ); ?>">
				&times;
			</button>
		</div>

		<div class="au-wms-modal-body">

			<div class="au-wms-licencia-form-row" style="margin-bottom: 20px;">
				<div class="au-wms-filter au-wms-licencia-form-row-nombre">
					<label for="au-wms-crear-licencia-nombre"><?php esc_html_e( 'Nombre *', 'au-wms' ); ?></label>
					<input type="text" id="au-wms-crear-licencia-nombre" class="au-wms-input" required />
				</div>

				<div class="au-wms-filter au-wms-licencia-form-row-duracion">
					<label for="au-wms-crear-licencia-duracion"><?php esc_html_e( 'Duración (días) *', 'au-wms' ); ?></label>
					<input type="number" id="au-wms-crear-licencia-duracion" class="au-wms-input" required />
				</div>
			</div>

			<h3 style="margin: 0 0 12px;"><?php esc_html_e( '2. Servicios incluidos', 'au-wms' ); ?></h3>
			<div class="au-wms-licencia-accesos-grid">
				<?php foreach ( AU_Repository_Licencias::CAMPOS_FORMULARIO as $campo => $etiqueta ) : ?>
					<div class="au-wms-filter au-wms-settings-toggle-row">
						<label class="au-wms-toggle-label">
							<input type="checkbox" class="au-wms-crear-licencia-acceso-input" data-campo="<?php echo esc_attr( $campo ); ?>" />
							<?php echo esc_html( $etiqueta ); ?>
						</label>
					</div>
				<?php endforeach; ?>
			</div>

			<p class="au-wms-import-help au-wms-hidden" id="au-wms-crear-licencia-error" style="margin-top: 14px;"></p>

		</div>

		<div class="au-wms-modal-footer">
			<button type="button" class="au-wms-btn au-wms-btn--secondary" id="au-wms-crear-licencia-btn-cancelar">
				<?php esc_html_e( 'Cancelar', 'au-wms' ); ?>
			</button>
			<button type="button" class="au-wms-btn au-wms-btn--primary" id="au-wms-crear-licencia-btn-guardar">
				<?php esc_html_e( 'Añadir licencia', 'au-wms' ); ?>
			</button>
		</div>

	</div>
</div>

<!-- Modal secundario: "Editar Licencia" (mismos campos que "Crear
     Licencia"; precargado con los valores reales de la licencia
     seleccionada en el listado) -->
<div class="au-wms-modal-overlay" id="au-wms-editar-licencia-overlay">
	<div class="au-wms-modal au-wms-modal--wide" role="dialog" aria-modal="true" aria-labelledby="au-wms-editar-licencia-title">

		<div class="au-wms-modal-header">
			<h2 id="au-wms-editar-licencia-title"><?php esc_html_e( 'Editar Licencia', 'au-wms' ); ?></h2>
			<button type="button" class="au-wms-modal-close" id="au-wms-editar-licencia-close" aria-label="<?php esc_attr_e( 'Cerrar', 'au-wms' ); ?>">
				&times;
			</button>
		</div>

		<div class="au-wms-modal-body">

			<div class="au-wms-form-warning">
				<span class="dashicons dashicons-warning"></span>
				<p><?php esc_html_e( 'Estás editando una licencia existente: los cambios se aplicarán a todas las empresas y áreas que ya la tengan asignada.', 'au-wms' ); ?></p>
			</div>

			<div class="au-wms-licencia-form-row" style="margin-bottom: 20px;">
				<div class="au-wms-filter au-wms-licencia-form-row-nombre">
					<label for="au-wms-editar-licencia-nombre"><?php esc_html_e( 'Nombre *', 'au-wms' ); ?></label>
					<input type="text" id="au-wms-editar-licencia-nombre" class="au-wms-input" required />
				</div>

				<div class="au-wms-filter au-wms-licencia-form-row-duracion">
					<label for="au-wms-editar-licencia-duracion"><?php esc_html_e( 'Duración (días) *', 'au-wms' ); ?></label>
					<input type="number" id="au-wms-editar-licencia-duracion" class="au-wms-input" required />
				</div>
			</div>

			<h3 style="margin: 0 0 12px;"><?php esc_html_e( '2. Servicios incluidos', 'au-wms' ); ?></h3>
			<div class="au-wms-licencia-accesos-grid">
				<?php foreach ( AU_Repository_Licencias::CAMPOS_FORMULARIO as $campo => $etiqueta ) : ?>
					<div class="au-wms-filter au-wms-settings-toggle-row">
						<label class="au-wms-toggle-label">
							<input type="checkbox" class="au-wms-editar-licencia-acceso-input" data-campo="<?php echo esc_attr( $campo ); ?>" />
							<?php echo esc_html( $etiqueta ); ?>
						</label>
					</div>
				<?php endforeach; ?>
			</div>

			<p class="au-wms-import-help au-wms-hidden" id="au-wms-editar-licencia-error" style="margin-top: 14px;"></p>

		</div>

		<div class="au-wms-modal-footer">
			<button type="button" class="au-wms-btn au-wms-btn--secondary" id="au-wms-editar-licencia-btn-cancelar">
				<?php esc_html_e( 'Cancelar', 'au-wms' ); ?>
			</button>
			<button type="button" class="au-wms-btn au-wms-btn--primary" id="au-wms-editar-licencia-btn-guardar">
				<?php esc_html_e( 'Guardar cambios', 'au-wms' ); ?>
			</button>
		</div>

	</div>
</div>
