<?php
/**
 * Modal "Editar perfil de usuario" (acción de cada fila del Tab
 * Integrantes).
 *
 * Mismos campos y validaciones que el formulario "Mi cuenta" del tema
 * (/mi-cuenta/edit-account/) salvo el correo y la contraseña, que no se
 * editan desde aquí. No toca rol, empresa, áreas, programas ni cursos.
 *
 * @package Administrador_Usuarios_WMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Misma lista (y mismo orden) que el select "País" del formulario del
// tema; ver AU_User_Service::paises_disponibles().
$au_wms_paises = AU_User_Service::paises_disponibles();
?>
<div class="au-wms-modal-overlay" id="au-wms-editar-perfil-overlay">
	<div class="au-wms-modal au-wms-modal--wide" role="dialog" aria-modal="true" aria-labelledby="au-wms-editar-perfil-title">

		<div class="au-wms-modal-header">
			<h2 id="au-wms-editar-perfil-title"><?php esc_html_e( 'Editar perfil de usuario', 'au-wms' ); ?></h2>
			<button type="button" class="au-wms-modal-close" id="au-wms-editar-perfil-close" aria-label="<?php esc_attr_e( 'Cerrar', 'au-wms' ); ?>">
				&times;
			</button>
		</div>

		<div class="au-wms-modal-body">
			<p class="au-wms-import-help" id="au-wms-editar-perfil-correo"></p>

			<div class="au-wms-ce-grid">
				<div class="au-wms-filter">
					<label for="au-wms-ep-first-name"><?php esc_html_e( 'Nombre *', 'au-wms' ); ?></label>
					<input type="text" id="au-wms-ep-first-name" class="au-wms-input" required />
				</div>
				<div class="au-wms-filter">
					<label for="au-wms-ep-last-name"><?php esc_html_e( 'Apellidos *', 'au-wms' ); ?></label>
					<input type="text" id="au-wms-ep-last-name" class="au-wms-input" required />
				</div>
				<div class="au-wms-filter">
					<label for="au-wms-ep-age"><?php esc_html_e( 'Edad *', 'au-wms' ); ?></label>
					<input type="text" id="au-wms-ep-age" class="au-wms-input" required />
				</div>
				<div class="au-wms-filter">
					<label for="au-wms-ep-gender"><?php esc_html_e( 'Género *', 'au-wms' ); ?></label>
					<select id="au-wms-ep-gender" class="au-wms-select">
						<option value=""><?php esc_html_e( 'Seleccione...', 'au-wms' ); ?></option>
						<?php foreach ( AU_User_Service::GENEROS as $au_wms_genero ) : ?>
							<option value="<?php echo esc_attr( $au_wms_genero ); ?>"><?php echo esc_html( $au_wms_genero ); ?></option>
						<?php endforeach; ?>
					</select>
				</div>
				<div class="au-wms-filter">
					<label for="au-wms-ep-country"><?php esc_html_e( 'País *', 'au-wms' ); ?></label>
					<select id="au-wms-ep-country" class="au-wms-select">
						<option value=""><?php esc_html_e( 'Seleccione...', 'au-wms' ); ?></option>
						<?php foreach ( $au_wms_paises as $au_wms_pais ) : ?>
							<option value="<?php echo esc_attr( $au_wms_pais ); ?>"><?php echo esc_html( $au_wms_pais ); ?></option>
						<?php endforeach; ?>
					</select>
				</div>
				<div class="au-wms-filter">
					<label for="au-wms-ep-phone"><?php esc_html_e( 'Número de contacto *', 'au-wms' ); ?></label>
					<input type="text" id="au-wms-ep-phone" class="au-wms-input" required />
				</div>
				<div class="au-wms-filter au-wms-ce-grid-full">
					<label for="au-wms-ep-position"><?php esc_html_e( 'Cargo *', 'au-wms' ); ?></label>
					<input type="text" id="au-wms-ep-position" class="au-wms-input" required />
				</div>
			</div>

			<p class="au-wms-settings-hint" style="margin-top: 12px;">
				<?php esc_html_e( 'El correo y la contraseña no se editan aquí; tienen sus propias acciones en «Cuenta y acceso». Los roles, la empresa, las áreas, los programas y los cursos del usuario no se modifican.', 'au-wms' ); ?>
			</p>

			<p class="au-wms-import-help au-wms-hidden" id="au-wms-editar-perfil-error" style="margin-top: 14px;"></p>
		</div>

		<div class="au-wms-modal-footer">
			<button type="button" class="au-wms-btn au-wms-btn--secondary" id="au-wms-editar-perfil-btn-cancelar">
				<?php esc_html_e( 'Cancelar', 'au-wms' ); ?>
			</button>
			<button type="button" class="au-wms-btn au-wms-btn--primary" id="au-wms-editar-perfil-btn-guardar">
				<?php esc_html_e( 'Guardar cambios', 'au-wms' ); ?>
			</button>
		</div>

	</div>
</div>
