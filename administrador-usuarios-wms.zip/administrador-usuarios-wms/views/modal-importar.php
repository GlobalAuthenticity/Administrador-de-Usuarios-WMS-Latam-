<?php
/**
 * Modal "Importar usuarios" — asistente de importación masiva.
 *
 * Variable disponible: $empresas (heredada del scope de tab-integrantes.php).
 *
 * @package Administrador_Usuarios_WMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="au-wms-modal-overlay" id="au-wms-import-overlay">
	<div class="au-wms-modal" role="dialog" aria-modal="true" aria-labelledby="au-wms-import-title">

		<div class="au-wms-modal-header">
			<h2 id="au-wms-import-title"><?php esc_html_e( 'Importar usuarios', 'au-wms' ); ?></h2>
			<button type="button" class="au-wms-modal-close" id="au-wms-import-close" aria-label="<?php esc_attr_e( 'Cerrar', 'au-wms' ); ?>">
				&times;
			</button>
		</div>

		<div class="au-wms-import-steps">
			<span class="au-wms-import-step-dot is-active" data-step="1">1</span>
			<span class="au-wms-import-step-dot" data-step="2">2</span>
			<span class="au-wms-import-step-dot" data-step="3">3</span>
			<span class="au-wms-import-step-dot" data-step="4">4</span>
			<span class="au-wms-import-step-dot" data-step="5">5</span>
		</div>

		<div class="au-wms-modal-body">

			<!-- Paso 1: Empresa y Área -->
			<div class="au-wms-import-panel is-active" data-step-panel="1">
				<div class="au-wms-filter">
					<label for="au-wms-import-empresa"><?php esc_html_e( 'Empresa', 'au-wms' ); ?></label>
					<select id="au-wms-import-empresa" class="au-wms-select">
						<option value=""><?php esc_html_e( 'Selecciona una empresa', 'au-wms' ); ?></option>
						<?php foreach ( $empresas as $empresa ) : ?>
							<option value="<?php echo esc_attr( $empresa['id'] ); ?>">
								<?php echo esc_html( $empresa['nombre'] ); ?>
							</option>
						<?php endforeach; ?>
					</select>
				</div>

				<div class="au-wms-filter" style="margin-top: 14px;">
					<label for="au-wms-import-area"><?php esc_html_e( 'Área / Paquete', 'au-wms' ); ?></label>
					<select id="au-wms-import-area" class="au-wms-select" disabled>
						<option value=""><?php esc_html_e( 'Selecciona una empresa primero', 'au-wms' ); ?></option>
					</select>
				</div>

				<div class="au-wms-import-area-info" id="au-wms-import-area-info" style="display:none;">
					<strong id="au-wms-import-area-nombre"></strong>
					<span id="au-wms-import-area-cupos"></span>
				</div>
			</div>

			<!-- Paso 2: Subida de archivo -->
			<div class="au-wms-import-panel" data-step-panel="2">
				<div class="au-wms-import-dropzone" id="au-wms-import-dropzone">
					<span class="dashicons dashicons-media-spreadsheet"></span>
					<p><?php esc_html_e( 'Arrastra tu archivo aquí o haz clic para seleccionarlo', 'au-wms' ); ?></p>
					<span class="au-wms-import-dropzone-hint">CSV, XLS, XLSX</span>
					<input type="file" id="au-wms-import-file-input" accept=".csv,.xls,.xlsx" hidden />
				</div>
				<div class="au-wms-import-file-selected" id="au-wms-import-file-selected" style="display:none;">
					<span class="dashicons dashicons-media-spreadsheet"></span>
					<span id="au-wms-import-file-name"></span>
					<button type="button" class="au-wms-import-file-remove" id="au-wms-import-file-remove">&times;</button>
				</div>
			</div>

			<!-- Paso 3: Mapeo de columnas -->
			<div class="au-wms-import-panel" data-step-panel="3">
				<p class="au-wms-import-help">
					<?php esc_html_e( 'Indica qué columna de tu archivo corresponde a cada campo. El sistema ya sugirió las coincidencias más probables.', 'au-wms' ); ?>
				</p>
				<div class="au-wms-table-wrapper">
					<table class="au-wms-table" id="au-wms-import-mapping-table">
						<thead>
							<tr>
								<th><?php esc_html_e( 'Campo del sistema', 'au-wms' ); ?></th>
								<th><?php esc_html_e( 'Columna del archivo', 'au-wms' ); ?></th>
							</tr>
						</thead>
						<tbody id="au-wms-import-mapping-body"></tbody>
					</table>
				</div>
			</div>

			<!-- Paso 4: Previsualización -->
			<div class="au-wms-import-panel" data-step-panel="4">
				<div class="au-wms-import-cupos-warning" id="au-wms-import-cupos-warning" style="display:none;"></div>

				<div class="au-wms-import-summary" id="au-wms-import-summary"></div>

				<div class="au-wms-import-groups">
					<div class="au-wms-import-group">
						<h3 class="au-wms-import-group-title au-wms-import-group-title--success">
							<?php esc_html_e( 'Usuarios nuevos', 'au-wms' ); ?>
							(<span id="au-wms-count-nuevos">0</span>)
						</h3>
						<ul class="au-wms-import-list" id="au-wms-list-nuevos"></ul>
					</div>

					<div class="au-wms-import-group">
						<h3 class="au-wms-import-group-title au-wms-import-group-title--info">
							<?php esc_html_e( 'Usuarios que serán actualizados', 'au-wms' ); ?>
							(<span id="au-wms-count-actualizar">0</span>)
						</h3>
						<ul class="au-wms-import-list" id="au-wms-list-actualizar"></ul>
					</div>

					<div class="au-wms-import-group">
						<h3 class="au-wms-import-group-title au-wms-import-group-title--multiarea">
							<?php esc_html_e( 'Usuarios que se agregarán a esta área', 'au-wms' ); ?>
							(<span id="au-wms-count-agregar-area">0</span>)
						</h3>
						<ul class="au-wms-import-list" id="au-wms-list-agregar-area"></ul>
					</div>

					<div class="au-wms-import-group">
						<h3 class="au-wms-import-group-title au-wms-import-group-title--danger">
							<?php esc_html_e( 'Usuarios omitidos', 'au-wms' ); ?>
							(<span id="au-wms-count-omitidos">0</span>)
						</h3>
						<ul class="au-wms-import-list" id="au-wms-list-omitidos"></ul>
					</div>

					<div class="au-wms-import-group" id="au-wms-import-group-duplicados" style="display:none;">
						<h3 class="au-wms-import-group-title au-wms-import-group-title--warning">
							<?php esc_html_e( 'Duplicados en el archivo', 'au-wms' ); ?>
							(<span id="au-wms-count-duplicados">0</span>)
						</h3>
						<ul class="au-wms-import-list" id="au-wms-list-duplicados"></ul>
					</div>
				</div>
			</div>

			<!-- Paso 5: Progreso y resultados -->
			<div class="au-wms-import-panel" data-step-panel="5">
				<div class="au-wms-import-progress">
					<div class="au-wms-import-progress-bar">
						<div class="au-wms-import-progress-fill" id="au-wms-import-progress-fill"></div>
					</div>
					<p id="au-wms-import-progress-text">0 / 0</p>
				</div>
				<div class="au-wms-import-final-summary" id="au-wms-import-final-summary" style="display:none;"></div>

				<!-- Credenciales de las cuentas creadas en esta importación -->
				<div class="au-wms-import-credenciales" id="au-wms-import-credenciales" style="display:none;">
					<div class="au-wms-import-credenciales-header">
						<h3><?php esc_html_e( 'Cuentas creadas — credenciales de acceso', 'au-wms' ); ?></h3>
						<div class="au-wms-import-credenciales-actions">
							<button type="button" class="au-wms-btn au-wms-btn--secondary" id="au-wms-import-btn-copiar">
								<?php esc_html_e( 'Copiar al portapapeles', 'au-wms' ); ?>
							</button>
							<button type="button" class="au-wms-btn au-wms-btn--primary" id="au-wms-import-btn-excel">
								<?php esc_html_e( 'Descargar Excel', 'au-wms' ); ?>
							</button>
						</div>
					</div>
					<div class="au-wms-table-wrapper au-wms-import-credenciales-wrapper">
						<table class="au-wms-table">
							<thead>
								<tr>
									<th><?php esc_html_e( 'Correo electrónico', 'au-wms' ); ?></th>
									<th><?php esc_html_e( 'Contraseña', 'au-wms' ); ?></th>
								</tr>
							</thead>
							<tbody id="au-wms-import-credenciales-body"></tbody>
						</table>
					</div>
				</div>
			</div>

		</div>

		<div class="au-wms-modal-footer">
			<button type="button" class="au-wms-btn au-wms-btn--secondary" id="au-wms-import-btn-atras" style="display:none;">
				<?php esc_html_e( 'Atrás', 'au-wms' ); ?>
			</button>
			<button type="button" class="au-wms-btn au-wms-btn--secondary" id="au-wms-import-btn-cancelar">
				<?php esc_html_e( 'Cancelar', 'au-wms' ); ?>
			</button>
			<button type="button" class="au-wms-btn au-wms-btn--primary" id="au-wms-import-btn-siguiente">
				<?php esc_html_e( 'Siguiente', 'au-wms' ); ?>
			</button>
			<button type="button" class="au-wms-btn au-wms-btn--primary" id="au-wms-import-btn-continuar" style="display:none;">
				<?php esc_html_e( 'Continuar', 'au-wms' ); ?>
			</button>
			<button type="button" class="au-wms-btn au-wms-btn--primary" id="au-wms-import-btn-finalizar" style="display:none;">
				<?php esc_html_e( 'Finalizar', 'au-wms' ); ?>
			</button>
		</div>

	</div>
</div>
