<?php
/**
 * Modal "Ver más" de la columna Áreas (Tab Empresas) — listado
 * paginado y con búsqueda de las áreas/paquetes de una empresa.
 *
 * Se renderiza a nivel superior (fuera de los paneles de tabs), igual
 * que el modal "Ver WP_USERMETA", para que funcione sin importar cuál
 * tab esté activo.
 *
 * @package Administrador_Usuarios_WMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="au-wms-modal-overlay" id="au-wms-areas-overlay">
	<div class="au-wms-modal au-wms-modal--wide" role="dialog" aria-modal="true" aria-labelledby="au-wms-areas-title">

		<div class="au-wms-modal-header">
			<div class="au-wms-modal-header-titlewrap">
				<h2 id="au-wms-areas-title"><?php esc_html_e( 'Áreas', 'au-wms' ); ?></h2>
				<span class="au-wms-badge au-wms-badge--brand" id="au-wms-areas-total-badge"></span>
			</div>
			<div class="au-wms-modal-header-actions">
				<button type="button" class="au-wms-btn au-wms-btn--primary" id="au-wms-areas-btn-crear">
					<span class="dashicons dashicons-plus-alt2"></span>
					<?php esc_html_e( 'Crear Área/s', 'au-wms' ); ?>
				</button>
				<button type="button" class="au-wms-modal-close" id="au-wms-areas-close" aria-label="<?php esc_attr_e( 'Cerrar', 'au-wms' ); ?>">
					&times;
				</button>
			</div>
		</div>

		<div class="au-wms-modal-body">

			<div class="au-wms-areas-toolbar">
				<div class="au-wms-areas-search-row">
					<input
						type="text"
						id="au-wms-areas-search"
						class="au-wms-input"
						placeholder="<?php esc_attr_e( 'Buscar por área, líder o licencia...', 'au-wms' ); ?>"
					/>
					<button type="button" class="au-wms-refresh-btn" id="au-wms-btn-refresh-areas" title="<?php esc_attr_e( 'Actualizar lista', 'au-wms' ); ?>">
						<span class="dashicons dashicons-update"></span>
					</button>
				</div>
				<div class="au-wms-areas-filters-row">
					<div class="au-wms-areas-filter-group">
						<label for="au-wms-areas-lider-filtro"><?php esc_html_e( 'Líder', 'au-wms' ); ?></label>
						<select id="au-wms-areas-lider-filtro" class="au-wms-select">
							<option value=""><?php esc_html_e( 'Todos los líderes', 'au-wms' ); ?></option>
							<option value="con_lider"><?php esc_html_e( 'Con líder asignado', 'au-wms' ); ?></option>
							<option value="sin_lider"><?php esc_html_e( 'Sin líder asignado', 'au-wms' ); ?></option>
						</select>
					</div>
					<div class="au-wms-areas-filter-group">
						<label for="au-wms-areas-licencia-filtro"><?php esc_html_e( 'Licencia', 'au-wms' ); ?></label>
						<select id="au-wms-areas-licencia-filtro" class="au-wms-select">
							<option value=""><?php esc_html_e( 'Todas las licencias', 'au-wms' ); ?></option>
							<?php foreach ( (array) ( $licencias ?? array() ) as $licencia ) : ?>
								<option value="<?php echo esc_attr( $licencia['id'] ); ?>">
									<?php echo esc_html( $licencia['nombre'] ); ?>
								</option>
							<?php endforeach; ?>
							<option value="sin_licencia"><?php esc_html_e( 'Sin licencia', 'au-wms' ); ?></option>
						</select>
					</div>
					<div class="au-wms-areas-filter-group">
						<label for="au-wms-areas-cursos-filtro"><?php esc_html_e( 'Cursos asignados', 'au-wms' ); ?></label>
						<select id="au-wms-areas-cursos-filtro" class="au-wms-select">
							<option value=""><?php esc_html_e( 'Todas las áreas', 'au-wms' ); ?></option>
							<option value="con_cursos"><?php esc_html_e( 'Con cursos asignados', 'au-wms' ); ?></option>
							<option value="sin_cursos"><?php esc_html_e( 'Sin cursos asignados', 'au-wms' ); ?></option>
						</select>
					</div>
					<div class="au-wms-areas-filter-group au-wms-areas-filter-group--narrow">
						<label for="au-wms-areas-per-page"><?php esc_html_e( 'Registros', 'au-wms' ); ?></label>
						<select id="au-wms-areas-per-page" class="au-wms-select">
							<option value="10">10</option>
							<option value="25">25</option>
							<option value="50">50</option>
							<option value="100">100</option>
						</select>
					</div>
				</div>
			</div>

			<div class="au-wms-table-wrapper">
				<table class="au-wms-table" id="au-wms-areas-table">
					<thead>
						<tr>
							<th><?php esc_html_e( 'Área', 'au-wms' ); ?></th>
							<th><?php esc_html_e( 'Líder', 'au-wms' ); ?></th>
							<th><?php esc_html_e( 'Cursos asignados', 'au-wms' ); ?></th>
							<th><?php esc_html_e( 'Uso / Límite', 'au-wms' ); ?></th>
							<th><?php esc_html_e( 'Acciones', 'au-wms' ); ?></th>
						</tr>
					</thead>
					<tbody id="au-wms-areas-body">
						<tr class="au-wms-row-loading">
							<td colspan="5">
								<div class="au-wms-spinner"></div>
								<?php esc_html_e( 'Cargando...', 'au-wms' ); ?>
							</td>
						</tr>
					</tbody>
				</table>
			</div>

			<div class="au-wms-pagination" id="au-wms-areas-pagination">
				<div class="au-wms-pagination-info">
					<span id="au-wms-areas-total">0</span>
					<?php esc_html_e( 'registros', 'au-wms' ); ?>
				</div>
				<div class="au-wms-pagination-controls">
					<button type="button" class="au-wms-page-btn" data-page="first">&laquo;</button>
					<button type="button" class="au-wms-page-btn" data-page="prev">&lsaquo;</button>
					<span class="au-wms-pagination-current">
						<?php esc_html_e( 'Página', 'au-wms' ); ?>
						<span id="au-wms-areas-current-page">1</span>
						<?php esc_html_e( 'de', 'au-wms' ); ?>
						<span id="au-wms-areas-total-pages">1</span>
					</span>
					<button type="button" class="au-wms-page-btn" data-page="next">&rsaquo;</button>
					<button type="button" class="au-wms-page-btn" data-page="last">&raquo;</button>
				</div>
			</div>

		</div>
	</div>
</div>

<!-- Plantilla de fila -->
<template id="au-wms-areas-row-template">
	<tr data-area-id="">
		<td>
			<div class="au-wms-user-id"></div>
			<div class="au-wms-area-row-nombre"></div>
			<div class="au-wms-area-row-licencia au-wms-user-email"></div>
		</td>
		<td>
			<span class="au-wms-area-row-lider-badge au-wms-badge au-wms-badge--danger-outline au-wms-hidden"></span>
			<div class="au-wms-area-row-lider-nombre au-wms-user-name"></div>
			<div class="au-wms-area-row-lider-email au-wms-user-email"></div>
		</td>
		<td class="au-wms-col-areas">
			<span class="au-wms-areas-count au-wms-area-row-cursos-count"></span>
			<button type="button" class="au-wms-areas-vermas-btn au-wms-area-row-cursos-btn au-wms-hidden"><?php esc_html_e( 'Ver cursos', 'au-wms' ); ?></button>
		</td>
		<td>
			<span class="au-wms-areas-uso-badge"></span>
		</td>
		<td class="au-wms-col-acciones">
			<div class="au-wms-actions-dropdown">
				<button type="button" class="au-wms-actions-btn">
					<?php esc_html_e( 'Acciones', 'au-wms' ); ?>
					<span class="dashicons dashicons-arrow-down-alt2"></span>
				</button>
				<div class="au-wms-actions-menu">
					<button type="button" class="au-wms-area-row-action-editar" data-action="editar-area">
						<span class="dashicons dashicons-edit"></span>
						<?php esc_html_e( 'Editar Área', 'au-wms' ); ?>
					</button>
				</div>
			</div>
		</td>
	</tr>
</template>

<!-- Plantilla de estado vacío -->
<template id="au-wms-areas-empty-template">
	<tr class="au-wms-row-empty">
		<td colspan="5">
			<div class="au-wms-empty-state">
				<span class="dashicons dashicons-category"></span>
				<p><?php esc_html_e( 'Esta empresa no tiene áreas registradas.', 'au-wms' ); ?></p>
			</div>
		</td>
	</tr>
</template>

<!-- Modal secundario: "Crear Área/s" (mismo flujo interno que
     /wp-admin/admin.php?page=companies-package-add: cada área es un
     cupón de WooCommerce — ver AU_Area_Service::crear()). A diferencia
     del formulario original: (1) no hay campo de código, siempre se
     genera uno aleatorio único en el servidor, de forma transparente
     para quien llena el formulario; (2) permite registrar varias áreas
     en una sola operación, con un paso de resumen/confirmación antes de
     crearlas. -->
<div class="au-wms-modal-overlay" id="au-wms-crear-area-overlay">
	<div class="au-wms-modal au-wms-modal--wide" role="dialog" aria-modal="true" aria-labelledby="au-wms-crear-area-title">

		<div class="au-wms-modal-header">
			<h2 id="au-wms-crear-area-title"><?php esc_html_e( 'Crear Área/s', 'au-wms' ); ?></h2>
			<button type="button" class="au-wms-modal-close" id="au-wms-crear-area-close" aria-label="<?php esc_attr_e( 'Cerrar', 'au-wms' ); ?>">
				&times;
			</button>
		</div>

		<div class="au-wms-modal-body">

			<!-- Panel 1: formulario de filas (una fila por área) -->
			<div id="au-wms-crear-area-panel-form">
				<div class="au-wms-crear-area-filas-header">
					<span><?php esc_html_e( 'Nombre del área', 'au-wms' ); ?></span>
					<span><?php esc_html_e( 'N.º de cupos (opcional)', 'au-wms' ); ?></span>
					<span><?php esc_html_e( 'Tipo de licencia (opcional)', 'au-wms' ); ?></span>
					<span></span>
				</div>
				<div id="au-wms-crear-area-filas"></div>

				<button type="button" class="au-wms-btn au-wms-btn--secondary" id="au-wms-crear-area-add-row">
					<?php esc_html_e( '+ Añadir área', 'au-wms' ); ?>
				</button>

				<p class="au-wms-import-help au-wms-hidden" id="au-wms-crear-area-error" style="margin-top: 14px;"></p>
			</div>

			<!-- Panel 2: resumen/confirmación + resultado por área -->
			<div id="au-wms-crear-area-panel-resumen" class="au-wms-hidden">
				<p class="au-wms-import-help" id="au-wms-crear-area-resumen-intro">
					<?php esc_html_e( 'Revisa las áreas que se van a crear:', 'au-wms' ); ?>
				</p>
				<div class="au-wms-table-wrapper">
					<table class="au-wms-table">
						<thead>
							<tr>
								<th><?php esc_html_e( 'Nombre', 'au-wms' ); ?></th>
								<th><?php esc_html_e( 'Cupos', 'au-wms' ); ?></th>
								<th><?php esc_html_e( 'Licencia', 'au-wms' ); ?></th>
								<th><?php esc_html_e( 'Estado', 'au-wms' ); ?></th>
							</tr>
						</thead>
						<tbody id="au-wms-crear-area-resumen-body"></tbody>
					</table>
				</div>
			</div>

		</div>

		<!-- Footer del panel 1 -->
		<div class="au-wms-modal-footer" id="au-wms-crear-area-footer-form">
			<button type="button" class="au-wms-btn au-wms-btn--secondary" id="au-wms-crear-area-btn-cancelar">
				<?php esc_html_e( 'Cancelar', 'au-wms' ); ?>
			</button>
			<button type="button" class="au-wms-btn au-wms-btn--primary" id="au-wms-crear-area-btn-registrar">
				<?php esc_html_e( 'Registrar área/s', 'au-wms' ); ?>
			</button>
		</div>

		<!-- Footer del panel 2 -->
		<div class="au-wms-modal-footer au-wms-hidden" id="au-wms-crear-area-footer-resumen">
			<button type="button" class="au-wms-btn au-wms-btn--secondary" id="au-wms-crear-area-btn-volver">
				&larr; <?php esc_html_e( 'Volver', 'au-wms' ); ?>
			</button>
			<button type="button" class="au-wms-btn au-wms-btn--primary" id="au-wms-crear-area-btn-confirmar">
				<?php esc_html_e( 'Crear áreas', 'au-wms' ); ?>
			</button>
		</div>

	</div>
</div>

<!-- Plantilla de fila (Nombre / Cupos / Licencia / Quitar) -->
<template id="au-wms-crear-area-fila-template">
	<div class="au-wms-crear-area-fila">
		<input type="text" class="au-wms-input au-wms-crear-area-fila-nombre" placeholder="<?php esc_attr_e( 'Nombre del área o grupo de empleados', 'au-wms' ); ?>" />
		<input type="number" class="au-wms-input au-wms-crear-area-fila-cupos" min="1" value="1" />
		<select class="au-wms-select au-wms-crear-area-fila-licencia">
			<option value=""><?php esc_html_e( 'Sin licencia', 'au-wms' ); ?></option>
			<?php foreach ( (array) ( $licencias ?? array() ) as $licencia ) : ?>
				<option value="<?php echo esc_attr( $licencia['id'] ); ?>">
					<?php echo esc_html( $licencia['nombre'] ); ?>
				</option>
			<?php endforeach; ?>
		</select>
		<button type="button" class="au-wms-crear-area-fila-remove" title="<?php esc_attr_e( 'Quitar área', 'au-wms' ); ?>">&times;</button>
	</div>
</template>

<!-- Modal secundario: "Editar Área" (acción "Editar Área" del dropdown
     de cada fila del listado de Áreas). Mismos campos que "Crear
     Área/s" (sin código: el código del cupón no se toca al editar). -->
<div class="au-wms-modal-overlay" id="au-wms-editar-area-overlay">
	<div class="au-wms-modal au-wms-modal--wide" role="dialog" aria-modal="true" aria-labelledby="au-wms-editar-area-title">

		<div class="au-wms-modal-header">
			<h2 id="au-wms-editar-area-title"><?php esc_html_e( 'Editar Área', 'au-wms' ); ?></h2>
			<button type="button" class="au-wms-modal-close" id="au-wms-editar-area-close" aria-label="<?php esc_attr_e( 'Cerrar', 'au-wms' ); ?>">
				&times;
			</button>
		</div>

		<div class="au-wms-modal-body">
			<div class="au-wms-editar-area-fila-header">
				<span><?php esc_html_e( 'Nombre del área', 'au-wms' ); ?></span>
				<span><?php esc_html_e( 'N.º de cupos (opcional)', 'au-wms' ); ?></span>
				<span><?php esc_html_e( 'Tipo de licencia (opcional)', 'au-wms' ); ?></span>
			</div>
			<div class="au-wms-editar-area-fila">
				<input type="text" id="au-wms-editar-area-nombre" class="au-wms-input" placeholder="<?php esc_attr_e( 'Nombre del área o grupo de empleados', 'au-wms' ); ?>" />
				<input type="number" id="au-wms-editar-area-cupos" class="au-wms-input" min="1" placeholder="<?php esc_attr_e( 'Por defecto 1', 'au-wms' ); ?>" />
				<select id="au-wms-editar-area-licencia" class="au-wms-select">
					<option value=""><?php esc_html_e( 'Sin licencia', 'au-wms' ); ?></option>
					<?php foreach ( (array) ( $licencias ?? array() ) as $licencia ) : ?>
						<option value="<?php echo esc_attr( $licencia['id'] ); ?>">
							<?php echo esc_html( $licencia['nombre'] ); ?>
						</option>
					<?php endforeach; ?>
				</select>
			</div>

			<p class="au-wms-import-help au-wms-hidden" id="au-wms-editar-area-error" style="margin-top: 14px;"></p>
		</div>

		<div class="au-wms-modal-footer">
			<button type="button" class="au-wms-btn au-wms-btn--secondary" id="au-wms-editar-area-btn-cancelar">
				<?php esc_html_e( 'Cancelar', 'au-wms' ); ?>
			</button>
			<button type="button" class="au-wms-btn au-wms-btn--primary" id="au-wms-editar-area-btn-guardar">
				<?php esc_html_e( 'Guardar cambios', 'au-wms' ); ?>
			</button>
		</div>

	</div>
</div>
