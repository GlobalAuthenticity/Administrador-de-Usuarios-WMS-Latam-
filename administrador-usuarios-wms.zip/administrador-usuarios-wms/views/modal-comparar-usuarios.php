<?php
/**
 * Modal "Comparar usuarios" (Tab Empresas) — wizard de 2 pasos:
 * 1) Pegar correos (se convierten en tags)  2) Resultado de la
 * comparación contra la empresa (verde = pertenece, rojo = no).
 *
 * @package Administrador_Usuarios_WMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="au-wms-modal-overlay" id="au-wms-compare-users-overlay">
	<div class="au-wms-modal au-wms-modal--wide" role="dialog" aria-modal="true" aria-labelledby="au-wms-compare-users-title">

		<div class="au-wms-modal-header">
			<div>
				<h2 id="au-wms-compare-users-title"><?php esc_html_e( 'Comparar usuarios', 'au-wms' ); ?></h2>
				<p class="au-wms-modal-subtitle" id="au-wms-compare-users-empresa-nombre"></p>
			</div>
			<button type="button" class="au-wms-modal-close" id="au-wms-compare-users-close" aria-label="<?php esc_attr_e( 'Cerrar', 'au-wms' ); ?>">
				&times;
			</button>
		</div>

		<div class="au-wms-import-steps">
			<span class="au-wms-import-step-dot is-active" data-step="1">1</span>
			<span class="au-wms-import-step-dot" data-step="2">2</span>
		</div>

		<div class="au-wms-modal-body">

			<!-- Paso 1: Pegar correos -->
			<div class="au-wms-import-panel is-active" data-step-panel="1">

				<p class="au-wms-import-help"><?php esc_html_e( 'Pega los correos que quieras comparar (separados por saltos de línea, comas o espacios). Cada uno se convertirá en una etiqueta.', 'au-wms' ); ?></p>

				<select id="au-wms-compare-users-input" multiple placeholder="<?php esc_attr_e( 'Pega o escribe correos y presiona Enter…', 'au-wms' ); ?>"></select>

				<div class="au-wms-reset-pwd-toolbar">
					<span class="au-wms-reset-pwd-contador" id="au-wms-compare-users-contador">0 <?php esc_html_e( 'correos', 'au-wms' ); ?></span>
				</div>
			</div>

			<!-- Paso 2: Resultado de la comparación -->
			<div class="au-wms-import-panel" data-step-panel="2">
				<div style="display:flex;align-items:flex-start;justify-content:space-between;gap:12px;flex-wrap:wrap;">
					<h3 style="margin:0;"><?php esc_html_e( 'Resultado de la comparación', 'au-wms' ); ?></h3>

					<div class="au-wms-actions-dropdown" id="au-wms-compare-users-export-dropdown">
						<button type="button" class="au-wms-actions-btn" id="au-wms-compare-users-export-btn">
							<span class="dashicons dashicons-media-spreadsheet"></span>
							<?php esc_html_e( 'Exportar Excel', 'au-wms' ); ?>
							<span class="dashicons dashicons-arrow-down-alt2"></span>
						</button>
						<div class="au-wms-actions-menu">
							<button type="button" class="au-wms-compare-users-export-option" data-estado="esta_empresa">
								<span class="dashicons dashicons-yes-alt"></span>
								<?php esc_html_e( 'Los que ya están en esta empresa', 'au-wms' ); ?>
							</button>
							<button type="button" class="au-wms-compare-users-export-option" data-estado="otra_empresa">
								<span class="dashicons dashicons-randomize"></span>
								<?php esc_html_e( 'Los registrados en otra empresa', 'au-wms' ); ?>
							</button>
							<button type="button" class="au-wms-compare-users-export-option" data-estado="no_existe">
								<span class="dashicons dashicons-dismiss"></span>
								<?php esc_html_e( 'Los que no están registrados', 'au-wms' ); ?>
							</button>
						</div>
					</div>
				</div>

				<p class="au-wms-import-help" id="au-wms-compare-users-resumen"></p>

				<div class="au-wms-table-wrapper au-wms-reset-pwd-table-wrapper">
					<table class="au-wms-table">
						<thead>
							<tr>
								<th><?php esc_html_e( 'Correo', 'au-wms' ); ?></th>
								<th><?php esc_html_e( 'Estado', 'au-wms' ); ?></th>
								<th><?php esc_html_e( 'Detalle', 'au-wms' ); ?></th>
								<th><?php esc_html_e( 'Test', 'au-wms' ); ?></th>
							</tr>
						</thead>
						<tbody id="au-wms-compare-users-results-body"></tbody>
					</table>
				</div>

				<!-- Plantilla de fila de resultado -->
				<template id="au-wms-compare-users-result-row-template">
					<tr>
						<td class="au-wms-compare-users-result-correo"></td>
						<td>
							<span class="au-wms-compare-users-result-badge"></span>
						</td>
						<td class="au-wms-compare-users-result-detalle"></td>
						<td>
							<span class="au-wms-compare-users-result-test"></span>
						</td>
					</tr>
				</template>
			</div>

		</div>

		<div class="au-wms-modal-footer">
			<button type="button" class="au-wms-btn au-wms-btn--secondary" id="au-wms-compare-users-btn-atras" style="display:none;">
				<?php esc_html_e( 'Atrás', 'au-wms' ); ?>
			</button>
			<button type="button" class="au-wms-btn au-wms-btn--secondary" id="au-wms-compare-users-btn-cancelar">
				<?php esc_html_e( 'Cancelar', 'au-wms' ); ?>
			</button>
			<button type="button" class="au-wms-btn au-wms-btn--primary" id="au-wms-compare-users-btn-siguiente" disabled>
				<?php esc_html_e( 'Siguiente', 'au-wms' ); ?>
			</button>
		</div>

	</div>
</div>
