<?php
/**
 * Modal "Crear Empresa" — asistente por pasos del Tab Empresas.
 *
 * Los pasos de áreas (3, 4 y 5) solo aparecen si su programa se eligió
 * en el paso 1; el JS decide la secuencia. Los valores iniciales de los
 * campos salen de "Usuarios WMS → Configuración" ($config_crear_empresa).
 *
 * Variables disponibles: $licencias, $config_crear_empresa.
 *
 * @package Administrador_Usuarios_WMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$cfg = isset( $config_crear_empresa ) ? $config_crear_empresa : AU_Settings::crear_empresa();
?>
<div class="au-wms-modal-overlay" id="au-wms-crear-empresa-overlay">
	<div class="au-wms-modal au-wms-modal--wide" role="dialog" aria-modal="true" aria-labelledby="au-wms-crear-empresa-title">

		<div class="au-wms-modal-header">
			<h2 id="au-wms-crear-empresa-title"><?php esc_html_e( 'Crear Empresa', 'au-wms' ); ?></h2>
			<button type="button" class="au-wms-modal-close" id="au-wms-crear-empresa-close" aria-label="<?php esc_attr_e( 'Cerrar', 'au-wms' ); ?>">
				&times;
			</button>
		</div>

		<div class="au-wms-ce-stepbar">
			<div class="au-wms-import-steps" id="au-wms-crear-empresa-steps"></div>
			<p class="au-wms-ce-paso-actual" id="au-wms-ce-paso-actual"></p>
		</div>

		<div class="au-wms-modal-body">

			<!-- Paso: programas -->
			<div class="au-wms-import-panel is-active" data-ce-panel="programas">
				<h3 class="au-wms-ce-pregunta"><?php esc_html_e( '¿Qué programas deseas agregar?', 'au-wms' ); ?></h3>

				<?php
				// Una tarjeta por programa: el estado "elegido" se ve en el
				// borde y el fondo, no solo en la casilla, porque es la
				// decisión que define el resto del asistente.
				$ce_programas = array(
					'wms'      => array(
						'etiqueta' => __( 'Liderazgo (WMS)', 'au-wms' ),
						'logo'     => 'liderazgo.svg',
					),
					'inspira'  => array(
						'etiqueta' => __( 'Inspira', 'au-wms' ),
						'logo'     => 'inspira.svg',
					),
					'octagono' => array(
						'etiqueta' => __( 'Octágono del sentido', 'au-wms' ),
						'logo'     => 'octagono.svg',
					),
				);
				?>
				<div class="au-wms-ce-programas">
					<?php foreach ( $ce_programas as $clave => $programa ) : ?>
						<label class="au-wms-ce-programa<?php echo 'wms' === $clave ? ' is-selected' : ''; ?>" data-programa="<?php echo esc_attr( $clave ); ?>">
							<input
								type="checkbox"
								class="au-wms-ce-programa-input"
								value="<?php echo esc_attr( $clave ); ?>"
								<?php checked( 'wms', $clave ); ?> />
							<span class="au-wms-ce-programa-icono" aria-hidden="true">
								<?php
								// Logo de marca del programa, en línea para que
								// herede el color del estado de la tarjeta
								// (`currentColor`): gris sin elegir, azul al
								// seleccionarla. Es un asset propio del plugin,
								// no contenido subido por nadie.
								$ce_logo = AU_WMS_PLUGIN_DIR . 'assets/img/programas/' . $programa['logo'];

								if ( file_exists( $ce_logo ) ) {
									echo file_get_contents( $ce_logo ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped, WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
								}
								?>
							</span>
							<span class="au-wms-ce-programa-texto">
								<strong><?php echo esc_html( $programa['etiqueta'] ); ?></strong>
								<?php // Solo se rellena si falta el token de esa API (ver crear-empresa.js). ?>
								<span class="au-wms-ce-programa-aviso au-wms-hidden"></span>
							</span>
						</label>
					<?php endforeach; ?>
				</div>

				<p class="au-wms-settings-hint">
					<?php esc_html_e( 'La empresa y su usuario siempre se registran en WMS. Si no eliges Liderazgo (WMS), ese usuario queda con el rol External User, sin áreas ni licencia de Liderazgo.', 'au-wms' ); ?>
				</p>
			</div>

			<!-- Paso: datos de la empresa -->
			<div class="au-wms-import-panel" data-ce-panel="empresa">
				<p class="au-wms-import-help">
					<?php esc_html_e( 'Solo el nombre de la empresa es obligatorio. Lo que dejes vacío se completa con los valores predeterminados de la configuración.', 'au-wms' ); ?>
				</p>

				<div class="au-wms-ce-grid">
					<div class="au-wms-filter">
						<label for="au-wms-ce-nombre-empresa"><?php esc_html_e( 'Razón social o nombre de la empresa *', 'au-wms' ); ?></label>
						<input type="text" id="au-wms-ce-nombre-empresa" class="au-wms-input" />
					</div>
					<div class="au-wms-filter">
						<label for="au-wms-ce-nit"><?php esc_html_e( 'NIT', 'au-wms' ); ?></label>
						<input type="text" id="au-wms-ce-nit" class="au-wms-input" placeholder="<?php esc_attr_e( 'Se genera uno único si lo dejas vacío', 'au-wms' ); ?>" />
					</div>
					<div class="au-wms-filter">
						<label for="au-wms-ce-nombre-encargado"><?php esc_html_e( 'Nombres del encargado', 'au-wms' ); ?></label>
						<input type="text" id="au-wms-ce-nombre-encargado" class="au-wms-input" placeholder="<?php echo esc_attr( $cfg['crear_empresa_nombre_encargado'] ); ?>" />
					</div>
					<div class="au-wms-filter">
						<label for="au-wms-ce-apellidos"><?php esc_html_e( 'Apellidos del encargado', 'au-wms' ); ?></label>
						<input type="text" id="au-wms-ce-apellidos" class="au-wms-input" placeholder="<?php echo esc_attr( $cfg['crear_empresa_apellidos_encargado'] ); ?>" />
					</div>
					<div class="au-wms-filter">
						<label for="au-wms-ce-contacto"><?php esc_html_e( 'Número de contacto', 'au-wms' ); ?></label>
						<input type="text" id="au-wms-ce-contacto" class="au-wms-input" placeholder="<?php echo esc_attr( $cfg['crear_empresa_contacto'] ); ?>" />
					</div>
					<div class="au-wms-filter">
						<label for="au-wms-ce-ocupacion"><?php esc_html_e( 'Ocupación / Cargo', 'au-wms' ); ?></label>
						<input type="text" id="au-wms-ce-ocupacion" class="au-wms-input" placeholder="<?php echo esc_attr( $cfg['crear_empresa_ocupacion'] ); ?>" />
					</div>
					<div class="au-wms-filter au-wms-ce-grid-full">
						<label for="au-wms-ce-email"><?php esc_html_e( 'Correo electrónico', 'au-wms' ); ?></label>
						<input type="email" id="au-wms-ce-email" class="au-wms-input" placeholder="<?php echo esc_attr( str_replace( '{nombre_empresa_normalizado}', 'nombreempresa', $cfg['crear_empresa_email_plantilla'] ) ); ?>" />
					</div>
					<div class="au-wms-filter au-wms-ce-grid-full au-wms-hidden" id="au-wms-ce-licencia-wrap">
						<label for="au-wms-ce-licencia"><?php esc_html_e( 'Tipo de licencia (Liderazgo)', 'au-wms' ); ?></label>
						<select id="au-wms-ce-licencia" class="au-wms-select">
							<option value=""><?php esc_html_e( 'Sin licencia', 'au-wms' ); ?></option>
							<?php foreach ( (array) ( $licencias ?? array() ) as $licencia ) : ?>
								<option value="<?php echo esc_attr( $licencia['id'] ); ?>"><?php echo esc_html( $licencia['nombre'] ); ?></option>
							<?php endforeach; ?>
						</select>
					</div>
				</div>
			</div>

			<!-- Paso: áreas de Liderazgo (WMS) -->
			<div class="au-wms-import-panel" data-ce-panel="areas_wms">
				<p class="au-wms-import-help"><?php esc_html_e( 'Áreas de Liderazgo (WMS). Debe quedar al menos una.', 'au-wms' ); ?></p>

				<div class="au-wms-crear-area-filas-header au-wms-ce-filas-header--wms">
					<span><?php esc_html_e( 'Nombre del área', 'au-wms' ); ?></span>
					<span><?php esc_html_e( 'N.º de cupos (opcional)', 'au-wms' ); ?></span>
					<span><?php esc_html_e( 'Tipo de licencia (opcional)', 'au-wms' ); ?></span>
					<span></span>
				</div>
				<div class="au-wms-ce-filas" data-ce-filas="areas_wms"></div>

				<button type="button" class="au-wms-btn au-wms-btn--secondary au-wms-ce-add-row" data-ce-add="areas_wms">
					<?php esc_html_e( '+ Añadir área', 'au-wms' ); ?>
				</button>
			</div>

			<!-- Paso: áreas de Inspira -->
			<div class="au-wms-import-panel" data-ce-panel="areas_inspira">
				<p class="au-wms-import-help"><?php esc_html_e( 'Áreas de Inspira. Debe quedar al menos una.', 'au-wms' ); ?></p>

				<div class="au-wms-crear-area-filas-header au-wms-ce-filas-header--externo">
					<span><?php esc_html_e( 'Nombre del área', 'au-wms' ); ?></span>
					<span><?php esc_html_e( 'N.º de cupos', 'au-wms' ); ?></span>
					<span><?php esc_html_e( 'Fecha de expiración', 'au-wms' ); ?></span>
					<span></span>
				</div>
				<div class="au-wms-ce-filas" data-ce-filas="areas_inspira"></div>

				<button type="button" class="au-wms-btn au-wms-btn--secondary au-wms-ce-add-row" data-ce-add="areas_inspira">
					<?php esc_html_e( '+ Añadir área', 'au-wms' ); ?>
				</button>
			</div>

			<!-- Paso: áreas de Octágono -->
			<div class="au-wms-import-panel" data-ce-panel="areas_octagono">
				<p class="au-wms-import-help"><?php esc_html_e( 'Áreas de Octágono del sentido. Debe quedar al menos una.', 'au-wms' ); ?></p>

				<div class="au-wms-crear-area-filas-header au-wms-ce-filas-header--externo">
					<span><?php esc_html_e( 'Nombre del área', 'au-wms' ); ?></span>
					<span><?php esc_html_e( 'N.º de cupos', 'au-wms' ); ?></span>
					<span><?php esc_html_e( 'Fecha de expiración', 'au-wms' ); ?></span>
					<span></span>
				</div>
				<div class="au-wms-ce-filas" data-ce-filas="areas_octagono"></div>

				<button type="button" class="au-wms-btn au-wms-btn--secondary au-wms-ce-add-row" data-ce-add="areas_octagono">
					<?php esc_html_e( '+ Añadir área', 'au-wms' ); ?>
				</button>
			</div>

			<!-- Paso: resumen -->
			<div class="au-wms-import-panel" data-ce-panel="resumen">
				<p class="au-wms-import-help"><?php esc_html_e( 'Revisa los datos antes de crear. Todavía no se ha creado nada.', 'au-wms' ); ?></p>
				<div id="au-wms-ce-resumen"></div>
			</div>

			<!-- Paso: resultado -->
			<div class="au-wms-import-panel" data-ce-panel="resultado">
				<div id="au-wms-ce-resultado"></div>
			</div>

			<p class="au-wms-import-help au-wms-hidden" id="au-wms-ce-error" style="margin-top: 14px;"></p>

		</div>

		<div class="au-wms-modal-footer">
			<button type="button" class="au-wms-btn au-wms-btn--secondary au-wms-hidden" id="au-wms-ce-btn-anterior">
				<?php esc_html_e( 'Anterior', 'au-wms' ); ?>
			</button>
			<button type="button" class="au-wms-btn au-wms-btn--secondary" id="au-wms-ce-btn-cancelar">
				<?php esc_html_e( 'Cancelar', 'au-wms' ); ?>
			</button>
			<button type="button" class="au-wms-btn au-wms-btn--primary" id="au-wms-ce-btn-siguiente">
				<?php esc_html_e( 'Siguiente', 'au-wms' ); ?>
			</button>
			<button type="button" class="au-wms-btn au-wms-btn--primary au-wms-hidden" id="au-wms-ce-btn-crear">
				<?php esc_html_e( 'Crear la empresa', 'au-wms' ); ?>
			</button>
			<button type="button" class="au-wms-btn au-wms-btn--primary au-wms-hidden" id="au-wms-ce-btn-finalizar">
				<?php esc_html_e( 'Finalizar', 'au-wms' ); ?>
			</button>
		</div>

	</div>
</div>

<!-- Plantilla de fila: área de Liderazgo (nombre / cupos / licencia) -->
<template id="au-wms-ce-fila-wms-template">
	<div class="au-wms-crear-area-fila au-wms-ce-fila au-wms-ce-fila--wms">
		<input type="text" class="au-wms-input au-wms-ce-fila-nombre" placeholder="<?php esc_attr_e( 'Nombre del área', 'au-wms' ); ?>" />
		<input type="number" class="au-wms-input au-wms-ce-fila-cupos" min="1" placeholder="1" />
		<select class="au-wms-select au-wms-ce-fila-licencia">
			<option value=""><?php esc_html_e( 'Sin licencia', 'au-wms' ); ?></option>
			<?php foreach ( (array) ( $licencias ?? array() ) as $licencia ) : ?>
				<option value="<?php echo esc_attr( $licencia['id'] ); ?>"><?php echo esc_html( $licencia['nombre'] ); ?></option>
			<?php endforeach; ?>
		</select>
		<button type="button" class="au-wms-crear-area-fila-remove au-wms-ce-fila-remove" aria-label="<?php esc_attr_e( 'Quitar área', 'au-wms' ); ?>">
			<span class="dashicons dashicons-trash"></span>
		</button>
	</div>
</template>

<!-- Plantilla de fila: área de un programa externo (nombre / cupos / fecha) -->
<template id="au-wms-ce-fila-externo-template">
	<div class="au-wms-crear-area-fila au-wms-ce-fila au-wms-ce-fila--externo">
		<input type="text" class="au-wms-input au-wms-ce-fila-nombre" placeholder="<?php esc_attr_e( 'Nombre del área', 'au-wms' ); ?>" />
		<input type="number" class="au-wms-input au-wms-ce-fila-cupos" min="1" placeholder="1" />
		<?php // `min` = hoy: las dos APIs externas rechazan una fecha anterior. ?>
		<input type="date" class="au-wms-input au-wms-ce-fila-fecha" min="<?php echo esc_attr( current_time( 'Y-m-d' ) ); ?>" />
		<button type="button" class="au-wms-crear-area-fila-remove au-wms-ce-fila-remove" aria-label="<?php esc_attr_e( 'Quitar área', 'au-wms' ); ?>">
			<span class="dashicons dashicons-trash"></span>
		</button>
	</div>
</template>
