<?php
/**
 * Modal "Exportar usuarios" (Tab Empresas) — wizard de 2 pasos:
 * 1) Seleccionar áreas  2) Previsualización y exportación a Excel.
 *
 * @package Administrador_Usuarios_WMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="au-wms-modal-overlay" id="au-wms-export-users-overlay">
	<div class="au-wms-modal au-wms-modal--wide" role="dialog" aria-modal="true" aria-labelledby="au-wms-export-users-title">

		<div class="au-wms-modal-header">
			<div>
				<h2 id="au-wms-export-users-title"><?php esc_html_e( 'Exportar usuarios', 'au-wms' ); ?></h2>
				<p class="au-wms-modal-subtitle" id="au-wms-export-users-empresa-nombre"></p>
			</div>
			<button type="button" class="au-wms-modal-close" id="au-wms-export-users-close" aria-label="<?php esc_attr_e( 'Cerrar', 'au-wms' ); ?>">
				&times;
			</button>
		</div>

		<div class="au-wms-import-steps">
			<span class="au-wms-import-step-dot is-active" data-step="1">1</span>
			<span class="au-wms-import-step-dot" data-step="2">2</span>
		</div>

		<div class="au-wms-modal-body">

			<!-- Paso 1: Selección de áreas -->
			<div class="au-wms-import-panel is-active" data-step-panel="1">

				<p class="au-wms-import-help"><?php esc_html_e( 'Selecciona las áreas cuyos usuarios quieres exportar. Todas las áreas vienen preseleccionadas.', 'au-wms' ); ?></p>

				<div class="au-wms-reset-pwd-toolbar">
					<label class="au-wms-checkbox-inline">
						<input type="checkbox" id="au-wms-export-users-check-all" />
						<span id="au-wms-export-users-check-all-label"><?php esc_html_e( 'Seleccionar todos', 'au-wms' ); ?></span>
					</label>
					<span class="au-wms-reset-pwd-contador" id="au-wms-export-users-contador">0 <?php esc_html_e( 'áreas seleccionadas', 'au-wms' ); ?></span>
				</div>

				<div class="au-wms-table-wrapper au-wms-reset-pwd-table-wrapper">
					<table class="au-wms-table">
						<thead>
							<tr>
								<th><?php esc_html_e( 'Área', 'au-wms' ); ?></th>
								<th class="au-wms-col-seleccion"><?php esc_html_e( 'Selección', 'au-wms' ); ?></th>
							</tr>
						</thead>
						<tbody id="au-wms-export-users-areas-body">
							<tr class="au-wms-row-loading">
								<td colspan="2">
									<div class="au-wms-spinner"></div>
									<?php esc_html_e( 'Cargando...', 'au-wms' ); ?>
								</td>
							</tr>
						</tbody>
					</table>
				</div>

				<!-- Plantilla de fila -->
				<template id="au-wms-export-users-area-row-template">
					<tr data-area-id="">
						<td class="au-wms-export-users-area-nombre"></td>
						<td class="au-wms-col-seleccion">
							<input type="checkbox" class="au-wms-export-users-area-checkbox" checked="checked" />
						</td>
					</tr>
				</template>

				<!-- Plantilla de estado vacío -->
				<template id="au-wms-export-users-areas-empty-template">
					<tr class="au-wms-row-empty">
						<td colspan="2">
							<div class="au-wms-empty-state">
								<span class="dashicons dashicons-category"></span>
								<p><?php esc_html_e( 'Esta empresa no tiene áreas registradas.', 'au-wms' ); ?></p>
							</div>
						</td>
					</tr>
				</template>
			</div>

			<!-- Paso 2: Previsualización -->
			<div class="au-wms-import-panel" data-step-panel="2">
				<h3><?php esc_html_e( 'Previsualización de la exportación', 'au-wms' ); ?></h3>
				<p class="au-wms-import-help" id="au-wms-export-users-resumen"></p>

				<div class="au-wms-table-wrapper au-wms-reset-pwd-table-wrapper">
					<table class="au-wms-table">
						<thead>
							<tr>
								<th><?php esc_html_e( 'Área', 'au-wms' ); ?></th>
								<th><?php esc_html_e( 'Usuarios a exportar', 'au-wms' ); ?></th>
							</tr>
						</thead>
						<tbody id="au-wms-export-users-preview-body"></tbody>
					</table>
				</div>

				<!-- Plantilla de fila de previsualización -->
				<template id="au-wms-export-users-preview-row-template">
					<tr>
						<td class="au-wms-export-users-preview-area"></td>
						<td class="au-wms-export-users-preview-total"></td>
					</tr>
				</template>
			</div>

		</div>

		<div class="au-wms-modal-footer">
			<button type="button" class="au-wms-btn au-wms-btn--secondary" id="au-wms-export-users-btn-atras" style="display:none;">
				<?php esc_html_e( 'Atrás', 'au-wms' ); ?>
			</button>
			<button type="button" class="au-wms-btn au-wms-btn--secondary" id="au-wms-export-users-btn-cancelar">
				<?php esc_html_e( 'Cancelar', 'au-wms' ); ?>
			</button>
			<button type="button" class="au-wms-btn au-wms-btn--primary" id="au-wms-export-users-btn-siguiente" disabled>
				<?php esc_html_e( 'Siguiente', 'au-wms' ); ?>
			</button>
			<button type="button" class="au-wms-btn au-wms-btn--primary" id="au-wms-export-users-btn-exportar" style="display:none;">
				<?php esc_html_e( 'Exportar usuarios', 'au-wms' ); ?>
			</button>
		</div>

	</div>
</div>
