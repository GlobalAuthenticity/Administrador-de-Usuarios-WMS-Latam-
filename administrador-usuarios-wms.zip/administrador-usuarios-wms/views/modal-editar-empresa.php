<?php
/**
 * Modal "Editar empresa" (acción de cada fila del Tab Empresas).
 *
 * Mismos campos que el formulario "Registrar Empresa" del tema
 * (/wp-admin/admin.php?page=companies-add) salvo dos: el correo y el
 * tipo de licencia. El correo es la identidad de la cuenta en los tres
 * programas, y la licencia tiene su propia acción ("Cambiar Licencia").
 * Tampoco se tocan áreas, integrantes ni asignaciones.
 *
 * @package Administrador_Usuarios_WMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="au-wms-modal-overlay" id="au-wms-editar-empresa-overlay">
	<div class="au-wms-modal au-wms-modal--wide" role="dialog" aria-modal="true" aria-labelledby="au-wms-editar-empresa-title">

		<div class="au-wms-modal-header">
			<h2 id="au-wms-editar-empresa-title"><?php esc_html_e( 'Editar empresa', 'au-wms' ); ?></h2>
			<button type="button" class="au-wms-modal-close" id="au-wms-editar-empresa-close" aria-label="<?php esc_attr_e( 'Cerrar', 'au-wms' ); ?>">
				&times;
			</button>
		</div>

		<div class="au-wms-modal-body">
			<p class="au-wms-import-help" id="au-wms-editar-empresa-correo"></p>

			<div class="au-wms-ce-grid">
				<div class="au-wms-filter au-wms-ce-grid-full">
					<label for="au-wms-ee-nombre-empresa"><?php esc_html_e( 'Razón social o nombre de la empresa *', 'au-wms' ); ?></label>
					<input type="text" id="au-wms-ee-nombre-empresa" class="au-wms-input" required />
				</div>
				<div class="au-wms-filter">
					<label for="au-wms-ee-nit"><?php esc_html_e( 'NIT', 'au-wms' ); ?></label>
					<input type="text" id="au-wms-ee-nit" class="au-wms-input" />
				</div>
				<div class="au-wms-filter">
					<label for="au-wms-ee-contacto"><?php esc_html_e( 'Número de contacto', 'au-wms' ); ?></label>
					<input type="text" id="au-wms-ee-contacto" class="au-wms-input" />
				</div>
				<div class="au-wms-filter">
					<label for="au-wms-ee-nombre-encargado"><?php esc_html_e( 'Nombres del encargado', 'au-wms' ); ?></label>
					<input type="text" id="au-wms-ee-nombre-encargado" class="au-wms-input" />
				</div>
				<div class="au-wms-filter">
					<label for="au-wms-ee-apellidos"><?php esc_html_e( 'Apellidos del encargado', 'au-wms' ); ?></label>
					<input type="text" id="au-wms-ee-apellidos" class="au-wms-input" />
				</div>
				<div class="au-wms-filter au-wms-ce-grid-full">
					<label for="au-wms-ee-ocupacion"><?php esc_html_e( 'Ocupación / Cargo', 'au-wms' ); ?></label>
					<input type="text" id="au-wms-ee-ocupacion" class="au-wms-input" />
				</div>
			</div>

			<p class="au-wms-settings-hint" style="margin-top: 12px;">
				<?php esc_html_e( 'El correo y el tipo de licencia no se editan aquí: el correo identifica la cuenta en los tres programas, y la licencia se cambia con la acción «Cambiar Licencia».', 'au-wms' ); ?>
			</p>

			<p class="au-wms-import-help au-wms-hidden" id="au-wms-editar-empresa-error" style="margin-top: 14px;"></p>
		</div>

		<div class="au-wms-modal-footer">
			<button type="button" class="au-wms-btn au-wms-btn--secondary" id="au-wms-editar-empresa-btn-cancelar">
				<?php esc_html_e( 'Cancelar', 'au-wms' ); ?>
			</button>
			<button type="button" class="au-wms-btn au-wms-btn--primary" id="au-wms-editar-empresa-btn-guardar">
				<?php esc_html_e( 'Guardar cambios', 'au-wms' ); ?>
			</button>
		</div>

	</div>
</div>
