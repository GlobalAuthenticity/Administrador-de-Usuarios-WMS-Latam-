<?php
/**
 * Modal "Resetear contraseñas" (Tab Empresas) — wizard de 4 pasos:
 * 1) Seleccionar usuarios  2) Confirmar  3) Procesar  4) Resultados.
 *
 * @package Administrador_Usuarios_WMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="au-wms-modal-overlay" id="au-wms-reset-pwd-overlay">
	<div class="au-wms-modal au-wms-modal--wide" role="dialog" aria-modal="true" aria-labelledby="au-wms-reset-pwd-title">

		<div class="au-wms-modal-header">
			<div>
				<h2 id="au-wms-reset-pwd-title"><?php esc_html_e( 'Resetear contraseñas', 'au-wms' ); ?></h2>
				<p class="au-wms-modal-subtitle" id="au-wms-reset-pwd-empresa-nombre"></p>
			</div>
			<button type="button" class="au-wms-modal-close" id="au-wms-reset-pwd-close" aria-label="<?php esc_attr_e( 'Cerrar', 'au-wms' ); ?>">
				&times;
			</button>
		</div>

		<div class="au-wms-import-steps">
			<span class="au-wms-import-step-dot is-active" data-step="1">1</span>
			<span class="au-wms-import-step-dot" data-step="2">2</span>
			<span class="au-wms-import-step-dot" data-step="3">3</span>
			<span class="au-wms-import-step-dot" data-step="4">4</span>
		</div>

		<div class="au-wms-modal-body">

			<!-- Paso 1: Selección de usuarios -->
			<div class="au-wms-import-panel is-active" data-step-panel="1">

				<div class="au-wms-filters au-wms-reset-pwd-filters">
					<div class="au-wms-filter">
						<label><?php esc_html_e( 'Área', 'au-wms' ); ?></label>
						<div class="au-wms-checkbox-dropdown" id="au-wms-reset-pwd-area-dropdown">
							<button type="button" class="au-wms-checkbox-dropdown-btn" id="au-wms-reset-pwd-area-btn">
								<span id="au-wms-reset-pwd-area-label"><?php esc_html_e( 'Todas las áreas', 'au-wms' ); ?></span>
								<span class="dashicons dashicons-arrow-down-alt2"></span>
							</button>
							<div class="au-wms-checkbox-dropdown-menu" id="au-wms-reset-pwd-area-menu"></div>
						</div>
					</div>

					<div class="au-wms-filter">
						<label for="au-wms-reset-pwd-perfil"><?php esc_html_e( 'Estado del perfil', 'au-wms' ); ?></label>
						<select id="au-wms-reset-pwd-perfil" class="au-wms-select">
							<option value=""><?php esc_html_e( 'Todos', 'au-wms' ); ?></option>
							<option value="completo"><?php esc_html_e( 'Perfil completado', 'au-wms' ); ?></option>
							<option value="incompleto"><?php esc_html_e( 'Perfil incompleto', 'au-wms' ); ?></option>
						</select>
					</div>
				</div>

				<div class="au-wms-reset-pwd-toolbar">
					<label class="au-wms-checkbox-inline">
						<input type="checkbox" id="au-wms-reset-pwd-check-all" />
						<span id="au-wms-reset-pwd-check-all-label"><?php esc_html_e( 'Seleccionar todos', 'au-wms' ); ?></span>
					</label>
					<span class="au-wms-reset-pwd-contador" id="au-wms-reset-pwd-contador">0 <?php esc_html_e( 'seleccionados', 'au-wms' ); ?></span>
				</div>

				<div class="au-wms-table-wrapper au-wms-reset-pwd-table-wrapper">
					<table class="au-wms-table">
						<thead>
							<tr>
								<th><?php esc_html_e( 'Usuario', 'au-wms' ); ?></th>
								<th><?php esc_html_e( 'Área', 'au-wms' ); ?></th>
								<th class="au-wms-col-seleccion"><?php esc_html_e( 'Selección', 'au-wms' ); ?></th>
							</tr>
						</thead>
						<tbody id="au-wms-reset-pwd-body">
							<tr class="au-wms-row-loading">
								<td colspan="3">
									<div class="au-wms-spinner"></div>
									<?php esc_html_e( 'Cargando...', 'au-wms' ); ?>
								</td>
							</tr>
						</tbody>
					</table>
				</div>

				<!-- Plantilla de fila -->
				<template id="au-wms-reset-pwd-row-template">
					<tr data-user-id="">
						<td>
							<div class="au-wms-user-name au-wms-reset-pwd-nombre"></div>
							<div class="au-wms-user-email au-wms-reset-pwd-correo"></div>
							<span class="au-wms-badge au-wms-reset-pwd-perfil-badge"></span>
						</td>
						<td class="au-wms-reset-pwd-area"></td>
						<td class="au-wms-col-seleccion">
							<input type="checkbox" class="au-wms-reset-pwd-checkbox" />
						</td>
					</tr>
				</template>

				<!-- Plantilla de estado vacío -->
				<template id="au-wms-reset-pwd-empty-template">
					<tr class="au-wms-row-empty">
						<td colspan="3">
							<div class="au-wms-empty-state">
								<span class="dashicons dashicons-admin-users"></span>
								<p><?php esc_html_e( 'No hay usuarios que coincidan con los filtros seleccionados.', 'au-wms' ); ?></p>
							</div>
						</td>
					</tr>
				</template>
			</div>

			<!-- Paso 2: Confirmación -->
			<div class="au-wms-import-panel" data-step-panel="2">
				<h3><?php esc_html_e( 'Confirmar reseteo de contraseñas', 'au-wms' ); ?></h3>
				<p class="au-wms-import-help" id="au-wms-reset-pwd-resumen-confirmacion"></p>

				<div class="au-wms-table-wrapper au-wms-reset-pwd-table-wrapper">
					<table class="au-wms-table">
						<thead>
							<tr>
								<th><?php esc_html_e( 'Correo electrónico', 'au-wms' ); ?></th>
								<th><?php esc_html_e( 'Nombre', 'au-wms' ); ?></th>
								<th><?php esc_html_e( 'Área', 'au-wms' ); ?></th>
							</tr>
						</thead>
						<tbody id="au-wms-reset-pwd-confirm-body"></tbody>
					</table>
				</div>
			</div>

			<!-- Paso 3: Procesamiento -->
			<div class="au-wms-import-panel" data-step-panel="3">
				<div class="au-wms-import-progress">
					<div class="au-wms-spinner au-wms-reset-pwd-spinner"></div>
					<p id="au-wms-reset-pwd-progress-text"><?php esc_html_e( 'Reseteando contraseñas...', 'au-wms' ); ?></p>
				</div>
			</div>

			<!-- Paso 4: Resultados -->
			<div class="au-wms-import-panel" data-step-panel="4">
				<div class="au-wms-import-final-summary" id="au-wms-reset-pwd-final-summary"></div>

				<div class="au-wms-import-credenciales" id="au-wms-reset-pwd-credenciales">
					<div class="au-wms-import-credenciales-header">
						<h3><?php esc_html_e( 'Nuevas contraseñas', 'au-wms' ); ?></h3>
						<div class="au-wms-import-credenciales-actions">
							<button type="button" class="au-wms-btn au-wms-btn--secondary" id="au-wms-reset-pwd-btn-copiar">
								<?php esc_html_e( 'Copiar lista', 'au-wms' ); ?>
							</button>
							<button type="button" class="au-wms-btn au-wms-btn--secondary" id="au-wms-reset-pwd-btn-enviar-correos">
								<?php esc_html_e( 'Enviar correos', 'au-wms' ); ?>
							</button>
							<button type="button" class="au-wms-btn au-wms-btn--primary" id="au-wms-reset-pwd-btn-excel">
								<?php esc_html_e( 'Descargar Excel', 'au-wms' ); ?>
							</button>
						</div>
					</div>
					<div class="au-wms-table-wrapper au-wms-import-credenciales-wrapper">
						<table class="au-wms-table">
							<thead>
								<tr>
									<th><?php esc_html_e( 'Correo electrónico', 'au-wms' ); ?></th>
									<th><?php esc_html_e( 'Nueva contraseña', 'au-wms' ); ?></th>
									<th><?php esc_html_e( 'Área', 'au-wms' ); ?></th>
								</tr>
							</thead>
							<tbody id="au-wms-reset-pwd-credenciales-body"></tbody>
						</table>
					</div>
				</div>
			</div>

		</div>

		<div class="au-wms-modal-footer">
			<button type="button" class="au-wms-btn au-wms-btn--secondary" id="au-wms-reset-pwd-btn-atras" style="display:none;">
				<?php esc_html_e( 'Atrás', 'au-wms' ); ?>
			</button>
			<button type="button" class="au-wms-btn au-wms-btn--secondary" id="au-wms-reset-pwd-btn-cancelar">
				<?php esc_html_e( 'Cancelar', 'au-wms' ); ?>
			</button>
			<button type="button" class="au-wms-btn au-wms-btn--primary" id="au-wms-reset-pwd-btn-siguiente" disabled>
				<?php esc_html_e( 'Siguiente', 'au-wms' ); ?>
			</button>
			<button type="button" class="au-wms-btn au-wms-btn--primary" id="au-wms-reset-pwd-btn-ejecutar" style="display:none;">
				<?php esc_html_e( 'Resetear contraseñas', 'au-wms' ); ?>
			</button>
			<button type="button" class="au-wms-btn au-wms-btn--primary" id="au-wms-reset-pwd-btn-finalizar" style="display:none;">
				<?php esc_html_e( 'Finalizar', 'au-wms' ); ?>
			</button>
		</div>

	</div>
</div>
