<?php
/**
 * Modal "Cambiar Licencia" (acción de cada fila del Tab Empresas).
 *
 * El select se llena con las mismas licencias que el filtro del listado
 * ($licencias, de AU_Repository_Empresas::get_licencias()); el JS marca
 * como seleccionada la licencia actual de la empresa al abrirlo.
 *
 * @package Administrador_Usuarios_WMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="au-wms-modal-overlay" id="au-wms-cambiar-licencia-overlay">
	<div class="au-wms-modal" role="dialog" aria-modal="true" aria-labelledby="au-wms-cambiar-licencia-title">

		<div class="au-wms-modal-header">
			<h2 id="au-wms-cambiar-licencia-title"><?php esc_html_e( 'Cambiar Licencia', 'au-wms' ); ?></h2>
			<button type="button" class="au-wms-modal-close" id="au-wms-cambiar-licencia-close" aria-label="<?php esc_attr_e( 'Cerrar', 'au-wms' ); ?>">
				&times;
			</button>
		</div>

		<div class="au-wms-modal-body">
			<p class="au-wms-import-help" id="au-wms-cambiar-licencia-empresa"></p>

			<div class="au-wms-filter">
				<label for="au-wms-cambiar-licencia-select"><?php esc_html_e( 'Licencia de la empresa', 'au-wms' ); ?></label>
				<select id="au-wms-cambiar-licencia-select" class="au-wms-select">
					<option value=""><?php esc_html_e( 'Sin licencia', 'au-wms' ); ?></option>
					<?php foreach ( (array) ( $licencias ?? array() ) as $licencia ) : ?>
						<option value="<?php echo esc_attr( $licencia['id'] ); ?>">
							<?php echo esc_html( $licencia['nombre'] ); ?>
						</option>
					<?php endforeach; ?>
				</select>
			</div>

			<p class="au-wms-settings-hint" style="margin-top: 10px;">
				<?php esc_html_e( 'Las áreas que no tengan una licencia propia pasarán a heredar esta.', 'au-wms' ); ?>
			</p>

			<?php
			// Los 9 atributos se pintan una sola vez (no una lista por
			// licencia): el JS marca cada uno como incluido o no según la
			// licencia elegida, con los datos que ya vienen en
			// AU_WMS_EMPRESAS.licenciasAccesos.
			?>
			<div class="au-wms-licencia-detalle" id="au-wms-cambiar-licencia-detalle" hidden>
				<div class="au-wms-licencia-detalle-head">
					<span class="au-wms-licencia-detalle-titulo"><?php esc_html_e( 'Accesos de la licencia', 'au-wms' ); ?></span>
					<span class="au-wms-licencia-detalle-duracion" id="au-wms-cambiar-licencia-duracion"></span>
				</div>
				<ul class="au-wms-licencia-detalle-lista">
					<?php foreach ( AU_Repository_Licencias::CAMPOS_ACCESO as $campo => $etiqueta ) : ?>
						<li data-campo="<?php echo esc_attr( $campo ); ?>">
							<span class="dashicons au-wms-licencia-detalle-icono" aria-hidden="true"></span>
							<span><?php echo esc_html( $etiqueta ); ?></span>
						</li>
					<?php endforeach; ?>
				</ul>
			</div>

			<p class="au-wms-licencia-detalle-vacio" id="au-wms-cambiar-licencia-detalle-vacio">
				<?php esc_html_e( 'La empresa quedará sin accesos asociados a una licencia.', 'au-wms' ); ?>
			</p>

			<p class="au-wms-import-help au-wms-hidden" id="au-wms-cambiar-licencia-error" style="margin-top: 14px;"></p>
		</div>

		<div class="au-wms-modal-footer">
			<button type="button" class="au-wms-btn au-wms-btn--secondary" id="au-wms-cambiar-licencia-btn-cancelar">
				<?php esc_html_e( 'Cancelar', 'au-wms' ); ?>
			</button>
			<button type="button" class="au-wms-btn au-wms-btn--primary" id="au-wms-cambiar-licencia-btn-guardar">
				<?php esc_html_e( 'Guardar cambios', 'au-wms' ); ?>
			</button>
		</div>

	</div>
</div>
