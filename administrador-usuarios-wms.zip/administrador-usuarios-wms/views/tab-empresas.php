<?php
/**
 * Tab "Empresas" — listado de usuarios con rol `company`.
 *
 * Reutiliza la misma experiencia del Tab Integrantes: buscador,
 * paginación, badges de "Programas" y el dropdown de acciones (aquí
 * limitado a "Iniciar sesión como usuario" y "Ver WP_USERMETA").
 *
 * @package Administrador_Usuarios_WMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<section id="au-wms-tab-empresas" class="au-wms-panel is-active" role="tabpanel" aria-labelledby="empresas">

	<div class="au-wms-empresas-toolbar">
		<?php
		// El aviso comparte fila con el botón "Acciones" (ocupa el hueco
		// libre de la izquierda) en vez de llevarse una fila entera.
		$aviso_seccion = __( 'Aquí se muestran las empresas que tienen asignado el programa Liderazgo (WMS).', 'au-wms' );
		require AU_WMS_PLUGIN_DIR . 'views/partial-aviso-seccion.php';
		?>
		<div class="au-wms-toolbar-dropdown" id="au-wms-empresas-acciones-dropdown">
			<button type="button" class="au-wms-btn au-wms-btn--primary au-wms-toolbar-dropdown-btn" id="au-wms-btn-empresas-acciones">
				<span class="dashicons dashicons-admin-generic"></span>
				<?php esc_html_e( 'Acciones', 'au-wms' ); ?>
				<span class="dashicons dashicons-arrow-down-alt2"></span>
			</button>
			<div class="au-wms-toolbar-dropdown-menu">
				<button type="button" class="au-wms-toolbar-dropdown-item" id="au-wms-btn-abrir-crear-empresa">
					<span class="dashicons dashicons-building"></span>
					<?php esc_html_e( 'Crear Empresa', 'au-wms' ); ?>
				</button>
				<button type="button" class="au-wms-toolbar-dropdown-item" id="au-wms-btn-abrir-licencias">
					<span class="dashicons dashicons-id-alt"></span>
					<?php esc_html_e( 'Licencias', 'au-wms' ); ?>
				</button>
				<?php
				// Refresca los programas de TODAS las cuentas con rol
				// `company` (las filas de este tab), no los de sus
				// integrantes: para eso está la acción "Refrescar
				// programas" de cada fila.
				?>
				<button type="button" class="au-wms-toolbar-dropdown-item" id="au-wms-btn-refrescar-empresas">
					<span class="dashicons dashicons-update"></span>
					<?php esc_html_e( 'Refrescar programas', 'au-wms' ); ?>
				</button>
			</div>
		</div>
	</div>

	<div class="au-wms-filters">
		<div class="au-wms-filter au-wms-filter--search">
			<label for="au-wms-empresas-search"><?php esc_html_e( 'Buscar', 'au-wms' ); ?></label>
			<div class="au-wms-search-row">
				<input
					type="text"
					id="au-wms-empresas-search"
					class="au-wms-input"
					placeholder="<?php esc_attr_e( 'Nombre de la empresa o del encargado...', 'au-wms' ); ?>"
				/>
				<button type="button" class="au-wms-refresh-btn" id="au-wms-btn-refresh-empresas" title="<?php esc_attr_e( 'Actualizar lista', 'au-wms' ); ?>">
					<span class="dashicons dashicons-update"></span>
				</button>
			</div>
		</div>

		<div class="au-wms-filter">
			<label for="au-wms-empresas-licencia"><?php esc_html_e( 'Licencia', 'au-wms' ); ?></label>
			<select id="au-wms-empresas-licencia" class="au-wms-select">
				<option value=""><?php esc_html_e( 'Todas las licencias', 'au-wms' ); ?></option>
				<?php foreach ( $licencias as $licencia ) : ?>
					<option value="<?php echo esc_attr( $licencia['id'] ); ?>">
						<?php echo esc_html( $licencia['nombre'] ); ?>
					</option>
				<?php endforeach; ?>
				<option value="sin_licencia"><?php esc_html_e( 'Sin licencia', 'au-wms' ); ?></option>
			</select>
		</div>

		<div class="au-wms-filter">
			<label for="au-wms-empresas-programa"><?php esc_html_e( 'Programa', 'au-wms' ); ?></label>
			<select id="au-wms-empresas-programa" class="au-wms-select">
				<option value=""><?php esc_html_e( 'Mostrar todos', 'au-wms' ); ?></option>
				<option value="inspira"><?php esc_html_e( 'Inspira', 'au-wms' ); ?></option>
				<option value="octagono"><?php esc_html_e( 'Octágono', 'au-wms' ); ?></option>
				<option value="todas"><?php esc_html_e( 'Todas', 'au-wms' ); ?></option>
				<option value="ninguna"><?php esc_html_e( 'Ninguna', 'au-wms' ); ?></option>
			</select>
		</div>

		<div class="au-wms-filter au-wms-filter--per-page">
			<label for="au-wms-empresas-per-page"><?php esc_html_e( 'Registros', 'au-wms' ); ?></label>
			<select id="au-wms-empresas-per-page" class="au-wms-select">
				<option value="10">10</option>
				<option value="25">25</option>
				<option value="50">50</option>
				<option value="100">100</option>
			</select>
		</div>
	</div>

	<div class="au-wms-table-wrapper">
		<table class="au-wms-table" id="au-wms-tabla-empresas">
			<thead>
				<tr>
					<th class="au-wms-col-usuario"><?php esc_html_e( 'Empresa', 'au-wms' ); ?></th>
					<th class="au-wms-col-areas"><?php esc_html_e( 'Áreas', 'au-wms' ); ?></th>
					<th class="au-wms-col-licencia"><?php esc_html_e( 'Licencia adquirida', 'au-wms' ); ?></th>
					<th class="au-wms-col-programas"><?php esc_html_e( 'Programas', 'au-wms' ); ?></th>
					<th class="au-wms-col-acciones"><?php esc_html_e( 'Acciones', 'au-wms' ); ?></th>
				</tr>
			</thead>
			<tbody id="au-wms-empresas-body">
				<tr class="au-wms-row-loading">
					<td colspan="5">
						<div class="au-wms-spinner"></div>
						<?php esc_html_e( 'Cargando...', 'au-wms' ); ?>
					</td>
				</tr>
			</tbody>
		</table>
	</div>

	<div class="au-wms-pagination" id="au-wms-empresas-pagination">
		<div class="au-wms-pagination-info">
			<span id="au-wms-empresas-total">0</span>
			<?php esc_html_e( 'registros', 'au-wms' ); ?>
		</div>
		<div class="au-wms-pagination-controls">
			<button type="button" class="au-wms-page-btn" data-page="first" title="<?php esc_attr_e( 'Primera página', 'au-wms' ); ?>">&laquo;</button>
			<button type="button" class="au-wms-page-btn" data-page="prev" title="<?php esc_attr_e( 'Anterior', 'au-wms' ); ?>">&lsaquo;</button>
			<span class="au-wms-pagination-current">
				<?php esc_html_e( 'Página', 'au-wms' ); ?>
				<span id="au-wms-empresas-current-page">1</span>
				<?php esc_html_e( 'de', 'au-wms' ); ?>
				<span id="au-wms-empresas-total-pages">1</span>
			</span>
			<button type="button" class="au-wms-page-btn" data-page="next" title="<?php esc_attr_e( 'Siguiente', 'au-wms' ); ?>">&rsaquo;</button>
			<button type="button" class="au-wms-page-btn" data-page="last" title="<?php esc_attr_e( 'Última página', 'au-wms' ); ?>">&raquo;</button>
		</div>
	</div>

	<!-- Plantilla de fila -->
	<template id="au-wms-empresas-row-template">
		<tr data-user-id="">
			<td class="au-wms-col-usuario">
				<div class="au-wms-user-meta-line">
					<span class="au-wms-user-id"></span>
					<span class="au-wms-user-date"></span>
				</div>
				<div class="au-wms-user-name au-wms-empresa-nombre"></div>
				<div class="au-wms-user-email"></div>
				<div class="au-wms-empresa-encargado"></div>
				<div class="au-wms-user-badges">
					<span class="au-wms-badge au-wms-badge--role-company" title="company"><?php esc_html_e( 'Empresa', 'au-wms' ); ?></span>
				</div>
			</td>
			<td class="au-wms-col-areas">
				<span class="au-wms-areas-count"></span>
				<button type="button" class="au-wms-areas-vermas-btn"><?php esc_html_e( 'Ver más', 'au-wms' ); ?></button>
			</td>
			<td class="au-wms-col-licencia">
				<span class="au-wms-licencia-badge"></span>
			</td>
			<td class="au-wms-col-programas">
				<div class="au-wms-programas-badges"></div>
			</td>
			<td class="au-wms-col-acciones">
				<div class="au-wms-actions-dropdown">
					<button type="button" class="au-wms-actions-btn">
						<?php esc_html_e( 'Acciones', 'au-wms' ); ?>
						<span class="dashicons dashicons-arrow-down-alt2"></span>
					</button>
					<div class="au-wms-actions-menu">
						<!-- Acceso (un solo ítem: sin submenú) -->
						<button type="button" class="au-wms-empresa-action-login" data-action="login">
							<span class="dashicons dashicons-admin-users"></span>
							<?php esc_html_e( 'Iniciar sesión como usuario', 'au-wms' ); ?>
						</button>

						<div class="au-wms-actions-menu-divider"></div>

						<!-- Datos de la empresa -->
						<div class="au-wms-actions-submenu">
							<button type="button" class="au-wms-actions-submenu-trigger">
								<span class="dashicons dashicons-portfolio"></span>
								<?php esc_html_e( 'Datos de la empresa', 'au-wms' ); ?>
								<span class="dashicons dashicons-arrow-right-alt2 au-wms-actions-submenu-arrow"></span>
							</button>
							<div class="au-wms-actions-submenu-panel">
								<button type="button" class="au-wms-empresa-action-ver-areas" data-action="ver-areas">
									<span class="dashicons dashicons-visibility"></span>
									<?php esc_html_e( 'Ver Áreas', 'au-wms' ); ?>
								</button>
								<button type="button" class="au-wms-empresa-action-editar" data-action="editar-empresa">
									<span class="dashicons dashicons-edit"></span>
									<?php esc_html_e( 'Editar empresa', 'au-wms' ); ?>
								</button>
								<button type="button" class="au-wms-empresa-action-cambiar-licencia" data-action="cambiar-licencia">
									<span class="dashicons dashicons-id-alt"></span>
									<?php esc_html_e( 'Cambiar Licencia', 'au-wms' ); ?>
								</button>
								<button type="button" class="au-wms-empresa-action-usermeta" data-action="usermeta">
									<span class="dashicons dashicons-editor-table"></span>
									<?php esc_html_e( 'Ver WP_USERMETA', 'au-wms' ); ?>
								</button>
							</div>
						</div>

						<!-- Cuenta y credenciales -->
						<div class="au-wms-actions-submenu">
							<button type="button" class="au-wms-actions-submenu-trigger">
								<span class="dashicons dashicons-admin-network"></span>
								<?php esc_html_e( 'Cuenta y credenciales', 'au-wms' ); ?>
								<span class="dashicons dashicons-arrow-right-alt2 au-wms-actions-submenu-arrow"></span>
							</button>
							<div class="au-wms-actions-submenu-panel">
								<button type="button" class="au-wms-empresa-action-cambiar-correo" data-action="cambiar-correo">
									<span class="dashicons dashicons-email-alt"></span>
									<?php esc_html_e( 'Cambiar correo', 'au-wms' ); ?>
								</button>
								<button type="button" class="au-wms-empresa-action-password" data-action="cambiar-password">
									<span class="dashicons dashicons-admin-network"></span>
									<?php esc_html_e( 'Cambiar Contraseña', 'au-wms' ); ?>
								</button>
								<button type="button" class="au-wms-empresa-action-reset-password" data-action="resetear-contrasenas">
									<span class="dashicons dashicons-lock"></span>
									<?php esc_html_e( 'Resetear contraseñas', 'au-wms' ); ?>
								</button>
							</div>
						</div>

						<!-- Sincronización y reportes -->
						<div class="au-wms-actions-submenu">
							<button type="button" class="au-wms-actions-submenu-trigger">
								<span class="dashicons dashicons-update"></span>
								<?php esc_html_e( 'Sincronización y reportes', 'au-wms' ); ?>
								<span class="dashicons dashicons-arrow-right-alt2 au-wms-actions-submenu-arrow"></span>
							</button>
							<div class="au-wms-actions-submenu-panel">
								<button type="button" class="au-wms-empresa-action-refrescar" data-action="refrescar-programas">
									<span class="dashicons dashicons-update"></span>
									<?php esc_html_e( 'Refrescar programas', 'au-wms' ); ?>
								</button>
								<button type="button" class="au-wms-empresa-action-codigo-empresa" data-action="actualizar-codigo-empresa">
									<span class="dashicons dashicons-admin-network"></span>
									<?php esc_html_e( 'Actualizar id empresa usuario', 'au-wms' ); ?>
								</button>
								<button type="button" class="au-wms-empresa-action-exportar-usuarios" data-action="exportar-usuarios">
									<span class="dashicons dashicons-media-spreadsheet"></span>
									<?php esc_html_e( 'Exportar usuarios', 'au-wms' ); ?>
								</button>
								<button type="button" class="au-wms-empresa-action-comparar-usuarios" data-action="comparar-usuarios">
									<span class="dashicons dashicons-randomize"></span>
									<?php esc_html_e( 'Comparar usuarios', 'au-wms' ); ?>
								</button>
							</div>
						</div>
					</div>
				</div>
			</td>
		</tr>
	</template>

	<!-- Plantilla de estado vacío -->
	<template id="au-wms-empresas-empty-template">
		<tr class="au-wms-row-empty">
			<td colspan="5">
				<div class="au-wms-empty-state">
					<span class="dashicons dashicons-building"></span>
					<p><?php esc_html_e( 'No se encontraron empresas con los filtros seleccionados.', 'au-wms' ); ?></p>
				</div>
			</td>
		</tr>
	</template>

</section>

<?php require AU_WMS_PLUGIN_DIR . 'views/modal-reset-password.php'; ?>
<?php require AU_WMS_PLUGIN_DIR . 'views/modal-exportar-usuarios.php'; ?>
<?php require AU_WMS_PLUGIN_DIR . 'views/modal-comparar-usuarios.php'; ?>
