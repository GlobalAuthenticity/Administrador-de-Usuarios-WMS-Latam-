<?php
/**
 * Recuadro informativo que encabeza cada pestaña y explica qué
 * registros se listan en ella.
 *
 * Es el mismo bloque en las tres pestañas, así que vive aquí en vez de
 * repetirse en cada vista. Quien lo incluya define `$aviso_seccion`
 * justo antes:
 *
 *     $aviso_seccion = __( 'Aquí se muestran…', 'au-wms' );
 *     require AU_WMS_PLUGIN_DIR . 'views/partial-aviso-seccion.php';
 *
 * @package Administrador_Usuarios_WMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( empty( $aviso_seccion ) ) {
	return;
}
?>
<div class="au-wms-seccion-aviso">
	<span class="dashicons dashicons-info-outline" aria-hidden="true"></span>
	<p><?php echo esc_html( $aviso_seccion ); ?></p>
</div>
