<?php
/**
 * Tab "Usuarios Externos" — listado de usuarios con rol `external_user`.
 *
 * Reutiliza la misma experiencia de Integrantes/Empresas: filtro de
 * "Programa", paginación, badges de "Programas" y el dropdown de
 * acciones (aquí limitado a "Iniciar sesión como usuario" y
 * "Ver WP_USERMETA").
 *
 * @package Administrador_Usuarios_WMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<section id="au-wms-tab-usuarios-externos" class="au-wms-panel" role="tabpanel" aria-labelledby="usuarios-externos">

	<div class="au-wms-integrantes-toolbar">
		<?php
		// Comparte fila con "Refrescar programas" (ver tab-empresas.php).
		$aviso_seccion = __( 'Estos usuarios no tienen asignado el programa Liderazgo (WMS). Sus cuentas se crean para permitirles el acceso a los programas Inspira y Octágono del Sentido.', 'au-wms' );
		require AU_WMS_PLUGIN_DIR . 'views/partial-aviso-seccion.php';
		?>
		<button type="button" class="au-wms-btn au-wms-btn--primary" id="au-wms-btn-refrescar-externos">
			<span class="dashicons dashicons-update"></span>
			<?php esc_html_e( 'Refrescar programas', 'au-wms' ); ?>
		</button>
	</div>

	<div class="au-wms-filters">
		<div class="au-wms-filter au-wms-filter--search">
			<label for="au-wms-externos-search"><?php esc_html_e( 'Buscar', 'au-wms' ); ?></label>
			<div class="au-wms-search-row">
				<input
					type="text"
					id="au-wms-externos-search"
					class="au-wms-input"
					placeholder="<?php esc_attr_e( 'Username, correo, nombre o apellido...', 'au-wms' ); ?>"
				/>
				<button type="button" class="au-wms-refresh-btn" id="au-wms-btn-refresh-externos" title="<?php esc_attr_e( 'Actualizar lista', 'au-wms' ); ?>">
					<span class="dashicons dashicons-update"></span>
				</button>
			</div>
		</div>

		<div class="au-wms-filter">
			<label for="au-wms-externos-programa"><?php esc_html_e( 'Programa', 'au-wms' ); ?></label>
			<select id="au-wms-externos-programa" class="au-wms-select">
				<option value=""><?php esc_html_e( 'Mostrar todos', 'au-wms' ); ?></option>
				<option value="inspira"><?php esc_html_e( 'Inspira', 'au-wms' ); ?></option>
				<option value="octagono"><?php esc_html_e( 'Octágono', 'au-wms' ); ?></option>
				<option value="todas"><?php esc_html_e( 'Todas', 'au-wms' ); ?></option>
				<option value="ninguna"><?php esc_html_e( 'Ninguna', 'au-wms' ); ?></option>
			</select>
		</div>

		<div class="au-wms-filter au-wms-filter--per-page">
			<label for="au-wms-externos-per-page"><?php esc_html_e( 'Registros', 'au-wms' ); ?></label>
			<select id="au-wms-externos-per-page" class="au-wms-select">
				<option value="10">10</option>
				<option value="25">25</option>
				<option value="50">50</option>
				<option value="100">100</option>
			</select>
		</div>
	</div>

	<div class="au-wms-table-wrapper">
		<table class="au-wms-table" id="au-wms-tabla-externos">
			<thead>
				<tr>
					<th class="au-wms-col-usuario"><?php esc_html_e( 'Usuario', 'au-wms' ); ?></th>
					<th class="au-wms-col-programas"><?php esc_html_e( 'Programas', 'au-wms' ); ?></th>
					<th class="au-wms-col-acciones"><?php esc_html_e( 'Acciones', 'au-wms' ); ?></th>
				</tr>
			</thead>
			<tbody id="au-wms-externos-body">
				<tr class="au-wms-row-loading">
					<td colspan="3">
						<div class="au-wms-spinner"></div>
						<?php esc_html_e( 'Cargando...', 'au-wms' ); ?>
					</td>
				</tr>
			</tbody>
		</table>
	</div>

	<div class="au-wms-pagination" id="au-wms-externos-pagination">
		<div class="au-wms-pagination-info">
			<span id="au-wms-externos-total">0</span>
			<?php esc_html_e( 'registros', 'au-wms' ); ?>
		</div>
		<div class="au-wms-pagination-controls">
			<button type="button" class="au-wms-page-btn" data-page="first" title="<?php esc_attr_e( 'Primera página', 'au-wms' ); ?>">&laquo;</button>
			<button type="button" class="au-wms-page-btn" data-page="prev" title="<?php esc_attr_e( 'Anterior', 'au-wms' ); ?>">&lsaquo;</button>
			<span class="au-wms-pagination-current">
				<?php esc_html_e( 'Página', 'au-wms' ); ?>
				<span id="au-wms-externos-current-page">1</span>
				<?php esc_html_e( 'de', 'au-wms' ); ?>
				<span id="au-wms-externos-total-pages">1</span>
			</span>
			<button type="button" class="au-wms-page-btn" data-page="next" title="<?php esc_attr_e( 'Siguiente', 'au-wms' ); ?>">&rsaquo;</button>
			<button type="button" class="au-wms-page-btn" data-page="last" title="<?php esc_attr_e( 'Última página', 'au-wms' ); ?>">&raquo;</button>
		</div>
	</div>

	<!-- Plantilla de fila -->
	<template id="au-wms-externos-row-template">
		<tr data-user-id="">
			<td class="au-wms-col-usuario">
				<div class="au-wms-user-meta-line">
					<span class="au-wms-user-id"></span>
				</div>
				<div class="au-wms-user-name"></div>
				<div class="au-wms-user-email"></div>
				<div class="au-wms-user-badges">
					<span class="au-wms-badge au-wms-badge--role-default" title="external_user"><?php esc_html_e( 'Usuario externo', 'au-wms' ); ?></span>
				</div>
			</td>
			<td class="au-wms-col-programas">
				<div class="au-wms-programas-badges"></div>
			</td>
			<td class="au-wms-col-acciones">
				<div class="au-wms-actions-dropdown">
					<button type="button" class="au-wms-actions-btn">
						<?php esc_html_e( 'Acciones', 'au-wms' ); ?>
						<span class="dashicons dashicons-arrow-down-alt2"></span>
					</button>
					<div class="au-wms-actions-menu">
						<button type="button" class="au-wms-externo-action-login" data-action="login">
							<span class="dashicons dashicons-admin-users"></span>
							<?php esc_html_e( 'Iniciar sesión como usuario', 'au-wms' ); ?>
						</button>
						<button type="button" class="au-wms-externo-action-usermeta" data-action="usermeta">
							<span class="dashicons dashicons-editor-table"></span>
							<?php esc_html_e( 'Ver WP_USERMETA', 'au-wms' ); ?>
						</button>
						<button type="button" class="au-wms-externo-action-refrescar" data-action="refrescar-programas">
							<span class="dashicons dashicons-update"></span>
							<?php esc_html_e( 'Refrescar programas', 'au-wms' ); ?>
						</button>
						<button type="button" class="au-wms-externo-action-password" data-action="cambiar-password">
							<span class="dashicons dashicons-admin-network"></span>
							<?php esc_html_e( 'Cambiar Contraseña', 'au-wms' ); ?>
						</button>
						<button type="button" class="au-wms-externo-action-delete" data-action="delete">
							<span class="dashicons dashicons-trash"></span>
							<?php esc_html_e( 'Borrar usuario', 'au-wms' ); ?>
						</button>
					</div>
				</div>
			</td>
		</tr>
	</template>

	<!-- Plantilla de estado vacío -->
	<template id="au-wms-externos-empty-template">
		<tr class="au-wms-row-empty">
			<td colspan="3">
				<div class="au-wms-empty-state">
					<span class="dashicons dashicons-external"></span>
					<p><?php esc_html_e( 'No se encontraron usuarios externos con los filtros seleccionados.', 'au-wms' ); ?></p>
				</div>
			</td>
		</tr>
	</template>

</section>
