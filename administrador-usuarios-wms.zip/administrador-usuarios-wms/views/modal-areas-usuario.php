<?php
/**
 * Modal "Áreas del usuario" (Tab Integrantes) — listado paginado y con
 * búsqueda por nombre de las áreas a las que pertenece un usuario.
 *
 * Se renderiza a nivel superior (fuera de los paneles de tabs), igual
 * que el modal "Ver WP_USERMETA" y el modal de Áreas del Tab Empresas,
 * para que funcione sin importar cuál tab esté activo.
 *
 * @package Administrador_Usuarios_WMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="au-wms-modal-overlay" id="au-wms-areas-usuario-overlay">
	<div class="au-wms-modal au-wms-modal--wide" role="dialog" aria-modal="true" aria-labelledby="au-wms-areas-usuario-title">

		<div class="au-wms-modal-header">
			<h2 id="au-wms-areas-usuario-title"><?php esc_html_e( 'Áreas del usuario', 'au-wms' ); ?></h2>
			<div class="au-wms-modal-header-actions">
				<button type="button" class="au-wms-btn au-wms-btn--primary" id="au-wms-areas-usuario-btn-agregar">
					<span class="dashicons dashicons-plus-alt2"></span>
					<?php esc_html_e( 'Agregar área', 'au-wms' ); ?>
				</button>
				<button type="button" class="au-wms-modal-close" id="au-wms-areas-usuario-close" aria-label="<?php esc_attr_e( 'Cerrar', 'au-wms' ); ?>">
					&times;
				</button>
			</div>
		</div>

		<div class="au-wms-modal-body">

			<div class="au-wms-usermeta-toolbar">
				<div class="au-wms-search-row au-wms-areas-usuario-search-row">
					<input
						type="text"
						id="au-wms-areas-usuario-search"
						class="au-wms-input"
						placeholder="<?php esc_attr_e( 'Buscar por nombre del área...', 'au-wms' ); ?>"
					/>
					<button type="button" class="au-wms-refresh-btn" id="au-wms-btn-refresh-areas-usuario" title="<?php esc_attr_e( 'Actualizar lista', 'au-wms' ); ?>">
						<span class="dashicons dashicons-update"></span>
					</button>
				</div>
				<select id="au-wms-areas-usuario-per-page" class="au-wms-select">
					<option value="10">10</option>
					<option value="25">25</option>
					<option value="50">50</option>
					<option value="100">100</option>
				</select>
			</div>

			<div class="au-wms-table-wrapper">
				<table class="au-wms-table" id="au-wms-areas-usuario-table">
					<thead>
						<tr>
							<th><?php esc_html_e( 'Área', 'au-wms' ); ?></th>
							<th><?php esc_html_e( 'Código', 'au-wms' ); ?></th>
							<th><?php esc_html_e( 'Uso / Límite', 'au-wms' ); ?></th>
							<th><?php esc_html_e( 'Acciones', 'au-wms' ); ?></th>
						</tr>
					</thead>
					<tbody id="au-wms-areas-usuario-body">
						<tr class="au-wms-row-loading">
							<td colspan="4">
								<div class="au-wms-spinner"></div>
								<?php esc_html_e( 'Cargando...', 'au-wms' ); ?>
							</td>
						</tr>
					</tbody>
				</table>
			</div>

			<div class="au-wms-pagination" id="au-wms-areas-usuario-pagination">
				<div class="au-wms-pagination-info">
					<span id="au-wms-areas-usuario-total">0</span>
					<?php esc_html_e( 'registros', 'au-wms' ); ?>
				</div>
				<div class="au-wms-pagination-controls">
					<button type="button" class="au-wms-page-btn" data-page="first">&laquo;</button>
					<button type="button" class="au-wms-page-btn" data-page="prev">&lsaquo;</button>
					<span class="au-wms-pagination-current">
						<?php esc_html_e( 'Página', 'au-wms' ); ?>
						<span id="au-wms-areas-usuario-current-page">1</span>
						<?php esc_html_e( 'de', 'au-wms' ); ?>
						<span id="au-wms-areas-usuario-total-pages">1</span>
					</span>
					<button type="button" class="au-wms-page-btn" data-page="next">&rsaquo;</button>
					<button type="button" class="au-wms-page-btn" data-page="last">&raquo;</button>
				</div>
			</div>

		</div>
	</div>
</div>

<!-- Plantilla de fila -->
<template id="au-wms-areas-usuario-row-template">
	<tr data-paquete-id="">
		<td>
			<div class="au-wms-user-id"></div>
			<div class="au-wms-area-row-nombre"></div>
		</td>
		<td>
			<span class="au-wms-areas-usuario-codigo"></span>
		</td>
		<td>
			<span class="au-wms-areas-uso-badge"></span>
		</td>
		<td class="au-wms-col-acciones">
			<div class="au-wms-actions-dropdown">
				<button type="button" class="au-wms-actions-btn">
					<?php esc_html_e( 'Acciones', 'au-wms' ); ?>
					<span class="dashicons dashicons-arrow-down-alt2"></span>
				</button>
				<div class="au-wms-actions-menu">
					<button type="button" class="au-wms-areas-usuario-action-desvincular" data-action="desvincular">
						<span class="dashicons dashicons-dismiss"></span>
						<?php esc_html_e( 'Desvincular área', 'au-wms' ); ?>
					</button>
				</div>
			</div>
		</td>
	</tr>
</template>

<!-- Plantilla de estado vacío -->
<template id="au-wms-areas-usuario-empty-template">
	<tr class="au-wms-row-empty">
		<td colspan="4">
			<div class="au-wms-empty-state">
				<span class="dashicons dashicons-category"></span>
				<p><?php esc_html_e( 'Este usuario no pertenece a ninguna área.', 'au-wms' ); ?></p>
			</div>
		</td>
	</tr>
</template>

<!-- Modal secundario: "Agregar área" -->
<div class="au-wms-modal-overlay" id="au-wms-vincular-area-overlay">
	<div class="au-wms-modal" role="dialog" aria-modal="true" aria-labelledby="au-wms-vincular-area-title">

		<div class="au-wms-modal-header">
			<h2 id="au-wms-vincular-area-title"><?php esc_html_e( 'Agregar área', 'au-wms' ); ?></h2>
			<button type="button" class="au-wms-modal-close" id="au-wms-vincular-area-close" aria-label="<?php esc_attr_e( 'Cerrar', 'au-wms' ); ?>">
				&times;
			</button>
		</div>

		<div class="au-wms-modal-body">
			<div class="au-wms-filter">
				<label for="au-wms-vincular-area-select-ts-control" id="au-wms-vincular-area-select-label">
					<?php esc_html_e( 'Área', 'au-wms' ); ?>
				</label>
				<select id="au-wms-vincular-area-select" class="au-wms-select">
					<option value=""><?php esc_html_e( 'Selecciona un área', 'au-wms' ); ?></option>
				</select>
			</div>

			<div class="au-wms-import-area-info" id="au-wms-vincular-area-info" style="display:none;">
				<strong id="au-wms-vincular-area-info-nombre"></strong>
				<span id="au-wms-vincular-area-info-cupos"></span>
			</div>

			<p class="au-wms-import-help" id="au-wms-vincular-area-sin-cupo" style="display:none;">
				<?php esc_html_e( 'Esta área ya no tiene cupos disponibles: no es posible vincular al usuario hasta que se libere o se amplíe un cupo.', 'au-wms' ); ?>
			</p>

			<p class="au-wms-import-help" id="au-wms-vincular-area-sin-opciones" style="display:none;">
				<?php esc_html_e( 'No hay áreas disponibles para agregar: el usuario ya pertenece a todas las áreas de su empresa, o no se pudo determinar su empresa.', 'au-wms' ); ?>
			</p>
		</div>

		<div class="au-wms-modal-footer">
			<button type="button" class="au-wms-btn au-wms-btn--secondary" id="au-wms-vincular-area-btn-cancelar">
				<?php esc_html_e( 'Cancelar', 'au-wms' ); ?>
			</button>
			<button type="button" class="au-wms-btn au-wms-btn--primary" id="au-wms-vincular-area-btn-vincular" disabled>
				<?php esc_html_e( 'Vincular área', 'au-wms' ); ?>
			</button>
		</div>

	</div>
</div>
