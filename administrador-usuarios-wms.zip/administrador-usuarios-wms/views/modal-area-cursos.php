<?php
/**
 * Modal "Ver cursos" de la columna "Cursos asignados" (Tab Empresas,
 * modal "Áreas") — lista de cursos de LearnDash (`wp_paquetes.course_ids`)
 * asignados a un área.
 *
 * Se renderiza a nivel superior, igual que el resto de modales
 * globales del plugin, para que funcione sin importar cuál tab esté
 * activo ni que el modal "Áreas" esté abierto encima.
 *
 * @package Administrador_Usuarios_WMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="au-wms-modal-overlay" id="au-wms-area-cursos-overlay">
	<div class="au-wms-modal" role="dialog" aria-modal="true" aria-labelledby="au-wms-area-cursos-title">

		<div class="au-wms-modal-header">
			<h2 id="au-wms-area-cursos-title"><?php esc_html_e( 'Cursos asignados', 'au-wms' ); ?></h2>
			<button type="button" class="au-wms-modal-close" id="au-wms-area-cursos-close" aria-label="<?php esc_attr_e( 'Cerrar', 'au-wms' ); ?>">
				&times;
			</button>
		</div>

		<div class="au-wms-modal-body">
			<div class="au-wms-cursos-toolbar">
				<input
					type="text"
					id="au-wms-area-cursos-search"
					class="au-wms-input"
					placeholder="<?php esc_attr_e( 'Buscar por nombre del curso...', 'au-wms' ); ?>"
				/>
			</div>
			<ul class="au-wms-cursos-list" id="au-wms-area-cursos-list">
				<li class="au-wms-row-loading">
					<div class="au-wms-spinner"></div>
					<?php esc_html_e( 'Cargando...', 'au-wms' ); ?>
				</li>
			</ul>
		</div>

	</div>
</div>

<!-- Plantilla de curso -->
<template id="au-wms-area-cursos-item-template">
	<li class="au-wms-curso-item">
		<span class="au-wms-curso-item-numero"></span>
		<span class="au-wms-curso-item-titulo"></span>
	</li>
</template>

<!-- Plantilla de estado vacío (sin cursos asignados) -->
<template id="au-wms-area-cursos-empty-template">
	<li class="au-wms-row-empty">
		<div class="au-wms-empty-state">
			<span class="dashicons dashicons-welcome-learn-more"></span>
			<p><?php esc_html_e( 'Esta área no tiene cursos asignados.', 'au-wms' ); ?></p>
		</div>
	</li>
</template>

<!-- Plantilla de estado vacío (búsqueda sin resultados) -->
<template id="au-wms-area-cursos-sin-resultados-template">
	<li class="au-wms-row-empty">
		<div class="au-wms-empty-state">
			<span class="dashicons dashicons-search"></span>
			<p><?php esc_html_e( 'Ningún curso coincide con esa búsqueda.', 'au-wms' ); ?></p>
		</div>
	</li>
</template>
