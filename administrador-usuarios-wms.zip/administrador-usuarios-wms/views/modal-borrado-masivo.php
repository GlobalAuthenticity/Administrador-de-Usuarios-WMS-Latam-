<?php
/**
 * Modal de previsualización del borrado masivo (Tab Integrantes):
 * lista los usuarios seleccionados, sus programas (tras refrescarlos) y
 * la acción que se les va a aplicar, antes de confirmar.
 *
 * Se renderiza a nivel superior (fuera de los paneles de tabs), igual
 * que el modal "Ver WP_USERMETA" y el de Áreas.
 *
 * @package Administrador_Usuarios_WMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="au-wms-modal-overlay" id="au-wms-borrado-masivo-overlay">
	<div class="au-wms-modal au-wms-modal--wide" role="dialog" aria-modal="true" aria-labelledby="au-wms-borrado-masivo-title">

		<div class="au-wms-modal-header">
			<h2 id="au-wms-borrado-masivo-title"><?php esc_html_e( '¿Procesar la eliminación de los usuarios seleccionados?', 'au-wms' ); ?></h2>
			<button type="button" class="au-wms-modal-close" id="au-wms-borrado-masivo-close" aria-label="<?php esc_attr_e( 'Cerrar', 'au-wms' ); ?>">
				&times;
			</button>
		</div>

		<div class="au-wms-modal-body">
			<div class="au-wms-table-wrapper">
				<table class="au-wms-table" id="au-wms-borrado-masivo-table">
					<thead>
						<tr>
							<th><?php esc_html_e( 'Usuario', 'au-wms' ); ?></th>
							<th><?php esc_html_e( 'Programas', 'au-wms' ); ?></th>
							<th><?php esc_html_e( 'Acción', 'au-wms' ); ?></th>
						</tr>
					</thead>
					<tbody id="au-wms-borrado-masivo-body"></tbody>
				</table>
			</div>
		</div>

		<div class="au-wms-modal-footer">
			<button type="button" class="au-wms-btn au-wms-btn--secondary" id="au-wms-borrado-masivo-cancelar">
				<?php esc_html_e( 'Cancelar', 'au-wms' ); ?>
			</button>
			<button type="button" class="au-wms-btn au-wms-btn--danger" id="au-wms-borrado-masivo-continuar">
				<?php esc_html_e( 'Continuar', 'au-wms' ); ?>
			</button>
		</div>

	</div>
</div>

<!-- Plantilla de fila -->
<template id="au-wms-borrado-masivo-row-template">
	<tr>
		<td>
			<div class="au-wms-user-id"></div>
			<div class="au-wms-user-name"></div>
			<div class="au-wms-user-email"></div>
		</td>
		<td>
			<div class="au-wms-programas-badges"></div>
		</td>
		<td>
			<span class="au-wms-borrado-masivo-accion"></span>
		</td>
	</tr>
</template>
