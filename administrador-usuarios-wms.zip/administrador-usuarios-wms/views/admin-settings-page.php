<?php
/**
 * Vista de la página "Configuración" (APIs / Webhooks).
 *
 * Variable disponible: $config (array devuelto por AU_Settings::get_all()).
 *
 * @package Administrador_Usuarios_WMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="wrap au-wms-wrap">
	<div class="au-wms-header">
		<h1 class="au-wms-title">
			<span class="dashicons dashicons-admin-generic"></span>
			<?php esc_html_e( 'Configuración', 'au-wms' ); ?>
		</h1>
		<p class="au-wms-subtitle">
			<?php esc_html_e( 'Configura las APIs y webhooks que utiliza el plugin, sin necesidad de tocar código.', 'au-wms' ); ?>
		</p>
	</div>

	<div class="au-wms-panel is-active">
		<form id="au-wms-settings-form">

			<div class="au-wms-settings-section">
				<div class="au-wms-settings-section-intro">
					<h2 class="au-wms-settings-section-title"><?php esc_html_e( 'Webhooks de importación de usuarios', 'au-wms' ); ?></h2>
					<p class="au-wms-import-help">
						<?php esc_html_e( 'Se llaman automáticamente al crear o actualizar un usuario desde el asistente de "Importar usuarios" del Tab Integrantes.', 'au-wms' ); ?>
					</p>
				</div>

				<div class="au-wms-filter">
					<label for="au-wms-cfg-webhook-nuevo"><?php esc_html_e( 'URL — Usuario nuevo creado', 'au-wms' ); ?></label>
					<input
						type="url"
						id="au-wms-cfg-webhook-nuevo"
						class="au-wms-input"
						value="<?php echo esc_attr( $config['webhook_nuevo_usuario_url'] ); ?>"
						placeholder="https://..."
					/>
				</div>

				<div class="au-wms-filter" style="margin-top: 14px;">
					<label for="au-wms-cfg-webhook-update"><?php esc_html_e( 'URL — Usuario actualizado (external_user → subscriber)', 'au-wms' ); ?></label>
					<input
						type="url"
						id="au-wms-cfg-webhook-update"
						class="au-wms-input"
						value="<?php echo esc_attr( $config['webhook_usuario_actualizado_url'] ); ?>"
						placeholder="https://..."
					/>
				</div>

				<div class="au-wms-filter" style="margin-top: 14px;">
					<label for="au-wms-cfg-token"><?php esc_html_e( 'Token de autorización (Bearer) — opcional', 'au-wms' ); ?></label>
					<div class="au-wms-token-field">
						<input
							type="password"
							id="au-wms-cfg-token"
							class="au-wms-input"
							value="<?php echo esc_attr( $config['token_autorizacion'] ); ?>"
							placeholder="<?php esc_attr_e( 'Déjalo vacío si el endpoint no requiere autenticación', 'au-wms' ); ?>"
							autocomplete="off"
						/>
						<button type="button" class="au-wms-token-toggle" data-target="au-wms-cfg-token" aria-label="<?php esc_attr_e( 'Mostrar/ocultar token', 'au-wms' ); ?>">
							<span class="dashicons dashicons-visibility"></span>
						</button>
					</div>
					<p class="au-wms-settings-hint">
						<?php esc_html_e( 'Si se define, se envía como encabezado "Authorization: Bearer {token}" en cada llamada.', 'au-wms' ); ?>
					</p>
				</div>

				<div class="au-wms-filter au-wms-settings-toggle-row" style="margin-top: 14px;">
					<label class="au-wms-toggle-label">
						<input
							type="checkbox"
							id="au-wms-cfg-activos"
							<?php checked( ! empty( $config['webhooks_activos'] ) ); ?>
						/>
						<?php esc_html_e( 'Activar el envío de webhooks', 'au-wms' ); ?>
					</label>
					<p class="au-wms-settings-hint">
						<?php esc_html_e( 'Si se desactiva, la importación de usuarios seguirá funcionando con normalidad, pero no se notificará a estos endpoints externos.', 'au-wms' ); ?>
					</p>
				</div>
			</div>

			<div class="au-wms-settings-section" style="margin-top: 28px;">
				<div class="au-wms-settings-section-intro">
					<h2 class="au-wms-settings-section-title"><?php esc_html_e( 'Sincronización de Programas (Inspira / Octágono)', 'au-wms' ); ?></h2>
					<p class="au-wms-import-help">
						<?php esc_html_e( 'Usadas por la acción "Refrescar programas" del Tab Empresas para verificar el rol de cada usuario en cada plataforma.', 'au-wms' ); ?>
					</p>
				</div>

				<?php $au_wms_tokens_faltantes = AU_Settings::tokens_sync_faltantes(); ?>
				<?php if ( ! empty( $au_wms_tokens_faltantes ) ) : ?>
					<div class="notice notice-warning inline" style="margin: 12px 0;">
						<p>
							<?php
							printf(
								/* translators: %s: programas sin token. */
								esc_html__( 'Falta el token de %s. "Refrescar programas" permanecerá bloqueado hasta que lo configures.', 'au-wms' ),
								esc_html( implode( ', ', $au_wms_tokens_faltantes ) )
							);
							?>
						</p>
					</div>
				<?php endif; ?>

				<div class="au-wms-filter">
					<label for="au-wms-cfg-inspira-url"><?php esc_html_e( 'URL API — Inspira', 'au-wms' ); ?></label>
					<input
						type="url"
						id="au-wms-cfg-inspira-url"
						class="au-wms-input"
						value="<?php echo esc_attr( $config['inspira_sync_url'] ); ?>"
					/>
				</div>

				<div class="au-wms-filter" style="margin-top: 14px;">
					<label for="au-wms-cfg-inspira-token"><?php esc_html_e( 'Token (Bearer) — Inspira', 'au-wms' ); ?></label>
					<div class="au-wms-token-field">
						<input
							type="password"
							id="au-wms-cfg-inspira-token"
							class="au-wms-input"
							value="<?php echo esc_attr( $config['inspira_sync_token'] ); ?>"
							autocomplete="off"
						/>
						<button type="button" class="au-wms-token-toggle" data-target="au-wms-cfg-inspira-token" aria-label="<?php esc_attr_e( 'Mostrar/ocultar token', 'au-wms' ); ?>">
							<span class="dashicons dashicons-visibility"></span>
						</button>
					</div>
				</div>

				<div class="au-wms-filter" style="margin-top: 14px;">
					<label for="au-wms-cfg-octagono-url"><?php esc_html_e( 'URL API — Octágono', 'au-wms' ); ?></label>
					<input
						type="url"
						id="au-wms-cfg-octagono-url"
						class="au-wms-input"
						value="<?php echo esc_attr( $config['octagono_sync_url'] ); ?>"
					/>
				</div>

				<div class="au-wms-filter" style="margin-top: 14px;">
					<label for="au-wms-cfg-octagono-token"><?php esc_html_e( 'Token (Bearer) — Octágono', 'au-wms' ); ?></label>
					<div class="au-wms-token-field">
						<input
							type="password"
							id="au-wms-cfg-octagono-token"
							class="au-wms-input"
							value="<?php echo esc_attr( $config['octagono_sync_token'] ); ?>"
							autocomplete="off"
						/>
						<button type="button" class="au-wms-token-toggle" data-target="au-wms-cfg-octagono-token" aria-label="<?php esc_attr_e( 'Mostrar/ocultar token', 'au-wms' ); ?>">
							<span class="dashicons dashicons-visibility"></span>
						</button>
					</div>
				</div>
			</div>

			<div class="au-wms-settings-section" style="margin-top: 28px;">
				<div class="au-wms-settings-section-intro">
					<h2 class="au-wms-settings-section-title"><?php esc_html_e( 'Cambio de contraseña', 'au-wms' ); ?></h2>
					<p class="au-wms-import-help">
						<?php esc_html_e( 'Usada por la acción "Cambiar Contraseña" (Integrantes, Empresas, Usuarios Externos) para notificar el correo y la nueva contraseña.', 'au-wms' ); ?>
					</p>
				</div>

				<div class="au-wms-filter">
					<label for="au-wms-cfg-recovery-pass-url"><?php esc_html_e( 'URL Webhook — Recuperación de contraseña', 'au-wms' ); ?></label>
					<input
						type="url"
						id="au-wms-cfg-recovery-pass-url"
						class="au-wms-input"
						value="<?php echo esc_attr( $config['webhook_recovery_pass_url'] ); ?>"
					/>
					<p class="au-wms-settings-hint">
						<?php esc_html_e( 'Reutiliza el mismo token de autorización configurado arriba, y respeta el interruptor "Activar el envío de webhooks".', 'au-wms' ); ?>
					</p>
				</div>
			</div>

			<div class="au-wms-settings-section" style="margin-top: 28px;">
				<div class="au-wms-settings-section-intro">
					<h2 class="au-wms-settings-section-title"><?php esc_html_e( 'Resetear contraseñas (envío masivo de correos)', 'au-wms' ); ?></h2>
					<p class="au-wms-import-help">
						<?php esc_html_e( 'Usada por el botón "Enviar correos" del modal "Resetear contraseñas" (Tab Empresas): envía un arreglo con el correo, la nueva contraseña y el área de cada usuario reseteado.', 'au-wms' ); ?>
					</p>
				</div>

				<div class="au-wms-filter">
					<label for="au-wms-cfg-reset-password-masivo-url"><?php esc_html_e( 'URL Webhook — Envío masivo de contraseñas', 'au-wms' ); ?></label>
					<input
						type="url"
						id="au-wms-cfg-reset-password-masivo-url"
						class="au-wms-input"
						value="<?php echo esc_attr( $config['webhook_reset_password_masivo_url'] ); ?>"
					/>
					<p class="au-wms-settings-hint">
						<?php esc_html_e( 'Reutiliza el mismo token de autorización configurado arriba, y respeta el interruptor "Activar el envío de webhooks".', 'au-wms' ); ?>
					</p>
				</div>
			</div>

			<div class="au-wms-settings-section" style="margin-top: 28px;">
				<div class="au-wms-settings-section-intro">
					<h2 class="au-wms-settings-section-title"><?php esc_html_e( 'Generación de PDF del test', 'au-wms' ); ?></h2>
					<p class="au-wms-import-help">
						<?php esc_html_e( 'Usada por el botón "Descargar resultado" de la columna Test (Tab Integrantes): recibe el resultado del test del integrante y devuelve la URL del PDF.', 'au-wms' ); ?>
					</p>
				</div>

				<div class="au-wms-filter">
					<label for="au-wms-cfg-pdf-resultado-test-url"><?php esc_html_e( 'URL Webhook — Informe individual (PDF)', 'au-wms' ); ?></label>
					<input
						type="url"
						id="au-wms-cfg-pdf-resultado-test-url"
						class="au-wms-input"
						value="<?php echo esc_attr( $config['pdf_resultado_test_url'] ); ?>"
						placeholder="https://..."
					/>
					<p class="au-wms-settings-hint">
						<?php
						printf(
							/* translators: %s: URL por defecto del microservicio de PDF. */
							esc_html__( 'Si se deja vacía se usa la URL por defecto: %s', 'au-wms' ),
							'<code>' . esc_html( AU_Settings::DEFAULT_PDF_RESULTADO_TEST_URL ) . '</code>'
						);
						?>
					</p>
				</div>
			</div>

			<div class="au-wms-settings-section" style="margin-top: 28px;">
				<h2 class="au-wms-settings-section-title"><?php esc_html_e( 'Asistente "Crear Empresa"', 'au-wms' ); ?></h2>
				<p class="au-wms-import-help">
					<?php esc_html_e( 'Valores con los que arranca el asistente "Crear Empresa" (Tab Empresas → Acciones) y APIs de los programas externos. Los cambios aplican a las creaciones futuras; no modifican empresas ni áreas ya creadas.', 'au-wms' ); ?>
				</p>

				<div class="au-wms-filter">
					<label for="au-wms-cfg-ce-webhook"><?php esc_html_e( 'URL Webhook — Credenciales de la empresa creada', 'au-wms' ); ?></label>
					<input type="url" id="au-wms-cfg-ce-webhook" class="au-wms-input" value="<?php echo esc_attr( $config['crear_empresa_webhook_url'] ); ?>" placeholder="https://..." />
					<p class="au-wms-settings-hint">
						<?php esc_html_e( 'Recibe por POST el nombre de la empresa, el correo, la contraseña de WMS y el estado de creación por plataforma. Los tokens de las APIs nunca se envían aquí.', 'au-wms' ); ?>
					</p>
				</div>

				<h3 class="au-wms-settings-subtitle"><?php esc_html_e( 'APIs de los programas externos', 'au-wms' ); ?></h3>

				<div class="au-wms-filter">
					<label for="au-wms-cfg-ce-inspira-url"><?php esc_html_e( 'URL API — Inspira (crear empresa)', 'au-wms' ); ?></label>
					<input type="url" id="au-wms-cfg-ce-inspira-url" class="au-wms-input" value="<?php echo esc_attr( $config['crear_empresa_inspira_url'] ); ?>" />
				</div>

				<div class="au-wms-filter" style="margin-top: 14px;">
					<label for="au-wms-cfg-ce-inspira-token"><?php esc_html_e( 'Token (Bearer) — Inspira (crear empresa)', 'au-wms' ); ?></label>
					<div class="au-wms-token-field">
						<input type="password" id="au-wms-cfg-ce-inspira-token" class="au-wms-input" value="<?php echo esc_attr( $config['crear_empresa_inspira_token'] ); ?>" autocomplete="off" />
						<button type="button" class="au-wms-token-toggle" data-target="au-wms-cfg-ce-inspira-token" aria-label="<?php esc_attr_e( 'Mostrar/ocultar token', 'au-wms' ); ?>">
							<span class="dashicons dashicons-visibility"></span>
						</button>
					</div>
				</div>

				<div class="au-wms-filter" style="margin-top: 14px;">
					<label for="au-wms-cfg-ce-octagono-url"><?php esc_html_e( 'URL API — Octágono del sentido (crear empresa)', 'au-wms' ); ?></label>
					<input type="url" id="au-wms-cfg-ce-octagono-url" class="au-wms-input" value="<?php echo esc_attr( $config['crear_empresa_octagono_url'] ); ?>" />
				</div>

				<div class="au-wms-filter" style="margin-top: 14px;">
					<label for="au-wms-cfg-ce-octagono-token"><?php esc_html_e( 'Token (Bearer) — Octágono del sentido (crear empresa)', 'au-wms' ); ?></label>
					<div class="au-wms-token-field">
						<input type="password" id="au-wms-cfg-ce-octagono-token" class="au-wms-input" value="<?php echo esc_attr( $config['crear_empresa_octagono_token'] ); ?>" autocomplete="off" />
						<button type="button" class="au-wms-token-toggle" data-target="au-wms-cfg-ce-octagono-token" aria-label="<?php esc_attr_e( 'Mostrar/ocultar token', 'au-wms' ); ?>">
							<span class="dashicons dashicons-visibility"></span>
						</button>
					</div>
					<p class="au-wms-settings-hint">
						<?php esc_html_e( 'Los dos tokens salen vacíos de fábrica a propósito: no viajan dentro del ZIP del plugin. Sin ellos, el asistente avisa y no llama a esa API.', 'au-wms' ); ?>
					</p>
				</div>

				<h3 class="au-wms-settings-subtitle"><?php esc_html_e( 'Valores predeterminados de la empresa', 'au-wms' ); ?></h3>

				<div class="au-wms-settings-grid">
					<div class="au-wms-filter">
						<label for="au-wms-cfg-ce-encargado"><?php esc_html_e( 'Nombre del encargado', 'au-wms' ); ?></label>
						<input type="text" id="au-wms-cfg-ce-encargado" class="au-wms-input" value="<?php echo esc_attr( $config['crear_empresa_nombre_encargado'] ); ?>" />
					</div>
					<div class="au-wms-filter">
						<label for="au-wms-cfg-ce-apellidos"><?php esc_html_e( 'Apellidos del encargado', 'au-wms' ); ?></label>
						<input type="text" id="au-wms-cfg-ce-apellidos" class="au-wms-input" value="<?php echo esc_attr( $config['crear_empresa_apellidos_encargado'] ); ?>" />
					</div>
					<div class="au-wms-filter">
						<label for="au-wms-cfg-ce-contacto"><?php esc_html_e( 'Contacto', 'au-wms' ); ?></label>
						<input type="text" id="au-wms-cfg-ce-contacto" class="au-wms-input" value="<?php echo esc_attr( $config['crear_empresa_contacto'] ); ?>" />
					</div>
					<div class="au-wms-filter">
						<label for="au-wms-cfg-ce-ocupacion"><?php esc_html_e( 'Ocupación', 'au-wms' ); ?></label>
						<input type="text" id="au-wms-cfg-ce-ocupacion" class="au-wms-input" value="<?php echo esc_attr( $config['crear_empresa_ocupacion'] ); ?>" />
					</div>
				</div>

				<div class="au-wms-filter" style="margin-top: 14px;">
					<label for="au-wms-cfg-ce-email-plantilla"><?php esc_html_e( 'Plantilla del correo', 'au-wms' ); ?></label>
					<input type="text" id="au-wms-cfg-ce-email-plantilla" class="au-wms-input" value="<?php echo esc_attr( $config['crear_empresa_email_plantilla'] ); ?>" />
					<p class="au-wms-settings-hint">
						<?php esc_html_e( 'Debe incluir {nombre_empresa_normalizado}: el nombre en minúsculas, sin tildes, sin la palabra "demo" y sin caracteres especiales. El NIT no se configura aquí: siempre se genera uno aleatorio y único cuando se deja vacío.', 'au-wms' ); ?>
					</p>
				</div>

				<h3 class="au-wms-settings-subtitle"><?php esc_html_e( 'Valores predeterminados de las áreas', 'au-wms' ); ?></h3>

				<div class="au-wms-settings-grid">
					<div class="au-wms-filter">
						<label for="au-wms-cfg-ce-area-nombre"><?php esc_html_e( 'Nombre inicial del área', 'au-wms' ); ?></label>
						<input type="text" id="au-wms-cfg-ce-area-nombre" class="au-wms-input" value="<?php echo esc_attr( $config['crear_empresa_area_nombre'] ); ?>" />
					</div>
					<div class="au-wms-filter">
						<label for="au-wms-cfg-ce-area-licencia"><?php esc_html_e( 'Licencia inicial (Liderazgo)', 'au-wms' ); ?></label>
						<select id="au-wms-cfg-ce-area-licencia" class="au-wms-select">
							<option value="0"><?php esc_html_e( 'Sin licencia', 'au-wms' ); ?></option>
							<?php foreach ( (array) ( $licencias ?? array() ) as $licencia ) : ?>
								<option value="<?php echo esc_attr( $licencia['id'] ); ?>" <?php selected( (int) $config['crear_empresa_area_licencia_id'], (int) $licencia['id'] ); ?>>
									<?php echo esc_html( $licencia['nombre'] ); ?>
								</option>
							<?php endforeach; ?>
						</select>
					</div>
					<div class="au-wms-filter">
						<label for="au-wms-cfg-ce-cupos-wms"><?php esc_html_e( 'Cupos iniciales — Liderazgo (WMS)', 'au-wms' ); ?></label>
						<input type="number" min="1" id="au-wms-cfg-ce-cupos-wms" class="au-wms-input" value="<?php echo esc_attr( $config['crear_empresa_area_cupos_wms'] ); ?>" />
					</div>
					<div class="au-wms-filter">
						<label for="au-wms-cfg-ce-cupos-inspira"><?php esc_html_e( 'Cupos iniciales — Inspira', 'au-wms' ); ?></label>
						<input type="number" min="1" id="au-wms-cfg-ce-cupos-inspira" class="au-wms-input" value="<?php echo esc_attr( $config['crear_empresa_area_cupos_inspira'] ); ?>" />
					</div>
					<div class="au-wms-filter">
						<label for="au-wms-cfg-ce-cupos-octagono"><?php esc_html_e( 'Cupos iniciales — Octágono del sentido', 'au-wms' ); ?></label>
						<input type="number" min="1" id="au-wms-cfg-ce-cupos-octagono" class="au-wms-input" value="<?php echo esc_attr( $config['crear_empresa_area_cupos_octagono'] ); ?>" />
					</div>
					<div class="au-wms-filter">
						<label for="au-wms-cfg-ce-meses"><?php esc_html_e( 'Plazo de expiración (meses) — Inspira y Octágono', 'au-wms' ); ?></label>
						<input type="number" min="1" id="au-wms-cfg-ce-meses" class="au-wms-input" value="<?php echo esc_attr( $config['crear_empresa_area_meses_expiracion'] ); ?>" />
					</div>
				</div>
			</div>

			<div class="au-wms-settings-footer">
				<button type="submit" class="au-wms-btn au-wms-btn--primary" id="au-wms-settings-guardar">
					<?php esc_html_e( 'Guardar cambios', 'au-wms' ); ?>
				</button>
			</div>

		</form>
	</div>
</div>
