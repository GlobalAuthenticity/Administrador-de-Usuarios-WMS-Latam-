<?php
/**
 * Modal "Ver WP_USERMETA" — listado, búsqueda, paginación y CRUD sobre
 * los registros de `wp_usermeta` de un usuario.
 *
 * @package Administrador_Usuarios_WMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="au-wms-modal-overlay" id="au-wms-usermeta-overlay">
	<div class="au-wms-modal au-wms-modal--wide" role="dialog" aria-modal="true" aria-labelledby="au-wms-usermeta-title">

		<div class="au-wms-modal-header">
			<h2 id="au-wms-usermeta-title"><?php esc_html_e( 'WP_USERMETA', 'au-wms' ); ?></h2>
			<button type="button" class="au-wms-modal-close" id="au-wms-usermeta-close" aria-label="<?php esc_attr_e( 'Cerrar', 'au-wms' ); ?>">
				&times;
			</button>
		</div>

		<div class="au-wms-modal-body">

			<!-- Vista de listado -->
			<div id="au-wms-usermeta-panel-list">
				<div class="au-wms-usermeta-toolbar">
					<input
						type="text"
						id="au-wms-usermeta-search"
						class="au-wms-input"
						placeholder="<?php esc_attr_e( 'Buscar por Meta Key o Meta Value...', 'au-wms' ); ?>"
					/>
					<select id="au-wms-usermeta-per-page" class="au-wms-select">
						<option value="10">10</option>
						<option value="25">25</option>
						<option value="50">50</option>
						<option value="100">100</option>
					</select>
					<button type="button" class="au-wms-btn au-wms-btn--primary" id="au-wms-usermeta-btn-agregar">
						<span class="dashicons dashicons-plus-alt2"></span>
						<?php esc_html_e( 'Agregar atributo', 'au-wms' ); ?>
					</button>
				</div>

				<div class="au-wms-table-wrapper">
					<table class="au-wms-table" id="au-wms-usermeta-table">
						<thead>
							<tr>
								<th><?php esc_html_e( 'Meta Key', 'au-wms' ); ?></th>
								<th><?php esc_html_e( 'Meta Value', 'au-wms' ); ?></th>
								<th><?php esc_html_e( 'Acciones', 'au-wms' ); ?></th>
							</tr>
						</thead>
						<tbody id="au-wms-usermeta-body">
							<tr class="au-wms-row-loading">
								<td colspan="3">
									<div class="au-wms-spinner"></div>
									<?php esc_html_e( 'Cargando...', 'au-wms' ); ?>
								</td>
							</tr>
						</tbody>
					</table>
				</div>

				<div class="au-wms-pagination" id="au-wms-usermeta-pagination">
					<div class="au-wms-pagination-info">
						<span id="au-wms-usermeta-total">0</span>
						<?php esc_html_e( 'registros', 'au-wms' ); ?>
					</div>
					<div class="au-wms-pagination-controls">
						<button type="button" class="au-wms-page-btn" data-page="first">&laquo;</button>
						<button type="button" class="au-wms-page-btn" data-page="prev">&lsaquo;</button>
						<span class="au-wms-pagination-current">
							<?php esc_html_e( 'Página', 'au-wms' ); ?>
							<span id="au-wms-usermeta-current-page">1</span>
							<?php esc_html_e( 'de', 'au-wms' ); ?>
							<span id="au-wms-usermeta-total-pages">1</span>
						</span>
						<button type="button" class="au-wms-page-btn" data-page="next">&rsaquo;</button>
						<button type="button" class="au-wms-page-btn" data-page="last">&raquo;</button>
					</div>
				</div>
			</div>

			<!-- Vista de formulario (crear/editar) -->
			<div id="au-wms-usermeta-panel-form" style="display:none;">
				<button type="button" class="au-wms-btn au-wms-btn--secondary" id="au-wms-usermeta-form-volver">
					&larr; <?php esc_html_e( 'Volver al listado', 'au-wms' ); ?>
				</button>

				<h3 class="au-wms-settings-section-title" id="au-wms-usermeta-form-title" style="margin-top: 16px;">
					<?php esc_html_e( 'Agregar atributo', 'au-wms' ); ?>
				</h3>

				<div class="au-wms-filter">
					<label for="au-wms-usermeta-form-key"><?php esc_html_e( 'Meta Key', 'au-wms' ); ?></label>
					<input type="text" id="au-wms-usermeta-form-key" class="au-wms-input" />
				</div>

				<div class="au-wms-filter" style="margin-top: 14px;">
					<label for="au-wms-usermeta-form-value"><?php esc_html_e( 'Meta Value', 'au-wms' ); ?></label>
					<textarea id="au-wms-usermeta-form-value" class="au-wms-input au-wms-textarea" rows="6"></textarea>
				</div>

				<div class="au-wms-settings-footer">
					<button type="button" class="au-wms-btn au-wms-btn--secondary" id="au-wms-usermeta-form-cancelar">
						<?php esc_html_e( 'Cancelar', 'au-wms' ); ?>
					</button>
					<button type="button" class="au-wms-btn au-wms-btn--primary" id="au-wms-usermeta-form-guardar">
						<?php esc_html_e( 'Guardar', 'au-wms' ); ?>
					</button>
				</div>
			</div>

		</div>
	</div>
</div>

<!-- Modal secundario: "Ver más" para meta_value largos -->
<div class="au-wms-modal-overlay" id="au-wms-usermeta-vermas-overlay">
	<div class="au-wms-modal">
		<div class="au-wms-modal-header">
			<h2><?php esc_html_e( 'Meta Value completo', 'au-wms' ); ?></h2>
			<button type="button" class="au-wms-modal-close" id="au-wms-usermeta-vermas-close" aria-label="<?php esc_attr_e( 'Cerrar', 'au-wms' ); ?>">
				&times;
			</button>
		</div>
		<div class="au-wms-modal-body">
			<pre class="au-wms-usermeta-vermas-content" id="au-wms-usermeta-vermas-content"></pre>
		</div>
	</div>
</div>

<!-- Plantilla de fila -->
<template id="au-wms-usermeta-row-template">
	<tr data-umeta-id="">
		<td class="au-wms-usermeta-key"></td>
		<td class="au-wms-usermeta-value-cell">
			<span class="au-wms-usermeta-value-text"></span>
			<button type="button" class="au-wms-usermeta-vermas-btn" style="display:none;">
				<?php esc_html_e( 'Ver más', 'au-wms' ); ?>
			</button>
		</td>
		<td>
			<div class="au-wms-usermeta-row-actions">
				<button type="button" class="au-wms-usermeta-editar" title="<?php esc_attr_e( 'Editar', 'au-wms' ); ?>">
					<span class="dashicons dashicons-edit"></span>
				</button>
				<button type="button" class="au-wms-usermeta-eliminar" title="<?php esc_attr_e( 'Eliminar', 'au-wms' ); ?>">
					<span class="dashicons dashicons-trash"></span>
				</button>
			</div>
		</td>
	</tr>
</template>

<!-- Plantilla de estado vacío -->
<template id="au-wms-usermeta-empty-template">
	<tr class="au-wms-row-empty">
		<td colspan="3">
			<div class="au-wms-empty-state">
				<span class="dashicons dashicons-editor-table"></span>
				<p><?php esc_html_e( 'Este usuario no tiene atributos personalizados registrados.', 'au-wms' ); ?></p>
			</div>
		</td>
	</tr>
</template>
