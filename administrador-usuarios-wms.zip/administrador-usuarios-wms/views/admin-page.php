<?php
/**
 * Vista principal: estructura de pestañas (Empresas, Integrantes,
 * Usuarios Externos).
 *
 * Variables disponibles: $empresas (array).
 *
 * @package Administrador_Usuarios_WMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="wrap au-wms-wrap">
	<div class="au-wms-topbar">
		<h1 class="au-wms-topbar-title">
			<span class="au-wms-topbar-logo" aria-hidden="true">
				<?php
				// En línea para que el logo tome el color del título por
				// `currentColor`. Es un asset propio del plugin.
				$au_wms_logo = AU_WMS_PLUGIN_DIR . 'assets/img/logo.svg';

				if ( file_exists( $au_wms_logo ) ) {
					echo file_get_contents( $au_wms_logo ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped, WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
				}
				?>
			</span>
			<span class="au-wms-topbar-title-text"><?php esc_html_e( 'Administrador de usuarios', 'au-wms' ); ?></span>
			<span class="au-wms-topbar-brand"><?php esc_html_e( 'WMS Latam', 'au-wms' ); ?></span>
		</h1>
		<nav class="au-wms-tabs" role="tablist">
			<button type="button" class="au-wms-tab is-active" data-tab="empresas" role="tab" aria-selected="true">
				<?php esc_html_e( 'Empresas', 'au-wms' ); ?>
				<span class="au-wms-tab-count" data-count-for="empresas" hidden></span>
			</button>
			<button type="button" class="au-wms-tab" data-tab="integrantes" role="tab" aria-selected="false">
				<?php esc_html_e( 'Integrantes', 'au-wms' ); ?>
				<span class="au-wms-tab-count" data-count-for="integrantes" hidden></span>
			</button>
			<button type="button" class="au-wms-tab" data-tab="usuarios-externos" role="tab" aria-selected="false">
				<?php esc_html_e( 'Usuarios Externos', 'au-wms' ); ?>
				<span class="au-wms-tab-count" data-count-for="usuarios-externos" hidden></span>
			</button>
		</nav>
	</div>
	<?php // WP inserta sus avisos (admin notices) justo después de este marcador. ?>
	<hr class="wp-header-end">

	<div class="au-wms-panels">
		<?php require AU_WMS_PLUGIN_DIR . 'views/tab-empresas.php'; ?>
		<?php require AU_WMS_PLUGIN_DIR . 'views/tab-integrantes.php'; ?>
		<?php require AU_WMS_PLUGIN_DIR . 'views/tab-usuarios-externos.php'; ?>
	</div>

	<?php // Modal "Ver WP_USERMETA": vive fuera de los paneles de tabs a
	// propósito. Cualquier tab (Empresas, Integrantes) puede abrirlo; si
	// estuviera anidado dentro de un panel con display:none, el modal
	// quedaría oculto aunque sea position:fixed, hasta cambiar de tab. ?>
	<?php require AU_WMS_PLUGIN_DIR . 'views/modal-usermeta.php'; ?>
	<?php require AU_WMS_PLUGIN_DIR . 'views/modal-licencias.php'; ?>
	<?php require AU_WMS_PLUGIN_DIR . 'views/modal-areas-empresa.php'; ?>
	<?php require AU_WMS_PLUGIN_DIR . 'views/modal-cambiar-licencia.php'; ?>
	<?php require AU_WMS_PLUGIN_DIR . 'views/modal-crear-empresa.php'; ?>
	<?php require AU_WMS_PLUGIN_DIR . 'views/modal-editar-empresa.php'; ?>
	<?php require AU_WMS_PLUGIN_DIR . 'views/modal-area-cursos.php'; ?>
	<?php require AU_WMS_PLUGIN_DIR . 'views/modal-areas-usuario.php'; ?>
	<?php require AU_WMS_PLUGIN_DIR . 'views/modal-editar-perfil.php'; ?>
	<?php require AU_WMS_PLUGIN_DIR . 'views/modal-borrado-masivo.php'; ?>
</div>
