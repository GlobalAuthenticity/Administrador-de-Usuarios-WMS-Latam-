<?php
/**
 * Tab "Integrantes" — módulo principal del plugin.
 *
 * Variables disponibles: $empresas (array de empresas para el filtro).
 *
 * @package Administrador_Usuarios_WMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<section id="au-wms-tab-integrantes" class="au-wms-panel" role="tabpanel" aria-labelledby="integrantes">

	<div class="au-wms-integrantes-toolbar">
		<?php
		// Comparte fila con "Opciones" (ver tab-empresas.php).
		$aviso_seccion = __( 'Aquí se muestran los usuarios que pertenecen al programa Liderazgo (WMS) y están vinculados a una o más áreas.', 'au-wms' );
		require AU_WMS_PLUGIN_DIR . 'views/partial-aviso-seccion.php';
		?>
		<button type="button" class="au-wms-btn au-wms-btn--danger" id="au-wms-btn-borrar-seleccionados" style="display:none;">
			<span class="dashicons dashicons-trash"></span>
			<?php esc_html_e( 'Borrar seleccionados', 'au-wms' ); ?>
			(<span id="au-wms-seleccionados-count">0</span>)
		</button>
		<div class="au-wms-toolbar-dropdown" id="au-wms-opciones-dropdown">
			<button type="button" class="au-wms-btn au-wms-btn--primary au-wms-toolbar-dropdown-btn" id="au-wms-btn-opciones">
				<span class="dashicons dashicons-admin-generic"></span>
				<?php esc_html_e( 'Opciones', 'au-wms' ); ?>
				<span class="dashicons dashicons-arrow-down-alt2"></span>
			</button>
			<div class="au-wms-toolbar-dropdown-menu">
				<button type="button" class="au-wms-toolbar-dropdown-item" id="au-wms-btn-importar">
					<span class="dashicons dashicons-upload"></span>
					<?php esc_html_e( 'Importar usuarios', 'au-wms' ); ?>
				</button>
				<button type="button" class="au-wms-toolbar-dropdown-item" id="au-wms-btn-mailupdate">
					<span class="dashicons dashicons-email-alt2"></span>
					<?php esc_html_e( 'Actualizar correos', 'au-wms' ); ?>
				</button>
			</div>
		</div>
	</div>

	<div class="au-wms-filters">
		<div class="au-wms-filter au-wms-filter--search">
			<label for="au-wms-search"><?php esc_html_e( 'Buscar', 'au-wms' ); ?></label>
			<div class="au-wms-search-row">
				<input
					type="text"
					id="au-wms-search"
					class="au-wms-input"
					placeholder="<?php esc_attr_e( 'Username, correo, nombre o apellido...', 'au-wms' ); ?>"
				/>
				<button type="button" class="au-wms-refresh-btn" id="au-wms-btn-refresh-integrantes" title="<?php esc_attr_e( 'Actualizar lista', 'au-wms' ); ?>">
					<span class="dashicons dashicons-update"></span>
				</button>
			</div>
		</div>

		<div class="au-wms-filter">
			<label for="au-wms-filter-empresa"><?php esc_html_e( 'Empresa', 'au-wms' ); ?></label>
			<select id="au-wms-filter-empresa" class="au-wms-select">
				<option value=""><?php esc_html_e( 'Todas las empresas', 'au-wms' ); ?></option>
				<?php foreach ( $empresas as $empresa ) : ?>
					<option value="<?php echo esc_attr( $empresa['id'] ); ?>">
						<?php echo esc_html( $empresa['nombre'] ); ?>
					</option>
				<?php endforeach; ?>
			</select>
		</div>

		<div class="au-wms-filter">
			<label for="au-wms-filter-area"><?php esc_html_e( 'Área / Paquete', 'au-wms' ); ?></label>
			<select id="au-wms-filter-area" class="au-wms-select" disabled>
				<option value=""><?php esc_html_e( 'Selecciona una empresa primero', 'au-wms' ); ?></option>
			</select>
		</div>

		<div class="au-wms-filter">
			<label for="au-wms-filter-test"><?php esc_html_e( 'Test', 'au-wms' ); ?></label>
			<select id="au-wms-filter-test" class="au-wms-select">
				<option value=""><?php esc_html_e( 'Todos', 'au-wms' ); ?></option>
				<option value="con_test"><?php esc_html_e( 'Han hecho el test', 'au-wms' ); ?></option>
				<option value="sin_test"><?php esc_html_e( 'No han hecho el test', 'au-wms' ); ?></option>
			</select>
		</div>

		<div class="au-wms-filter">
			<label for="au-wms-filter-programa"><?php esc_html_e( 'Programa', 'au-wms' ); ?></label>
			<select id="au-wms-filter-programa" class="au-wms-select">
				<option value=""><?php esc_html_e( 'Mostrar todos', 'au-wms' ); ?></option>
				<option value="inspira"><?php esc_html_e( 'Inspira', 'au-wms' ); ?></option>
				<option value="octagono"><?php esc_html_e( 'Octágono', 'au-wms' ); ?></option>
				<option value="todas"><?php esc_html_e( 'Todas', 'au-wms' ); ?></option>
				<option value="ninguna"><?php esc_html_e( 'Ninguna', 'au-wms' ); ?></option>
			</select>
		</div>

		<div class="au-wms-filter au-wms-filter--per-page">
			<label for="au-wms-per-page"><?php esc_html_e( 'Registros', 'au-wms' ); ?></label>
			<select id="au-wms-per-page" class="au-wms-select">
				<option value="10">10</option>
				<option value="25">25</option>
				<option value="50">50</option>
				<option value="100">100</option>
			</select>
		</div>
	</div>

	<div class="au-wms-table-wrapper">
		<table class="au-wms-table" id="au-wms-tabla-usuarios">
			<thead>
				<tr>
					<th class="au-wms-col-checkbox">
						<input type="checkbox" id="au-wms-select-all" title="<?php esc_attr_e( 'Seleccionar todos', 'au-wms' ); ?>" />
					</th>
					<th class="au-wms-col-usuario"><?php esc_html_e( 'Usuario', 'au-wms' ); ?></th>
					<th class="au-wms-col-asignacion"><?php esc_html_e( 'Asignación', 'au-wms' ); ?></th>
					<th class="au-wms-col-test"><?php esc_html_e( 'Test', 'au-wms' ); ?></th>
					<th class="au-wms-col-programas"><?php esc_html_e( 'Programas', 'au-wms' ); ?></th>
					<th class="au-wms-col-acciones"><?php esc_html_e( 'Acciones', 'au-wms' ); ?></th>
				</tr>
			</thead>
			<tbody id="au-wms-tabla-body">
				<tr class="au-wms-row-loading">
					<td colspan="6">
						<div class="au-wms-spinner"></div>
						<?php esc_html_e( 'Cargando...', 'au-wms' ); ?>
					</td>
				</tr>
			</tbody>
		</table>
	</div>

	<div class="au-wms-pagination" id="au-wms-pagination">
		<div class="au-wms-pagination-info">
			<span id="au-wms-total-registros">0</span>
			<?php esc_html_e( 'registros', 'au-wms' ); ?>
		</div>
		<div class="au-wms-pagination-controls">
			<button type="button" class="au-wms-page-btn" data-page="first" title="<?php esc_attr_e( 'Primera página', 'au-wms' ); ?>">
				&laquo;
			</button>
			<button type="button" class="au-wms-page-btn" data-page="prev" title="<?php esc_attr_e( 'Anterior', 'au-wms' ); ?>">
				&lsaquo;
			</button>
			<span class="au-wms-pagination-current">
				<?php esc_html_e( 'Página', 'au-wms' ); ?>
				<span id="au-wms-current-page">1</span>
				<?php esc_html_e( 'de', 'au-wms' ); ?>
				<span id="au-wms-total-pages">1</span>
			</span>
			<button type="button" class="au-wms-page-btn" data-page="next" title="<?php esc_attr_e( 'Siguiente', 'au-wms' ); ?>">
				&rsaquo;
			</button>
			<button type="button" class="au-wms-page-btn" data-page="last" title="<?php esc_attr_e( 'Última página', 'au-wms' ); ?>">
				&raquo;
			</button>
		</div>
	</div>

	<!-- Plantilla para una fila de la tabla (usada por JS con clonado de nodo). -->
	<template id="au-wms-row-template">
		<tr data-user-id="">
			<td class="au-wms-col-checkbox">
				<input type="checkbox" class="au-wms-row-checkbox" />
			</td>
			<td class="au-wms-col-usuario">
				<div class="au-wms-user-meta-line">
					<span class="au-wms-user-id"></span>
					<span class="au-wms-user-date"></span>
				</div>
				<div class="au-wms-user-name"></div>
				<div class="au-wms-user-email"></div>
				<div class="au-wms-user-badges">
					<span class="au-wms-user-empresa-badge"></span>
					<span class="au-wms-user-importado-badge"></span>
					<span class="au-wms-user-acceso-badge"></span>
					<span class="au-wms-user-perfil-badge"></span>
				</div>
			</td>
			<td class="au-wms-col-asignacion">
				<div class="au-wms-asignacion-item">
					<span class="au-wms-asignacion-label"><?php esc_html_e( 'Área', 'au-wms' ); ?></span>
					<div class="au-wms-area-lista"></div>
				</div>
				<div class="au-wms-asignacion-item">
					<span class="au-wms-asignacion-label"><?php esc_html_e( 'Rol', 'au-wms' ); ?></span>
					<span class="au-wms-role-badge"></span>
				</div>
			</td>
			<td class="au-wms-col-test">
				<span class="au-wms-test-badge"></span>
				<button type="button" class="au-wms-descargar-resultado" style="display:none;">
					<span class="dashicons dashicons-download" aria-hidden="true"></span>
					<span class="au-wms-descargar-resultado-texto"></span>
				</button>
			</td>
			<td class="au-wms-col-programas">
				<div class="au-wms-programas-badges"></div>
			</td>
			<td class="au-wms-col-acciones">
				<div class="au-wms-actions-dropdown">
					<button type="button" class="au-wms-actions-btn">
						<?php esc_html_e( 'Acciones', 'au-wms' ); ?>
						<span class="dashicons dashicons-arrow-down-alt2"></span>
					</button>
					<div class="au-wms-actions-menu">
						<button type="button" class="au-wms-action-login" data-action="login">
							<span class="dashicons dashicons-admin-users"></span>
							<?php esc_html_e( 'Iniciar sesión como usuario', 'au-wms' ); ?>
						</button>

						<div class="au-wms-actions-menu-divider"></div>

						<div class="au-wms-actions-submenu">
							<button type="button" class="au-wms-actions-submenu-trigger">
								<span class="dashicons dashicons-id"></span>
								<?php esc_html_e( 'Datos del usuario', 'au-wms' ); ?>
								<span class="dashicons dashicons-arrow-right-alt2 au-wms-actions-submenu-arrow"></span>
							</button>
							<div class="au-wms-actions-submenu-panel">
								<button type="button" class="au-wms-action-editar-perfil" data-action="editar-perfil">
									<span class="dashicons dashicons-id-alt"></span>
									<?php esc_html_e( 'Editar perfil de usuario', 'au-wms' ); ?>
								</button>
								<button type="button" class="au-wms-action-areas-usuario" data-action="areas-usuario">
									<span class="dashicons dashicons-category"></span>
									<?php esc_html_e( 'Áreas del usuario', 'au-wms' ); ?>
								</button>
								<button type="button" class="au-wms-action-refrescar-programas" data-action="refrescar-programas">
									<span class="dashicons dashicons-update"></span>
									<?php esc_html_e( 'Refrescar programas', 'au-wms' ); ?>
								</button>
								<button type="button" class="au-wms-action-usermeta" data-action="usermeta">
									<span class="dashicons dashicons-editor-table"></span>
									<?php esc_html_e( 'Ver WP_USERMETA', 'au-wms' ); ?>
								</button>
							</div>
						</div>

						<div class="au-wms-actions-submenu">
							<button type="button" class="au-wms-actions-submenu-trigger">
								<span class="dashicons dashicons-admin-network"></span>
								<?php esc_html_e( 'Cuenta y acceso', 'au-wms' ); ?>
								<span class="dashicons dashicons-arrow-right-alt2 au-wms-actions-submenu-arrow"></span>
							</button>
							<div class="au-wms-actions-submenu-panel">
								<button type="button" class="au-wms-action-cambiar-correo" data-action="cambiar-correo">
									<span class="dashicons dashicons-email-alt"></span>
									<?php esc_html_e( 'Cambiar correo', 'au-wms' ); ?>
								</button>
								<button type="button" class="au-wms-action-cambiar-password" data-action="cambiar-password">
									<span class="dashicons dashicons-admin-network"></span>
									<?php esc_html_e( 'Cambiar Contraseña', 'au-wms' ); ?>
								</button>
								<button type="button" class="au-wms-action-toggle-acceso" data-action="toggle-acceso">
									<span class="dashicons dashicons-lock"></span>
									<span class="au-wms-action-toggle-acceso-texto"></span>
								</button>
							</div>
						</div>

						<div class="au-wms-actions-menu-divider"></div>

						<button type="button" class="au-wms-action-delete" data-action="delete">
							<span class="dashicons dashicons-trash"></span>
							<?php esc_html_e( 'Borrar usuario', 'au-wms' ); ?>
						</button>
					</div>
				</div>
			</td>
		</tr>
	</template>

	<!-- Plantilla de estado vacío. -->
	<template id="au-wms-empty-template">
		<tr class="au-wms-row-empty">
			<td colspan="6">
				<div class="au-wms-empty-state">
					<span class="dashicons dashicons-search"></span>
					<p><?php esc_html_e( 'No se encontraron usuarios con los filtros seleccionados.', 'au-wms' ); ?></p>
				</div>
			</td>
		</tr>
	</template>

	<?php require AU_WMS_PLUGIN_DIR . 'views/modal-importar.php'; ?>
	<?php require AU_WMS_PLUGIN_DIR . 'views/modal-actualizar-correos.php'; ?>

</section>
