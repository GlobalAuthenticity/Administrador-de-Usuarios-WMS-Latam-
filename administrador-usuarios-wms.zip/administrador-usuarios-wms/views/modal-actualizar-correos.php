<?php
/**
 * Modal "Actualizar correos" — asistente de actualización masiva de
 * correos electrónicos (Tab Integrantes).
 *
 * @package Administrador_Usuarios_WMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="au-wms-modal-overlay" id="au-wms-mailupdate-overlay">
	<div class="au-wms-modal au-wms-modal--wide" role="dialog" aria-modal="true" aria-labelledby="au-wms-mailupdate-title">

		<div class="au-wms-modal-header">
			<h2 id="au-wms-mailupdate-title"><?php esc_html_e( 'Actualizar correos', 'au-wms' ); ?></h2>
			<button type="button" class="au-wms-modal-close" id="au-wms-mailupdate-close" aria-label="<?php esc_attr_e( 'Cerrar', 'au-wms' ); ?>">
				&times;
			</button>
		</div>

		<div class="au-wms-import-steps">
			<span class="au-wms-import-step-dot is-active" data-step="1">1</span>
			<span class="au-wms-import-step-dot" data-step="2">2</span>
			<span class="au-wms-import-step-dot" data-step="3">3</span>
		</div>

		<div class="au-wms-modal-body">

			<!-- Paso 1: Subida de archivo + selección de columnas -->
			<div class="au-wms-import-panel is-active" data-step-panel="1">
				<div class="au-wms-import-dropzone" id="au-wms-mailupdate-dropzone">
					<span class="dashicons dashicons-media-spreadsheet"></span>
					<p><?php esc_html_e( 'Arrastra tu archivo aquí o haz clic para seleccionarlo', 'au-wms' ); ?></p>
					<span class="au-wms-import-dropzone-hint">XLS, XLSX</span>
					<input type="file" id="au-wms-mailupdate-file-input" accept=".xls,.xlsx" hidden />
				</div>
				<div class="au-wms-import-file-selected" id="au-wms-mailupdate-file-selected" style="display:none;">
					<span class="dashicons dashicons-media-spreadsheet"></span>
					<span id="au-wms-mailupdate-file-name"></span>
					<button type="button" class="au-wms-import-file-remove" id="au-wms-mailupdate-file-remove">&times;</button>
				</div>

				<div class="au-wms-mailupdate-columnas" id="au-wms-mailupdate-columnas" style="display:none;">
					<div class="au-wms-filter" style="margin-top: 18px;">
						<label for="au-wms-mailupdate-col-actual"><?php esc_html_e( 'Correo actual (correo registrado actualmente en WordPress)', 'au-wms' ); ?></label>
						<select id="au-wms-mailupdate-col-actual" class="au-wms-select">
							<option value=""><?php esc_html_e( '— Selecciona una columna —', 'au-wms' ); ?></option>
						</select>
					</div>

					<div class="au-wms-filter" style="margin-top: 14px;">
						<label for="au-wms-mailupdate-col-nuevo"><?php esc_html_e( 'Correo nuevo (correo al que será actualizado)', 'au-wms' ); ?></label>
						<select id="au-wms-mailupdate-col-nuevo" class="au-wms-select">
							<option value=""><?php esc_html_e( '— Selecciona una columna —', 'au-wms' ); ?></option>
						</select>
					</div>
				</div>
			</div>

			<!-- Paso 2: Validación previa -->
			<div class="au-wms-import-panel" data-step-panel="2">
				<div class="au-wms-import-summary" id="au-wms-mailupdate-summary"></div>

				<div class="au-wms-table-wrapper">
					<table class="au-wms-table" id="au-wms-mailupdate-preview-table">
						<thead>
							<tr>
								<th><?php esc_html_e( 'Correo actual', 'au-wms' ); ?></th>
								<th><?php esc_html_e( 'Correo nuevo', 'au-wms' ); ?></th>
								<th><?php esc_html_e( 'Estado', 'au-wms' ); ?></th>
								<th><?php esc_html_e( 'Observaciones', 'au-wms' ); ?></th>
							</tr>
						</thead>
						<tbody id="au-wms-mailupdate-preview-body"></tbody>
					</table>
				</div>

				<div class="au-wms-mailupdate-checkbox-row">
					<label>
						<input type="checkbox" id="au-wms-mailupdate-generar-password" />
						<?php esc_html_e( 'Generar una nueva contraseña y notificar al usuario por correo después de actualizar el correo electrónico.', 'au-wms' ); ?>
					</label>
				</div>
			</div>

			<!-- Paso 3: Progreso y resultados -->
			<div class="au-wms-import-panel" data-step-panel="3">
				<div class="au-wms-import-progress">
					<div class="au-wms-import-progress-bar">
						<div class="au-wms-import-progress-fill" id="au-wms-mailupdate-progress-fill"></div>
					</div>
					<p id="au-wms-mailupdate-progress-current" class="au-wms-import-progress-current"></p>
					<p id="au-wms-mailupdate-progress-text">0 / 0</p>
				</div>

				<div id="au-wms-mailupdate-final-summary" style="display:none;"></div>

				<div class="au-wms-table-wrapper" id="au-wms-mailupdate-final-table-wrapper" style="display:none;">
					<table class="au-wms-table">
						<thead>
							<tr>
								<th><?php esc_html_e( 'Correo anterior', 'au-wms' ); ?></th>
								<th><?php esc_html_e( 'Correo nuevo', 'au-wms' ); ?></th>
								<th><?php esc_html_e( 'Resultado', 'au-wms' ); ?></th>
							</tr>
						</thead>
						<tbody id="au-wms-mailupdate-final-table-body"></tbody>
					</table>
				</div>
			</div>

		</div>

		<div class="au-wms-modal-footer">
			<button type="button" class="au-wms-btn au-wms-btn--secondary" id="au-wms-mailupdate-btn-atras" style="display:none;">
				<?php esc_html_e( 'Atrás', 'au-wms' ); ?>
			</button>
			<button type="button" class="au-wms-btn au-wms-btn--secondary" id="au-wms-mailupdate-btn-cancelar">
				<?php esc_html_e( 'Cancelar', 'au-wms' ); ?>
			</button>
			<button type="button" class="au-wms-btn au-wms-btn--primary" id="au-wms-mailupdate-btn-siguiente" disabled>
				<?php esc_html_e( 'Siguiente', 'au-wms' ); ?>
			</button>
			<button type="button" class="au-wms-btn au-wms-btn--primary" id="au-wms-mailupdate-btn-actualizar" style="display:none;" disabled>
				<?php esc_html_e( 'Actualizar correos', 'au-wms' ); ?>
			</button>
			<button type="button" class="au-wms-btn au-wms-btn--primary" id="au-wms-mailupdate-btn-finalizar" style="display:none;">
				<?php esc_html_e( 'Finalizar', 'au-wms' ); ?>
			</button>
		</div>

	</div>
</div>
